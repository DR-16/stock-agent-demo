"""Q12 - the texts of the synthetic-data demo, shared by the browser demo (browser/entry.py) and the local workbench's demo mode
(workbench/oneclick.py), so both say the same thing about what a demo report is and is not."""
from __future__ import annotations

DEMO_LIMITS = [
    "演示:公司、价格、财报、公告和内部人交易申报都是合成的;不对应任何真实公司,也不是最新数据。",
    "没有经过金融有效性验证,不是投资建议,不提供买卖信号。",
    "技术面、宏观是生产在用的规则模型(原样调用),它们的“偏强 / 偏弱 / 偏负面”是规则读法,未经验证;宏观描述市场环境,不针对这家公司。",
    "基本面、估值、公告是实验版本,生产中未激活。",
    "公告事件由规则从原文抽取,是待核实的线索;系统不能确定的放在“需要核实”。内部人交易按申报原样列出。",
    "估值倍数用最近一个财年的年报数字,不是最近四个季度;没有参考区间,不判断贵或便宜。",
    "没有找到事件不等于没有事件;没有触发规则不等于没有风险。",
]


def demo_notice(name, as_of) -> str:
    return (f"演示数据:{name} 是合成公司,价格、财报和公告都是为演示编写的,截止日 {str(as_of)[:10]}。"
            "不是任何真实公司的最新分析,也不是投资建议。")
