"""(CORRECTNESS 002: derived from 001 shared/output.py; output contract te-output-1.1.0, input contract te-input-1.1.0; R-07 removes CLAIM_VERIFIED.)
The common experimental output contract (Track D) and the registry of result codes. Every code an expert emits is registered here with a
plain-language meaning; an unregistered code is a defect (the tests check it).

The contract keeps five questions apart: did the calculation succeed, are the data adequate, is the evidence sufficient, is a financial
interpretation supported, and is predictive validity demonstrated. The last one is always False in this stage; no field carries a probability or a
score, and meta_eligibility is always NOT_ELIGIBLE.
"""
from __future__ import annotations

import hashlib
import json

OUTPUT_CONTRACT_VERSION = "te-output-1.1.0"
INPUT_CONTRACT_VERSION = "te-input-1.1.0"

CODES = {
    # ---- strict input (shared)
    "JSON_NOT_TEXT": "the input is not text",
    "JSON_BOM": "a byte-order mark is refused",
    "JSON_TOO_LARGE": "the input is larger than the contract allows",
    "JSON_INVALID": "the input is not valid JSON",
    "JSON_DUPLICATE_KEY": "a key appears twice in one object; neither value is used",
    "JSON_NON_FINITE_LITERAL": "NaN or Infinity is not a number in this contract",
    "JSON_NUMBER_OVERFLOW": "a number overflows to infinity",
    "JSON_TOO_DEEP": "the input is nested deeper than the contract allows",
    "UNKNOWN_FIELD": "a field that the contract does not define (it is refused, not ignored)",
    "REQUIRED_FIELD_MISSING": "a required field is missing",
    "NULL_NOT_ALLOWED": "null is not allowed for this field",
    "TYPE_OBJECT_EXPECTED": "an object was expected",
    "TYPE_ARRAY_EXPECTED": "a list was expected",
    "TYPE_STRING_EXPECTED": "a text value was expected",
    "TYPE_NUMBER_EXPECTED": "a finite number was expected (true/false, text and NaN are not numbers)",
    "TYPE_INTEGER_EXPECTED": "a whole number was expected",
    "TYPE_BOOLEAN_EXPECTED": "true or false was expected",
    "ARRAY_TOO_SHORT": "the list has fewer entries than required",
    "ARRAY_TOO_LONG": "the list has more entries than allowed",
    "STRING_TOO_SHORT": "the text is shorter than required",
    "STRING_TOO_LONG": "the text is longer than allowed",
    "VALUE_NOT_ALLOWED": "the value is not one of the allowed values",
    "NUMBER_BELOW_MIN": "the number is below the allowed range",
    "NUMBER_ABOVE_MAX": "the number is above the allowed range",
    "DATE_INVALID": "not a real calendar date in YYYY-MM-DD form",
    "DATETIME_INVALID_OR_WITHOUT_TIMEZONE": "a timestamp must be ISO-8601 with a time zone; none is guessed",
    "DATA_SOURCE_NOT_SYNTHETIC": "only synthetic inputs (and, in Q9, PUBLIC_SOURCE_INTERNAL_TEST inputs) are accepted in this stage",
    "SECTION_ABSENT": "the fixture has no input for this expert",
    "INTERNAL_ERROR": "an unexpected error inside the expert; no result is given",
    # ---- fixtures and loading
    "FIXTURE_UNKNOWN": "the fixture is not in the registry of approved synthetic fixtures",
    "FIXTURE_PATH_REFUSED": "the registry entry points outside the fixture directory, through a link, or to a non-JSON file",
    "FIXTURE_HASH_MISMATCH": "the fixture file does not match the hash recorded in the registry",
    "FIXTURE_NOT_UTF8": "the fixture file is not valid UTF-8",
    "PRICE_DATASET_SECURITY_MISMATCH": "the price dataset is for a different security than the fixture's issuer",
    "PRICE_DATASET_AS_OF_MISMATCH": "the price dataset's as-of date is not the fixture's as-of date",
    "NO_PRICE_DATASET": "the fixture names no price dataset, so Technical and Macro are not run",
    # ---- time
    "FUTURE_PERIOD_EXCLUDED": "a statement period that became available after as_of is excluded",
    "PERIOD_END_AFTER_AS_OF": "a statement period that ends after as_of is excluded",
    "AVAILABILITY_TIMESTAMP_MISSING": "no availability time: the item cannot be shown to be known at as_of and is excluded",
    "AVAILABILITY_BEFORE_PERIOD_END": "the stated availability time is before the period it reports on ended; the item is excluded",
    # ---- fundamental
    "CURRENCY_MISMATCH": "values in different currencies; nothing is converted, the comparison is refused",
    "SCALE_NORMALIZED": "a declared scale (thousands, millions, billions) was converted to units; the values are unchanged",
    "DUPLICATE_PERIOD_IDENTICAL": "an identical duplicate period was removed (recorded)",
    "DUPLICATE_PERIOD_CONFLICT": "two different statements for the same fiscal year; the input is refused",
    "PERIODS_REORDERED": "periods were put in fiscal-year order (recorded)",
    "NO_USABLE_PERIOD": "no statement period is usable at as_of",
    "NEGATIVE_VALUE_INVALID": "a value that cannot be negative is negative; that value is not used",
    "GROSS_PROFIT_IDENTITY_MISMATCH": "gross profit differs from revenue minus cost of revenue by more than the tolerance",
    "BALANCE_SHEET_IDENTITY_MISMATCH": "total assets differ from liabilities plus equity by more than the tolerance",
    "NET_INCOME_ABOVE_REVENUE": "net income above revenue is unusual and is flagged for review",
    "NON_CONSECUTIVE_YEARS": "fiscal years are not consecutive; growth across the gap is not computed",
    "DENOMINATOR_ZERO": "the denominator is zero; the ratio is unavailable",
    "DENOMINATOR_NEGATIVE": "the denominator is negative; the ratio is not meaningful and is unavailable",
    "INPUT_UNAVAILABLE": "a required input is not supplied; the metric is unavailable",
    "NEGATIVE_EQUITY": "equity is negative; equity-based ratios are unavailable",
    # ---- valuation
    "FORECAST_INPUT_NOT_ACCEPTED": "analyst forecasts are not accepted: no qualified source exists; forward P/E and PEG stay unavailable",
    "FORWARD_METHOD_UNAVAILABLE": "the method needs forecast data that this prototype does not have",
    "PRICE_AFTER_AS_OF": "the market price is dated after as_of",
    "FINANCIALS_AFTER_AS_OF": "the financial data became available after as_of",
    "SHARE_COUNT_MISSING": "no share count: per-share values cannot be computed",
    "DEBT_OR_CASH_MISSING": "debt or cash is missing: enterprise value and equity bridges cannot be computed",
    "NEGATIVE_EARNINGS": "earnings are zero or negative: P/E is not meaningful",
    "NEGATIVE_BOOK_VALUE": "book value is zero or negative: P/B is not meaningful",
    "NEGATIVE_EBITDA": "EBITDA is zero or negative: EV/EBITDA is not meaningful",
    "NEGATIVE_BASE_FCF": "the starting free cash flow is zero or negative: a growth-based DCF is not meaningful",
    "INDUSTRY_NOT_APPLICABLE": "the method is not applicable to this industry class",
    "DISCOUNT_RATE_OUT_OF_BOUNDS": "the discount rate is outside the declared valid range",
    "TERMINAL_GROWTH_OUT_OF_BOUNDS": "the terminal growth is outside the declared valid range or too close to the discount rate",
    "GROWTH_OUT_OF_BOUNDS": "a stage growth rate is outside the declared valid range",
    "SCENARIO_ORDER_INCONSISTENT": "bear, base and bull assumptions are not ordered as their names say",
    "HIGH_ASSUMPTION_SENSITIVITY": "small assumption changes move the modelled value a lot",
    "TERMINAL_VALUE_DOMINANT": "most of the modelled value comes from the terminal value",
    "UNITS_IMPLAUSIBLE": "market value and fundamentals differ by an implausible factor: the units are probably inconsistent",
    "REFERENCE_MULTIPLE_RANGE_ABSENT": "no declared reference multiple range: only the observed multiple is shown, no implied value",
    "NO_APPLICABLE_METHOD": "no valuation method is applicable to the supplied data",
    # ---- information
    "DOCUMENT_ISSUER_MISMATCH": "the document is about another issuer and is not analysed",
    "DOCUMENT_CATEGORY_UNSUPPORTED": "the document category is not supported by this prototype",
    "DOCUMENT_EMPTY": "the document has no text",
    "DOCUMENT_AFTER_AS_OF": "the document became available after as_of and is excluded",
    "DOCUMENT_TIMESTAMP_AFTER_AVAILABILITY": "the document date is after its availability time; the timestamps are inconsistent",
    "DOCUMENT_DUPLICATE_IDENTICAL": "an identical duplicate document was removed (recorded)",
    "DOCUMENT_ID_CONFLICT": "two different documents share one id; both are excluded",
    "AMENDMENT_TARGET_UNKNOWN": "an amendment does not name the document it amends; supersession is not resolved",
    "AMENDMENT_TARGET_NOT_FOUND": "the amended document is not among the available documents",
    "SUPERSEDED_BY_AMENDMENT": "the document's events are superseded by an available amendment",
    "NO_SUPPORTED_EVENT": "the document contains no supported event",
    "EVENT_AMBIGUOUS": "an event is indicated but cannot be identified reliably: AMBIGUOUS",
    "EVENT_NOT_VERIFIABLE": "a statement cannot be verified from the document: NOT_VERIFIABLE",
    "EVENT_NEGATED": "the sentence negates the event; no event is extracted",
    "ITEM_NOT_INTERPRETED": "an 8-K item that this prototype records as present but does not interpret (broad item)",
    "CONTRADICTORY_EVIDENCE": "available documents state incompatible facts",
    "CITATION_FOUND": "the exact quoted text was found in an admissible source document (this says nothing about whether the claim is true)",
    "CITATION_NOT_FOUND": "the exact quoted text is not in the cited admissible document",
    "CITATION_NOT_EVALUATED": "the cited document is not admissible (excluded, not supplied or unavailable at as_of), so the citation was not looked up",
    # ---- Q4 (Information V2) additions; every earlier code keeps its meaning
    "SOURCE_NOT_FULLY_ASSESSED": "the citation is found and no contrary record exists, but an unresolved mention of a person named in the cited span exists in an eligible document: completeness / contradiction status cannot be established",
    "UNRESOLVED_MENTION": "an Item 5.02 clause names a person with a management word but resolves to no event, hazard or non-event class",
    "DATE_OWNERSHIP_AMBIGUOUS": "two different dates could belong to the event's clause; no date is assigned",
    "HISTORICAL_STATEMENT": "a relative clause about a past role ('who previously served as'), or a completed change dated by a bare year ('in 2018'); not an event",
    "DISCLOSURE_TEMPLATE_NOT_EVENT": "an Item 5.02(d) disclosure template sentence ('There is no arrangement or understanding ... pursuant to which ... was selected'); it restates a selection and is not an event (Q10)",
    "DUPLICATE_EVENT_MERGED": "the same person, action, role and date stated again in another sentence of the same document: one event is kept, the other sentence is cited as a further mention (Q10)",
    "TITLE_ALREADY_HELD": "an 'appointment' to a title the same sentence says the person already holds: not a change, no event (Q11)",
    "DEPARTURE_IMPLIED_BY_SUCCESSION": "'X is to succeed Y as R': Y's departure from R is implied with the same date and modality; shown, marked ambiguous (Q11 0.4.5)",
    "OTHER_ITEM_SENTENCE_NOT_USED": "a sentence of Item 7.01 / 8.01 / the preamble is conditional, forward-looking, historical or about another company's change: no event is taken from it (Q11 0.4.4)",
    "PREVIOUSLY_REPORTED_EVENT": "the sentence restates an earlier report ('As previously reported, ...'): shown, marked ambiguous - it may not be a new change (Q11 0.4.3)",
    "NON_OFFICER_TRANSITION_ROLE": "the person stays with the company in a role that is not an officer or director title (an advisory / employee role after leaving a title): shown, marked ambiguous (Q11 0.4.3)",
    "ROLE_AT_ANOTHER_COMPANY": "a role at another company ('Chair of the Board of <another company>'): not a change at this issuer, no event (Q11)",
    "EVENT_FROM_OTHER_ITEM": "a change stated only in Item 7.01 / 8.01 or the Explanatory Note, of a person no Item 5.02 record covers: kept as an event with its section (Q11)",
    "UNRESOLVED_COVERED_BY_EVENT": "an unresolved-mention diagnostic whose every person is a shown event of the same sentence: not repeated (Q11)",
    "DATE_LINK_AMBIGUOUS": "a defined date term or another section gives more than one date for this change: no date is linked (Q11)",
    "COMMITTEE_LIST_SPLIT_UNDETERMINED": "a list of Board committees whose split into separate committees is not determined by the text: one ambiguous record (Q11)",
    "NON_FACTUAL_STATEMENT": "a departure or appointment stated in a non-factual context (denied, asked to, offered to, conditional, rumoured): not an event (Q5)",
    "PERSON_ROLE_PAIRING_UNDETERMINED": "several persons and several roles without 'respectively': the pairing is not stated, so no role is assigned (Q5)",
    "CITED_STATEMENT_NOT_ASSESSED": "the cited span states a management change that was not resolved into an unambiguous record (Q5 evidence completeness gate G5)",
    "RELATED_UNRESOLVED_EVIDENCE": "an unresolved statement about the same person (or the same role with an unknown person) exists (Q5 gate G6)",
    "RELATED_DATE_AMBIGUITY": "the same person and role have an invalid / unreadable date or disagreeing dates (Q5 gate G7)",
    "AMBIGUOUS_REFERENCE": "a pronoun whose referent is not a single named person; no event is asserted",
    "WITHIN_DOCUMENT_INCONSISTENCY": "one document states a departure and a continuation for the same person and role (not a contradiction between documents)",
    "DATE_DISAGREEMENT": "documents state different effective dates for the same appointment or departure (reported apart from section-4 contradictions)",
    "SOURCE_CURRENT": "the cited source is admissible and the quoted text is not part of a superseded or contradicted extraction",
    "SOURCE_SUPERSEDED": "the quoted text belongs to an extraction that a later amendment supersedes",
    "SOURCE_CONTRADICTED": "the quoted text belongs to an extraction that another available document contradicts",
    "SOURCE_EXCLUDED": "the cited document was excluded or rejected (issuer, category, time, duplicate, emptiness) and cannot support a claim",
    "SOURCE_NOT_SUPPLIED": "the cited document is not among the supplied documents",
    "CLAIM_SUPPORT_UNDETERMINED": "the citation exists, but whether the cited text supports the free-text claim is not determined by this prototype",
    "CLAIM_SUPPORT_NOT_ASSESSED": "there is no admissible citation, so claim support is not assessed",
    "TRUTH_NOT_DETERMINED": "the factual truth of a claim is never determined by this prototype",
    "GUIDANCE_ANALYSIS_UNAVAILABLE": "management guidance is not analysed: the task definition has unresolved blocking questions",
    "FORM4_ROW_INVALID": "a Form 4 transaction row is incomplete or invalid and is not used",
    "UNSUPPORTED_RESEARCH_REQUEST": "the requested kind of research is not supported by this prototype and is refused",
    "PERIOD_NOT_ANNUAL": "the statement period is not an annual period (350-380 days); it is excluded",
    "PRICE_BEFORE_FINANCIALS_AVAILABLE": "the price is dated before the financials became public; the multiple mixes two moments",
    "UNITS_PLAUSIBILITY_NOT_CHECKED": "no positive revenue or book value (or no market cap): unit plausibility could not be checked",
    "HORIZON_OUT_OF_BOUNDS": "the DCF horizon is outside the declared valid range",
    "NEGATIVE_FREE_CASH_FLOW": "free cash flow is zero or negative: the yield is shown as such and P/FCF is not meaningful",
    "AVAILABILITY_UNKNOWN_SEMANTICS": "a date-only or offset-less time: the instant is unknown, so the document is not used (no midnight, zone or filing date is assumed)",
    "AVAILABILITY_INVALID": "the availability time cannot be read",
    "DOCUMENT_DUPLICATE_CONTENT": "a document with another id but the same text and availability time; the first is kept (recorded)",
    "AMENDMENT_ORDER_INVALID": "the amended document is not available before its amendment; supersession is not resolved",
    "ROUTINE_ELECTION_EXCLUDED": "an annual-meeting election or re-election is not treated as a management change",
    "NON_ROUTINE_IN_ANNUAL_MEETING_SENTENCE": "an officer change stated in an annual-meeting sentence is kept (only Board-seat elections are routine)",
    "SECTION_SUPPRESSED": "wording inside a forward-looking, risk-factor or safe-harbor section is not interpreted",
    "NUMBER_NOT_REPRESENTABLE": "an integer too large to be represented safely (magnitude above 2**53); it is refused, never converted or clamped",
    "OBLIGATIONS_EXCEED_MODELED_EV": "net obligations (debt - cash) exceed the modelled enterprise value: equity value is negative and no per-share value is meaningful",
    "OBLIGATIONS_EQUAL_MODELED_EV": "net obligations equal the modelled enterprise value: equity value is zero and no per-share value is meaningful",
    "SENSITIVITY_RANGE_NOT_SHOWN": "the sensitivity grid contains cells without a meaningful per-share value, so no per-share range is shown",
    "SCENARIO_RANGE_NOT_SHOWN": "not every DCF scenario has a meaningful per-share value, so no scenario range is shown",
    "EQUITY_SIGN_CHANGES_ACROSS_GRID": "equity value changes sign across the sensitivity grid",
    "DUPLICATE_MATCH_MERGED": "two rules matched the same event in one sentence; one event is kept",
    "SEGMENTATION_AMBIGUOUS": "two different event matches overlap in one sentence and cannot be separated reliably; no event is extracted from them",
    "EFFECTIVE_DATE_INVALID": "the stated effective date is not a real calendar date; the event is AMBIGUOUS and no date is substituted",
    "EFFECTIVE_DATE_UNREADABLE": "the effective date is written in a form this prototype does not read; the event is AMBIGUOUS and no date is guessed",
    "DOCUMENT_PROCESSING_ERROR": "an unexpected error while processing this one document; it is excluded and every other document is still processed",
    "VALUE_NOT_REPRESENTABLE": "a ratio or multiple is not a representable finite number (an input is too small or too large); no value is given",
    "IMPLIED_EQUITY_NOT_POSITIVE": "the equity value implied by a declared multiple is not positive; no per-share value is given for that end of the range",
    "IDENTITY_NOT_CHECKED": "an accounting identity could not be checked because an input is missing; consistency is not asserted",
    "INDETERMINATE_RISK_CHECK": "a risk check could not be evaluated because an input is missing; its absence from the risk flags is not reassurance",
}


def sha256_of(o) -> str:
    b = json.dumps(o, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8") if not isinstance(o, (bytes, str)) else (o.encode("utf-8") if isinstance(o, str) else o)
    return hashlib.sha256(b).hexdigest()


def code(c: str, path: str = "", detail: str = "") -> dict:
    if c not in CODES:
        raise KeyError(f"unregistered result code {c}")
    return {"code": c, "meaning": CODES[c], "path": path, "detail": str(detail)[:240]}


def envelope(expert: str, version: str, analysis_type: str, research_status: str, as_of: str, provenance: dict) -> dict:
    return {
        "expert_name": expert,
        "prototype_version": version,
        "experimental": True,
        "execution_status": "NOT_RUN",
        "analysis_type": analysis_type,
        "research_status": research_status,
        "data_source": ((provenance or {}).get("fixture_provenance") or {}).get("kind") or "SYNTHETIC",   # Q9: what the input was, not a constant
        "data_status": {},
        "as_of": as_of,
        "input_provenance": provenance,
        "input_contract_version": INPUT_CONTRACT_VERSION,
        "output_contract_version": OUTPUT_CONTRACT_VERSION,
        "evidence": [],
        "counter_evidence": [],
        "findings": {},
        "confidence_basis": "",
        "warnings": [],
        "missing_dependencies": [],
        "abstentions": [],
        "calculation_or_extraction_trace": [],
        "questions": {"calculation_succeeded": False, "data_adequate": "NOT_ASSESSED", "evidence_sufficient": "NOT_ASSESSED",
                      "financial_interpretation_supported": "NOT_ASSESSED", "predictive_validity_demonstrated": False},
        "predictive_validation": "NOT_ESTABLISHED",
        "research_validation_status": "NOT_VALIDATED: Level 1 FUNCTIONAL_SYNTHETIC_PROTOTYPE target only; Level 2 RESEARCH_VALIDATION_ELIGIBLE not met",
        "meta_eligibility": "NOT_ELIGIBLE",
        "production_state_unchanged": True,
        "result_codes": [],
    }


def reject(env: dict, problems: list) -> dict:
    env["execution_status"] = "REJECTED_INPUT"
    env["result_codes"] = [code(p["code"], p.get("path", ""), p.get("detail", "")) for p in problems]
    env["questions"]["calculation_succeeded"] = False
    env["questions"]["data_adequate"] = "INADEQUATE"
    env["confidence_basis"] = "no result: the input was refused (see result_codes); nothing was calculated"
    return env
