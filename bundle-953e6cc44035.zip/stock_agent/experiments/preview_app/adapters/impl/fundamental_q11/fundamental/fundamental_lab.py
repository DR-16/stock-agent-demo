"""TE Fundamental laboratory, CORRECTNESS 002 (derived from 001 fundamental/fundamental_lab.py, sha24 f9c940225f4f3b7f1995e595). Experimental
prototype; synthetic statements only; descriptive accounting analysis, NOT a return prediction.

002 corrections: R-02 - point-in-time eligibility is applied BEFORE duplicate versions are compared, so a restatement that was not yet available at
as_of can no longer change or refuse the as_of analysis; versions that are both eligible and differ are still refused. R-06 - every descriptive flag
is 'TRUE' | 'FALSE' | 'UNKNOWN' | 'NOT_APPLICABLE'; a missing input is never read as a reassuring False, and risk checks that cannot be evaluated are
listed. R-15 - the deviation list below includes the interest-expense sign rule. Post-review fixes: each accounting identity is CONSISTENT,
MISMATCH or NOT_CHECKED, and 'consistent' is never said of an identity that could not be checked (review R-06); ratios are always finite (R-12).

Fundamental 0.1.0 stays a FROZEN_FAILED_REFERENCE_CANDIDATE (FOV2 NOT_ELIGIBLE_FOR_META_EXPERIMENT; research state WAIT_FOR_MORE_DATA) and is not
imported or changed. This module re-uses its accounting DEFINITIONS (read only): net margin = NI / revenue, FCF = OCF - capex, interest coverage =
operating income / interest expense, cash conversion OCF / NI only when NI > 0, ROIC = NOPAT / (debt + equity - cash), the Piotroski checklist.
It does NOT port the peer percentiles, the composite score, the signal, or the good / poor thresholds. Where 0.1.0 had hidden assumptions the
prototype makes them explicit: no 0.21 tax default (the effective rate comes from the statements or ROIC is unavailable), missing cash is never 0,
zero interest expense is its own state, multi-period metrics are paired by fiscal year and never by list position, CAGR uses the real number of years,
and a negative interest expense is refused (NEGATIVE_VALUE_INVALID) where 0.1.0 took abs(interest_expense).

Q5 isolated fix (Q4 review M-02): three computations bypassed ratio()'s finiteness check - the effective tax rate (income tax / pretax income), NOPAT
inside ROIC (operating income * (1 - effective tax rate)) and the Piotroski long-term debt / total assets. With a subnormal denominator they gave inf
(and inf inside a metric's inputs). Each is now NOT_MEANINGFUL / VALUE_NOT_REPRESENTABLE (the Piotroski criterion NOT_EVALUATED) instead. No other
formula, threshold or value is changed.

Classifications are descriptive (direction of change within declared dead bands, and definitional facts such as a loss or current liabilities above
current assets). "Adequate" is only assessed against assumptions the user supplies. Nothing here is a forward-return signal or a probability.
"""
from __future__ import annotations

import json
import math
import statistics
from datetime import date
from decimal import Decimal

from shared import output as O
from shared import schema
from shared.constants import (ANNUAL_PERIOD_DAYS, COMPLETENESS_NEEDS_MORE_DATA_BELOW, CURRENCIES, FUNDAMENTAL_REQUIRED_LATEST, GROWTH_FLAT_BAND, IDENTITY_TOLERANCE,
                              LEVERAGE_STABLE_BAND, MARGIN_STABLE_BAND, MAX_ABS_AMOUNT, REQUESTS, SCALES, applicability)

VERSION = "q5-fundamental-d 0.2.2-experimental+q11.3 (Q11.3 (second review N5): a margin / leverage check that cannot be evaluated although its inputs are present says why, a missing input stays named, ROIC names the missing input; Q11.2 (mid-round review FU-1..3): a revenue growth that is not meaningful for any reason (zero / negative / too small prior revenue) is NOT_MEANINGFUL, revenue_down compares the revenues for any sign, a risk check that cannot be evaluated although its inputs are present says why (RISK_CHECK_NOT_MEANINGFUL), ROIC with a pretax loss is NOT_MEANINGFUL, a flat revenue is neutral evidence, evidence numbers are written readably; Q11: a revenue growth that is not a finite number is NOT_MEANINGFUL with its code, never INSUFFICIENT_DATA; revenue_down compares the two revenues directly. Q10: margin-trend change checked for finiteness (Q5R5-01); evidence placement follows the margin classification; every deterioration indicator that is TRUE is in the counter evidence; Q9 input contract and wording kept; no metric, threshold or classification rule changed)"
AMT = {"type": "number", "min": -MAX_ABS_AMOUNT, "max": MAX_ABS_AMOUNT, "nullable": True}
INCOME = ("revenue", "cost_of_revenue", "gross_profit", "operating_income", "interest_expense", "pretax_income", "income_tax_expense", "net_income")
CASH = ("operating_cash_flow", "capex", "depreciation_amort")
BAL = ("total_assets", "total_liabilities", "stockholders_equity", "current_assets", "current_liabilities", "cash_and_equivalents", "long_term_debt", "short_term_debt")
NON_NEGATIVE = ("revenue", "cost_of_revenue", "interest_expense", "capex", "depreciation_amort", "total_assets", "total_liabilities", "current_assets", "current_liabilities",
                "cash_and_equivalents", "long_term_debt", "short_term_debt")
PERIOD = {"type": "object", "required": ["fiscal_year", "period_start", "period_end", "available_at", "currency", "scale"], "keys": {
    "fiscal_year": {"type": "integer", "min": 1900, "max": 2100}, "period_start": {"type": "date"}, "period_end": {"type": "date"},
    "available_at": {"type": "datetime", "nullable": True}, "currency": {"type": "string", "enum": list(CURRENCIES)}, "scale": {"type": "string", "enum": list(SCALES)},
    "source_document_id": {"type": "string", "min": 1, "max": 80},
    "income": {"type": "object", "keys": {k: AMT for k in INCOME}}, "cash_flow": {"type": "object", "keys": {k: AMT for k in CASH}},
    "balance": {"type": "object", "keys": {k: AMT for k in BAL}},
    "shares_outstanding": {"type": "number", "min": 0.000001, "max": 1e13, "nullable": True}, "shares_scale": {"type": "string", "enum": list(SCALES)}}}
SPEC = {"type": "object", "required": ["currency", "periods"], "keys": {
    "currency": {"type": "string", "enum": list(CURRENCIES)},
    "requests": {"type": "array", "max": 10, "items": {"type": "string", "enum": list(REQUESTS["fundamental"]["supported"] + REQUESTS["fundamental"]["unsupported"])}},
    "assumptions": {"type": "object", "keys": {"min_current_ratio": {"type": "number", "min": 0, "max": 100}, "max_debt_to_equity": {"type": "number", "min": 0, "max": 1000},
                                               "min_interest_coverage": {"type": "number", "min": -1000, "max": 1000}, "rationale": {"type": "string", "max": 500}}},
    "periods": {"type": "array", "min": 1, "max": 12, "items": PERIOD},
    "notes": {"type": "string", "max": 2000}}}


def metric(fy, value, status, formula, inputs, code=None, detail=""):
    return {"fiscal_year": fy, "value": value, "status": status, "formula": formula, "inputs": inputs,
            "code": O.code(code, "", detail) if code else None}


def ratio(fy, num, den, formula, names, allow_negative_den=False):
    inputs = {names[0]: num, names[1]: den}
    if num is None or den is None:
        return metric(fy, None, "MISSING", formula, inputs, "INPUT_UNAVAILABLE", ", ".join(n for n, x in zip(names, (num, den)) if x is None))
    if den == 0:
        return metric(fy, None, "NOT_MEANINGFUL", formula, inputs, "DENOMINATOR_ZERO", names[1])
    if den < 0 and not allow_negative_den:
        return metric(fy, None, "NOT_MEANINGFUL", formula, inputs, "DENOMINATOR_NEGATIVE", names[1])
    val = num / den
    if not math.isfinite(val):                                  # post-review R-12: never inf or nan
        return metric(fy, None, "NOT_MEANINGFUL", formula, inputs, "VALUE_NOT_REPRESENTABLE", f"{names[0]} / {names[1]}")
    return metric(fy, val, "COMPUTED", formula, inputs)


def _pct(x) -> str:
    """Q11.2 (review FU-3): a growth rate as a reader reads it - never '+inf%' or a 300-digit number"""
    if x is None or not math.isfinite(x):
        return "not a finite number"
    return f"{x:+.2%}" if abs(x) < 100 else f"{x:+.3g} (as a fraction; more than {100:.0f}x)"


def _num4(x) -> str:
    if x is None or not math.isfinite(x):
        return "not a finite number"
    return f"{x:.4f}" if abs(x) < 1e6 else f"{x:.4g}"


def _pp(x) -> str:
    if x is None or not math.isfinite(x) or not math.isfinite(x * 100):
        return "change not a finite number"
    return f"{x * 100:+.2f} pp" if abs(x) < 1e6 else f"{x * 100:+.3g} pp"


def _finite(x):
    """Q5 M-02: a value that is not finite is not a value"""
    return x if x is None or math.isfinite(x) else None


def not_applicable(fy, formula, industry, why):
    return metric(fy, None, "NOT_APPLICABLE", formula, {}, "INDUSTRY_NOT_APPLICABLE", f"{industry}: {why}")


def tri(x) -> str:
    """002 (R-06): a descriptive truth value; None (an input is missing) is UNKNOWN, never False"""
    return "UNKNOWN" if x is None else "TRUE" if x else "FALSE"


def _canon(p):
    return json.dumps(p, sort_keys=True)


PROVENANCE_KEYS = ("available_at", "source_document_id")       # Track D: when and where a statement was filed is not part of the statement


def _statement(p: dict) -> dict:
    """the statement content of a period - every amount in currency units as an exact decimal, the share count in units, the dates and the currency;
    availability and provenance excluded, so an identical refiling made at another time (or in another scale) compares equal"""
    k = Decimal(str(SCALES[p["scale"]]))
    out = {}
    for key, val in p.items():
        if key in PROVENANCE_KEYS or key in ("scale", "shares_scale", "shares_outstanding"):
            continue
        if isinstance(val, dict):
            for n, x in val.items():
                out[(key, n)] = Decimal(str(x)) * k if isinstance(x, (int, float)) and not isinstance(x, bool) else x
        else:
            out[key] = val
    sh = p.get("shares_outstanding")
    out["shares_outstanding_units"] = Decimal(str(sh)) * Decimal(str(SCALES[p.get("shares_scale", "UNITS")])) if sh is not None else None
    return out


def _same_statement(a: dict, b: dict) -> bool:
    sa, sb = _statement(a), _statement(b)
    return all(sa.get(key) == sb.get(key) for key in set(sa) | set(sb))


def _identity_mismatch(a: Decimal, b: Decimal) -> bool:
    """Track D (declared contract, exact): relative IDENTITY_TOLERANCE of the larger side, in exact decimal arithmetic of the supplied numbers; a difference
    equal to the tolerance is CONSISTENT, above it a MISMATCH; both sides zero is CONSISTENT"""
    if a == 0 and b == 0:
        return False
    return abs(a - b) > Decimal(str(IDENTITY_TOLERANCE)) * max(abs(a), abs(b))


def analyze(section: dict | None, common: dict) -> dict:
    prov = {"fixture_id": common["fixture_id"], "section": "fundamental", "section_sha256": O.sha256_of(section) if section is not None else None,
            "fixture_provenance": common["provenance"], "issuer_id": common["issuer"]["issuer_id"]}
    env = O.envelope("Fundamental", VERSION, "DESCRIPTIVE_FINANCIAL_ANALYSIS", "DESCRIPTIVE_ONLY", common["as_of"], prov)
    if section is None:
        env["result_codes"] = [O.code("SECTION_ABSENT", "$.fundamental")]
        env["confidence_basis"] = "not run: the fixture has no fundamental input"
        return env
    probs = schema.check(section, SPEC, "$.fundamental")
    if probs:
        return O.reject(env, probs)
    industry = common["issuer"]["industry_class"]
    as_of = schema.parse_datetime(common["as_of"])
    reqs = section.get("requests") or ["DESCRIPTIVE_FINANCIAL_CONDITION"]
    for q in reqs:
        if q in REQUESTS["fundamental"]["unsupported"]:
            env["abstentions"].append({"request": q, **O.code("UNSUPPORTED_RESEARCH_REQUEST", "$.fundamental.requests", q)})
    if "DESCRIPTIVE_FINANCIAL_CONDITION" not in reqs:
        env["execution_status"] = "NOT_RUN"
        env["confidence_basis"] = "not run: no supported fundamental request"
        return env
    cur = section["currency"]
    bad_cur = [p["fiscal_year"] for p in section["periods"] if p["currency"] != cur]
    if bad_cur:
        return O.reject(env, [{"code": "CURRENCY_MISMATCH", "path": "$.fundamental.periods", "detail": f"section currency {cur}; fiscal years in another currency: {bad_cur}"}])
    codes, trace, excluded = [], [], []
    # ---- 002 (R-02): point-in-time eligibility FIRST, then duplicate versions among the eligible ones only
    usable, seen = [], {}
    for i, p in enumerate(section["periods"]):
        fy = p["fiscal_year"]
        start, end = date.fromisoformat(p["period_start"]), date.fromisoformat(p["period_end"])
        why = None
        if p["available_at"] is None:
            why = ("AVAILABILITY_TIMESTAMP_MISSING", "no availability time")
        elif end > as_of.date():
            why = ("PERIOD_END_AFTER_AS_OF", f"period ends {p['period_end']}")
        elif schema.parse_datetime(p["available_at"]) > as_of:
            why = ("FUTURE_PERIOD_EXCLUDED", f"available {p['available_at']}")
        elif schema.parse_datetime(p["available_at"]).date() < end:
            why = ("AVAILABILITY_BEFORE_PERIOD_END", f"available {p['available_at']} before period end {p['period_end']}")
        elif not ANNUAL_PERIOD_DAYS[0] <= (end - start).days <= ANNUAL_PERIOD_DAYS[1]:
            why = ("PERIOD_NOT_ANNUAL", f"{(end - start).days} days")
        if why:
            excluded.append({"fiscal_year": fy, "index": i, **O.code(why[0], f"$.fundamental.periods[{i}]", why[1])})
            continue
        if fy in seen:
            if _same_statement(seen[fy], p):              # Track D: identical statement content, possibly refiled at another (valid) time
                earlier = schema.parse_datetime(p["available_at"]) < schema.parse_datetime(seen[fy]["available_at"])
                codes.append(O.code("DUPLICATE_PERIOD_IDENTICAL", f"$.fundamental.periods[{i}]",
                                    f"FY{fy}: the same statement available {seen[fy]['available_at']} and {p['available_at']}; the earliest availability is kept"))
                if earlier:
                    usable[next(j for j, u in enumerate(usable) if u is seen[fy])] = p
                    seen[fy] = p
                continue
            return O.reject(env, [{"code": "DUPLICATE_PERIOD_CONFLICT", "path": f"$.fundamental.periods[{i}]",
                                   "detail": f"two different statements for FY{fy}, both eligible at as_of"}])
        seen[fy] = p
        usable.append(p)
    if [p["fiscal_year"] for p in usable] != sorted(p["fiscal_year"] for p in usable):
        codes.append(O.code("PERIODS_REORDERED", "$.fundamental.periods", "periods put in fiscal-year order"))
    usable.sort(key=lambda p: p["fiscal_year"])
    env["findings"]["excluded_periods"] = excluded
    if not usable:
        env["execution_status"] = "COMPLETED_NO_RESULT"
        env["result_codes"] = codes + [O.code("NO_USABLE_PERIOD", "$.fundamental.periods")] + [{k: e[k] for k in ("code", "meaning", "path", "detail")} for e in excluded]
        env["questions"]["data_adequate"] = "INADEQUATE"
        env["confidence_basis"] = "no result: no statement period is usable at as_of"
        return env
    # ---- normalize to currency units, apply sign conventions
    scales = sorted({p["scale"] for p in usable})
    if scales != ["UNITS"]:
        codes.append(O.code("SCALE_NORMALIZED", "$.fundamental.periods", f"declared scales {scales} converted to {cur} units"))
    P = {}
    for p in usable:
        k = SCALES[p["scale"]]
        row = {}
        for grp, names in (("income", INCOME), ("cash_flow", CASH), ("balance", BAL)):
            for n in names:
                x = (p.get(grp) or {}).get(n)
                row[n] = x * k if x is not None else None
                row.setdefault("_dec", {})[n] = Decimal(str(x)) * Decimal(str(k)) if x is not None else None   # Track D: exact decimal for the identities
        for n in NON_NEGATIVE:
            if row[n] is not None and row[n] < 0:
                codes.append(O.code("NEGATIVE_VALUE_INVALID", f"$.fundamental.periods[FY{p['fiscal_year']}].{n}", f"{n} < 0 is not used"))
                row[n] = None
                row["_dec"][n] = None
        row["shares"] = p["shares_outstanding"] * SCALES[p.get("shares_scale", "UNITS")] if p.get("shares_outstanding") is not None else None
        row["_period_end"], row["_available_at"], row["_source"] = p["period_end"], p["available_at"], p.get("source_document_id")
        P[p["fiscal_year"]] = row
    years = sorted(P)
    latest = years[-1]
    prev = latest - 1 if latest - 1 in P else None
    # ---- per-period metrics
    M, identity_checks = {}, []
    for fy in years:
        r = P[fy]
        m = {}
        gp, gp_status = r["gross_profit"], "STATED"
        gp_check = "NOT_CHECKED"
        if r["revenue"] is not None and r["cost_of_revenue"] is not None:
            derived = r["revenue"] - r["cost_of_revenue"]
            if gp is None:
                gp, gp_status = derived, "DERIVED (revenue - cost_of_revenue)"
                gp_check = "NOT_CHECKED (gross profit derived, nothing to compare)"
            elif _identity_mismatch(r["_dec"]["gross_profit"], r["_dec"]["revenue"] - r["_dec"]["cost_of_revenue"]):
                codes.append(O.code("GROSS_PROFIT_IDENTITY_MISMATCH", f"FY{fy}", f"stated {gp:g} vs revenue - cost {derived:g}"))
                gp_check = "MISMATCH"
            else:
                gp_check = "CONSISTENT"
        if all(r[n] is not None for n in ("total_assets", "total_liabilities", "stockholders_equity")):
            side = r["total_liabilities"] + r["stockholders_equity"]
            if _identity_mismatch(r["_dec"]["total_assets"], r["_dec"]["total_liabilities"] + r["_dec"]["stockholders_equity"]):
                codes.append(O.code("BALANCE_SHEET_IDENTITY_MISMATCH", f"FY{fy}", f"assets {r['total_assets']:g} vs liabilities + equity {side:g}"))
                bs_check = "MISMATCH"
            else:
                bs_check = "CONSISTENT"
        else:
            bs_check = "NOT_CHECKED"
        identity_checks.append({"fiscal_year": fy, "gross_profit": gp_check if applicability("GROSS_MARGIN", industry)[0] != "NOT_APPLICABLE" else "NOT_APPLICABLE",
                                "balance_sheet": bs_check})
        if r["net_income"] is not None and r["revenue"] is not None and r["revenue"] > 0 and r["net_income"] > r["revenue"]:
            codes.append(O.code("NET_INCOME_ABOVE_REVENUE", f"FY{fy}"))
        app = applicability("GROSS_MARGIN", industry)
        m["gross_profit_used"] = {"value": gp, "status": gp_status if gp is not None else "MISSING"}
        m["gross_margin"] = not_applicable(fy, "gross_profit / revenue", industry, app[1]) if app[0] == "NOT_APPLICABLE" else \
            ratio(fy, gp, r["revenue"], "gross_profit / revenue", ("gross_profit", "revenue"))
        m["operating_margin"] = ratio(fy, r["operating_income"], r["revenue"], "operating_income / revenue", ("operating_income", "revenue"))
        m["net_margin"] = ratio(fy, r["net_income"], r["revenue"], "net_income / revenue", ("net_income", "revenue"))
        app = applicability("FREE_CASH_FLOW", industry)
        if app[0] == "NOT_APPLICABLE":
            m["free_cash_flow"] = not_applicable(fy, "operating_cash_flow - capex", industry, app[1])
            m["fcf_margin"] = not_applicable(fy, "free_cash_flow / revenue", industry, app[1])
        elif r["operating_cash_flow"] is None or r["capex"] is None:
            m["free_cash_flow"] = metric(fy, None, "MISSING", "operating_cash_flow - capex", {"operating_cash_flow": r["operating_cash_flow"], "capex": r["capex"]}, "INPUT_UNAVAILABLE")
            m["fcf_margin"] = metric(fy, None, "MISSING", "free_cash_flow / revenue", {}, "INPUT_UNAVAILABLE", "free_cash_flow")
        else:
            fcf = r["operating_cash_flow"] - r["capex"]
            m["free_cash_flow"] = metric(fy, fcf, "COMPUTED", "operating_cash_flow - capex (capex a positive outflow)", {"operating_cash_flow": r["operating_cash_flow"], "capex": r["capex"]})
            m["fcf_margin"] = ratio(fy, fcf, r["revenue"], "free_cash_flow / revenue", ("free_cash_flow", "revenue"))
        if r["net_income"] is not None and r["net_income"] <= 0:
            m["cash_conversion"] = metric(fy, None, "NOT_MEANINGFUL", "operating_cash_flow / net_income (only when net_income > 0)",
                                          {"operating_cash_flow": r["operating_cash_flow"], "net_income": r["net_income"]}, "DENOMINATOR_NEGATIVE" if r["net_income"] < 0 else "DENOMINATOR_ZERO", "net income <= 0")
        else:
            m["cash_conversion"] = ratio(fy, r["operating_cash_flow"], r["net_income"], "operating_cash_flow / net_income (only when net_income > 0)", ("operating_cash_flow", "net_income"))
        pr = P.get(fy - 1)
        avg_ta = (r["total_assets"] + pr["total_assets"]) / 2 if pr and r["total_assets"] is not None and pr["total_assets"] is not None else None
        acc_num = r["net_income"] - r["operating_cash_flow"] if r["net_income"] is not None and r["operating_cash_flow"] is not None else None
        m["accruals_ratio"] = ratio(fy, acc_num, avg_ta, "(net_income - operating_cash_flow) / average total assets (this and the prior fiscal year)",
                                    ("net_income - operating_cash_flow", "average_total_assets"))
        m["roa"] = ratio(fy, r["net_income"], avg_ta, "net_income / average total assets", ("net_income", "average_total_assets"))
        m["asset_turnover"] = ratio(fy, r["revenue"], avg_ta, "revenue / average total assets", ("revenue", "average_total_assets"))
        debt = r["long_term_debt"] + r["short_term_debt"] if r["long_term_debt"] is not None and r["short_term_debt"] is not None else None
        m["total_debt"] = metric(fy, debt, "COMPUTED" if debt is not None else "MISSING", "long_term_debt + short_term_debt",
                                 {"long_term_debt": r["long_term_debt"], "short_term_debt": r["short_term_debt"]}, None if debt is not None else "INPUT_UNAVAILABLE")
        eq = r["stockholders_equity"]
        if eq is not None and eq < 0:
            m["debt_to_equity"] = metric(fy, None, "NOT_MEANINGFUL", "total_debt / stockholders_equity", {"total_debt": debt, "stockholders_equity": eq}, "NEGATIVE_EQUITY")
            m["roe"] = metric(fy, None, "NOT_MEANINGFUL", "net_income / stockholders_equity", {"net_income": r["net_income"], "stockholders_equity": eq}, "NEGATIVE_EQUITY")
        else:
            m["debt_to_equity"] = ratio(fy, debt, eq, "total_debt / stockholders_equity", ("total_debt", "stockholders_equity"))
            m["roe"] = ratio(fy, r["net_income"], eq, "net_income / stockholders_equity (end of year)", ("net_income", "stockholders_equity"))
        m["liabilities_to_assets"] = ratio(fy, r["total_liabilities"], r["total_assets"], "total_liabilities / total_assets", ("total_liabilities", "total_assets"))
        m["net_debt"] = metric(fy, debt - r["cash_and_equivalents"] if debt is not None and r["cash_and_equivalents"] is not None else None,
                               "COMPUTED" if debt is not None and r["cash_and_equivalents"] is not None else "MISSING", "total_debt - cash_and_equivalents",
                               {"total_debt": debt, "cash_and_equivalents": r["cash_and_equivalents"]},
                               None if debt is not None and r["cash_and_equivalents"] is not None else "INPUT_UNAVAILABLE")
        app = applicability("CURRENT_RATIO", industry)
        if app[0] == "NOT_APPLICABLE":
            m["current_ratio"] = not_applicable(fy, "current_assets / current_liabilities", industry, app[1])
            m["cash_ratio"] = not_applicable(fy, "cash_and_equivalents / current_liabilities", industry, app[1])
        else:
            m["current_ratio"] = ratio(fy, r["current_assets"], r["current_liabilities"], "current_assets / current_liabilities", ("current_assets", "current_liabilities"))
            m["cash_ratio"] = ratio(fy, r["cash_and_equivalents"], r["current_liabilities"], "cash_and_equivalents / current_liabilities", ("cash_and_equivalents", "current_liabilities"))
        app = applicability("INTEREST_COVERAGE", industry)
        if app[0] == "NOT_APPLICABLE":
            m["interest_coverage"] = not_applicable(fy, "operating_income / interest_expense", industry, app[1])
        elif r["interest_expense"] == 0:
            m["interest_coverage"] = metric(fy, None, "NO_INTEREST_EXPENSE", "operating_income / interest_expense", {"operating_income": r["operating_income"], "interest_expense": 0.0},
                                            "DENOMINATOR_ZERO", "no interest expense reported: coverage is not a number (not the same as missing)")
        else:
            m["interest_coverage"] = ratio(fy, r["operating_income"], r["interest_expense"], "operating_income / interest_expense (a positive magnitude)", ("operating_income", "interest_expense"))
        if r["pretax_income"] is None or r["income_tax_expense"] is None:
            m["effective_tax_rate"] = metric(fy, None, "MISSING", "income_tax_expense / pretax_income", {"pretax_income": r["pretax_income"], "income_tax_expense": r["income_tax_expense"]}, "INPUT_UNAVAILABLE")
        elif r["pretax_income"] <= 0:
            m["effective_tax_rate"] = metric(fy, None, "NOT_MEANINGFUL", "income_tax_expense / pretax_income (only when pretax_income > 0)",
                                             {"pretax_income": r["pretax_income"], "income_tax_expense": r["income_tax_expense"]}, "DENOMINATOR_NEGATIVE" if r["pretax_income"] < 0 else "DENOMINATOR_ZERO")
        elif not math.isfinite(r["income_tax_expense"] / r["pretax_income"]):         # Q5 M-02
            m["effective_tax_rate"] = metric(fy, None, "NOT_MEANINGFUL", "income_tax_expense / pretax_income",
                                             {"pretax_income": r["pretax_income"], "income_tax_expense": r["income_tax_expense"]}, "VALUE_NOT_REPRESENTABLE",
                                             "income_tax_expense / pretax_income")
        else:
            m["effective_tax_rate"] = metric(fy, r["income_tax_expense"] / r["pretax_income"], "COMPUTED", "income_tax_expense / pretax_income",
                                             {"pretax_income": r["pretax_income"], "income_tax_expense": r["income_tax_expense"]})
        etr = m["effective_tax_rate"]["value"]
        invested = debt + eq - r["cash_and_equivalents"] if debt is not None and eq is not None and r["cash_and_equivalents"] is not None else None
        nopat = r["operating_income"] * (1 - etr) if r["operating_income"] is not None and etr is not None else None
        if m["effective_tax_rate"]["status"] == "NOT_MEANINGFUL" and (m["effective_tax_rate"].get("code") or {}).get("code") == "VALUE_NOT_REPRESENTABLE" \
                or (nopat is not None and not math.isfinite(nopat)):                  # Q5 M-02: never inf inside the metric or its inputs
            m["roic"] = metric(fy, None, "NOT_MEANINGFUL", "operating_income * (1 - effective_tax_rate) / (total_debt + equity - cash)",
                               {"operating_income": r["operating_income"], "effective_tax_rate": etr, "invested_capital": invested}, "VALUE_NOT_REPRESENTABLE",
                               "nopat")
        elif etr is None and m["effective_tax_rate"]["status"] == "NOT_MEANINGFUL" and r["operating_income"] is not None and invested is not None:
            m["roic"] = metric(fy, None, "NOT_MEANINGFUL", "operating_income * (1 - effective_tax_rate) / (total_debt + equity - cash)",       # Q11.2 (review FU-2)
                               {"operating_income": r["operating_income"], "effective_tax_rate": None, "invested_capital": invested},
                               (m["effective_tax_rate"].get("code") or {}).get("code") or "DENOMINATOR_NEGATIVE", "the effective tax rate is not meaningful (a pretax loss or zero pretax income)")
        elif r["operating_income"] is None or etr is None or invested is None:
            m["roic"] = metric(fy, None, "MISSING", "operating_income * (1 - effective_tax_rate) / (total_debt + equity - cash)",
                               {"operating_income": r["operating_income"], "effective_tax_rate": etr, "invested_capital": invested}, "INPUT_UNAVAILABLE",
                               "missing: " + ", ".join([n_ for n_, x_ in (("operating_income", r["operating_income"]), ("pretax_income / income_tax_expense (tax rate)", etr if m["effective_tax_rate"]["status"] != "NOT_MEANINGFUL" else 0),
                                                                          ("total_debt / stockholders_equity / cash_and_equivalents (invested capital)", invested)) if x_ is None])
                               + "; no tax-rate default is assumed (0.1.0 used 0.21)")       # Q11.3 (2nd review N5): the input that is actually missing
        else:
            m["roic"] = ratio(fy, nopat, invested, "operating_income * (1 - effective_tax_rate) / (total_debt + equity - cash)", ("nopat", "invested_capital"))
        M[fy] = m
    # ---- growth (paired by fiscal year; consecutive years only)
    growth = {}
    for fy in years:
        if fy - 1 not in P:
            growth[fy] = metric(fy, None, "NOT_AVAILABLE", "revenue[fy] / revenue[fy-1] - 1", {}, "NON_CONSECUTIVE_YEARS" if fy != years[0] else "INPUT_UNAVAILABLE",
                                "no prior fiscal year in the usable periods")
            continue
        a, b = P[fy]["revenue"], P[fy - 1]["revenue"]
        g = ratio(fy, a, b, "revenue[fy] / revenue[fy-1] - 1", ("revenue", "revenue_prior"))
        if g["value"] is not None:
            g["value"] -= 1.0
        growth[fy] = g
    run = [latest]
    while run[0] - 1 in P:
        run.insert(0, run[0] - 1)
    cagr = None
    if len(run) >= 3 and P[run[0]]["revenue"] and P[run[-1]]["revenue"] is not None and P[run[0]]["revenue"] > 0 and P[run[-1]]["revenue"] >= 0:
        yrs = run[-1] - run[0]
        try:
            cg = (P[run[-1]]["revenue"] / P[run[0]]["revenue"]) ** (1.0 / yrs) - 1.0
        except (OverflowError, ZeroDivisionError):
            cg = float("inf")
        cagr = metric(latest, cg, "COMPUTED", f"(revenue[FY{run[-1]}] / revenue[FY{run[0]}])^(1/{yrs}) - 1",
                      {"first": P[run[0]]["revenue"], "last": P[run[-1]]["revenue"], "years": yrs}) if math.isfinite(cg) else \
            metric(latest, None, "NOT_MEANINGFUL", "CAGR", {"consecutive_years": run}, "VALUE_NOT_REPRESENTABLE")
    else:
        cagr = metric(latest, None, "NOT_AVAILABLE", "CAGR over at least three consecutive fiscal years", {"consecutive_years": run}, "INPUT_UNAVAILABLE")
    gvals = [growth[fy]["value"] for fy in run[1:] if growth[fy]["value"] is not None]
    stability = {"growth_values": gvals, "population_stdev": statistics.pstdev(gvals) if len(gvals) >= 3 else None, "declines": sum(1 for x in gvals if x < 0),
                 "note": "descriptive statistics only; no stability class is assigned (no threshold is declared)"} if gvals else {"growth_values": [], "population_stdev": None, "declines": 0}
    # ---- Piotroski checklist (latest vs prior, both averages symmetric)
    pio = None
    if prev:
        L, Q, mL, mQ = P[latest], P[prev], M[latest], M[prev]

        def crit(name, cond_inputs, fn):
            vals = list(cond_inputs.values())
            if any(x is None for x in vals):
                return {"criterion": name, "met": None, "inputs": cond_inputs, "status": "NOT_EVALUATED (input unavailable)"}
            return {"criterion": name, "met": bool(fn(*vals)), "inputs": cond_inputs, "status": "EVALUATED"}
        ltd_ta = lambda r: _finite(r["long_term_debt"] / r["total_assets"]) if r["long_term_debt"] is not None and r["total_assets"] else None  # noqa: E731
        items = [crit("net income > 0", {"net_income": L["net_income"]}, lambda a: a > 0),
                 crit("operating cash flow > 0", {"operating_cash_flow": L["operating_cash_flow"]}, lambda a: a > 0),
                 crit("ROA up (net income / average total assets)", {"roa": mL["roa"]["value"], "roa_prior": mQ["roa"]["value"]}, lambda a, b: a > b),
                 crit("operating cash flow > net income", {"operating_cash_flow": L["operating_cash_flow"], "net_income": L["net_income"]}, lambda a, b: a > b),
                 crit("long-term debt / total assets down", {"ltd_ta": ltd_ta(L), "ltd_ta_prior": ltd_ta(Q)}, lambda a, b: a < b),
                 crit("current ratio up", {"current_ratio": mL["current_ratio"]["value"], "current_ratio_prior": mQ["current_ratio"]["value"]}, lambda a, b: a > b),
                 crit("no increase in shares", {"shares": L["shares"], "shares_prior": Q["shares"]}, lambda a, b: a <= b),
                 crit("gross margin up", {"gross_margin": mL["gross_margin"]["value"], "gross_margin_prior": mQ["gross_margin"]["value"]}, lambda a, b: a > b),
                 crit("asset turnover up", {"asset_turnover": mL["asset_turnover"]["value"], "asset_turnover_prior": mQ["asset_turnover"]["value"]}, lambda a, b: a > b)]
        pio = {"fiscal_year": latest, "against": prev, "criteria": items, "criteria_met": sum(1 for i in items if i["met"]), "criteria_evaluated": sum(1 for i in items if i["met"] is not None),
               "definition": "Piotroski (2000) checklist as in stock_agent/indicators.py, with ROA on average assets for both years and pairing by fiscal year",
               "note": "a descriptive checklist; not a return signal"}
    # ---- classifications (descriptive)
    mL = M[latest]
    v = lambda name, fy=latest: (M[fy][name]["value"] if fy in M else None)  # noqa: E731
    gL = growth[latest]["value"]
    g_code = (growth[latest].get("code") or {}).get("code")
    g_nm = gL is None and growth[latest]["status"] == "NOT_MEANINGFUL"         # Q11.2 (review FU-2): any reason - zero, negative or too small prior revenue
    if g_nm:                                     # Q11 (M-02 class on the growth path): both revenues are there, their ratio is not a meaningful number
        codes.append(O.code("VALUE_NOT_REPRESENTABLE" if g_code == "VALUE_NOT_REPRESENTABLE" else g_code or "DENOMINATOR_ZERO", "$.findings.financial_growth",
                            "revenue / prior revenue is not a meaningful finite number (prior revenue zero, negative or too small); no growth class is given"))
    fin_growth = {"classification": "NOT_MEANINGFUL" if g_nm else "INSUFFICIENT_DATA" if gL is None else "EXPANDING" if gL > GROWTH_FLAT_BAND else "CONTRACTING" if gL < -GROWTH_FLAT_BAND else "FLAT",
                  "latest_growth": gL, "growth_by_year": {fy: growth[fy]["value"] for fy in years}, "revenue_cagr": cagr, "revenue_stability": stability,
                  "rule": f"latest revenue growth vs a flat band of +/-{GROWTH_FLAT_BAND}"}

    def trend(name, band):
        a, b = v(name), v(name, prev) if prev else None
        if a is None or b is None:
            return {"classification": "INSUFFICIENT_DATA", "latest": a, "prior": b}
        d = a - b
        if not math.isfinite(d):                     # Q10 (Q5R5-01, M-02 class on the trend path): two finite margins whose difference is not a number
            codes.append(O.code("VALUE_NOT_REPRESENTABLE", f"$.findings.financial_profitability.{name}", "latest - prior is not a finite number; no trend is classified"))
            return {"classification": "NOT_MEANINGFUL", "latest": a, "prior": b, "band": band}
        return {"classification": "IMPROVING" if d > band else "DETERIORATING" if d < -band else "STABLE", "latest": a, "prior": b, "change": d, "band": band}
    prof = {"gross_margin": trend("gross_margin", MARGIN_STABLE_BAND), "operating_margin": trend("operating_margin", MARGIN_STABLE_BAND),
            "net_margin": trend("net_margin", MARGIN_STABLE_BAND), "loss_making": tri(None if P[latest]["net_income"] is None else P[latest]["net_income"] < 0),
            "operating_loss": tri(None if P[latest]["operating_income"] is None else P[latest]["operating_income"] < 0)}
    ni, ocf = P[latest]["net_income"], P[latest]["operating_cash_flow"]
    if ni is None or ocf is None:
        cfq = "INSUFFICIENT_DATA"
    elif ni > 0:
        cfq = "OCF_EXCEEDS_NET_INCOME" if ocf >= ni else "OCF_BELOW_NET_INCOME" if ocf > 0 else "EARNINGS_CASH_DIVERGENCE"
    else:
        cfq = "LOSS_WITH_POSITIVE_OCF" if ocf > 0 else "LOSS_AND_NEGATIVE_OCF"
    cash_q = {"classification": cfq, "operating_cash_flow": ocf, "net_income": ni, "free_cash_flow": v("free_cash_flow"), "cash_conversion": mL["cash_conversion"],
              "accruals_ratio": mL["accruals_ratio"]}
    de, de_p = v("debt_to_equity"), v("debt_to_equity", prev) if prev else None
    lev = "INSUFFICIENT_DATA" if de is None or de_p is None else "INCREASING" if de - de_p > LEVERAGE_STABLE_BAND else "DECREASING" if de - de_p < -LEVERAGE_STABLE_BAND else "STABLE"
    ca, cl = P[latest]["current_assets"], P[latest]["current_liabilities"]
    liq_fact = "NOT_APPLICABLE" if mL["current_ratio"]["status"] == "NOT_APPLICABLE" else "INSUFFICIENT_DATA" if ca is None or cl is None else \
        "CURRENT_ASSETS_COVER_CURRENT_LIABILITIES" if ca >= cl else "CURRENT_LIABILITIES_EXCEED_CURRENT_ASSETS"
    A = section.get("assumptions") or {}

    def vs(name, value, key, higher_ok):
        if key not in A:
            return {"assessment": "NOT_ASSESSED", "why": f"no '{key}' assumption supplied"}
        if value is None:
            return {"assessment": "INSUFFICIENT_DATA", "assumption": A[key]}
        ok = value >= A[key] if higher_ok else value <= A[key]
        return {"assessment": "WITHIN_USER_ASSUMPTION" if ok else "OUTSIDE_USER_ASSUMPTION", "value": value, "assumption": A[key], "source": "user-supplied assumption"}
    bsh = {"leverage_trend": lev, "debt_to_equity": mL["debt_to_equity"], "debt_to_equity_prior": de_p, "liabilities_to_assets": mL["liabilities_to_assets"],
           "net_debt": mL["net_debt"], "liquidity_fact": liq_fact, "current_ratio": mL["current_ratio"], "cash_ratio": mL["cash_ratio"],
           "interest_coverage": mL["interest_coverage"], "roic": mL["roic"], "roe": mL["roe"],
           "under_user_assumptions": {"liquidity": vs("current_ratio", v("current_ratio"), "min_current_ratio", True),
                                      "leverage": vs("debt_to_equity", de, "max_debt_to_equity", False),
                                      "interest_coverage": vs("interest_coverage", v("interest_coverage"), "min_interest_coverage", True)},
           "rule": f"leverage trend: change in debt / equity vs a band of +/-{LEVERAGE_STABLE_BAND}; liquidity fact: current assets vs current liabilities (definitional)"}
    risks = []
    flag = lambda f, ev: risks.append({"flag": f, "evidence": ev})  # noqa: E731
    if prof["loss_making"] == "TRUE":
        flag("LOSS_MAKING", f"net income {ni:g}")
    if ocf is not None and ocf < 0:
        flag("NEGATIVE_OPERATING_CASH_FLOW", f"operating cash flow {ocf:g}")
    if v("free_cash_flow") is not None and v("free_cash_flow") < 0:
        flag("NEGATIVE_FREE_CASH_FLOW", f"free cash flow {v('free_cash_flow'):g}")
    if cfq == "EARNINGS_CASH_DIVERGENCE":
        flag("EARNINGS_CASH_DIVERGENCE", "net income positive while operating cash flow is not")
    ie, oi = P[latest]["interest_expense"], P[latest]["operating_income"]
    if mL["interest_coverage"]["status"] != "NOT_APPLICABLE" and ie is not None and ie > 0 and oi is not None:
        if oi <= 0:
            flag("OPERATING_LOSS_INTEREST_UNCOVERED", f"operating income {oi:g} against interest expense {ie:g}")
        elif oi < ie:
            flag("INTEREST_NOT_COVERED", f"operating income {oi:g} below interest expense {ie:g}")
    if lev == "INCREASING":
        flag("LEVERAGE_INCREASING", f"debt / equity {de_p:.4g} -> {de:.4g}")
    if eq_neg := (P[latest]["stockholders_equity"] is not None and P[latest]["stockholders_equity"] < 0):
        flag("NEGATIVE_EQUITY", f"equity {P[latest]['stockholders_equity']:g}")
    if liq_fact == "CURRENT_LIABILITIES_EXCEED_CURRENT_ASSETS":
        flag("CURRENT_LIABILITIES_EXCEED_CURRENT_ASSETS", f"current assets {ca:g} < current liabilities {cl:g}")
    if fin_growth["classification"] == "CONTRACTING":
        flag("REVENUE_CONTRACTING", f"revenue growth {gL:.4g}")
    if prof["operating_margin"]["classification"] == "DETERIORATING":
        flag("OPERATING_MARGIN_DETERIORATING", f"{prof['operating_margin']['prior']:.4g} -> {prof['operating_margin']['latest']:.4g}")
    ident = [c for c in codes if c["code"] in ("GROSS_PROFIT_IDENTITY_MISMATCH", "BALANCE_SHEET_IDENTITY_MISMATCH")]
    if ident:
        flag("ACCOUNTING_IDENTITY_MISMATCH", "; ".join(f"{c['path']}: {c['detail']}" for c in ident))
    for k2, a in bsh["under_user_assumptions"].items():
        if a["assessment"] == "OUTSIDE_USER_ASSUMPTION":
            flag(f"OUTSIDE_USER_ASSUMPTION:{k2}", f"{a['value']:.4g} vs {a['assumption']}")
    def down(name):
        if mL[name]["status"] == "NOT_APPLICABLE":
            return "NOT_APPLICABLE"
        a, b = v(name), (v(name, prev) if prev else None)
        return tri(None if a is None or b is None else a < b)
    rL_, rP_ = P[latest]["revenue"], (P[prev]["revenue"] if prev else None)
    deter = {"revenue_down": tri(None if rL_ is None or rP_ is None else rL_ < rP_),     # Q11 / Q11.2 (review FU-2): a direct comparison, for any sign (no division needed)
             "operating_margin_down": tri(prof["operating_margin"]["change"] < 0) if "change" in prof["operating_margin"] else "UNKNOWN",
             "net_margin_down": tri(prof["net_margin"]["change"] < 0) if "change" in prof["net_margin"] else "UNKNOWN",
             "leverage_up": tri(None if de is None or de_p is None else de > de_p),
             "current_ratio_down": down("current_ratio"), "cash_conversion_down": down("cash_conversion"),
             "states": "TRUE | FALSE | UNKNOWN (an input or the comparison period is missing) | NOT_APPLICABLE (industry rule); UNKNOWN is never reassurance"}
    # 002 (R-06): every risk check has a state; a check that cannot be evaluated is listed, so a missing flag is never read as 'no risk'
    fcf_na = mL["free_cash_flow"]["status"] == "NOT_APPLICABLE"
    id_unchecked = [f"FY{c['fiscal_year']} {k}" for c in identity_checks for k in ("gross_profit", "balance_sheet") if c[k].startswith("NOT_CHECKED")]
    ident = [c for c in codes if c["code"] in ("GROSS_PROFIT_IDENTITY_MISMATCH", "BALANCE_SHEET_IDENTITY_MISMATCH")]
    for u in id_unchecked:
        codes.append(O.code("IDENTITY_NOT_CHECKED", u, "an input of the identity is missing"))
    ic_na = mL["interest_coverage"]["status"] == "NOT_APPLICABLE"
    flagged = {r["flag"] for r in risks}
    def _absent(need):                            # Q11.3 (2nd review N5): of the inputs a check needs, those really absent (both years where it says so)
        out_ = []
        for n_ in need:
            base_ = n_.split(" ")[0]
            fields_ = ("long_term_debt", "short_term_debt") if base_ == "total_debt" else (base_,)
            years_ = [y for y in ((latest, prev) if "both years" in n_ else (latest,)) if y]
            if any(P.get(y, {}).get(f_) is None for y in years_ for f_ in fields_) or (prev is None and "both years" in n_):
                out_.append(n_)
        return out_
    checks = {"LOSS_MAKING": ("UNKNOWN" if ni is None else None, ["net_income"]),
              "NEGATIVE_OPERATING_CASH_FLOW": ("UNKNOWN" if ocf is None else None, ["operating_cash_flow"]),
              "NEGATIVE_FREE_CASH_FLOW": ("NOT_APPLICABLE" if fcf_na else "UNKNOWN" if v("free_cash_flow") is None else None, ["operating_cash_flow", "capex"]),
              "EARNINGS_CASH_DIVERGENCE": ("UNKNOWN" if cfq == "INSUFFICIENT_DATA" else None, ["net_income", "operating_cash_flow"]),
              "OPERATING_LOSS_INTEREST_UNCOVERED": ("NOT_APPLICABLE" if ic_na else "UNKNOWN" if ie is None or oi is None else None, ["operating_income", "interest_expense"]),
              "LEVERAGE_INCREASING": ("UNKNOWN" if lev == "INSUFFICIENT_DATA" else None, ["total_debt (both years)", "stockholders_equity (both years)"],
                                      ("debt / equity is not meaningful (" + "; ".join(sorted({(((M.get(y, {}).get("debt_to_equity") or {}).get("code") or {}).get("meaning") or "not meaningful")
                                                                                              for y in (latest, prev) if y and (M.get(y, {}).get("debt_to_equity") or {}).get("status") == "NOT_MEANINGFUL"})) + ")")
                                      if lev == "INSUFFICIENT_DATA" and any((M.get(y, {}).get("debt_to_equity") or {}).get("status") == "NOT_MEANINGFUL" for y in (latest, prev) if y) else None),   # Q11.3: the metric's own reason
              "NEGATIVE_EQUITY": ("UNKNOWN" if P[latest]["stockholders_equity"] is None else None, ["stockholders_equity"]),
              "CURRENT_LIABILITIES_EXCEED_CURRENT_ASSETS": ("NOT_APPLICABLE" if liq_fact == "NOT_APPLICABLE" else "UNKNOWN" if liq_fact == "INSUFFICIENT_DATA" else None,
                                                            ["current_assets", "current_liabilities"]),
              "REVENUE_CONTRACTING": ("UNKNOWN" if fin_growth["classification"] in ("INSUFFICIENT_DATA", "NOT_MEANINGFUL") else None, ["revenue (both years)"],
                                      (f"revenue growth is not meaningful (prior revenue {rP_:.4g}: zero, negative or too small to divide by); the direct comparison is in "
                                       f"revenue_down") if fin_growth["classification"] == "NOT_MEANINGFUL" else None),
              "OPERATING_MARGIN_DETERIORATING": ("UNKNOWN" if prof["operating_margin"]["classification"] == "INSUFFICIENT_DATA" else None, ["operating_income", "revenue (both years)"],
                                                 ("an operating margin is not meaningful (revenue zero, negative or too small to divide by)" if prof["operating_margin"]["classification"] == "INSUFFICIENT_DATA"
                                                  and all(P.get(y, {}).get(f_) is not None for y in (latest, prev) if y for f_ in ("operating_income", "revenue")) else None)),   # Q11.3 (2nd review N5)
              "INTEREST_NOT_COVERED": ("NOT_APPLICABLE" if ic_na else "UNKNOWN" if ie is None or oi is None else None, ["operating_income", "interest_expense"]),
              "ACCOUNTING_IDENTITY_MISMATCH": (None if ident else "UNKNOWN" if id_unchecked else None, ["the inputs of the identities not checked: " + ", ".join(id_unchecked)])}
    checks = {k: (v_ + (None,))[:3] for k, v_ in checks.items()}
    risk_checks = {k: (st if st else "TRUE" if k in flagged else "FALSE") for k, (st, _, _) in checks.items()}
    indeterminate = [{"check": k, "state": "UNKNOWN", "inputs_needed": need if not why else _absent(need), **({"why": why} if why else {})} for k, (st, need, why) in checks.items() if st == "UNKNOWN"]   # Q11.3: a missing input stays named
    for it in indeterminate:                      # Q11.2 (review FU-2): the inputs are present but the measure is not meaningful - said as such, never 'inputs needed'
        codes.append(O.code("RISK_CHECK_NOT_MEANINGFUL", it["check"], it["why"]) if it.get("why") else
                     O.code("INDETERMINATE_RISK_CHECK", it["check"], "inputs needed: " + ", ".join(it["inputs_needed"])))
    # ---- evidence (facts with their inputs), missing information, completeness
    sup, cnt = [], []

    def fact(lst, text, name, fy=latest):
        lst.append({"fact": text, "metric": name, "fiscal_year": fy, "source_document_id": P[fy]["_source"], "available_at": P[fy]["_available_at"],
                    "detail": M[fy].get(name) if name in M[fy] else None})
    neutral = []
    if gL is not None:                            # Q11.2 (review FU-1): the placement follows the classification, as for the margins
        gtxt = f"revenue {_pct(gL)} FY{latest - 1}->FY{latest} ({fin_growth['classification']} against a flat band of +/-{GROWTH_FLAT_BAND:.0%})"
        if fin_growth["classification"] == "EXPANDING":
            fact(sup, "revenue grew: " + gtxt, "revenue_growth")
        elif fin_growth["classification"] == "CONTRACTING":
            fact(cnt, "revenue fell: " + gtxt, "revenue_growth")
        elif gL < 0:
            fact(cnt, "revenue slightly lower: " + gtxt + "; a decline within the flat band (deterioration indicator TRUE)", "revenue_growth")
        else:
            fact(neutral, ("revenue unchanged: " if gL == 0 else "revenue slightly higher: ") + gtxt, "revenue_growth")
    for nm in ("gross_margin", "operating_margin", "net_margin"):     # Q10: placement follows the classification (a sign inside the stable band is not evidence)
        t = prof[nm]
        if "change" in t:
            txt = f"{nm.replace('_', ' ')} {_num4(t['prior'])} -> {_num4(t['latest'])} ({_pp(t['change'])}; {t['classification']} against a stable band of +/-{t['band'] * 100:.1f} pp)"
            if t["classification"] == "IMPROVING":
                fact(sup, txt, nm)
            elif t["classification"] == "DETERIORATING":
                fact(cnt, txt, nm)
            elif t["change"] < 0:
                fact(cnt, txt + "; a decline within the stable band (deterioration indicator TRUE)", nm)
            else:
                fact(neutral, txt, nm)
    if cfq in ("OCF_EXCEEDS_NET_INCOME", "LOSS_WITH_POSITIVE_OCF"):
        fact(sup, f"operating cash flow {ocf:g} vs net income {ni:g} ({cfq})", "cash_conversion")
    elif cfq not in ("INSUFFICIENT_DATA",):
        fact(cnt, f"operating cash flow {ocf:g} vs net income {ni:g} ({cfq})", "cash_conversion")
    if lev in ("INCREASING", "DECREASING"):
        fact(cnt if lev == "INCREASING" else sup, f"debt / equity {_num4(de_p)} -> {_num4(de)} ({lev})", "debt_to_equity")
    if liq_fact in ("CURRENT_ASSETS_COVER_CURRENT_LIABILITIES", "CURRENT_LIABILITIES_EXCEED_CURRENT_ASSETS"):
        fact(sup if liq_fact.startswith("CURRENT_ASSETS") else cnt, f"current assets {ca:g} vs current liabilities {cl:g}", "current_ratio")
    for rk in risks:
        if rk["flag"] in ("LOSS_MAKING", "NEGATIVE_FREE_CASH_FLOW", "OPERATING_LOSS_INTEREST_UNCOVERED", "INTEREST_NOT_COVERED", "NEGATIVE_EQUITY", "ACCOUNTING_IDENTITY_MISMATCH"):
            cnt.append({"fact": f"{rk['flag']}: {rk['evidence']}", "metric": None, "fiscal_year": latest})
    metric_of = {"revenue_down": "revenue_growth", "operating_margin_down": "operating_margin", "net_margin_down": "net_margin", "leverage_up": "debt_to_equity",
                 "current_ratio_down": "current_ratio", "cash_conversion_down": "cash_conversion"}
    for k, st in deter.items():          # Q10: no deterioration indicator stays internal - each TRUE one is a counter-evidence fact
        if st != "TRUE" or any(c.get("metric") == metric_of[k] for c in cnt):
            continue
        mk = metric_of[k]
        a, b = v(mk), (v(mk, prev) if prev else None)
        fact(cnt, f"{mk.replace('_', ' ')} {_num4(b)} -> {_num4(a)} (down; deterioration indicator {k} = TRUE"
             + (", within the leverage stable band)" if k == "leverage_up" else ", no stable band is declared for this metric)"), mk)
        if k == "leverage_up":
            cnt[-1]["fact"] = f"debt / equity {de_p:.4f} -> {de:.4f} (up; deterioration indicator leverage_up = TRUE, within the stable band of +/-{LEVERAGE_STABLE_BAND})"
    present = [n for n in FUNDAMENTAL_REQUIRED_LATEST if P[latest].get(n) is not None]
    na_fields = {"current_assets", "current_liabilities"} if mL["current_ratio"]["status"] == "NOT_APPLICABLE" else set()
    required = [n for n in FUNDAMENTAL_REQUIRED_LATEST if n not in na_fields]
    completeness = sum(1 for n in required if P[latest].get(n) is not None) / len(required)
    missing = [{"field": n, "fiscal_year": latest, "status": "MISSING"} for n in required if P[latest].get(n) is None]
    missing += [{"metric": name, "fiscal_year": latest, "status": mm["status"], "reason": mm["code"]["code"] if mm.get("code") else None}
                for name, mm in mL.items() if isinstance(mm, dict) and mm.get("status") in ("MISSING", "NOT_MEANINGFUL", "NO_INTEREST_EXPENSE", "NOT_AVAILABLE")]
    sufficiency = "SUFFICIENT" if completeness >= 0.8 and len(years) >= 3 else "PARTIAL" if completeness >= COMPLETENESS_NEEDS_MORE_DATA_BELOW and len(years) >= 2 else "INSUFFICIENT"
    explanation = (f"Not a probability and not a forecast. Data completeness {completeness:.2f} ({len([n for n in required if P[latest].get(n) is not None])}/{len(required)} required fields "
                   f"in FY{latest}); {len(years)} usable annual period(s) {years}; {len(excluded)} excluded; identities "
                   f"{'INCONSISTENT (see financial_risks)' if ident else ('NOT CHECKED for ' + ', '.join(id_unchecked) + ' (inputs missing); only the others were checked and found consistent') if id_unchecked else 'consistent (all checked)'}"
                   f"; sufficiency {sufficiency}"
                   f"{'; needs more data' if completeness < COMPLETENESS_NEEDS_MORE_DATA_BELOW else ''}.")
    trace.append({"step": "periods", "usable": years, "excluded": excluded, "values_in": f"{cur} units (scales {scales} converted)"})
    env["findings"] = {
        "financial_growth": fin_growth, "financial_profitability": prof, "cash_flow_quality": cash_q, "balance_sheet_health": bsh,
        "financial_risks": risks, "risk_checks": risk_checks, "neutral_facts": neutral, "identity_checks": identity_checks, "indeterminate_risk_checks": indeterminate, "deterioration_indicators": deter, "missing_information": missing, "supporting_evidence": sup, "counter_evidence": cnt,
        "confidence_explanation": explanation, "piotroski_checklist": pio, "metrics_by_year": {fy: M[fy] for fy in years},
        "inputs_by_year": {fy: {k: x for k, x in P[fy].items() if k != "_dec"} for fy in years}, "excluded_periods": excluded,
        "data_completeness": {"value": completeness, "required_fields": required, "present": present, "needs_more_data": completeness < COMPLETENESS_NEEDS_MORE_DATA_BELOW,
                              "sufficiency": sufficiency, "note": "data completeness, not confidence in any prediction"},
    }
    env["evidence"], env["counter_evidence"] = sup, cnt
    env["warnings"] = [c for c in codes if c["code"] in ("GROSS_PROFIT_IDENTITY_MISMATCH", "BALANCE_SHEET_IDENTITY_MISMATCH", "NET_INCOME_ABOVE_REVENUE", "NEGATIVE_VALUE_INVALID")]
    env["missing_dependencies"] = sorted({m_.get("field") or m_.get("metric") for m_ in missing})
    env["calculation_or_extraction_trace"] = trace + [{"metric": name, "fiscal_year": latest, "formula": mm.get("formula"), "inputs": mm.get("inputs"), "value": mm.get("value"), "status": mm.get("status")}
                                                      for name, mm in mL.items() if isinstance(mm, dict) and "formula" in mm]
    env["result_codes"] = codes + [{k: e[k] for k in ("code", "meaning", "path", "detail")} for e in excluded]
    env["data_status"] = {"usable_periods": years, "latest_fiscal_year": latest, "completeness": completeness, "sufficiency": sufficiency, "currency": cur}
    env["confidence_basis"] = explanation
    env["execution_status"] = "COMPLETED"
    env["questions"] = {"calculation_succeeded": True, "data_adequate": "ADEQUATE" if sufficiency == "SUFFICIENT" else "PARTIAL" if sufficiency == "PARTIAL" else "INADEQUATE",
                        "evidence_sufficient": "SUFFICIENT_FOR_DESCRIPTION" if sufficiency != "INSUFFICIENT" else "INSUFFICIENT",
                        "financial_interpretation_supported": "DESCRIPTIVE_ONLY: accounting condition as reported in the input statements",
                        "predictive_validity_demonstrated": False}
    return env
