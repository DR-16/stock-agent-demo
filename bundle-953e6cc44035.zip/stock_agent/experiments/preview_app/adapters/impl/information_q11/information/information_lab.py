"""Information V2.1 (q5-information-v21 0.2.0, INFORMATION EVIDENCE INTEGRITY 005; Q5_INFORMATION_V21_CONTRACT.json) - successor of Q4 V2 0.1.1.
Q5 changes here: the evidence completeness gate in stage D (G1..G7: SOURCE_CURRENT only when every claim-related statement was assessed); an event with
an INVALID / UNREADABLE date is asserted with its date state (no event-level abstention); event / narrative dates and the date basis in the details;
hazard codes for NON_FACTUAL and AMBIGUOUS_REFERENCE (Q4 coded the latter as HISTORICAL_STATEMENT).

Information V2 (q4-information-v2 0.1.0, INFORMATION RELIABILITY 004) - an isolated experimental successor of C2's Information laboratory
(te-information-lab 0.2.0-prototype, CORRECTNESS 002, sha256 2d86bebc...). C2 itself is unchanged; this file started as a byte copy of it.

Kept from C2: document identity and issuer checks, availability reading, duplicates and id conflicts, the 8-K metadata layer, Form 4 rows,
amendment / supersession rules, the exact-span self-check and the output envelope.
Replaced (Q4_INFORMATION_V2_CONTRACT.json):
  stage A/B - the Item 5.02 body layer: sentences -> clauses; each clause's predicate, voice, subject (SUBJECT / OBJECT / COORDINATED / PRONOUN /
              INHERITED / RELATIVE), roles, negation and tentativeness, and its OWN effective date with the exact words used (semantics.py);
  stage C  - contradictions: TASK_SPEC_Q3 section 4 between DIFFERENT current documents only (kind Q3_SECTION_4); date disagreements and
              within-document inconsistencies are reported apart; unresolved mentions are kept;
  stage D  - claims: the source status is SOURCE_NOT_FULLY_ASSESSED when an unresolved mention of a person named in the cited span exists in an
              eligible document (silence is not proof that no contradiction exists); citation, support and truth stay separate.
Experimental; synthetic only; never a Meta input.
"""
from __future__ import annotations

import hashlib
import re
from datetime import date, datetime

from information import semantics as SEM
from shared import output as O
from shared import schema
from shared.constants import REQUESTS, TEN_B5_1_APPLICABLE_FROM

VERSION = ("q11-information 0.4.6 (Q11 successor of q10-information 0.3.1: current_status is the status at as_of (IN_EFFECT / NOT_YET_EFFECTIVE / ENDED / "
           "PENDING_INTENTION / UNKNOWN), the old combined value is evidence_status; dates defined as a term, stated in another section or referred to as "
           "'the same date' are linked with their evidence; events of Item 7.01 / 8.01 / the Explanatory Note for people Item 5.02 does not cover; "
           "already-held titles, intentions, continuation ends, name suffixes; diagnostics that only repeat a shown event removed; committee lists split; 0.4.1: company names are not people, reporting verbs ('notified ... of her decision to resign'), nominal departures, 'will serve as', 'commencing DATE', date terms defined as 'means' / 'designated', conditional future changes are tentative, roles at another company, 'X as R1 and Y as R2', 'respectively' dates, appositive title lists, 'service as R ended'; 0.4.2: 'with effect from' / 'with her role commencing' dates, 'take over as', 'position of R was vacated by X', 'the end of X's tenure as R', 'by the Board of <company> as R', degrees after names; 0.4.3: a condition before a sentence's first predicate governs its later clauses, 'announced that X would' is reported speech, a non-officer transition role after leaving a title, 'take up / take on the role of', 'stop serving as', 'transition out of', 'keep serving', 'continue his tenure as', 'continue to be a member of the Board', 'act as', 'to become R', a predicate word inside an earlier role phrase, 'continue to <other verb>' is not a role, principal officers, accented letters in names, 'appointed him/her to', 'Chair of the X Committee', 'its Chair', 'As previously reported'; 0.4.4 (mid-round independent review E1-E14): another section dates a record only when it names the same person with a word of the same action and is not conditional, forward-looking or historical; one person only when first names (and suffixes) agree; titles held now (not former, not at another company, 'our', a title stated earlier) are not appointments; conditions after the verb and 'plan to', 'preferred candidate', 'recommended that', 'asked X to' are tentative; interim roles end at their stated end or when a permanent holder takes over; 'effective immediately upon' waits for the event; 'that date' is the date written last before it; uncertain defined dates are not linked; 7.01 / 8.01 sentences that are forward-looking, historical or another company's are not events; only the catch-all diagnostic is merged; organisation names defined in the document; DeAngelo-type names; 'respectively' dates for two titles; two dates without 'respectively' are ambiguous; 0.4.5 (second independent review N1-N14 + W1/W2 / paraphrase classes): another section dates a record only through its own reading of the same change; tentative phrases only where they govern the predicate; conditions only in the event's own segment and as classes (once / pending / assuming / if ... approve); an appointment's end only from its own segment, a term extension; held titles need issuer evidence; people vs organisations; another company needs a legal form, a defined name or 'X, a ... company'; a role at a subsidiary; 'respectively' variants; a year before the filing's; 'that date' not from a biography, ambiguous when two dates precede; implied predecessor departure; pronoun objects; committee joins; candidates; 'each effective'; 0.4.6 (third independent review C1-C6, M1-M4, against 131 fresh paragraphs now a development set): the registrant's name (on file, cover page) is the issuer and a role at another named company is shown as an unresolved mention, not dropped silently; 'board of directors of X' in any case; 'agreed / determined / decided that X would' is a reported decision; a vote, a proposal, a nomination and a condition before the subject (subject to / contingent upon / upon receipt of) are tentative; a historical relative clause without a comma; 'rejoined the Board'; a completed change dated only by 'On D,' is IN_EFFECT when the sentence and the next have no other timing words; a later sentence that dates the change ('X's appointment will become effective on D', 'This appointment will be effective on D', 'last day ... will be D'); 'effective upon the conclusion of the meeting on D'; 'at which time' right after a date; 'on that date' after the predicate; 'Upon X's departure' takes that departure's date (flagged); death, separation, 'no longer serve as', not standing for re-election (flagged), 'voted to remove', 'terminated the employment of', 'assume the duties of', 'replace X as', 'following his retirement as R', 'to be named', nominations; titles: 'Co-', 'its new', 'the additional role of', 'positions as', an appositive with one inner comma, comma-separated title lists; a division / segment is the issuer's - see semantics.py)")
SOURCE_TYPES = ["SYNTHETIC_8K", "SEC_8K", "SYNTHETIC_FORM4", "SYNTHETIC_PRESS_RELEASE", "SYNTHETIC_NEWS_ARTICLE", "SYNTHETIC_10K", "SYNTHETIC_10Q", "SYNTHETIC_TRANSCRIPT", "OTHER"]
SUPPORTED = {"SYNTHETIC_8K": ("8-K", "8-K/A"), "SEC_8K": ("8-K", "8-K/A"), "SYNTHETIC_FORM4": ("4", "4/A")}
DOC = {"type": "object", "required": ["document_id", "issuer_id", "source_type", "form_type", "document_timestamp", "availability_timestamp", "text"], "keys": {
    "document_id": {"type": "string", "min": 1, "max": 80}, "issuer_id": {"type": "string", "min": 1, "max": 40},
    "source_type": {"type": "string", "enum": SOURCE_TYPES}, "form_type": {"type": "string", "min": 1, "max": 20},
    "document_timestamp": {"type": "string", "max": 40, "nullable": True}, "availability_timestamp": {"type": "string", "max": 40, "nullable": True},
    "amends": {"type": "string", "min": 1, "max": 80, "nullable": True}, "text": {"type": "string", "max": 200_000}}}
CLAIM = {"type": "object", "required": ["claim_id", "document_id", "quoted_span"], "keys": {
    "claim_id": {"type": "string", "min": 1, "max": 40}, "document_id": {"type": "string", "min": 1, "max": 80},
    "quoted_span": {"type": "string", "min": 1, "max": 2000}, "claim": {"type": "string", "max": 2000}}}
SPEC = {"type": "object", "required": ["documents"], "keys": {
    "requests": {"type": "array", "max": 10, "items": {"type": "string", "enum": list(REQUESTS["information"]["supported"] + REQUESTS["information"]["unsupported"])}},
    "documents": {"type": "array", "min": 0, "max": 200, "items": DOC},
    "claims_to_verify": {"type": "array", "max": 200, "items": CLAIM}}}

# ---- IDEC1 / IERC1 tables (mirrored from idec1_pre_registration.py and ierc1_pre_registration.py; read only)
ITEM_TO_EVENT_TYPE = {"1.01": "MA", "1.02": "OPERATIONAL", "1.03": "OPERATIONAL", "2.01": "MA", "2.02": "GUIDANCE", "2.03": "DEBT_EVENT", "2.04": "DEBT_EVENT",
                      "2.05": "RESTRUCTURING", "2.06": "OPERATIONAL", "3.01": "REGULATORY", "3.02": "EQUITY_ISSUANCE", "3.03": "OTHER_MATERIAL", "4.01": "OTHER_MATERIAL",
                      "4.02": "OPERATIONAL", "5.01": "MA", "5.02": "MANAGEMENT_CHANGE", "5.03": "OTHER_MATERIAL", "5.07": "OPERATIONAL", "5.08": "OPERATIONAL",
                      "7.01": "OTHER_MATERIAL", "8.01": "OTHER_MATERIAL", "9.01": "OTHER_MATERIAL"}
INHERENTLY_AMBIGUOUS_ITEMS = ("1.01", "7.01", "8.01")
FORM4_CODE_TO_TYPE = {"P": "PURCHASE", "S": "SALE", "A": "GRANT", "F": "TAX_WITHHOLDING", "M": "OPTION_EXERCISE", "X": "OPTION_EXERCISE", "C": "OPTION_EXERCISE"}
MATERIAL_EVENT_TAXONOMY = ("MANAGEMENT_CHANGE", "MA", "DIVESTITURE", "RESTRUCTURING", "BUYBACK", "EQUITY_ISSUANCE", "DEBT_EVENT", "REGULATORY", "LITIGATION", "PRODUCT",
                           "CUSTOMER", "OPERATIONAL", "GUIDANCE", "OTHER_MATERIAL")

RE_ITEM = re.compile(r"^Item ([1-9]\.[0-9]{2})\b[^\n]*$", re.M)
RE_SUPPRESS = re.compile(r"^(?:Forward-Looking Statements|Cautionary Note Regarding Forward-Looking Statements|Risk Factors|Safe Harbor Statement)[ \t]*$", re.M | re.I)
NAME = r"[A-Z][a-z]+(?:[-'][A-Z][a-z]+)?(?: [A-Z]\.)?(?: [A-Z][a-z]+(?:[-'][A-Z][a-z]+)?){1,2}"
ROLE = (r"Chief Executive Officer|Chief Financial Officer|Chief Operating Officer|Chief Accounting Officer|Chief Technology Officer|General Counsel|President|"
        r"Treasurer|Corporate Secretary|a director|director|member of the Board of Directors|the Board of Directors")
PRE = r"(?:the )?(?:Company's )?"
RULES = [  # (rule id, action, pattern) - applied in this order, the first match per sentence position wins
    ("MC-NEG-1", "NEGATED", re.compile(rf"(?P<person>{NAME})(?:, [^,.]{{1,60}},)? (?:did|has|have|had|will|does) not (?:resign|retire|step down|depart)\b(?: (?:as|from) {PRE}(?P<role>{ROLE}))?")),
    ("MC-TEN-1", "TENTATIVE", re.compile(rf"(?P<person>{NAME}) (?:may|might|could|is expected to|intends to|plans to|is considering whether to) (?:resign|retire|step down|depart)\b(?: (?:as|from) {PRE}(?P<role>{ROLE}))?")),
    ("MC-DEP-1", "DEPARTURE", re.compile(rf"(?P<person>{NAME}) (?:has |had |will )?(?:resigned|retired|stepped down|departed|resign|retire|step down|depart)\b(?: (?:as|from) {PRE}(?P<role>{ROLE}))?")),
    ("MC-APP-1", "APPOINTMENT", re.compile(rf"\b(?:appointed|named|elected) (?P<person>{NAME}) (?:to serve )?as {PRE}(?P<role>{ROLE})")),
    ("MC-APP-2", "APPOINTMENT", re.compile(rf"(?P<person>{NAME}) (?:was|has been|will be|had been) (?:appointed|named|elected) (?:as )?{PRE}(?P<role>{ROLE})")),
    ("MC-CON-1", "CONTINUATION", re.compile(rf"(?P<person>{NAME}) (?:will continue to serve|continues to serve|will remain|remains) as {PRE}(?P<role>{ROLE})")),
]
NAME_STOP = {"The", "Company", "Board", "Directors", "Chief", "Officer", "Financial", "Executive", "Operating", "President", "Item", "On", "At", "This", "Exhibit", "Form"}
RE_ROUTINE = re.compile(r"\bannual meeting\b|\bre-elected\b", re.I)
RE_EFFECTIVE_ANY = re.compile(r"\beffective (?:as of |on )?(?P<raw>[A-Z][a-z]+\.? [0-9]{1,2}, [0-9]{1,6}(?![0-9])|[0-9]{1,2} [A-Z][a-z]+ [0-9]{4}(?![0-9])"
                              r"|[0-9]{4}-[0-9]{2}-[0-9]{2}|[0-9]{1,2}/[0-9]{1,2}/[0-9]{2,4})")   # post-review R-05: 'on', 'Nov.', no truncated year
RE_STRICT_DATE = re.compile(r"(?P<m>[A-Z][a-z]+) (?P<d>[0-9]{1,2}), (?P<y>[0-9]{4})")
SUBJECT_RULES = ("MC-DEP-1", "MC-APP-2", "MC-CON-1", "MC-NEG-1", "MC-TEN-1")   # rules whose 'person' is the grammatical subject (MC-APP-1's is the object)
RE_COORD_CON = re.compile(rf"\b(?:but|and|while) (?:will continue to serve|continues to serve|will remain|remains) as {PRE}(?P<role>{ROLE})")
RE_AMEND = re.compile(r"\bAmendment No\. [0-9]+\b|\bamends\b")
MONTHS = {m: i for i, m in enumerate(("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"), 1)}
ABBREV = ("No.", "Inc.", "Co.", "Corp.", "Ltd.", "Mr.", "Ms.", "Dr.", "St.", "Jan.", "Feb.", "Mar.", "Apr.", "Jun.", "Jul.", "Aug.", "Sep.", "Sept.", "Oct.", "Nov.", "Dec.",
          "Jr.", "Sr.", "Mrs.", "M.D.", "Ph.D.", "Esq.")    # Q11: a name suffix does not end a sentence
RE_TS_OK = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?(?:Z|[+-][0-9]{2}:[0-9]{2})")
RE_DATE_ONLY = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}")
RE_TS_NO_OFFSET = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}[T ][0-9]{2}:[0-9]{2}(?::[0-9]{2}(?:\.[0-9]+)?)?(?:z| ?[A-Za-z_/]+)?")
RE_NEG_10B51 = re.compile(r"\bnot\b[^.]{0,40}\bpursuant to (?:a |an )?Rule 10b5-1\b", re.I)
RE_POS_10B51 = re.compile(r"\bpursuant to (?:a |an )?Rule 10b5-1\b", re.I)


def classify_time(s) -> tuple[str, datetime | None, str]:
    """(state, instant, code) for an availability string, read as written; never guessed"""
    if s is None or (isinstance(s, str) and not s.strip()):
        return "ABSTAIN_MISSING_TIMESTAMP", None, "AVAILABILITY_TIMESTAMP_MISSING"
    if RE_TS_OK.fullmatch(s):
        d = schema.parse_datetime(s)
        return ("OK", d, "") if d is not None else ("ABSTAIN_INVALID_INPUT", None, "AVAILABILITY_INVALID")
    if RE_DATE_ONLY.fullmatch(s):
        ok = schema.parse_date(s) is not None
        return ("ABSTAIN_UNKNOWN_SEMANTICS", None, "AVAILABILITY_UNKNOWN_SEMANTICS") if ok else ("ABSTAIN_INVALID_INPUT", None, "AVAILABILITY_INVALID")
    if RE_TS_NO_OFFSET.fullmatch(s):
        return "ABSTAIN_UNKNOWN_SEMANTICS", None, "AVAILABILITY_UNKNOWN_SEMANTICS"
    return "ABSTAIN_INVALID_INPUT", None, "AVAILABILITY_INVALID"


def sentences(text: str, start: int, end: int):
    """(char_start, char_end) of each sentence in text[start:end]; a line break also ends a sentence; abbreviations and initials do not"""
    i = start
    while i < end:
        while i < end and text[i] in " \t\n":
            i += 1
        if i >= end:
            break
        j = i
        while j < end:
            c = text[j]
            if c == "\n":
                break
            if c in ".!?" and (j + 1 >= end or text[j + 1] in " \t\n"):
                word = text[max(i, text.rfind(" ", i, j) + 1): j + 1]
                if not (word in ABBREV or re.fullmatch(r"[A-Z]\.", word)):
                    j += 1
                    break
            j += 1
        s, e = i, j
        while e > s and text[e - 1] in " \t":
            e -= 1
        if e > s:
            yield s, e
        i = j


def sections_of(text: str) -> list:
    heads = [(m.start(), "ITEM", m.group(1), m.group(0)) for m in RE_ITEM.finditer(text)] + \
            [(m.start(), "SUPPRESSED", None, m.group(0).strip()) for m in RE_SUPPRESS.finditer(text)]
    heads.sort()
    out = [{"kind": "PREAMBLE", "item_code": None, "heading": "", "start": 0, "body_start": 0, "end": heads[0][0] if heads else len(text)}]
    for k, (pos, kind, code, heading) in enumerate(heads):
        endp = heads[k + 1][0] if k + 1 < len(heads) else len(text)
        out.append({"kind": kind, "item_code": code, "heading": heading, "start": pos, "body_start": pos + len(heading), "end": endp})
    return out


def metadata_layer(secs: list) -> dict:
    codes = []
    for s in secs:
        if s["kind"] == "ITEM" and s["item_code"] not in codes:
            codes.append(s["item_code"])
    raw = list(codes)
    if not codes:
        return {"raw_item_codes": raw, "item_codes": [], "event_types": [], "ambiguity_state": "AMBIGUOUS", "note": "no item heading"}
    if "9.01" in codes and len(codes) > 1:
        codes = [c for c in codes if c != "9.01"]
    types = []
    for c in codes:
        t = ITEM_TO_EVENT_TYPE.get(c, "OTHER_MATERIAL")
        t = "NOT_INTERPRETED (GUIDANCE_ANALYSIS_UNAVAILABLE)" if t == "GUIDANCE" else t
        if t not in types:
            types.append(t)
    if codes == ["9.01"]:
        state = "AMBIGUOUS"
    elif len(types) == 1 and any(c in INHERENTLY_AMBIGUOUS_ITEMS for c in codes):
        state = "AMBIGUOUS"
    else:
        state = "UNAMBIGUOUS" if len(types) == 1 else "MULTI_EVENT"
    return {"raw_item_codes": raw, "item_codes": codes, "event_types": types, "ambiguity_state": state,
            "note": "item metadata only (IDEC1 rules); never evidence that an event happened (IDEC4)"}


def effective_date(text: str) -> dict:
    """002 (R-04): {state, value, raw}. State NOT_STATED | VALID | INVALID (not a real calendar date) | UNREADABLE (a date-like text in another form).
    Never raises, never substitutes a date, never uses today's date."""
    m = RE_EFFECTIVE_ANY.search(text)
    if not m:
        return {"state": "NOT_STATED", "value": None, "raw": None}
    raw = m.group("raw")
    s = RE_STRICT_DATE.fullmatch(raw)
    if not s or s.group("m") not in MONTHS:
        return {"state": "UNREADABLE", "value": None, "raw": raw}
    y, d = int(s.group("y")), int(s.group("d"))
    if not 1900 <= y <= 2100:
        return {"state": "INVALID", "value": None, "raw": raw}
    try:
        return {"state": "VALID", "value": date(y, MONTHS[s.group("m")], d).isoformat(), "raw": raw}
    except ValueError:
        return {"state": "INVALID", "value": None, "raw": raw}


def _role(r: str | None) -> str | None:
    if r is None:
        return None
    return "Director" if r in ("a director", "director", "member of the Board of Directors", "the Board of Directors") else r


def _record(d: dict, as_of: str, category: str, claim: str, start: int, end: int, location: dict, rule: str, basis: str, ambiguity: str, details: dict) -> dict:
    return {"record_id": f"{d['document_id']}#{rule}#{start}", "document_id": d["document_id"], "issuer_id": d["issuer_id"], "source_type": d["source_type"],
            "form_type": d["form_type"], "document_timestamp": d["document_timestamp"], "availability_timestamp": d["availability_timestamp"], "as_of": as_of,
            "event_category": category, "claim": claim, "exact_evidence_span": d["text"][start:end],
            "evidence_location": {"char_start": start, "char_end": end, **location}, "extraction_method": {"rule_id": rule, "extractor_version": VERSION},
            "confidence_basis": basis, "ambiguity_status": ambiguity, "document_sha256": hashlib.sha256(d["text"].encode("utf-8")).hexdigest(), "details": details}


def _n(x) -> str:
    return " ".join(str(x or "").split()).casefold()


RE_DEFTERM = re.compile(rf"(?P<raw>{SEM.DATE_ANY})\s*\((?:the |a |an )?[\"“](?P<term>[A-Z][A-Za-z\- ]{{2,40}}?)[\"”]\)")
RE_DEFTERM2 = re.compile(rf"(?:the )?[\"“](?P<term>[A-Z][A-Za-z\- ]{{2,40}}?)[\"”] (?:means|shall mean|will be|is) (?P<raw>{SEM.DATE_ANY})")      # Q11: 'the "Transition Date" means January 4, 2027'
RE_DEFTERM3 = re.compile(rf"\bdesignated (?P<raw>{SEM.DATE_ANY}) as the (?P<term>[A-Z][A-Za-z\- ]{{2,40}}? Date)\b")                                # Q11: 'designated November 30, 2026 as the Succession Date'
RE_SAME_DATE = re.compile(r"\b[Ee]ffective (?:on|as of) (?:the same date|that date|such date|the same day)\b|(?<=[a-z,] )(?:on|as of) (?:that date|such date)\b")   # 0.4.6 (3rd review D01): 'who will retire as CEO on that date' (not a sentence-initial 'On that date, ...')
RE_AT_WHICH = re.compile(rf"(?P<raw>{SEM.DATE_ANY}),?\s+at (?:which|that|such) time\b")     # 0.4.6 (3rd review D03): '... effective D, at which time X will become R' - only right after a date   # 0.4.6 (3rd review D01 / D03): 'who will retire as CEO on that date', 'at which time X will become R' (not a sentence-initial 'On that date, ...')   # Q11: only an EFFECTIVE reference ('On the same date, the Board ...' dates the action)
RE_DEFTERM_MOVED = re.compile(rf"\b(?:postponed|rescheduled|changed|moved|extended|delayed|accelerated|deferred) the (?P<term>[A-Z][A-Za-z\- ]{{2,40}}? Date) to (?P<raw>{SEM.DATE_ANY})|"
                              rf"\b[Tt]he (?P<term2>[A-Z][A-Za-z\- ]{{2,40}}? Date) (?:has|had|was|were|will be)(?: since| later| now)? (?:been )?(?:postponed|rescheduled|changed|moved|extended|delayed|accelerated|deferred) to (?P<raw2>{SEM.DATE_ANY})")
RE_DEF_UNSURE = re.compile(r"\bor (?:such )?(?:other|another|a later|an earlier|later|earlier|any other) date\b|\bon or (?:before|about|after)\b|\bno later than\b|"
                           r"\bor (?:as )?(?:otherwise )?(?:agreed|determined)\b|\bunless (?:the Board|the Company|the parties) (?:determines?|decides?|agrees?) otherwise\b|"
                           r"\b(?:is|are) expected to (?:close|occur|be)\b|\bexpected (?:closing|completion)\b|\bas (?:may be )?(?:extended|postponed|adjusted)\b", re.I)   # 0.4.5 (2nd review N10)
SECONDARY_ITEMS = ("7.01", "8.01")                    # Q11: their sentences may date an Item 5.02 event, or state a change of a person 5.02 does not cover


SUFFIXES = ("Jr", "Sr", "II", "III", "IV")


def _name_parts(x: str) -> tuple:
    toks = [t.strip(".,") for t in str(x).split() if t.strip(".,")]
    suf = toks[-1] if toks and toks[-1] in SUFFIXES else None
    core = [t for t in toks if t not in SUFFIXES and not re.fullmatch(r"[A-Z]", t)]
    return (core[0].casefold() if core else "", SEM.surname(x).casefold(), suf)


def _initials(x: str) -> list:
    return [t.strip(".") for t in str(x).split()[1:-1] if re.fullmatch(r"[A-Z]\.?", t)]


def _same(a, b) -> bool:
    """0.4.4 (review E2): one person only when the first name, the surname and a suffix (Jr. / Sr. / II ...) agree (middle initials may differ);
    an honorific short form ('Mr. Okafor') by surname - names() resolves a short form only when one full name has that surname"""
    if not a or not b:
        return False
    if _n(a) == _n(b):
        return True
    if SEM.surname(a).casefold() != SEM.surname(b).casefold():
        return False
    if re.match(r"^(?:Mr|Ms|Mrs|Dr)\.", a) or re.match(r"^(?:Mr|Ms|Mrs|Dr)\.", b):
        return True
    if _initials(a) and _initials(b) and _initials(a) != _initials(b):
        return False                                          # 0.4.5 (2nd review N14): Ann C. Lee is not Ann B. Lee
    return _name_parts(a) == _name_parts(b)


def _rkey(r) -> str:
    """a title compared without 'of the Board (of Directors)' ('Chair' = 'Chair of the Board') - 0.4.5"""
    return re.sub(r"\s+of the board(?: of directors)?$", "", _n(r))


RE_SEC_COND = re.compile(r"^\s*(?:If|Unless|Whether|In the event|Assuming)\b|\b(?:if|unless|subject to|upon the (?:closing|completion|consummation)|(?-i:would|could|may|might)|"
                         r"expects?|expected|anticipates?|intends?|plans?|forward-looking|future events|risks? and uncertaint|uncertainties|notes? that)\b", re.I)   # 0.4.5 (2nd review N11)
RE_SEC_SKIP = re.compile(r"^\s*(?:If|Unless|Whether|In the event|Assuming)\b|\b(?:if|unless|subject to|upon the (?:closing|completion|consummation)|(?-i:would|could|may|might)|"
                         r"expects?|expected|anticipates?|intends?|plans?|forward-looking|notes? that|first (?:appointed|named|elected)|joined the Company|previously|formerly|"
                         r"has served|had served|since (?:19|20)[0-9]{2}|in (?:19|20)[0-9]{2}\b)", re.I)   # 0.4.4 (review E1 / E11): conditional, forward-looking or historical
ACTION_WORDS = {"APPOINTMENT": re.compile(r"\b(?:appoint|name[ds]?\b|elect|promot|join|become|became|assum|serv|succeed|hire|designat|select|take[s]? (?:over|up|on))", re.I),
                "DEPARTURE": re.compile(r"\b(?:resign|retir|depart|step|leav|left|cease|terminat|separat|transition|vacat)", re.I),
                "CONTINUATION": re.compile(r"\b(?:continu|remain|stay|retain|keep|transition|move[sd]? to)", re.I)}


def _too_old(value: str, doc_ts: str | None) -> bool:
    """a date more than a year before the filing is not the date of a change this filing reports (0.4.4, review E1 / E11)"""
    try:
        from datetime import date as _d
        return bool(doc_ts) and (_d.fromisoformat(doc_ts[:10]) - _d.fromisoformat(value)).days > 366
    except ValueError:
        return False


def _names_person(st_: str, person: str, known: list) -> bool:
    """the sentence names this person: a full name that is the same person, or a short form that resolves to it (0.4.4, review E1: never a substring)"""
    old = list(SEM._KNOWN)
    SEM._KNOWN[:] = list(dict.fromkeys(list(known) + [person]))
    try:
        ns = [n[2] for n in SEM.names(st_)]
    finally:
        SEM._KNOWN[:] = old
    return any(_n(n) == _n(person) or (not re.match(r"^(?:Mr|Ms|Mrs|Dr)\.", n) and _same(n, person)) for n in ns)


RE_ANCHORED = re.compile(rf"\b[Ee]ffective (?:immediately )?(?:upon|following|after|at) (?:the )?(?:(?:conclusion|close|end|adjournment|completion) of )?(?:the |its |our )?"
                         rf"(?:Company['\u2019]s |Board['\u2019]s )?(?:[A-Za-z-]+ ){{0,5}}(?:meeting|annual meeting|special meeting)(?: of (?:the )?(?:[Bb]oard|stockholders|shareholders|directors))?,? "
                         rf"(?:held |to be held |scheduled )?(?:on|for) (?P<raw>{SEM.DATE_ANY})")      # 0.4.6: a meeting with its date (not a closing, an approval or a successor)
RE_UPON_DEP = re.compile(r"\b(?:[Uu]pon|[Ff]ollowing|[Aa]fter|[Ee]ffective (?:upon|with))(?: the effectiveness of)? (?P<who>(?:(?:Mr|Ms|Mrs|Dr)\.\s+)?[A-Z][\w'\u2019.-]+(?: [A-Z][\w'\u2019.-]+)*)['\u2019]s? "
                         r"(?:departure|resignation|retirement|separation)\b")
RE_TIMING = re.compile(r"\b(?:effective|effect|upon|commenc\w*|beginning|starting|as of|following|when|until|through|succeed\w*|subject to|after|before|prior to|"
                       r"pending|once|at the (?:close|end|conclusion)|in each case|each|respectively|[0-9]{4})\b", re.I)   # 0.4.6: any other timing word (or another year)
RE_FOLLOW_DET = re.compile(rf"\b(?:This|The|These|Both|Such|Each|All|Their|His|Her|Those) (?:new |two |three )?(?P<noun>appointments?|elections?|promotions?|resignations?|retirements?|"
                           r"departures?|changes?|transitions?)(?: as [^,.;]{3,80}?)? (?:will become|becomes|became|will be|were|was|is|are|shall be|will take|took|takes?) "
                           rf"(?:effective|effect)(?: as of| on)?\s+(?P<raw>{SEM.DATE_ANY})")      # 0.4.6 (3rd review A10; paraphrases)
RE_FOLLOW_UP = re.compile(rf"(?P<who>\b(?:his|her|their|His|Her|Their)|(?:(?:Mr|Ms|Mrs|Dr)\.\s+)?[A-Z][\w'\u2019.-]+(?: [A-Z][\w'\u2019.-]+)*?)['\u2019]s?\s+"
                          r"(?:(?P<app>appointment|election|promotion|service as [^,.;]{3,80}? (?:will begin|begins|began|will commence|commences|commenced))|"
                          r"(?P<dep>resignation|retirement|departure|separation(?: from the (?:Company|Registrant))?|last day(?: of (?:employment|service))?(?: with the (?:Company|Registrant))?))"
                          rf"(?: as [^,.;]{{3,80}}?)?(?: (?:will become|becomes|became|will be|is|was|shall be|is expected to be)(?: effective)?(?: as of| on)?)\s+(?P<raw>{SEM.DATE_ANY})")


def _follow_up_date(text: str, r_: dict, det: dict, secs: list, kept: list):
    """0.4.6 (3rd review A10 / B09): a LATER sentence of the same section that dates this person's change - "Mr. X's appointment will become effective on
    D", "Ms. X's last day of employment will be D", "his resignation is effective D" (a pronoun only when this record is the only one in the section
    before it); the change word must be of the record's action; two different dates are ambiguous. Returns a date record, "AMBIGUOUS" or None."""
    end_ = r_["evidence_location"]["char_end"]
    sec = next((x for x in secs if x["start"] <= end_ <= x["end"]), None)
    if sec is None:
        return None
    found = {}
    for a2, b2 in sentences(text, end_, sec["end"]):
        for m in RE_FOLLOW_UP.finditer(text[a2:b2]):
            who = m.group("who")
            kind = "APPOINTMENT" if m.group("app") else "DEPARTURE"
            if kind != det["action"]:
                continue
            if who.lower() in ("his", "her", "their"):
                prior = [k for k in kept if k["evidence_location"]["char_start"] < a2 and k["evidence_location"]["char_start"] >= sec["start"]]
                if len({_n(k["details"]["person"]) for k in prior}) != 1:
                    continue
            elif not (_same(who.replace("Mr. ", "").replace("Ms. ", "").replace("Mrs. ", "").replace("Dr. ", ""), det["person"])
                      or SEM.surname(who) == SEM.surname(det["person"])):
                continue
            pd_ = SEM.parse_date(m.group("raw"))
            if pd_.get("state") == "VALID":
                found[pd_["value"]] = {"value": pd_["value"], "text": text[a2 + m.start():a2 + m.end()], "char_start": a2 + m.start(), "char_end": a2 + m.end(),
                                       "section": "Item 5.02"}
    nxt = next(iter(sentences(text, end_, sec["end"])), None)
    if nxt is not None and not text[end_:nxt[0]].strip(" .\n"):          # 'This appointment will be effective on D': only the very next sentence
        for m in RE_FOLLOW_DET.finditer(text[nxt[0]:nxt[1]]):
            noun = m.group("noun").lower()
            kind = "APPOINTMENT" if noun.startswith(("appointment", "election", "promotion")) else "DEPARTURE" if noun.startswith(("resignation", "retirement", "departure")) else None
            if kind not in (None, det["action"]):
                continue
            pd_ = SEM.parse_date(m.group("raw"))
            if pd_.get("state") == "VALID":
                found[pd_["value"]] = {"value": pd_["value"], "text": text[nxt[0] + m.start():nxt[0] + m.end()], "char_start": nxt[0] + m.start(),
                                       "char_end": nxt[0] + m.end(), "section": "Item 5.02"}
    if len(found) > 1:
        return "AMBIGUOUS"
    return next(iter(found.values())) if found else None


def as_of_status(det: dict, as_of: str, doc_ts: str | None) -> tuple[str, str]:
    """the status of a record at as_of, from the record's own dates only: (status, basis)"""
    a = as_of[:10]
    if det.get("modality") == "TENTATIVE":
        return "PENDING_INTENTION", "tentative wording: not decided"
    end = det.get("end_date") or {}
    if det.get("action") != "DEPARTURE" and end.get("state") == "VALID":           # 0.4.4 (review E6): also 'appointed ... to serve until D' / 'from D1 through D2'
        if det.get("effective_date") and det["effective_date"] > a:
            return "NOT_YET_EFFECTIVE", f"effective {det['effective_date']}, after as_of (until {end['value']})"
        return ("ENDED", f"ends {end['value']} ({end.get('raw')}), before as_of") if end["value"] < a else ("IN_EFFECT", f"runs until {end['value']}")
    eff = det.get("effective_date") or (det.get("linked_date") or {}).get("value")
    if eff:
        return ("IN_EFFECT", f"effective {eff}, on or before as_of") if eff <= a else ("NOT_YET_EFFECTIVE", f"effective {eff}, after as_of")
    if det.get("effective_immediately") and doc_ts and doc_ts[:10] <= a:
        return "IN_EFFECT", "effective immediately, document dated on or before as_of"
    if det.get("event_date") and det.get("event_date_sole_timing") and det.get("action") in ("DEPARTURE", "APPOINTMENT") and det["event_date"] <= a:
        return "IN_EFFECT", f"a completed change (past tense) dated {det['event_date']}; the sentence has no other timing words"     # 0.4.6 (3rd review M3)
    return "UNKNOWN", "no effective date stated for this change"


def _committee_split(role: str | None, text_after: str) -> tuple[list, str | None]:
    """a committee role that names several committees: ([one role per committee], note). Two committees each written with 'Committee' are split;
    a plural shared head ('the Audit and Compensation Committees') is split only when exactly two names are joined by one 'and'"""
    if not role or "Committee" not in role:
        return [role], None
    m = re.fullmatch(r"(?P<pre>(?:Member|Chair) of the )(?P<body>.+)", role)
    if not m:
        return [role], None
    body = m.group("body")
    parts = re.findall(r"((?:[A-Z][A-Za-z&]*,? (?:and )?)*?[A-Z][A-Za-z&]* Committee)", body)
    if len(parts) >= 2 and re.fullmatch(r"\s*" + r"\s*(?:,|and|, and)\s*".join(re.escape(x) for x in parts) + r"\s*", body):
        return [m.group("pre") + x.strip() for x in parts], None
    if text_after.startswith("s") and body.count(" and ") == 1 and "," not in body:      # plural shared head
        a_, b_ = body[:-len(" Committee")].split(" and ")
        return [f"{m.group('pre')}{a_} Committee", f"{m.group('pre')}{b_} Committee"], None
    if text_after.startswith("s"):
        return [role], "COMMITTEE_LIST_SPLIT_UNDETERMINED"
    return [role], None


def extract_8k(d: dict, as_of: str, registrant: str | None = None) -> tuple[dict, list, list, list]:
    """stages A and B: (metadata, records, notes, unresolved mentions)"""
    text = d["text"]
    secs = sections_of(text)
    meta = metadata_layer(secs)
    recs, notes, unresolved = [], [], []
    doc_known = []
    for a, b in sentences(text, 0, secs[0]["end"]):             # Q10: names in the preamble (e.g. an Explanatory Note) are known to the sections that follow
        doc_known.extend(x for x in SEM.analyse_sentence(text[a:b], {})["next_context"].get("known") or [] if x not in doc_known)
    defs = {}                                                  # Q11: 'effective July 16, 2026 (the "CEO Transition Date")' - a term defined as a calendar date
    for m in [*RE_DEFTERM.finditer(text), *RE_DEFTERM2.finditer(text), *RE_DEFTERM3.finditer(text), *RE_DEFTERM_MOVED.finditer(text)]:
        g_ = m.groupdict()
        term_, raw_ = (g_.get("term") or g_.get("term2") or "").strip(), g_.get("raw") or g_.get("raw2")
        dd = SEM.parse_date(raw_)
        if dd["state"] == "VALID" and re.search(r"\bDate$", term_):      # Q11: only a term that names a date ('the Annual Meeting' is an event)
            unsure = bool(RE_DEF_UNSURE.search(text[max(0, m.start() - 40):m.end() + 80]))      # 0.4.4 (review E9): 'or such other date as ...', 'on or before'
            defs.setdefault(term_, []).append({"value": dd["value"], "raw": raw_, "span": [m.start(), m.end()], "unsure": unsure,
                                                                 "section": next((("Item " + x["item_code"]) if x["item_code"] else "Explanatory Note / preamble")
                                                                                 for x in secs if x["start"] <= m.start() < x["end"])})
    secondary = []                                             # sentences of Item 7.01 / 8.01 and of the preamble
    for s in secs:
        if s["kind"] == "PREAMBLE" or (s["kind"] == "ITEM" and s["item_code"] in SECONDARY_ITEMS):
            for a, b in sentences(text, s["body_start"], s["end"]):
                secondary.append((a, b, "Explanatory Note / preamble" if s["kind"] == "PREAMBLE" else f"Item {s['item_code']}"))
    for s in secs:
        if s["kind"] == "ITEM" and s["item_code"] != "5.02":
            why = ("broad item: item metadata alone cannot support its event semantics (IDEC2); its sentences are read only to date an Item 5.02 event or for a change "
                   "of a person Item 5.02 does not cover (Q11)" if s["item_code"] in SECONDARY_ITEMS else
                   "broad item: item metadata alone cannot support its event semantics (IDEC2); the body is not interpreted" if s["item_code"] in INHERENTLY_AMBIGUOUS_ITEMS
                   else "guidance analysis is unavailable" if s["item_code"] == "2.02" else "no body rule for this item in this prototype")
            notes.append({"item_code": s["item_code"], **O.code("GUIDANCE_ANALYSIS_UNAVAILABLE" if s["item_code"] == "2.02" else "ITEM_NOT_INTERPRETED", f"Item {s['item_code']}", why)})
    issuers = []
    for m in re.finditer(r"(?P<org>(?:[A-Z][\w&\u2019'.-]*,? ){1,6}?(?:Inc|Corp|Co|LLC|Ltd|Corporation|Company|plc|Trust|Bancorp)?\.?)(?:,? an? [^()]{0,60}?)?\s*\("
                         r"(?:[\"\u201c](?P<short>[^\"\u201d]{2,40})[\"\u201d] or )?(?:the |collectively, the )?[\"\u201c](?:Company|Registrant|Corporation|Bank|Trust|Partnership)[\"\u201d]\)", text):
        issuers += [m.group("org").strip(" ,")] + ([m.group("short")] if m.group("short") else [])      # 0.4.4 (review E10) / 0.4.5 (2nd review N9)
    registrant = [x for x in [registrant] + [m.group(1).strip() for m in re.finditer(r"(?m)^[ \t]*([A-Z][^\n]{1,80}?)[ \t]*\n[ \t]*\(Exact name of (?:the )?registrant", text)] if x]
    issuers = list(dict.fromkeys(issuers + registrant))       # 0.4.6 (3rd review M1): the registrant's name (on file, and the cover page's 'Exact name of registrant') is the issuer
    orgs = list(dict.fromkeys(x for m in re.finditer(r"(?P<org>(?:[A-Z][\w&\u2019'.-]*,? ){1,6}?(?:Inc|Corp|Co|LLC|Ltd|Corporation|Company|plc|Holdings|Group|L\.P|LP)\.?),?\s*\((?:the )?[\"\u201c](?P<short>[A-Z][\w&\- ]{1,40})[\"\u201d]\)", text)
                              if m.group("short") not in ("Company", "Registrant", "Corporation", "Bank", "Trust", "Partnership") for x in (m.group("short"), m.group("org").strip(" ,"))))   # 0.4.4
    passes = [(s, "PRIMARY") for s in secs if s["kind"] == "SUPPRESSED" or (s["kind"] == "ITEM" and s["item_code"] == "5.02")] + \
             [(s, "SECONDARY") for s in secs if s["kind"] == "PREAMBLE" or (s["kind"] == "ITEM" and s["item_code"] in SECONDARY_ITEMS)]
    sec_events, sec_events_all = [], []
    for s, role_ in passes:
        ctx = {"known": list(doc_known), "issuers": issuers, "registrant": registrant, "orgs": orgs, "doc_year": (d.get("document_timestamp") or "")[:4] or None}   # Q10: full names named earlier in the document resolve a short form ('Mr. Watts') in a later section
        for a, b in sentences(text, s["body_start"], s["end"]):
            sent = text[a:b]
            sec_name = s["heading"][:60] if s["kind"] == "SUPPRESSED" else ("Explanatory Note / preamble" if s["kind"] == "PREAMBLE" else f"Item {s['item_code']}")
            r = SEM.analyse_sentence(sent, ctx)
            ctx = r["next_context"]
            doc_known.extend(x for x in ctx.get("known") or [] if x not in doc_known)
            if role_ == "SECONDARY" and not r["routine"]:
                sec_events_all.extend((a, b, sec_name, e) for e in r["events"])      # 0.4.5: every reading of 7.01 / 8.01 / the preamble, for date linking
            if role_ == "SECONDARY":                           # Q11: only events, kept for linking and for people Item 5.02 does not cover
                if not r["routine"] and not re.search(r"\b(?:previously (?:reported|announced|disclosed)|as previously|which reported|amends the Current Report|Amendment No\.)", sent, re.I):
                    for e in r["events"]:
                        sec_events.append((a, b, sec_name, e))
                continue
            if s["kind"] == "SUPPRESSED":
                if r["events"]:
                    notes.append({"rule_id": r["events"][0]["rule"], "span": [a, b], **O.code("SECTION_SUPPRESSED", sec_name, "wording inside a suppressed section is not interpreted")})
                continue
            for h in r["hazards"]:
                code = {"NEGATED": "EVENT_NEGATED", "HISTORICAL": "HISTORICAL_STATEMENT", "NON_FACTUAL": "NON_FACTUAL_STATEMENT",
                        "AMBIGUOUS_REFERENCE": "AMBIGUOUS_REFERENCE", "TEMPLATE": "DISCLOSURE_TEMPLATE_NOT_EVENT",
                        "ALREADY_HELD": "TITLE_ALREADY_HELD", "OTHER_COMPANY": "ROLE_AT_ANOTHER_COMPANY"}.get(h["kind"], "HISTORICAL_STATEMENT")      # Q11
                notes.append({"rule_id": "V2-HAZARD", "span": [a + h["span"][0], a + h["span"][1]], **O.code(code, sec_name, text[a + h["span"][0]:a + h["span"][1]][:80] +
                                                                                                      (f" ({h['role']})" if h.get("role") else ""))})
            sent_events = _sentence_records(d, as_of, r, a, b, sec_name, text, notes, rule_prefix="")
            covered = {_n(x["details"]["person"]) for x in sent_events} | {_n(h_["persons"][0]) for h_ in r["hazards"] if h_.get("kind") == "ALREADY_HELD" and h_.get("persons")}
            for u in r["unresolved"]:
                ua, ub = a + u["span"][0], a + u["span"][1]
                left = [p_ for p_ in u["persons"] if not any(_same(p_, c) for c in covered)]
                if u["persons"] and not left and u["why"].startswith("a named person not resolved"):   # 0.4.4 (review E12): only the catch-all; a pronoun / subject-less clause stays
                    notes.append({"rule_id": "V2-UNRESOLVED", "span": [ua, ub], **O.code("UNRESOLVED_COVERED_BY_EVENT", sec_name, ", ".join(u["persons"])[:80])})
                    continue
                unresolved.append({"document_id": d["document_id"], "span": [ua, ub], "text": text[ua:ub], "persons": left or u["persons"], "roles": u.get("roles") or [],
                                   "why": u["why"], "kind": u.get("kind"), "persons_with_a_shown_event_omitted": [p_ for p_ in u["persons"] if p_ not in left]})
                notes.append({"rule_id": "V2-UNRESOLVED", "span": [ua, ub], **O.code("UNRESOLVED_MENTION", sec_name, ", ".join(left or u["persons"])[:80])})
            recs.extend(sent_events)
    roled = {}
    for r_ in recs:
        if r_["details"].get("role") and "Committee" not in str(r_["details"]["role"]):      # a committee is another change
            roled.setdefault((r_["details"]["action"], _n(r_["details"]["person"])), set()).add(r_["details"].get("effective_date"))
    for r_ in [x for x in recs if not x["details"].get("role") and x["details"]["modality"] != "TENTATIVE" and (x["details"]["action"], _n(x["details"]["person"])) in roled
               and (x["details"].get("effective_date") is None or x["details"].get("effective_date") in roled[(x["details"]["action"], _n(x["details"]["person"]))])]:   # 0.4.4 (review E14)
        recs.remove(r_)                                       # Q11: a role-less mention of a person whose same change has a role elsewhere in the document
        notes.append({"rule_id": r_["extraction_method"]["rule_id"], "span": [r_["evidence_location"]["char_start"], r_["evidence_location"]["char_end"]],
                      **O.code("DUPLICATE_EVENT_MERGED", "Item 5.02", f"{r_['details']['action']} {r_['details']['person']} (no role; the role is stated elsewhere)")})
    kept = []                                                 # Q10: the same person, action, role and date stated again in another sentence: one event
    for r_ in recs:
        d_ = r_["details"]
        twin = next((k for k in kept if (k["details"]["action"], _n(k["details"]["person"]), _n(k["details"]["role"]), k["details"]["modality"])
                     == (d_["action"], _n(d_["person"]), _n(d_["role"]), d_["modality"]) and d_["role"] is not None
                     and (k["details"]["effective_date"] == d_["effective_date"] or d_["effective_date"] is None)), None)   # never two different dates
        if twin is None and d_["role"] is not None and d_["effective_date"] is not None:   # an undated earlier mention of the same event: the dated one is kept
            twin_u = next((k for k in kept if (k["details"]["action"], _n(k["details"]["person"]), _n(k["details"]["role"]), k["details"]["modality"])
                           == (d_["action"], _n(d_["person"]), _n(d_["role"]), d_["modality"]) and k["details"]["effective_date"] is None), None)
            if twin_u is not None:
                kept[kept.index(twin_u)] = r_
                r_["details"].setdefault("further_mentions", []).append(twin_u["evidence_location"])
                notes.append({"rule_id": d_.get("item_code"), "span": [twin_u["evidence_location"]["char_start"], twin_u["evidence_location"]["char_end"]],
                              **O.code("DUPLICATE_EVENT_MERGED", "Item 5.02", f"{d_['action']} {d_['person']} {d_['role']}")})
                continue
        if twin:
            twin["details"].setdefault("further_mentions", []).append(r_["evidence_location"])
            notes.append({"rule_id": d_.get("item_code"), "span": [r_["evidence_location"]["char_start"], r_["evidence_location"]["char_end"]],
                          **O.code("DUPLICATE_EVENT_MERGED", "Item 5.02", f"{d_['action']} {d_['person']} {d_['role']}")})
            continue
        kept.append(r_)
    for r_ in [x for x in kept if x["details"]["action"] == "APPOINTMENT" and x["details"].get("role")]:      # 0.4.5: '..., a role he has held since 2021' / 'He has held the role of COO since 2021'
        d_ = r_["details"]
        a0, b0 = r_["evidence_location"]["char_start"], r_["evidence_location"]["char_end"]
        win = text[a0:min(len(text), b0 + 400)]
        who = rf"(?:{re.escape(d_['person'])}|(?:Mr|Ms|Mrs|Dr)\.\s+{re.escape(SEM.surname(d_['person']))}|\b(?:he|she|He|She)\b)"
        rr = re.escape(d_.get("role_as_written") or d_["role"])
        held_ = re.search(rf"{who}[^.;]{{0,30}}\b(?:has|have) (?:held|been (?:serving|acting) as|served as|been the)\b[^.;]{{0,40}}\b{rr}\b[^.;]{{0,30}}\bsince (?:19|20)[0-9]{{2}}", win) \
            or re.search(rf"\b{rr},? a (?:role|position|title) (?:he|she|they) (?:has|have) held since (?:19|20)[0-9]{{2}}", win)
        if held_ and not re.search(r"\b(?:interim|acting)\b", held_.group(0), re.I):
            kept.remove(r_)
            notes.append({"rule_id": r_["extraction_method"]["rule_id"], "span": [a0, b0], **O.code("TITLE_ALREADY_HELD", "Item 5.02", f"{d_['person']}: {d_['role']} (held since: {held_.group(0)[:60]})")})
    for r_ in [x for x in kept if x["details"].get("implied_by_succession")]:      # 0.4.5: an implied departure gives way to a stated one of the same title
        d_ = r_["details"]
        if any(k is not r_ and not k["details"].get("implied_by_succession") and _same(k["details"]["person"], d_["person"])
               and _rkey(k["details"].get("role")) == _rkey(d_.get("role")) for k in kept):     # any stated record of that person and title (a departure, or 'continue ... until')
            kept.remove(r_)
            notes.append({"rule_id": r_["extraction_method"]["rule_id"], "span": [r_["evidence_location"]["char_start"], r_["evidence_location"]["char_end"]],
                          **O.code("DUPLICATE_EVENT_MERGED", "Item 5.02", f"implied departure of {d_['person']} ({d_['role']}): the document states it")})
    # ---- Q11: dates linked with their evidence (a defined term; another section's sentence; 'the same date'); never two different dates
    for r_ in kept:
        det = r_["details"]
        if det["effective_date"] or det["modality"] == "TENTATIVE":
            continue
        cl = r_["evidence_location"].get("clause_offsets") or [r_["evidence_location"]["char_start"], r_["evidence_location"]["char_end"]]
        ctext = text[cl[0]:cl[1]]
        hit = [(t, v) for t, vs in defs.items() for v in vs                                  # Q11: the term must be the clause's effective date ('effective as of / on / upon / commencing on')
               if re.search(rf"\b(?:[Ee]ffective (?:as of |on |upon )?|commencing (?:on )?|beginning (?:on )?|(?<![Aa]fter )(?<![Uu]ntil )(?:[Oo]n|[Aa]s of|[Uu]pon) )(?:the )?{re.escape(t)}\b", ctext)
               or re.search(rf"\bon a date to be (?:designated|determined)[^()]{{0,60}}\((?:the )?[\"“]{re.escape(t)}[\"”]\)", ctext)]     # Q11: '... on a date to be designated (the "Succession Date")'
        if hit and any(v.get("unsure") for _, v in hit):
            notes.append({"rule_id": "Q11-DATE-LINK", "span": cl, **O.code("DATE_LINK_AMBIGUOUS", "Item 5.02", f"{det['person']}: the term's date is not fixed ('or such other date', 'on or before')")})
            det["date_link_ambiguous"] = True
            continue
        if len({v["value"] for _, v in hit}) == 1:
            t, v = hit[0]
            det.update(effective_date=v["value"], effective_date_state="VALID", effective_date_raw=f"the {t} = {v['raw']}", date_basis="DEFINED_TERM",
                       date_evidence={"text": text[v["span"][0]:v["span"][1]], "char_start": v["span"][0], "char_end": v["span"][1], "section": v["section"],
                                      "defined_term": t})
            continue
        if len({v["value"] for _, v in hit}) > 1:
            notes.append({"rule_id": "Q11-DATE-LINK", "span": cl, **O.code("DATE_LINK_AMBIGUOUS", "Item 5.02", f"{det['person']}: the term has two dates")})
            det["date_link_ambiguous"] = True
            continue
        if det.get("role") and det.get("effective_date_state") not in ("UNREADABLE", "INVALID"):
            cands, ev = {}, None                              # 0.4.5 (2nd review N1): another section dates a record only when ITS OWN reading is the same change -
            for a2, b2, sname, e2 in sec_events_all:          # the same person, the same action (or a move into the same title), the same title, asserted, with a
                dd2 = e2.get("date") or {}                   # date written for that change (not a date of another statement / company in the sentence)
                if not (_same(e2["person"], det["person"]) and e2.get("role") and _rkey(e2["role"]) == _rkey(det["role"]) and e2.get("modality") == "ASSERTED"
                        and (e2["action"] == det["action"] or {e2["action"], det["action"]} == {"APPOINTMENT", "CONTINUATION"})):
                    continue
                if dd2.get("state") != "VALID" or dd2.get("basis") not in ("EFFECTIVE_EXPLICIT", "ON_ADJACENT") or _too_old(dd2["value"], d.get("document_timestamp")) \
                        or RE_SEC_COND.search(text[a2:b2]):
                    continue
                sp2 = dd2.get("span") or [0, 0]
                cands[dd2["value"]] = {"text": text[a2 + sp2[0]:a2 + sp2[1]] if dd2.get("span") else dd2.get("raw"), "char_start": a2 + sp2[0], "char_end": a2 + sp2[1], "section": sname}
            if len(cands) == 1:
                v2, ev = next(iter(cands.items()))
                det.update(effective_date=v2, effective_date_state="VALID", effective_date_raw=ev["text"], date_basis="OTHER_SECTION", date_evidence=ev)
                continue
            if len(cands) > 1:
                notes.append({"rule_id": "Q11-DATE-LINK", "span": cl, **O.code("DATE_LINK_AMBIGUOUS", "Item 5.02", f"{det['person']}: other sections give two dates")})
                continue
        so_ = r_["evidence_location"].get("sentence_text_offsets") or cl
        aw_ = [m for m in RE_AT_WHICH.finditer(text[so_[0]:cl[1]]) if SEM.surname(det["person"]) in text[so_[0] + m.end():so_[0] + m.end() + 40]]   # the person is the subject right after it
        if aw_ and SEM.parse_date(aw_[-1].group("raw")).get("state") == "VALID":
            v_ = SEM.parse_date(aw_[-1].group("raw"))["value"]
            det["linked_date"] = {"value": v_, "basis": "SAME_DATE_REFERENCE", "refers_to_record": None, "words": "at which time", "date_text": aw_[-1].group("raw"),
                                  "date_char_start": so_[0] + aw_[-1].start(), "note": "the text says 'at which time' right after a date; it is read as that date - shown as a reference"}
            continue
        up_ = RE_UPON_DEP.search(text[so_[0]:cl[1]])
        if up_ and det["action"] in ("APPOINTMENT", "CONTINUATION") and not _same(up_.group("who"), det["person"]):   # 0.4.6 (3rd review D04): 'Upon Mr. X's departure, Y will ...'
            w_ = re.sub(r"^(?:Mr|Ms|Mrs|Dr)\.\s+", "", up_.group("who"))
            dep_ = [k for k in kept if k["details"]["action"] == "DEPARTURE" and (_same(w_, k["details"]["person"]) or SEM.surname(w_) == SEM.surname(k["details"]["person"]))
                    and k["details"].get("effective_date")]
            if len({k["details"]["effective_date"] for k in dep_}) == 1:
                det["linked_date"] = {"value": dep_[0]["details"]["effective_date"], "basis": "SAME_DATE_REFERENCE", "refers_to_record": dep_[0]["record_id"],
                                      "words": up_.group(0), "date_text": dep_[0]["details"].get("effective_date_raw"), "date_char_start": None,
                                      "note": f"the text ties this change to {dep_[0]['details']['person']}'s departure; it is read as that departure's date - shown as a reference"}
                det["date_link_inferred"] = True              # a date inferred from another change: flagged, never certain
                continue
        an_ = RE_ANCHORED.search(ctext)
        if an_ and SEM.parse_date(an_.group("raw")).get("state") == "VALID":      # 0.4.6 (3rd review A08 / E05): 'effective upon the conclusion of the meeting on D'
            v_ = SEM.parse_date(an_.group("raw"))["value"]
            det.update(effective_date=v_, effective_date_state="VALID", effective_date_raw=an_.group(0), date_basis="EVENT_ANCHORED_DATE",
                       date_evidence={"text": an_.group(0), "char_start": cl[0] + an_.start(), "char_end": cl[0] + an_.end(), "section": "Item 5.02"})
            continue
        fu_ = _follow_up_date(text, r_, det, secs, kept)
        if fu_ == "AMBIGUOUS":
            notes.append({"rule_id": "Q11-DATE-LINK", "span": cl, **O.code("DATE_LINK_AMBIGUOUS", "Item 5.02", f"{det['person']}: later sentences give two dates")})
            det["date_link_ambiguous"] = True
            continue
        if fu_:
            det.update(effective_date=fu_["value"], effective_date_state="VALID", effective_date_raw=fu_["text"], date_basis="FOLLOW_UP_SENTENCE", date_evidence=fu_)
            continue
        sm_ = RE_SAME_DATE.search(ctext)
        if sm_:
            ref_at = cl[0] + sm_.start()
            sec_start = next((x["body_start"] for x in secs if x["start"] <= ref_at < x["end"]), 0)
            prev_d = [m for m in re.finditer(SEM.DATE_ANY, text[sec_start:ref_at])
                      if not re.search(r"\b(?:joined|since|born|founded|from|between|until|through|aged?|in|who [^,]{0,60})\s+(?:the Company\s+)?(?:on\s+)?$", text[sec_start:sec_start + m.start()][-70:])
                      and not re.search(r",\s*who\b[^,]*$", text[sec_start:sec_start + m.start()][-120:])]     # 0.4.5 (2nd review N5): not a biography / relative-clause date
            sent_start = max(text.rfind(". ", sec_start, ref_at - 2), sec_start)
            last_sent = [m for m in prev_d if sec_start + m.start() >= text.rfind(". ", sec_start, sent_start) + 1]
            if len({SEM.parse_date(m.group(0)).get("value") for m in last_sent}) > 1 and not any(sec_start + m.start() > sent_start for m in prev_d):
                notes.append({"rule_id": "Q11-DATE-LINK", "span": cl, **O.code("DATE_LINK_AMBIGUOUS", "Item 5.02", f"{det['person']}: 'the same date' could be either of two dates")})
                det["date_link_ambiguous"] = True
                prev_d = []
            pd_ = SEM.parse_date(prev_d[-1].group(0)) if prev_d else {"state": "NONE"}
            if pd_["state"] == "VALID":                          # 0.4.4 (review E8): the date the words refer to - the one written last before them
                k = next((k for k in kept if k["details"].get("effective_date") == pd_["value"] and k is not r_), None)
                det["linked_date"] = {"value": pd_["value"], "basis": "SAME_DATE_REFERENCE", "refers_to_record": k["record_id"] if k else None,
                                      "words": sm_.group(0), "date_text": prev_d[-1].group(0), "date_char_start": sec_start + prev_d[-1].start(),
                                      "note": "the text says 'the same date' / 'that date'; it is read as the date written last before these words - shown as a reference, not as a stated date"}
    # ---- Q11: a change stated only in Item 7.01 / 8.01 / the preamble, of a person no Item 5.02 record covers
    for a, b, sname, e in sec_events:
        if any(_same(k["details"]["person"], e["person"]) for k in kept) or e["role"] is None:
            continue
        st_ = text[a:b]
        if RE_SEC_COND.search(st_) or (e.get("date") or {}).get("value") and _too_old(e["date"]["value"], d.get("document_timestamp")) \
                or (re.search(r"\b(?:appointed|named|elected|hired|promoted|become|becomes|serve as)\b[^.]{0,160}\b(?:as )?(?:its|their)\b", st_) and not re.match(r"^\s*(?:The |Our |the )?(?:Board|Company|Registrant)\b", st_)):   # 0.4.5 (2nd review N9): 'named Jane Doe its CFO', 'will become its CEO'
            notes.append({"rule_id": e["rule"], "span": [a, b], **O.code("OTHER_ITEM_SENTENCE_NOT_USED", sname, f"{e['person']}: conditional, forward-looking, historical or another company's change")})
            continue
        recs2 = _sentence_records(d, as_of, {"events": [e]}, a, b, sname, text, notes, rule_prefix="Q11-OTHER-ITEM:")
        for r2 in recs2:
            r2["details"]["item_code"] = sname.replace("Item ", "") if sname.startswith("Item ") else "PREAMBLE"
            notes.append({"rule_id": r2["extraction_method"]["rule_id"], "span": [r2["evidence_location"]["char_start"], r2["evidence_location"]["char_end"]],
                          **O.code("EVENT_FROM_OTHER_ITEM", sname, f"{e['action']} {e['person']}: stated in {sname} (no Item 5.02 record of this person)")})
            kept.append(r2)
    for r_ in kept:                                            # Q11: the status at as_of (separate from the evidence status) and the claim's wording
        st, why = as_of_status(r_["details"], as_of, d.get("document_timestamp"))
        dr = r_["details"]
        own = dr.get("effective_date") or (dr.get("linked_date") or {}).get("value")
        own_ev = own or dr.get("event_date") or dr.get("narrative_date")      # 0.4.5 (2nd review N4c): the decision date when no effective date is stated
        def _eff(k):
            return k["details"].get("effective_date") or (k["details"].get("linked_date") or {}).get("value")
        if dr["action"] == "APPOINTMENT" and st in ("IN_EFFECT", "UNKNOWN"):
            later = [k for k in kept if k["details"]["action"] == "DEPARTURE" and _same(k["details"]["person"], dr["person"])
                     and _n(k["details"].get("role")) == _n(dr.get("role")) and k["details"].get("modality") == "ASSERTED"
                     and (_eff(k) or "9999") <= as_of[:10]
                     and ((_eff(k) >= own_ev) if (own_ev and _eff(k)) else k["evidence_location"]["char_start"] > r_["evidence_location"]["char_start"])]   # 0.4.4 (review E2) / 0.4.5
            if later:
                st, why = "ENDED", f"the document says this title ended ({later[0]['record_id']})"
            base_ = re.sub(r"^(?:[Ii]nterim|[Aa]cting) ", "", str(dr.get("role") or ""))
            if st in ("IN_EFFECT", "UNKNOWN") and base_ != str(dr.get("role") or ""):     # 0.4.4 (review E6): an interim / acting title ends when another person's permanent one takes effect
                succ = [k for k in kept if k["details"]["action"] == "APPOINTMENT" and not _same(k["details"]["person"], dr["person"]) and _n(k["details"].get("role")) == _n(base_)
                        and k["details"].get("modality") == "ASSERTED" and _eff(k) and _eff(k) <= as_of[:10]
                        and ((_eff(k) >= own_ev) if own_ev else k["evidence_location"]["char_start"] > r_["evidence_location"]["char_start"])]     # 0.4.5 (2nd review N4b)
                if succ:
                    st, why = "ENDED", f"{succ[0]['details']['person']} took the permanent title effective {_eff(succ[0])} ({succ[0]['record_id']})"
        if dr["action"] == "CONTINUATION" and st in ("IN_EFFECT", "UNKNOWN") and (dr.get("end_date") or {}).get("state") == "RELATIVE" \
                and re.search(r"successor", str((dr.get("end_date") or {}).get("raw"))):         # 0.4.4 (review E6): '... until her successor is appointed'
            succ = [k for k in kept if k["details"]["action"] == "APPOINTMENT" and not _same(k["details"]["person"], dr["person"]) and _n(k["details"].get("role")) == _n(dr.get("role"))
                    and k["details"].get("modality") == "ASSERTED" and _eff(k) and _eff(k) <= as_of[:10]]
            if succ:
                st, why = "ENDED", f"the successor {succ[0]['details']['person']} took the title effective {_eff(succ[0])} ({succ[0]['record_id']})"
                dr["ended_by_successor"] = {"person": succ[0]["details"]["person"], "effective": _eff(succ[0])}
        r_["details"]["as_of_status"], r_["details"]["as_of_status_basis"] = st, why
        if r_["details"].get("date_link_ambiguous") or r_["details"].get("date_link_inferred"):   # 0.4.4 (review E9): the date the text points to is not fixed; 0.4.6: or is inferred from another change
            r_["ambiguity_status"] = "AMBIGUOUS"
        r_["claim"] = _claim(r_["details"], r_["claim"])
    return meta, kept, notes, unresolved


def _claim(det: dict, old: str) -> str:
    """the readable claim, with the date's basis and the status at as_of when they matter"""
    p, role, act = det["person"], det.get("role"), det["action"]
    if det.get("modality") == "TENTATIVE":
        return old
    st = det.get("as_of_status")
    end = det.get("end_date") or {}
    if act == "CONTINUATION":
        what = f"{p} continues to serve as {role}" if role else f"The document says {p} remains with the Company, without naming a titled role"
        if end.get("state") == "VALID":
            if st == "ENDED":
                how_ = (f"with the Company in a {role}" if det.get("transition_role") and role and re.search(r"(?:role|capacity|position)$", role) else
                        "as " + role if role else "with the Company (no titled role)")
                return (f"The document says {p} would remain {how_} through {end['value']} ({end.get('raw')}); that period ended before the as-of date.")
            return f"{what} through {end['value']} ({end.get('raw')})."
        if end.get("state") == "RELATIVE":
            if st == "ENDED" and det.get("ended_by_successor"):
                es = det["ended_by_successor"]
                return (f"The document says {p} would remain {'as ' + role if role else 'with the Company'} until {end.get('raw')}; the successor {es['person']} "
                        f"took the title effective {es['effective']}, so that period ended before the as-of date.")
            return f"{what} {('until ' + end.get('raw')) if end.get('raw') else ''}.".replace(" .", ".")
        return old
    if not role:
        return old
    verb = {"DEPARTURE": "is leaving the role of", "APPOINTMENT": "is appointed"}[act]
    basis = det.get("date_basis")
    if det.get("effective_date") and basis == "DEFINED_TERM":
        ev = det.get("date_evidence") or {}
        txt = f"{p} {verb} {role}, effective {det['effective_date']} (the “{ev.get('defined_term')}” as defined in {ev.get('section')})"
    elif det.get("effective_date") and basis == "OTHER_SECTION":
        txt = f"{p} {verb} {role}, effective {det['effective_date']} (date stated in {(det.get('date_evidence') or {}).get('section')})"
    elif det.get("linked_date"):
        txt = f"{p} {verb} {role}, effective on the same date as the preceding change ({det['linked_date']['value']})"
    else:
        txt = old.rstrip(".")
    tail = " (not yet effective at the as-of date)." if st == "NOT_YET_EFFECTIVE" else \
        f" (this role had ended by the as-of date: {det.get('as_of_status_basis')})." if (st == "ENDED" and act == "APPOINTMENT") else "."
    return txt.rstrip(".") + tail


def _sentence_records(d: dict, as_of: str, r: dict, a: int, b: int, sec_name: str, text: str, notes: list, rule_prefix: str) -> list:
    """the records of one analysed sentence (Q10 logic, moved here so that Item 7.01 / 8.01 / preamble events use the same form)"""
    out = []
    events = []
    for e in r["events"]:                                  # merge identical events and a role-less duplicate of a resolved one
        key = (e["action"], _n(e["person"]), _n(e["role"]))
        dup = next((x for x in events if (x["action"], _n(x["person"]), _n(x["role"])) == key or
                    (e["role"] is None and x["action"] == e["action"] and _n(x["person"]) == _n(e["person"]))), None)
        if dup:
            notes.append({"rule_id": e["rule"], "span": [a + e["pred"][0], a + e["pred"][1]], **O.code("DUPLICATE_MATCH_MERGED", sec_name, f"{e['action']} {e['person']}")})
            continue
        events.append(e)
    if r.get("routine"):
        keep = []
        for e in events:
            if e["action"] in ("APPOINTMENT", "DEPARTURE"):
                notes.append({"rule_id": e["rule"], "span": [a, b], **O.code("ROUTINE_ELECTION_EXCLUDED", sec_name, "an annual-meeting election or re-election is not a management change")})
            else:
                keep.append(e)
        events = keep
    split = []                                             # Q11: one record per committee
    for e in events:
        parts, cnote = _committee_split(e["role"], text[a + e["role_end"]:a + e["role_end"] + 2] if e.get("role_end") is not None else "")
        if cnote:
            notes.append({"rule_id": e["rule"], "span": [a, b], **O.code(cnote, sec_name, f"{e['person']}: {e['role']}")})
        for k_, rp in enumerate(parts):
            split.append({**e, "role": rp, "committee_list_undetermined": bool(cnote)} if len(parts) > 1 or cnote else e)
    events = split
    single = len(events) == 1
    for k, e in enumerate(events):
        dt = e["date"]
        if dt.get("basis") == "EVENT_DATE":            # Q10 acceptance correction: a sentence-initial 'On DATE,' dates the statement; it is not an effective date
            dt = {**dt, "value": None, "state": "NOT_STATED", "event_date": dt.get("event_date") or dt.get("value")}
        whole = single or e["subject_kind"] in ("INHERITED", "PRONOUN")      # an inherited / pronoun subject is named elsewhere in the sentence: cite the sentence
        sa, sb = (a, b) if whole else (a + e["clause"][0], a + e["clause"][1])
        loc = {"section": sec_name, "sentence_text_offsets": [a, b], "span_scope": "sentence" if whole else "event clause",
               "clause_offsets": [a + e["clause"][0], a + e["clause"][1]]}
        date_bad = dt["state"] in ("INVALID", "UNREADABLE")
        ambiguous = e["modality"] == "TENTATIVE" or e["role"] is None or e.get("committee_list_undetermined") or e.get("transition_role") or e.get("restated") \
            or e.get("implied_by_succession") or e.get("rule") == "V2-DEP-NSR"      # 0.4.6: not standing for re-election - the seat ends at the meeting (flagged, as the annotations read it)
        clause_txt = text[a + e["clause"][0]:a + e["clause"][1]]
        details = {"action": e["action"], "person": e["person"], "role": e["role"], "role_as_written": e["role_text"], "effective_date": dt["value"],
                   "effective_date_state": dt["state"], "effective_date_raw": dt.get("raw"), "item_code": "5.02",
                   "date_evidence": ({"text": text[a + dt["span"][0]:a + dt["span"][1]], "char_start": a + dt["span"][0], "char_end": a + dt["span"][1]}
                                     if dt.get("span") else None),
                   "subject_reference": {"kind": e["subject_kind"], "spans": [[a + x, a + y] for x, y in e["subject_spans"]]},
                   "polarity": "AFFIRMED", "modality": e["modality"], "clause_index": e["clause_index"],
                   "event_date": dt.get("event_date"), "narrative_date": dt.get("narrative_date"), "date_basis": dt.get("basis", "NONE"),
                   "event_date_sole_timing": bool(dt.get("event_date")) and not RE_TIMING.search(re.sub(rf"^\s*(?:On|As of) {SEM.DATE_ANY},", "", text[a:b]))
                                             and not re.search(r"\b(?:effective|effect)\b", text[slice(*next(iter(sentences(text, b, min(len(text), b + 600))), (b, b)))], re.I),   # 0.4.6: this sentence and the next
                   "pairing": e.get("pairing"), "role_basis": e.get("role_basis"), "end_date": e.get("end"), "held_titles": e.get("held_titles") or [],
                   "effective_immediately": bool(re.search(r"\beffective immediately\b(?!,?\s+(?:upon|following|after|prior to|before|preceding|at|on|when|once|as of|subject|in connection with|conditioned|contingent|if|pending))", clause_txt, re.I)),
                   "section": sec_name,
                   "transition_role": bool(e.get("transition_role")), "previously_reported": bool(e.get("restated")),
                   "implied_by_succession": e.get("implied_by_succession")}
        if dt.get("note"):
            notes.append({"rule_id": e["rule"], "span": [sa, sb], **O.code("DATE_OWNERSHIP_AMBIGUOUS", sec_name, f"{e['person']}: two dates could belong to the clause")})
        if date_bad:
            notes.append({"rule_id": e["rule"], "span": [sa, sb], **O.code("EFFECTIVE_DATE_INVALID" if dt["state"] == "INVALID" else "EFFECTIVE_DATE_UNREADABLE", sec_name,
                                                                 f"{dt.get('raw')!r}: the event is asserted with this date state; no date is substituted")})
        vb = {"DEPARTURE": ("may leave", "is leaving a role"), "APPOINTMENT": ("may be appointed", "is appointed"), "CONTINUATION": ("may continue", "continues to serve")}[e["action"]]
        if e["modality"] == "TENTATIVE":
            claim = f"The document says {e['person']} {vb[0]}{' (' + e['role'] + ')' if e['role'] else ''} (tentative wording; not stated as decided)."
            basis = f"rule {e['rule']}: tentative wording in the event's own clause; the event is not determinable"
        elif e["role"] is None:
            claim = f"The document says {e['person']} {vb[1]}, without naming the role." if not e.get("pairing") else \
                f"The document says {e['person']} {vb[1]}; which of the named roles is not stated."
            basis = f"rule {e['rule']}: " + ("persons and roles are not paired (no 'respectively')" if e.get("pairing") else "the role is not identified in the clause")
        else:
            verb = {"DEPARTURE": "is leaving the role of", "APPOINTMENT": "is appointed", "CONTINUATION": "continues to serve as"}[e["action"]]
            claim = f"{e['person']} {verb} {e['role']}" + (f", effective {dt['value']}" if dt["value"] else f" (effective date {dt['state'].lower()})" if date_bad else
                                                            f" (the filing dates this {dt['event_date']}; no effective date is stated as a calendar date)" if dt.get("event_date") else "") + "."
            basis = (f"rule {e['rule']}: subject {e['subject_kind']} in clause {e['clause_index']}; not negated; not tentative; person and role identified; "
                     f"effective date {dt['state'].lower().replace('_', ' ')} (clause-owned)")
        if e.get("transition_role") and e["modality"] != "TENTATIVE":     # Q11 0.4.3
            end_ = e.get("end") or {}
            claim = (f"{e['person']} stays with the Company in a non-officer transition role ({e['role']})"
                     + (f" through {end_['value']} ({end_.get('raw')})" if end_.get("state") == "VALID" else "") + "; whether this is a management role is not determined.")
            notes.append({"rule_id": e["rule"], "span": [sa, sb], **O.code("NON_OFFICER_TRANSITION_ROLE", sec_name, f"{e['person']}: {e['role']}")})
        if e.get("implied_by_succession") and e["modality"] != "TENTATIVE":     # 0.4.5: the departure is implied, not stated
            claim = claim.rstrip(".") + f" (implied: {e['implied_by_succession']} is to succeed {e['person']}; the departure itself is not stated separately)."
            notes.append({"rule_id": e["rule"], "span": [sa, sb], **O.code("DEPARTURE_IMPLIED_BY_SUCCESSION", sec_name, f"{e['person']}: {e['role']}")})
        if e.get("restated"):                                # Q11 0.4.3: 'As previously reported, ...' - an earlier report restated, not shown as a new change
            claim = "As previously reported (a restatement in this filing): " + claim
            notes.append({"rule_id": e["rule"], "span": [sa, sb], **O.code("PREVIOUSLY_REPORTED_EVENT", sec_name, f"{e['person']}: {e['role']}")})
        if e.get("committee_list_undetermined"):
            claim = f"The document says {e['person']} joins Board committees ({e['role']}); how the list splits into committees is not determined."
        rec = _record(d, as_of, "MANAGEMENT_CHANGE" if e["action"] != "CONTINUATION" else "MANAGEMENT_STATUS_STATEMENT", claim, sa, sb, loc, rule_prefix + e["rule"], basis,
                      "AMBIGUOUS" if ambiguous else "UNAMBIGUOUS", details)
        rec["record_id"] = f"{d['document_id']}#{rule_prefix}{e['rule']}#{sa}#{k}"
        out.append(rec)
    return out


def extract_form4(d: dict, as_of: str, avail: datetime) -> tuple[list, list]:
    text = d["text"]
    recs, notes, owners, foot, filing_flag, rows = [], [], [], {}, None, []
    pos = 0
    for line in text.split("\n"):
        a, b = pos, pos + len(line)
        pos = b + 1
        parts = line.split("|")
        kind = parts[0]
        if kind == "ISSUER" and len(parts) == 2:
            if parts[1] != d["issuer_id"]:
                notes.append(O.code("DOCUMENT_ISSUER_MISMATCH", "ISSUER line", f"{parts[1]} vs {d['issuer_id']}"))
                return [], notes
        elif kind == "OWNER" and len(parts) == 3:
            owners.append({"name": parts[1], "role": parts[2]})
        elif kind == "FOOTNOTE" and len(parts) == 3:
            foot[parts[1]] = (parts[2], a, b)
        elif kind == "FILING-10B5-1-FLAG" and len(parts) == 2:
            filing_flag = parts[1] if parts[1] in ("TRUE", "FALSE") else None
        elif kind == "TXN":
            rows.append((parts, a, b))
    for parts, a, b in rows:
        bad = None
        if len(parts) != 12:
            bad = "a TXN line has 12 fields"
        else:
            _, idx, tdate, sec, codech, ad, shares, price, after, own, fids, rflag = parts
            num = lambda s: float(s) if re.fullmatch(r"-?[0-9]{1,15}(?:\.[0-9]{1,6})?", s) else None  # noqa: E731  post-review R-07: at most 15 integer digits
            if not re.fullmatch(r"[0-9]+", idx) or schema.parse_date(tdate) is None:
                bad = "index or transaction date invalid"
            elif not re.fullmatch(r"[A-Z]", codech) or ad not in ("A", "D") or own not in ("D", "I") or rflag not in ("TRUE", "FALSE", "-"):
                bad = "code, acquired/disposed, ownership or row flag invalid"
            elif any(x != "-" and re.fullmatch(r"-?[0-9]+(?:\.[0-9]+)?", x) and num(x) is None for x in (shares, price, after)):
                bad = "a number is not representable safely (more than 15 integer digits or 6 decimals)"
            elif num(shares) is None or num(shares) <= 0:
                bad = "shares must be a positive number"
            elif (price != "-" and (num(price) is None or num(price) < 0)) or (after != "-" and (num(after) is None or num(after) < 0)):
                bad = "price or shares after the transaction invalid"
            elif codech == "P" and ad != "A" or codech == "S" and ad != "D":
                bad = "a purchase must be an acquisition and a sale a disposition"
            elif fids != "-" and any(f not in foot for f in fids.split(",")):
                bad = "a referenced footnote is missing"
        if bad:
            notes.append({"span": [a, b], **O.code("FORM4_ROW_INVALID", f"{d['document_id']} line at {a}", bad)})
            recs.append(_record(d, as_of, "INSIDER_TRANSACTION", "Invalid transaction row: not used.", a, b, {"section": "Form 4 table"}, "F4-ROW-INVALID",
                                f"row rejected: {bad}", "NOT_VERIFIABLE", {"reason": bad}))
            continue
        ttype = FORM4_CODE_TO_TYPE.get(codech, "OTHER_TRANSACTION_TYPE")
        sh, pr = float(shares), (float(price) if price != "-" else None)
        if avail.date() < date.fromisoformat(TEN_B5_1_APPLICABLE_FROM):
            t5, basis5, span5 = "NOT_APPLICABLE", f"filed before {TEN_B5_1_APPLICABLE_FROM}", None
        elif rflag in ("TRUE", "FALSE"):
            t5, basis5, span5 = rflag, "row flag", None
        else:
            t5, basis5, span5 = None, None, None
            for f in ([] if fids == "-" else fids.split(",")):
                ftext, fa, fb = foot[f]
                if RE_NEG_10B51.search(ftext):
                    t5, basis5, span5 = "FALSE", f"footnote {f} (negation checked first)", [fa, fb]
                    break
                if RE_POS_10B51.search(ftext):
                    t5, basis5, span5 = "TRUE", f"footnote {f}", [fa, fb]
                    break
            if t5 is None:
                t5, basis5 = (filing_flag, "filing-level flag") if filing_flag else ("AMBIGUOUS", "no row flag, no referenced footnote and no filing flag (never FALSE from silence)")
        claim = (f"Form 4 reports a {ttype} (code {codech}, {'acquired' if ad == 'A' else 'disposed'}) of {sh:g} shares"
                 f"{f' at {pr:g}' if pr is not None else ' (no price)'} on {tdate} by {', '.join(o['name'] for o in owners) or 'an unnamed owner'}.")
        recs.append(_record(d, as_of, f"INSIDER_TRANSACTION:{ttype}", claim, a, b, {"section": "Form 4 table", "row": int(idx)}, "F4-TXN-1",
                            "deterministic parse of a transaction line; type from the IDEC1 code table", "UNAMBIGUOUS",
                            {"transaction_type": ttype, "raw_code": codech, "acquired_disposed": ad, "shares": sh, "price": pr, "value": sh * pr if pr is not None else None,
                             "transaction_date": tdate, "ownership": own, "owners": owners, "ten_b5_1": {"value": t5, "basis": basis5, "footnote_span": span5,
                                                                                                        "footnote_text": text[span5[0]:span5[1]] if span5 else None}}))
    return recs, notes


def verify_records(records: list, texts: dict) -> list:
    """every evidence span is the text at its offsets in the document it names"""
    bad = []
    for r in records:
        t = texts.get(r["document_id"])
        a, b = r["evidence_location"]["char_start"], r["evidence_location"]["char_end"]
        if t is None or t[a:b] != r["exact_evidence_span"] or not r["exact_evidence_span"]:
            bad.append(r["record_id"])
    return bad


def analyze(section: dict | None, common: dict) -> dict:
    prov = {"fixture_id": common["fixture_id"], "section": "information", "section_sha256": O.sha256_of(section) if section is not None else None,
            "fixture_provenance": common["provenance"], "issuer_id": common["issuer"]["issuer_id"]}
    env = O.envelope("Information", VERSION, "EVIDENCE_EXTRACTION", "EVIDENCE_EXTRACTION_ONLY", common["as_of"], prov)
    if section is None:
        env["result_codes"] = [O.code("SECTION_ABSENT", "$.information")]
        env["confidence_basis"] = "not run: the fixture has no documents"
        return env
    probs = schema.check(section, SPEC, "$.information")
    if probs:
        return O.reject(env, probs)
    as_of_s, as_of = common["as_of"], schema.parse_datetime(common["as_of"])
    issuer = common["issuer"]["issuer_id"]
    reqs = section.get("requests") or ["EVIDENCE_EXTRACTION", "CLAIM_VERIFICATION"]
    for q in reqs:
        if q in REQUESTS["information"]["unsupported"]:
            env["abstentions"].append({"request": q, **O.code("UNSUPPORTED_RESEARCH_REQUEST", "$.information.requests", q)})
    env["abstentions"].append({"request": "MANAGEMENT_GUIDANCE", **O.code("GUIDANCE_ANALYSIS_UNAVAILABLE", "$.information",
                                                                           "GUIDANCE_TASK_DEFINITION v2_1: 7 blocking open questions; v3: 5 blocking NQs")})
    if not any(q in reqs for q in REQUESTS["information"]["supported"]):
        env["execution_status"] = "NOT_RUN"
        env["confidence_basis"] = "not run: no supported information request"
        return env
    processed, temporal, by_id, texts, conflicted = [], [], {}, {}, set()
    # ---- per document: identity, category, emptiness, time
    for i, d in enumerate(section["documents"]):
        entry = {"document_id": d["document_id"], "index": i, "source_type": d["source_type"], "form_type": d["form_type"],
                 "sha256": hashlib.sha256(d["text"].encode("utf-8")).hexdigest(), "status": None, "codes": []}
        processed.append(entry)
        st, inst, c = classify_time(d["availability_timestamp"])
        tv = {"document_id": d["document_id"], "availability_timestamp": d["availability_timestamp"], "state": st, "as_of": as_of_s}
        if st == "OK":
            tv["state"] = "AVAILABLE_AS_OF" if inst <= as_of else "REJECT_FUTURE"
        temporal.append(tv)
        if d["issuer_id"] != issuer:
            entry.update(status="EXCLUDED"); entry["codes"].append(O.code("DOCUMENT_ISSUER_MISMATCH", f"$.information.documents[{i}]", f"{d['issuer_id']} is not {issuer}")); continue
        if d["source_type"] not in SUPPORTED or d["form_type"] not in SUPPORTED[d["source_type"]]:
            entry.update(status="ABSTAINED"); entry["codes"].append(O.code("DOCUMENT_CATEGORY_UNSUPPORTED", f"$.information.documents[{i}]", f"{d['source_type']} / {d['form_type']}")); continue
        if not d["text"].strip():
            entry.update(status="ABSTAINED"); entry["codes"].append(O.code("DOCUMENT_EMPTY", f"$.information.documents[{i}]")); continue
        if st != "OK":
            entry.update(status="EXCLUDED"); entry["codes"].append(O.code(c, f"$.information.documents[{i}].availability_timestamp", tv["state"])); continue
        if inst > as_of:
            entry.update(status="EXCLUDED"); entry["codes"].append(O.code("DOCUMENT_AFTER_AS_OF", f"$.information.documents[{i}]", f"{d['availability_timestamp']} > {as_of_s}")); continue
        dst, dinst, _ = classify_time(d["document_timestamp"])
        if dst == "OK" and dinst > inst:
            entry.update(status="EXCLUDED"); entry["codes"].append(O.code("DOCUMENT_TIMESTAMP_AFTER_AVAILABILITY", f"$.information.documents[{i}]",
                                                                          f"document {d['document_timestamp']} after availability {d['availability_timestamp']}: conflicting times, not resolved")); continue
        if d["document_id"] in conflicted:                     # post-review R-08: once an id is contested, every later document with it is excluded too
            entry.update(status="EXCLUDED"); entry["codes"].append(O.code("DOCUMENT_ID_CONFLICT", f"$.information.documents[{i}]", d["document_id"])); continue
        if d["document_id"] in by_id:
            if by_id[d["document_id"]]["d"] == d:
                entry.update(status="DUPLICATE"); entry["codes"].append(O.code("DOCUMENT_DUPLICATE_IDENTICAL", f"$.information.documents[{i}]", d["document_id"])); continue
            first = by_id.pop(d["document_id"])
            conflicted.add(d["document_id"])
            first["entry"].update(status="EXCLUDED"); first["entry"]["codes"].append(O.code("DOCUMENT_ID_CONFLICT", "", d["document_id"]))
            entry.update(status="EXCLUDED"); entry["codes"].append(O.code("DOCUMENT_ID_CONFLICT", f"$.information.documents[{i}]", d["document_id"]))
            continue
        same = [x for x in by_id.values() if x["d"]["text"] == d["text"] and x["d"]["availability_timestamp"] == d["availability_timestamp"]]
        if same:
            entry.update(status="DUPLICATE"); entry["codes"].append(O.code("DOCUMENT_DUPLICATE_CONTENT", f"$.information.documents[{i}]", f"same content as {same[0]['d']['document_id']}")); continue
        by_id[d["document_id"]] = {"d": d, "entry": entry, "avail": inst}
        entry["status"] = "ANALYSED"
    # ---- extraction, in availability order
    records, metadata, notes, rejected, unresolved_by_doc = [], {}, [], [], {}
    for did, x in sorted(by_id.items(), key=lambda kv: (kv[1]["avail"], kv[0])):
        d = x["d"]
        try:                                                  # 002: one document's unexpected error never discards the others
            if d["source_type"] in ("SYNTHETIC_8K", "SEC_8K"):
                meta, recs, nts, unres = extract_8k(d, as_of_s, (common.get("issuer") or {}).get("name"))     # 0.4.6: the registrant's name on file
                metadata[did] = meta
                unresolved_by_doc[did] = unres
            else:
                recs, nts = extract_form4(d, as_of_s, x["avail"])
        except Exception as e:                                # noqa: BLE001 - recorded as a code, never re-raised
            recs, nts = [], [O.code("DOCUMENT_PROCESSING_ERROR", did, f"{type(e).__name__}: {str(e)[:160]}")]
        if any(n["code"] in ("DOCUMENT_ISSUER_MISMATCH", "DOCUMENT_PROCESSING_ERROR") for n in nts):
            x["entry"].update(status="EXCLUDED")              # 002 (R-08): out of the active evidence index (below), no records
            x["entry"]["codes"].extend(nts)
            rejected.append(did)
            metadata.pop(did, None)
            continue
        texts[did] = d["text"]
        x["entry"]["codes"].extend(nts)
        if not [r for r in recs if r["ambiguity_status"] != "NOT_VERIFIABLE"] and x["entry"]["status"] == "ANALYSED":
            x["entry"]["codes"].append(O.code("NO_SUPPORTED_EVENT", did, "the document was processed in full; no supported event was found"))
        records.extend(recs)
        notes.extend({"document_id": did, **n} for n in nts)
    for did in rejected:                                      # 002 (R-08): a rejected document is never authoritative evidence
        by_id.pop(did)
        unresolved_by_doc.pop(did, None)
    # ---- amendments: supersession records (never mutation)
    supersessions, current = [], {r["record_id"]: r["ambiguity_status"] for r in records}
    for did, x in sorted(by_id.items(), key=lambda kv: (kv[1]["avail"], kv[0])):
        d = x["d"]
        if not d["form_type"].endswith("/A"):
            continue
        tgt = d.get("amends")
        if not tgt:
            x["entry"]["codes"].append(O.code("AMENDMENT_TARGET_UNKNOWN", did, "the amendment names no amended document; supersession is not resolved"))
            continue
        if tgt not in by_id:
            x["entry"]["codes"].append(O.code("AMENDMENT_TARGET_NOT_FOUND", did, tgt)); continue
        if not RE_AMEND.search(d["text"]) or tgt not in d["text"]:
            x["entry"]["codes"].append(O.code("AMENDMENT_TARGET_UNKNOWN", did, "no amendment wording naming the target in the text")); continue
        if by_id[tgt]["avail"] >= x["avail"]:
            x["entry"]["codes"].append(O.code("AMENDMENT_ORDER_INVALID", did, f"{tgt} is not available before the amendment")); continue
        restated = set(metadata.get(did, {}).get("raw_item_codes", []))
        sup = [r["record_id"] for r in records if r["document_id"] == tgt and r["details"].get("item_code") in restated]
        supersessions.append({"amendment": did, "supersedes_document": tgt, "items_restated": sorted(restated), "superseded_records": sup,
                              "rule": "declared target + amendment wording + target id in the text + target available first", **O.code("SUPERSEDED_BY_AMENDMENT", did)})
        for rid in sup:
            current[rid] = "SUPERSEDED"
    # ---- stage C: contradictions (TASK_SPEC_Q3 section 4) between DIFFERENT current documents; date disagreements and within-document inconsistencies apart
    superseded_docs = {x["supersedes_document"] for x in supersessions}
    conflicts, date_disagreements, within_doc = [], [], []
    groups = {}
    for r in records:
        date_only = current[r["record_id"]] == "AMBIGUOUS" and r["details"].get("effective_date_state") in ("INVALID", "UNREADABLE") and r["details"].get("role") \
            and r["details"].get("modality") != "TENTATIVE"
        if (current[r["record_id"]] == "UNAMBIGUOUS" or date_only) and r["document_id"] not in superseded_docs and r["details"].get("action") in ("DEPARTURE", "APPOINTMENT", "CONTINUATION"):
            groups.setdefault((_n(r["details"]["person"]), _n(r["details"]["role"])), []).append(r)
    CHANGE = re.compile(r"\b(?:no longer|instead|has decided|have decided|reversed|rescind|withdr[ae]w|as previously (?:announced|reported|disclosed)|will not .{0,40}as previously)\b", re.I)
    for (pn, rn), rs in groups.items():
        dep = [r for r in rs if r["details"]["action"] == "DEPARTURE"]
        con = [r for r in rs if r["details"]["action"] == "CONTINUATION"]
        pairs_docs = {(x["document_id"], y["document_id"]) for x in dep for y in con if x["document_id"] != y["document_id"]}
        if pairs_docs:
            ids = sorted({r["record_id"] for r in dep + con if any(r["document_id"] in pd for pd in pairs_docs)})
            docs = sorted({dd for pd in pairs_docs for dd in pd})
            last = max(docs, key=lambda dd: by_id[dd]["avail"])
            later_change = any(CHANGE.search(by_id[last]["d"]["text"][r["evidence_location"]["sentence_text_offsets"][0]:r["evidence_location"]["sentence_text_offsets"][1]])
                               for r in dep + con if r["document_id"] == last)
            reason = "one document says the person is leaving the role, another that the person continues in it"
            conflicts.append({"person": rs[0]["details"]["person"], "role": rs[0]["details"]["role"], "records": ids, "documents": docs, "reason": reason,
                              "kind": "Q3_SECTION_4", "later_change_wording": later_change, **O.code("CONTRADICTORY_EVIDENCE", f"{rs[0]['details']['person']} / {rs[0]['details']['role']}", reason)})
            for rid in ids:
                current[rid] = "CONTRADICTED"
        same_doc = {x["document_id"] for x in dep} & {y["document_id"] for y in con}
        for dd in sorted(same_doc):
            within_doc.append({"person": rs[0]["details"]["person"], "role": rs[0]["details"]["role"], "document_id": dd,
                               **O.code("WITHIN_DOCUMENT_INCONSISTENCY", dd, "a departure and a continuation in one document")})
        for act in ("DEPARTURE", "APPOINTMENT"):
            dates = {r["details"]["effective_date"] for r in rs if r["details"]["action"] == act and r["details"]["effective_date"]}
            if len(dates) > 1:
                date_disagreements.append({"person": rs[0]["details"]["person"], "role": rs[0]["details"]["role"], "action": act, "dates": sorted(dates),
                                           "documents": sorted({r["document_id"] for r in rs if r["details"]["action"] == act}),
                                           **O.code("DATE_DISAGREEMENT", f"{rs[0]['details']['person']} / {rs[0]['details']['role']}", f"{act.lower()} dates {sorted(dates)}")})
    # ---- stage D: claims - Q5 evidence completeness gate (G1..G7); citation, source status, support and truth stay separate answers
    eligible = {did for did in by_id if did not in superseded_docs}
    EVIDENCE_KINDS = ("AMBIGUOUS_REFERENCE", "SHORT_NAME_UNRESOLVED", "UNRESOLVED_SUBJECT", "UNPARSED_CHANGE_STATEMENT")
    unresolved_all = [u for did, us in unresolved_by_doc.items() if did in eligible for u in us if u.get("kind") in EVIDENCE_KINDS]
    assessed_notes = [n for n in notes if n.get("code") in ("EVENT_NEGATED", "HISTORICAL_STATEMENT", "NON_FACTUAL_STATEMENT") and n.get("span")]
    amb_recs = [r for r in records if r["document_id"] in eligible and current[r["record_id"]] == "AMBIGUOUS" and r["details"].get("person")
                and r["details"].get("modality") != "TENTATIVE" and r["details"].get("action") in ("DEPARTURE", "APPOINTMENT", "CONTINUATION")]
    claims = []
    for cl in section.get("claims_to_verify") or []:
        out = {"claim_id": cl["claim_id"], "document_id": cl["document_id"], "quoted_span": cl["quoted_span"], "claim": cl.get("claim"), "truth": "TRUTH_NOT_DETERMINED"}
        entry = next((e for e in processed if e["document_id"] == cl["document_id"]), None)
        gates = {g: "NOT_REACHED" for g in ("G1", "G2", "G3", "G4", "G5", "G6", "G7")}
        reasons, related = [], []
        if cl["document_id"] not in by_id:
            gates["G2"] = "FAIL"
            out.update(citation="CITATION_NOT_EVALUATED", source_status="SOURCE_EXCLUDED" if entry else "SOURCE_NOT_SUPPLIED", claim_support="CLAIM_SUPPORT_NOT_ASSESSED",
                       source_reason=[c["code"] for c in entry["codes"]][:3] if entry else ["not supplied"])
        else:
            gates["G2"] = "PASS"
            t = by_id[cl["document_id"]]["d"]["text"]
            k = t.find(cl["quoted_span"])
            if k < 0:
                gates["G1"] = "FAIL"
                out.update(citation="CITATION_NOT_FOUND", source_status="SOURCE_SUPERSEDED" if cl["document_id"] in superseded_docs else "SOURCE_CURRENT",
                           claim_support="CLAIM_SUPPORT_NOT_ASSESSED", match_rule="exact text only; no fuzzy matching")
            else:
                gates["G1"] = "PASS"
                ke = k + len(cl["quoted_span"])
                own = lambda r: r["evidence_location"].get("clause_offsets") or [r["evidence_location"]["char_start"], r["evidence_location"]["char_end"]]  # noqa: E731
                rel = [r for r in records if r["document_id"] == cl["document_id"] and own(r)[0] < ke and k < own(r)[1]]     # the clause that owns the predicate
                sts = {current[r["record_id"]] for r in rel}
                cover = [r for r in rel if current[r["record_id"]] in ("UNAMBIGUOUS", "CONTRADICTED", "SUPERSEDED")]
                tentative = [r for r in rel if current[r["record_id"]] == "AMBIGUOUS" and r["details"].get("modality") == "TENTATIVE"]
                unassessed = [r for r in rel if current[r["record_id"]] == "AMBIGUOUS" and r["details"].get("modality") != "TENTATIVE"]
                in_span_unres = [u for u in unresolved_all if u["document_id"] == cl["document_id"] and u["span"][0] < ke and k < u["span"][1]]
                hz = [n for n in assessed_notes if n.get("document_id") == cl["document_id"] and n["span"][0] < ke and k < n["span"][1]]
                persons = {_n(r["details"]["person"]) for r in cover if r["details"].get("person")} or {_n(n[2]) for n in SEM.names(cl["quoted_span"])}
                roles = {_n(r["details"].get("role")) for r in cover if r["details"].get("role")}
                assessed = bool(cover or tentative or hz)
                body = [(x["body_start"], x["end"]) for x in sections_of(t) if x["kind"] == "ITEM" and x.get("item_code") == "5.02"]
                in_502 = any(a_ < ke and k < b_ for a_, b_ in body)     # Q5: a statement outside Item 5.02 is outside this system's scope (not 'unassessed')
                in_scope = bool(rel or in_span_unres or hz) or (SEM._has_pred(cl["quoted_span"]) and in_502)
                src = None
                gates["G3"] = "FAIL" if (cl["document_id"] in superseded_docs or "SUPERSEDED" in sts) else "PASS"
                if gates["G3"] == "FAIL":
                    src = "SOURCE_SUPERSEDED"
                else:
                    gates["G4"] = "FAIL" if "CONTRADICTED" in sts else "PASS"
                    if gates["G4"] == "FAIL":
                        src = "SOURCE_CONTRADICTED"
                if src is None:
                    g5_fail = bool(unassessed or in_span_unres) or (SEM._has_pred(cl["quoted_span"]) and in_502 and not assessed)
                    gates["G5"] = "FAIL" if g5_fail else ("PASS" if in_scope else "NOT_APPLICABLE")
                    if gates["G5"] == "FAIL":
                        reasons.append("CITED_STATEMENT_NOT_ASSESSED")
                        related += [{"kind": "AMBIGUOUS_RECORD_IN_SPAN", "record_id": r["record_id"]} for r in rel]
                    un_rel = []
                    for u in unresolved_all:
                        up = {_n(p) for p in u["persons"] if not SEM.RE_HON_ONLY.match(p)}
                        in_span = u["document_id"] == cl["document_id"] and u["span"][0] < ke and k < u["span"][1]
                        role_hit = (not up) and bool(roles & {_n(x) for x in u.get("roles") or []})
                        if (persons & up) or in_span or role_hit or (persons & {_n(p) for p in u["persons"]}):
                            un_rel.append({"kind": "UNRESOLVED_MENTION", "document_id": u["document_id"], "span": u["span"], "persons": u["persons"], "why": u["why"]})
                    amb_rel = [{"kind": "AMBIGUOUS_RECORD", "record_id": r["record_id"], "document_id": r["document_id"]} for r in amb_recs
                               if _n(r["details"]["person"]) in persons and r not in rel]       # contract G6 (a): the same person, whatever the role
                    gates["G6"] = "FAIL" if (un_rel or amb_rel) else "PASS"
                    if gates["G6"] == "FAIL":
                        reasons.append("RELATED_UNRESOLVED_EVIDENCE")
                        related += un_rel[:10] + amb_rel[:10]
                    same = [r for r in records if r["document_id"] in eligible and _n(r["details"].get("person")) in persons and _n(r["details"].get("role")) in roles
                            and r["details"].get("effective_date_state") in ("INVALID", "UNREADABLE") and r not in rel]     # another statement, not the claim's own
                    dd = [x for x in date_disagreements if _n(x["person"]) in persons and _n(x["role"]) in roles]
                    gates["G7"] = "FAIL" if (same or dd) else "PASS"
                    if gates["G7"] == "FAIL":
                        reasons.append("RELATED_DATE_AMBIGUITY")
                        related += [{"kind": "DATE_STATE", "record_id": r["record_id"], "state": r["details"]["effective_date_state"]} for r in same][:5] + \
                                   [{"kind": "DATE_DISAGREEMENT", "dates": x["dates"], "documents": x["documents"]} for x in dd][:5]
                    src = "SOURCE_NOT_FULLY_ASSESSED" if reasons else "SOURCE_CURRENT"
                out.update(citation="CITATION_FOUND", source_status=src, claim_support="CLAIM_SUPPORT_UNDETERMINED",
                           evidence_location={"char_start": k, "char_end": ke, "occurrences": t.count(cl["quoted_span"])},
                           related_records=[{"record_id": r["record_id"], "current_status": current[r["record_id"]], "claim": r["claim"]} for r in rel],
                           contrary_search={"searched_documents": sorted(by_id), "contrary_records": [i for c in conflicts for i in c["records"] if any(r["record_id"] in c["records"] for r in rel)],
                                            "unresolved_mentions": [x for x in related if x["kind"] == "UNRESOLVED_MENTION"][:10]})
        out["completeness"] = {"gates": gates, "reasons": reasons, "related_evidence": related[:20],
                               "rule": "Q5_INFORMATION_V21_CONTRACT.json evidence_completeness_gate: SOURCE_CURRENT only when G1..G7 pass (G5 NOT_APPLICABLE for an out-of-scope statement)"}
        out["codes"] = [O.code(out["citation"], cl["claim_id"]), O.code(out["source_status"], cl["claim_id"]), O.code(out["claim_support"], cl["claim_id"]),
                        O.code("TRUTH_NOT_DETERMINED", cl["claim_id"])] + [O.code(rsn, cl["claim_id"]) for rsn in reasons]
        claims.append(out)
    # ---- self-check: every span exact
    bad = verify_records(records, texts)
    if bad:
        env["execution_status"] = "FAILED"
        env["result_codes"] = [O.code("INTERNAL_ERROR", "", f"evidence spans that do not match their source: {bad}")]
        return env
    view = [{**{k: r[k] for k in ("record_id", "document_id", "event_category", "claim", "exact_evidence_span", "ambiguity_status")},
             "evidence_status": current[r["record_id"]],                          # Q11: was 'current_status' (UNAMBIGUOUS / AMBIGUOUS / CONTRADICTED / SUPERSEDED)
             "current_status": (r.get("details") or {}).get("as_of_status", "UNKNOWN") if current[r["record_id"]] not in ("SUPERSEDED", "CONTRADICTED") else "UNKNOWN",
             "current_status_basis": (r.get("details") or {}).get("as_of_status_basis") if current[r["record_id"]] not in ("SUPERSEDED", "CONTRADICTED")
             else f"evidence status {current[r['record_id']]}: no status at as_of is given"}
            for r in records]
    supporting = [r for r in records if current[r["record_id"]] == "UNAMBIGUOUS" and r["event_category"] != "MANAGEMENT_STATUS_STATEMENT"]
    ambiguous = [r for r in records if r["ambiguity_status"] in ("AMBIGUOUS", "NOT_VERIFIABLE")]
    meta_amb = [{"document_id": k, **v} for k, v in metadata.items() if v["ambiguity_state"] != "UNAMBIGUOUS"]
    analysed = [e for e in processed if e["status"] == "ANALYSED"]
    lat = max((x["avail"] for x in by_id.values()), default=None)
    summary = []
    for r in records:
        if current[r["record_id"]] in ("UNAMBIGUOUS", "CONTRADICTED", "SUPERSEDED", "AMBIGUOUS"):
            summary.append(f"[{current[r['record_id']]}] {r['document_id']} ({r['form_type']}, available {r['availability_timestamp']}): {r['claim']} "
                           f"Evidence: \"{r['exact_evidence_span'][:160]}\"")
    for c in conflicts:
        summary.append(f"[CONTRADICTORY] {c['person']} / {c['role']}: {c['reason']} ({', '.join(c['documents'])}).")
    env["findings"] = {
        "documents_processed": processed,
        "events_detected": view,
        "supporting_evidence": supporting,
        "conflicting_evidence": conflicts,
        "ambiguous_claims": ambiguous,
        "metadata_layer": metadata,
        "metadata_ambiguity": meta_amb,
        "abstentions": [e for e in processed if e["status"] in ("ABSTAINED", "EXCLUDED")] + env["abstentions"],
        "temporal_validation": temporal,
        "supersessions": supersessions,
        "rejection_audit": [{"document_id": e["document_id"], "status": e["status"], "reasons": [c["code"] for c in e["codes"]], "sha256": e["sha256"],
                             "note": "diagnostic metadata only; this document is not in the active evidence index and cannot support any claim"}
                            for e in processed if e["status"] in ("EXCLUDED", "ABSTAINED", "DUPLICATE")],
        "claims_verification": claims,
        "unresolved_mentions": unresolved_all,
        "date_disagreements": date_disagreements,
        "within_document_inconsistencies": within_doc,
        "all_extraction_records": records,
        "notes": notes,
        "information_quality": {
            "COMPLETENESS": {"documents_supplied": len(processed), "analysed": len(analysed), "excluded_or_abstained": len([e for e in processed if e["status"] in ("EXCLUDED", "ABSTAINED")]),
                             "duplicates": len([e for e in processed if e["status"] == "DUPLICATE"])},
            "PROVENANCE": {"records": len(records), "spans_verified_exact": len(records) - len(bad), "document_hashes": {e["document_id"]: e["sha256"] for e in analysed}},
            "FRESHNESS": {"latest_available_document": lat.isoformat() if lat else None, "days_before_as_of": (as_of - lat).total_seconds() / 86400 if lat else None},
            "AMBIGUITY": {"ambiguous_or_not_verifiable_records": len(ambiguous), "metadata_ambiguous_documents": len(meta_amb), "contradictions": len(conflicts),
                          "superseded_records": sum(1 for v in current.values() if v == "SUPERSEDED")},
            "note": "four separate dimensions; no single confidence number"},
        "guidance": {"status": "UNAVAILABLE", **O.code("GUIDANCE_ANALYSIS_UNAVAILABLE", "$.information")},
        "research_summary": summary,
        "limitations": [
            "rules tuned on synthetic documents authored for testing; deterministic rules over a narrow scope (MANAGEMENT_CHANGE in Item 5.02 sections; Form 4 transaction lines)",
            "Q9: real SEC 8-K text (converted from the filing HTML by the Q9 adapter) is read by the same synthetic-tuned rules; real Form 4 is not supported",
            "evidence grounding is not semantic correctness; self-authored synthetic tests show that the text determines the output, not that the output is right in general (OQ07)",
            "items 1.01 / 7.01 / 8.01 and every item other than 5.02 are recorded as metadata only; item metadata is never treated as evidence of an event",
            "management guidance is unavailable; no sentiment, direction or probability is produced",
            "the availability check is a fail-closed reading of the supplied timestamps; it is not PIT-qualified and says nothing about real filings",
        ],
    }
    env["evidence"] = supporting
    env["counter_evidence"] = conflicts
    env["warnings"] = [c for e in processed for c in e["codes"] if c["code"] in ("DOCUMENT_ID_CONFLICT", "AMENDMENT_TARGET_UNKNOWN", "AMENDMENT_TARGET_NOT_FOUND", "AMENDMENT_ORDER_INVALID",
                                                                                  "DOCUMENT_TIMESTAMP_AFTER_AVAILABILITY")]
    env["missing_dependencies"] = ["management guidance analysis (blocked task definition)"]
    env["calculation_or_extraction_trace"] = [{"document_id": did, "rules": [r["extraction_method"]["rule_id"] for r in records if r["document_id"] == did]} for did in by_id]
    env["result_codes"] = [c for e in processed for c in e["codes"]] + [{k: n[k] for k in ("code", "meaning", "path", "detail")} for n in notes if n.get("code") not in
                                                                         [c["code"] for e in processed for c in e["codes"]]] + \
                          [{k: c[k] for k in ("code", "meaning", "path", "detail")} for c in conflicts] + [c for cl in claims for c in cl["codes"]]
    env["data_status"] = {"documents_supplied": len(processed), "analysed": len(analysed), "records": len(records)}
    env["execution_status"] = "COMPLETED"
    env["questions"] = {"calculation_succeeded": True, "data_adequate": "ADEQUATE" if analysed else "INADEQUATE",
                        "evidence_sufficient": "SUFFICIENT_FOR_STATED_EXTRACTIONS" if supporting else "INSUFFICIENT",
                        "financial_interpretation_supported": "NO: what the documents say, with spans; no financial interpretation",
                        "predictive_validity_demonstrated": False}
    env["confidence_basis"] = (f"no probability: {len(analysed)} of {len(processed)} documents analysed; {len(records)} extraction records, all spans exact; "
                               f"{len(ambiguous)} ambiguous / not verifiable; {len(conflicts)} contradiction(s); {len(supersessions)} supersession(s)")
    return env
