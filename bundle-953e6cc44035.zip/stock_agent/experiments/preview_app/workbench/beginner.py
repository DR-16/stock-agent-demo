"""Q11 beginner's report (q11-beginner 1.0.0): what a beginner sees first, built from the run's own expert outputs - in plain Chinese, in four
separate parts, each key point with the evidence it rests on:

  facts        公司事实：公告里的管理层变动（谁、什么职务、何时生效、在 as_of 是否已生效）、财报里的数字（哪一年、来自哪份数据）
  readings     指标解读：技术面、宏观、估值倍数 —— 说明这是规则读法 / 描述值，不是买卖建议
  gaps         数据缺口：哪些数据缺了、因此哪些没有算（不按零处理）
  limits       系统限制：离线快照、未经金融验证、抽取是待核实线索、年报不是 TTM、时点未核实 ……（真实限制不隐藏）
  experts      五个专家各自有没有结果，没有的原因
  advanced     内部代码、规则编号、记录编号（只在“高级详情”里）

No internal code, rule id or record id appears in the four main parts (a test checks this); they stay in `advanced`. Nothing here is computed
anew: every number and every event is read from the run record, with its source.
"""
from __future__ import annotations

import re

VERSION = "q12-beginner 1.2.0"   # 1.2.0 (Q12): Form 4 rows and other non-management events no longer crash the report (KeyError on a synthetic case). 1.1.2   # 1.1.0 (mid-round review): technical / macro evidence names the price dataset; the price date is the case's own; an
                                 # expert with no valid finding is not '有结果'; repeated gaps once; evidence numbers formatted
FIELD_ZH = {"revenue": "收入", "net_income": "净利润", "stockholders_equity": "股东权益", "operating_income": "营业利润", "depreciation_amort": "折旧摊销",
            "operating_cash_flow": "经营现金流", "capex": "资本开支", "long_term_debt": "长期债务", "short_term_debt": "短期债务", "cash_and_equivalents": "现金及等价物",
            "total_assets": "总资产", "total_liabilities": "总负债", "current_assets": "流动资产", "current_liabilities": "流动负债", "interest_expense": "利息费用",
            "cost_of_revenue": "营业成本", "gross_profit": "毛利", "shares_outstanding": "股数", "price": "股价", "pretax_income": "税前利润",
            "income_tax_expense": "所得税", "shares": "股数", "market_cap": "市值", "enterprise_value": "企业价值", "free_cash_flow": "自由现金流",
            "total_debt": "债务合计", "cash": "现金", "ebitda": "EBITDA（营业利润 + 折旧摊销）", "price_date": "价格日期", "fiscal_year": "财年"}
METHOD_ZH = {"TRAILING_PE": "市盈率", "PRICE_TO_BOOK": "市净率", "EV_EBITDA": "企业价值 / EBITDA", "EV_SALES": "企业价值 / 收入", "FCF_YIELD": "自由现金流收益率",
             "FORWARD_PE": "前瞻市盈率", "PEG": "PEG", "DCF_FCF": "现金流折现估值"}
TECH_ZH = {"momentum_12m_1m": "过去 12 个月涨幅（不含最近 1 个月）", "relative_strength_6m": "近 6 个月相对大盘（SPY）的表现", "sma50_sma200_ratio": "50 日均线与 200 日均线之比",
           "momentum_1m": "近 1 个月涨幅", "momentum_3m": "近 3 个月涨幅", "momentum_6m": "近 6 个月涨幅", "volatility_63d_ann": "近 3 个月年化波动率",
           "max_drawdown_2y": "两年内最大回撤", "rsi_14": "14 日 RSI", "tnx_change_6m": "10 年期国债利率（美国财政部数据，替代 ^TNX）6 个月变化",
           "tnx_level": "10 年期国债利率", "irx_level": "13 周国库券利率", "yield_curve_slope": "长短端利差", "vix_level": "VIX 波动率指数",
           "credit_risk_proxy_change_3m": "信用风险代理 3 个月变化", "usd_proxy_change_3m": "美元代理 3 个月变化"}
PCT = ("momentum_12m_1m", "relative_strength_6m", "momentum_1m", "momentum_3m", "momentum_6m", "volatility_63d_ann", "max_drawdown_2y",
       "credit_risk_proxy_change_3m", "usd_proxy_change_3m")
CLASS_ZH = {"EXPANDING": "增长", "CONTRACTING": "下降", "FLAT": "基本持平", "INSUFFICIENT_DATA": "数据不足，无法判断", "NOT_MEANINGFUL": "数值异常，无法计算",
            "IMPROVING": "改善", "STABLE": "稳定", "DETERIORATING": "下滑", "INCREASING": "上升", "DECREASING": "下降"}
STATUS_ZH = {"IN_EFFECT": "截至报告日已生效", "NOT_YET_EFFECTIVE": "截至报告日尚未生效", "ENDED": "截至报告日已经结束", "PENDING_INTENTION": "只是意向，尚未确定",
             "UNKNOWN": "公告没有写明生效日期，截至报告日是否生效无法判断"}
ACTION_ZH = {"APPOINTMENT": "被任命为", "DEPARTURE": "卸任", "CONTINUATION": "继续担任"}
EXPERT_ZH = {"technical": "技术面（价格走势）", "macro": "宏观（市场环境）", "fundamental": "基本面（财报）", "valuation": "估值（倍数）", "information": "公告（8-K 管理层变动）"}
CODE_RX = re.compile(r"\b(?:[A-Z][A-Z0-9]*_[A-Z0-9_]+|[a-z]+_[a-z0-9_]+|Q\d+R\d+-\d+|R-[A-Z]\d|V2-[A-Z]+-[A-Z]+|[0-9]{10}-[0-9]{2}-[0-9]{6}(?:#\S+)?)\b")


def _num(v):
    """an evidence number as a person reads it (no 17-digit floats); text and None as they are"""
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return v
    if v != v or v in (float("inf"), float("-inf")):
        return "不是有限数"
    return f"{v:,.0f}" if abs(v) >= 1000 else f"{v:.4g}"


def _pct(x) -> str:
    return f"{x * 100:+.1f}%" if isinstance(x, (int, float)) else "—"


def _role_zh(role: str | None) -> str:
    if not role:
        return "（公告没有写明职务）"
    if role == "Director":
        return "董事"
    m = re.fullmatch(r"(Member|Chair) of the (.+ Committee)", role)
    if m:
        return f"董事会 {m.group(2)} {'主席' if m.group(1) == 'Chair' else '成员'}"
    return f"“{role}”"


def _reason_zh_form4(reason) -> str:
    return {"shares must be a positive number": "股数不是正数"}.get(str(reason), f"记录不完整（{reason}）")


def _date_zh(det: dict) -> str:
    b = det.get("date_basis")
    ev = det.get("date_evidence") or {}
    if det.get("effective_date"):
        where = {"DEFINED_TERM": f"（公告在{_sec_zh(ev.get('section'))}把“{ev.get('defined_term')}”定义为这一天）",
                 "OTHER_SECTION": f"（生效日期写在{_sec_zh(ev.get('section'))}）"}.get(b, "")
        return f"{det['effective_date']} 生效{where}"
    if det.get("linked_date"):
        return f"与前一项变动同日生效（{det['linked_date']['value']}，公告原文是“the same date”）"
    if det.get("event_date"):
        return f"公告写明决定日期 {det['event_date']}，但没有写明生效日期"
    return "公告没有写明生效日期"


def _sec_zh(s: str | None) -> str:
    if not s:
        return "公告中"
    if s.startswith("Explanatory"):
        return "开头的说明段"
    return s.replace("Item ", "第 ") + " 项"


def _shares_date(rec: dict) -> str | None:
    for it in ((rec.get("q8") or {}).get("identity") or {}).get("items", {}).get("valuation") or []:
        for s_ in it.get("source_says") or []:
            m = re.search(r"股数 [0-9]+：.*?截至 ([0-9]{4}-[0-9]{2}-[0-9]{2})", s_)
            if m:
                return m.group(1)
    return None


def build(rec: dict, ticker: str, company: str, as_of: str, snap: dict) -> dict:
    E = rec["experts"]
    out = {"version": VERSION, "company": company, "ticker": ticker, "as_of": as_of, "facts": [], "readings": [], "gaps": [], "limits": [], "experts": [],
           "needs_check": [], "advanced": {"codes": [], "record_ids": [], "rule_ids": []}}
    dates = [(k_zh, snap.get(k)) for k, k_zh in (("sec_filings", "SEC 申报列表"), ("sec_xbrl", "SEC 财报数据"), ("prices", "日线价格"), ("vix", "VIX"),
                                                 ("treasury", "国债利率")) if snap.get(k)]
    out["data_notice"] = "本次使用已有数据（离线快照），不是刚刚获取的最新数据。" + "快照取得时间：" + "；".join(f"{a} {b[:16].replace('T', ' ')} UTC" for a, b in dates)
    # ---- Information: management changes
    I = E["information"]
    if I["execution_status"] == "COMPLETED":
        F = (I.get("output") or {}).get("findings") or {}
        det = {r["record_id"]: r for r in F.get("all_extraction_records") or []}
        docs = {d["document_id"]: d for d in F.get("documents_processed") or []}
        shown = 0
        for e in F.get("events_detected") or []:
            r = det.get(e["record_id"]) or {}
            d = r.get("details") or {}
            ev = {"kind": "公告原文", "document": e["document_id"], "form": r.get("form_type"), "available": (r.get("availability_timestamp") or "")[:10],
                  "section": (r.get("evidence_location") or {}).get("section"), "quote": e.get("exact_evidence_span"),
                  "date_quote": (d.get("date_evidence") or {}).get("text")}
            out["advanced"]["record_ids"].append(e["record_id"])
            out["advanced"]["rule_ids"].append(((r.get("extraction_method") or {}).get("rule_id")))
            cat = str(e.get("event_category") or "")
            if cat.startswith("INSIDER_TRANSACTION"):          # Q12: Form 4 rows (synthetic cases have them; real Form 4 is not supported)
                ev = {**ev, "kind": "Form 4 原文", "section": None}
                if not d.get("transaction_type"):
                    out["needs_check"].append({"text": f"一行内部人交易记录没有使用：{_reason_zh_form4(d.get('reason'))}", "status": "无法判断", "evidence": ev})
                    continue
                who = "、".join(o.get("name") or "" for o in d.get("owners") or []) or "（没有写明交易人）"
                kind_ = {"PURCHASE": "买入", "SALE": "卖出"}.get(d["transaction_type"], f"其他类型交易（代码 {d.get('raw_code')}）")
                px = f"，每股 {_num(d['price'])}" if d.get("price") is not None else "，没有写明价格"
                out["facts"].append({"kind": "内部人交易", "text": f"{who} 在 {d.get('transaction_date')} {kind_} {_num(d.get('shares'))} 股{px}（Form 4 申报，按申报原样列出）。",
                                     "status": None, "evidence": ev})
                continue
            if d.get("action") not in ACTION_ZH and d.get("action") != "DEPARTURE":     # Q12: any other event kind is listed with its original claim
                out["needs_check"].append({"text": f"其他类型的公告事件（系统没有中文说明，下面是原文摘要）：{e.get('claim')}", "status": "无法判断", "evidence": ev})
                continue
            if d.get("modality") == "TENTATIVE" or e.get("ambiguity_status") != "UNAMBIGUOUS" or e.get("evidence_status") in ("CONTRADICTED", "SUPERSEDED"):
                why = ("措辞是意向（例如“打算退休”），不是确定的决定" if d.get("modality") == "TENTATIVE" else
                       "公告没有写明是哪个职务" if not d.get("role") else
                       "委员会名单怎么拆分，原文不能确定" if "committees" in str(e.get("claim")) else
                       "另一份公告与它不一致" if e.get("evidence_status") == "CONTRADICTED" else
                       "已被后来的修订公告取代" if e.get("evidence_status") == "SUPERSEDED" else "原文的读法不唯一")
                verb = ({"DEPARTURE": "表示打算离任", "APPOINTMENT": "可能被任命为", "CONTINUATION": "可能继续担任"} if d.get("modality") == "TENTATIVE" else
                        {"DEPARTURE": "卸任", "APPOINTMENT": "被任命为", "CONTINUATION": "继续担任"}).get(d.get("action"), "")
                rz = _role_zh(d.get("role")) if d.get("role") else ("（公告没有写明职务）" if d.get("modality") != "TENTATIVE" else "")
                out["needs_check"].append({"text": f"{d.get('person')} {verb}{rz}——需要核实：{why}",
                                           "status": STATUS_ZH.get(e.get("current_status"), STATUS_ZH["UNKNOWN"]), "evidence": ev})
                continue
            shown += 1
            act = d.get("action")
            txt = (f"{d.get('person')} {ACTION_ZH[act]}{_role_zh(d.get('role'))}" if act != "DEPARTURE" else f"{d.get('person')} 卸任{_role_zh(d.get('role'))}")
            if act == "CONTINUATION" and (d.get("end_date") or {}).get("value"):
                txt += f"，任期到 {d['end_date']['value']}"
            stz = STATUS_ZH.get(e.get("current_status"), STATUS_ZH["UNKNOWN"]) if e.get("current_status") != "UNKNOWN" else "截至报告日是否生效无法判断"
            out["facts"].append({"kind": "公告事件", "text": f"{txt}；{_date_zh(d)}。{stz}。",
                                 "status": e.get("current_status"), "evidence": ev})
        if not shown and not out["needs_check"]:
            out["facts"].append({"kind": "公告事件", "text": f"在本次读取的 {len(docs)} 份 8-K 公告里，没有找到能确定的管理层变动。这不等于没有发生：本系统只读管理层变动条目。",
                                 "status": None, "evidence": {"kind": "读取范围", "documents": sorted(docs)}})
    # ---- Fundamental
    Fu = E["fundamental"]
    if Fu["execution_status"] == "COMPLETED":
        F = (Fu.get("output") or {}).get("findings") or {}
        mb = F.get("metrics_by_year") or {}
        fy = max(mb, key=lambda k: int(k)) if mb else None
        src = next((x.get("source_document_id") for x in (Fu.get("output") or {}).get("evidence") or [] if x.get("source_document_id")), None)
        av = next((x.get("available_at") for x in (Fu.get("output") or {}).get("evidence") or [] if x.get("available_at")), None)
        evb = {"kind": "财报数据", "source": src, "fiscal_year": fy, "available": (av or "")[:10]}
        g = F.get("financial_growth") or {}
        if g.get("classification"):
            v = g.get("latest_growth")
            out["facts"].append({"kind": "财报", "text": f"FY{fy} 收入较上一年 {_pct(v) if v is not None else ''}（{CLASS_ZH.get(g['classification'], '无法判断')}）。".replace("  ", " "),
                                 "evidence": {**evb, "inputs": "revenue (两年)"}})
        prof = F.get("financial_profitability") or {}
        parts = []
        for k, zh in (("gross_margin", "毛利率"), ("operating_margin", "营业利润率"), ("net_margin", "净利率")):
            t = prof.get(k) or {}
            if t.get("latest") is not None:
                parts.append(f"{zh} {t['latest'] * 100:.1f}%（{CLASS_ZH.get(t.get('classification'), '无法判断')}" + (f"，{t['change'] * 100:+.2f} 个百分点" if t.get("change") is not None else "") + "）")
            elif t.get("classification"):
                parts.append(f"{zh}：{CLASS_ZH.get(t['classification'], '无法判断')}")
        if parts:
            out["facts"].append({"kind": "财报", "text": f"FY{fy} " + "；".join(parts) + "。“稳定”指变化在 ±0.5 个百分点以内。", "evidence": {**evb, "inputs": "利润表"}})
        bsh = F.get("balance_sheet_health") or {}
        de = (bsh.get("debt_to_equity") or {})
        if de.get("status") == "COMPUTED":
            out["facts"].append({"kind": "财报", "text": f"FY{fy} 债务合计 {de['inputs']['total_debt']:,.0f} 美元，约为股东权益的 {de['value']:.2f} 倍（长期债务 + 短期债务）。",
                                 "evidence": {**evb, "inputs": "长期债务、短期债务、股东权益"}})
        cr = (bsh.get("current_ratio") or {})
        if cr.get("status") == "COMPUTED":
            out["facts"].append({"kind": "财报", "text": f"FY{fy} 流动资产是流动负债的 {cr['value']:.2f} 倍。", "evidence": {**evb, "inputs": "流动资产、流动负债"}})
        for c in (Fu.get("output") or {}).get("counter_evidence") or []:
            if c.get("metric") and isinstance(c.get("fact"), str) and "deterioration indicator" in c["fact"]:
                nm = {"current_ratio": "流动比率", "cash_conversion": "经营现金流与净利润之比", "debt_to_equity": "债务与权益之比", "gross_margin": "毛利率",
                      "operating_margin": "营业利润率", "net_margin": "净利率", "revenue_growth": "收入"}.get(c["metric"], "一项财务指标")
                within = "（变化在稳定区间以内）" if "within the stable band" in c["fact"] else ""
                out["facts"].append({"kind": "财报", "text": f"需要留意：{nm}比上一年变差{within}。", "evidence": {**evb, "inputs": c.get("metric")}})
        for m in F.get("missing_information") or []:
            nm_ = {"liabilities_to_assets": "负债/资产", "current_ratio": "流动比率", "debt_to_equity": "债务/权益", "interest_coverage": "利息保障倍数",
                   "gross_margin": "毛利率", "operating_margin": "营业利润率", "net_margin": "净利率", "roe": "净资产收益率", "roic": "投入资本回报率",
                   "cash_conversion": "经营现金流/净利润", "fcf_margin": "自由现金流率", "revenue_growth": "收入增长", "total_debt": "债务合计（长期 + 短期）",
                   "net_debt": "净债务", "effective_tax_rate": "实际税率", "free_cash_flow": "自由现金流", "asset_turnover": "资产周转率"}.get(m.get("metric"))
            out["gaps"].append({"text": f"财报缺少计算“{nm_ or '一项比率'}”所需的数据，这一项没有算（不按零处理）。"})
        for it in F.get("indeterminate_risk_checks") or []:
            out["gaps"].append({"text": f"有一项风险检查因缺少输入无法判断（{ {'ACCOUNTING_IDENTITY_MISMATCH': '会计恒等式核对', 'LEVERAGE_INCREASING': '杠杆是否上升'}.get(it.get('check'), '一项检查')}）；无法判断不等于没有风险。"})
            out["advanced"]["codes"].append(it.get("check"))
    # ---- Valuation
    V = E["valuation"]
    if V["execution_status"] == "COMPLETED":
        F = (V.get("output") or {}).get("findings") or {}
        sd = _shares_date(rec)
        pdate = (((rec.get("q8") or {}).get("model") or {}).get("valuation") or {}).get("market", {}).get("price_date") or (rec.get("context") or {}).get("as_of", as_of)[:10]
        try:
            from datetime import date as _d
            lag = (_d.fromisoformat(pdate[:10]) - _d.fromisoformat(sd)).days if sd else None
        except ValueError:
            lag = None
        sd_txt = (f"股数截至 {sd}" + (f"，比价格日早 {lag} 天" if lag is not None and lag > 0 else "")) if sd else "股数日期未知"
        if lag is not None and lag > 90:
            out["gaps"].append({"text": f"股数是 {sd} 的数字，比价格日早 {lag} 天；这期间回购或增发会让所有按市值计算的倍数偏离（没有更新的股数）。"})
        for w_ in ((V.get("output") or {}).get("warnings") or []):          # 1.1.2 (2nd review N8): old figures / an old price are said in words
            if w_.get("code") == "FINANCIALS_STALE":
                out["gaps"].append({"text": "估值用的年报数字比价格日早一年以上，倍数是拿现在的价格和较旧的年度数字比，参考意义有限。"})
            elif w_.get("code") == "PRICE_NOT_CURRENT":
                out["gaps"].append({"text": "估值用的价格不是报告截止日附近的价格，倍数不代表截止日的情况。"})
        fin = next((m.get("inputs") for m in F.get("methods") or [] if m.get("status") == "COMPUTED"), None)
        for m in F.get("methods") or []:
            name = METHOD_ZH.get(m.get("method"), "一种估值方法")
            if m.get("status") == "COMPUTED" and m.get("observed_multiple") is not None:
                val = f"{m['observed_multiple'] * 100:.1f}%" if m["method"] == "FCF_YIELD" else f"{m['observed_multiple']:.1f} 倍"
                out["readings"].append({"kind": "估值倍数", "text": f"{name} {val}（价格是 {pdate[:10]} 的收盘价；财务数据用最近一个财年的年报，不是最近四个季度；"
                                        f"{sd_txt}）。这是描述值，没有参考区间，不判断贵或便宜。",
                                        "evidence": {"kind": "估值输入", "inputs": {FIELD_ZH.get(k, f"输入 {k}"): _num(v) for k, v in (m.get("inputs") or {}).items()}}})
            elif m.get("status") != "COMPUTED":
                miss = [FIELD_ZH.get(x, x) for x in m.get("missing_fields") or [] if x in FIELD_ZH]
                codes = [c.get("code") for c in m.get("codes") or []]
                out["advanced"]["codes"] += codes
                if "FORWARD_METHOD_UNAVAILABLE" in codes:
                    why = "需要分析师预测数据，本系统没有合格来源"
                elif "NEGATIVE_EARNINGS" in codes:
                    why = "最近一个财年是亏损，市盈率没有意义"                  # 1.1.2 (2nd review N8)
                elif "NEGATIVE_ENTERPRISE_VALUE" in codes:
                    why = "企业价值（市值 + 债务 − 现金）为零或负数，这个倍数没有意义"
                elif "NEGATIVE_BOOK_VALUE" in codes:
                    why = "股东权益为负数，市净率没有意义"
                elif "NEGATIVE_EBITDA" in codes:
                    why = "EBITDA 为负数，这个倍数没有意义"
                elif "DENOMINATOR_ZERO" in codes:
                    why = "作为分母的数字是零，这个倍数没有意义"
                elif "NEGATIVE_VALUE_INVALID" in codes:
                    why = "有一项输入是负数（不应为负），没有使用"
                elif m.get("method") == "DCF_FCF":
                    why = "没有声明现金流假设，系统不自行假设"
                elif miss:
                    why = "缺少" + "、".join(miss)
                elif m.get("applicability") == "NOT_APPLICABLE":
                    why = "对这个行业不适用"
                else:
                    why = "所需数据不全或不适用"
                out["gaps"].append({"text": f"{name}没有计算：{why}（缺的数据不按零处理）。"})
        del fin
    # ---- Technical / Macro (production models, unchanged; their own rule readings)
    for eid in ("technical", "macro"):
        X = E[eid]
        if X["execution_status"] != "COMPLETED":
            continue
        o = X.get("output") or {}
        for ev_ in (o.get("evidence") or []) + (o.get("counter_evidence") or []):
            k, v = ev_.get("metric"), ev_.get("value")
            name = TECH_ZH.get(k, "一项指标")
            vtxt = _pct(v) if k in PCT else (f"{v:+.2f} 个百分点" if k == "tnx_change_6m" else f"{v:.2f}" if isinstance(v, (int, float)) else "—")
            lean = {"positive": "偏强" if eid == "technical" else "对市场环境偏正面", "negative": "偏弱" if eid == "technical" else "对市场环境偏负面"}.get(ev_.get("interpretation"), "中性")
            out["readings"].append({"kind": "技术面" if eid == "technical" else "宏观（市场层面，不针对这家公司）",
                                    "text": f"{name} {vtxt}；生产模型的规则读法：{lean}。这是对指标的规则读法，未经验证，不是买卖信号。",
                                    "evidence": {"kind": "价格序列" if eid == "technical" else "宏观序列",
                                                 "dataset": (((rec.get("q8") or {}).get("model") or {}).get("price_dataset") or (rec.get("q8") or {}).get("price_dataset")
                                                             or (rec.get("context") or {}).get("price_dataset")),
                                                 "metric": name, "metric_value": (_pct(v) if k in PCT else _num(v)), "as_of": (o.get("as_of") or (rec.get("context") or {}).get("as_of") or as_of or "")[:10]}})
            out["advanced"]["codes"].append(k)
    # ---- experts table
    from synthesis import synthesize as SY
    BX = (rec.get("synthesis") or {}).get("B_experts") or {}
    for eid in ("technical", "macro", "fundamental", "valuation", "information"):
        X = E[eid]
        ok = X["execution_status"] == "COMPLETED"
        valid = ok and bool((BX.get(eid) or {}).get("used_in_synthesis")) and SY.valid_finding(eid, BX.get(eid) or {})
        reason = None if ok else "；".join(_reason_zh(x) for x in X.get("status_reasons") or [])[:200] or "原因未记录"
        out["experts"].append({"expert": eid, "name": EXPERT_ZH[eid], "ok": ok, "valid_content": bool(valid),
                               "text": ("运行完成，有有效发现" if valid else "运行完成，但没有有效发现（这不等于没有风险）") if ok else
                               f"没有结果：{reason}。这个维度在本次报告中缺失，不按零或中性处理，也不等于没有风险。"})
        out["advanced"]["codes"] += [x.get("code") for x in X.get("status_reasons") or []]
    # ---- limits (always shown)
    out["limits"] = [
        "内部试验：没有经过金融有效性验证，不是投资建议，不提供买卖信号。",
        "离线：用的是上面写明日期的已有快照，没有联网获取最新数据。",
        "公告事件由规则从 8-K 原文抽取，是待核实的线索，系统不判断真伪；只读管理层变动（第 5.02 项，以及第 7.01 / 8.01 项和说明段中能对上的日期与人员），不读其他事件类型，也没有内部人交易（Form 4）。",
        "没有找到事件不等于没有事件；没有触发规则不等于没有风险。",
        "估值倍数用最近一个财年的年报数字，不是最近四个季度（TTM）；股数日期写在每条倍数旁边。",
        "技术面、宏观的“偏强 / 偏负面”是生产模型的规则读法，未经验证；宏观描述市场环境，不针对这家公司。",
        "每项数据当时是否已经公开（历史时点）没有逐项核实。",
    ]
    for g in ((rec.get("synthesis") or {}).get("K_key_gaps") or []):
        out["advanced"]["codes"] += [it.split("（")[0] for it in g.get("items") or []]
    out["advanced"]["codes"] = sorted({c for c in out["advanced"]["codes"] if c})
    seen_ = set()                                    # 1.1.0: the same gap once
    out["gaps"] = [g for g in out["gaps"] if not (g["text"] in seen_ or seen_.add(g["text"]))]
    return out


def _reason_zh(x: dict) -> str:
    c = x.get("code") or ""
    return {"INJECTED_FAULT": "测试注入的故障", "PROCESS_CRASH": "专家进程异常退出", "TIMEOUT": "运行超时", "INPUT_REJECTED": "输入没有通过检查",
            "IDENTITY_MISMATCH": "代码身份核对没有通过", "OUTPUT_CONTRACT_VIOLATION": "输出不符合约定格式", "DEPENDENCY_MISSING": "缺少需要的输入数据"}.get(c) or \
        (x.get("meaning_zh") or "运行没有正常完成")


def code_tokens(b: dict) -> list:
    """internal codes that leaked into the four main parts or the experts table (the evidence blocks and `advanced` are exempt)"""
    texts = [x["text"] for k in ("facts", "readings", "gaps", "needs_check") for x in b.get(k) or []] + list(b.get("limits") or []) + [x["text"] for x in b.get("experts") or []]
    return sorted({m for t in texts for m in CODE_RX.findall(t)})
