"""Q12 public demo - the Python side of one analysis in the browser (Pyodide in a Web Worker started for this one analysis and ended after it).

analyze(case_id) runs the five experts on one SYNTHETIC case of the demo list (DEMO_CASES; nothing else can be named), through the same
orchestrator.run_q8 the local workbench uses (the subprocess calls run in this interpreter: browser/inprocess.py), builds the beginner report and
returns one JSON text: the page view, the full run record for download, and a SHA-256 of the record, so the page, the download and the browser
history all belong to the same run. No network, no real data: the bundle has no real-data files and no data-fetching module.
"""
from __future__ import annotations

import hashlib
import json
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
APP = HERE.parent
sys.path.insert(0, str(APP))
sys.path.insert(0, str(HERE))
import inprocess  # noqa: E402

inprocess.install()
from orchestrator import q8_input as Q, run as RUN  # noqa: E402
from workbench import beginner as BG  # noqa: E402
from adapters import registry as R  # noqa: E402

DEMO_CASES = {c["case_id"]: {k: v for k, v in c.items() if k != "case_id"} for c in json.loads((HERE / "demo_cases.json").read_text(encoding="utf-8"))["cases"]}   # synthetic only
DEMO_LIMITS = [
    "演示:公司、价格、财报、公告和内部人交易申报都是合成的;不对应任何真实公司,也不是最新数据。",
    "没有经过金融有效性验证,不是投资建议,不提供买卖信号。",
    "技术面、宏观是生产在用的规则模型(原样调用),它们的“偏强 / 偏弱 / 偏负面”是规则读法,未经验证;宏观描述市场环境,不针对这家公司。",
    "基本面、估值、公告是实验版本,生产中未激活。",
    "公告事件由规则从原文抽取,是待核实的线索;系统不能确定的放在“需要核实”。内部人交易按申报原样列出。",
    "估值倍数用最近一个财年的年报数字,不是最近四个季度;没有参考区间,不判断贵或便宜。",
    "没有找到事件不等于没有事件;没有触发规则不等于没有风险。",
]
EXPERT_ZH = {"technical": "技术面(价格走势)", "macro": "宏观(市场环境)", "fundamental": "基本面(财报)", "valuation": "估值(倍数)", "information": "公告(管理层变动、内部人交易)"}
STATUS_ZH = {"COMPLETED": "已运行", "COMPLETED_NO_RESULT": "已运行,没有结果", "REJECTED": "输入被拒绝", "NOT_APPLICABLE": "不适用", "NOT_EXECUTED": "没有运行",
             "FAILED": "运行失败"}


def cases() -> str:
    return json.dumps([{"case_id": k, **v} for k, v in DEMO_CASES.items()], ensure_ascii=False)


def _short_version(v) -> str:
    """the version name only - the long development notes inside version strings are not shown on the page"""
    s = str(v or "")
    return s.split(" (")[0][:60]


def analyze(case_id: str) -> str:
    if case_id not in DEMO_CASES:
        return json.dumps({"ok": False, "error": "这个演示只支持列出的合成公司和场景。"}, ensure_ascii=False)
    t = time.time()
    model, kind, _, case_sha = Q.load_case(case_id)
    rec = RUN.run_q8(model, None, "REGISTERED_CASE")
    subject = model.get("subject") or {}
    as_of = model.get("as_of") or rec.get("as_of")
    beg = BG.build(rec, subject.get("security") or "", subject.get("name") or "", str(as_of), {})
    beg["data_notice"] = (f"演示数据:{subject.get('name')} 是合成公司,价格、财报和公告都是为演示编写的,截止日 {str(as_of)[:10]}。"
                          "不是任何真实公司的最新分析,也不是投资建议。")
    beg.pop("advanced", None)                                  # rule ids and internal codes stay in the downloadable record only
    beg["limits"] = DEMO_LIMITS                                # the beginner report's limits describe the real-data mode; the demo has its own
    record_text = json.dumps(rec, ensure_ascii=False, sort_keys=True, allow_nan=False, default=str)
    sha = hashlib.sha256(record_text.encode("utf-8")).hexdigest()
    experts = []
    for eid in R.ORDER:
        r = rec["experts"][eid]
        experts.append({"expert": eid, "name": EXPERT_ZH.get(eid, eid), "status": r["execution_status"],
                        "status_zh": STATUS_ZH.get(r["execution_status"], r["execution_status"]),
                        "version": _short_version(r.get("implementation_version")),
                        "tier": "生产在用(原样调用)" if R.EXPERTS[eid]["tier"] == "PRODUCTION_ACTIVE" else "实验版本(生产中未激活)",
                        "reasons": [{"meaning": x.get("meaning"), "detail": str(x.get("detail") or "")[:300]} for x in (r.get("status_reasons") or [])][:6]})
    view = {"ok": True, "run_id": rec["run_id"], "case_id": case_id, "case": DEMO_CASES[case_id], "subject": subject, "as_of": as_of,
            "started_at": rec.get("started_at"), "finished_at": rec.get("finished_at"), "seconds": round(time.time() - t, 2),
            "synthesis_status": (rec.get("synthesis") or {}).get("status"), "experts": experts, "beginner": beg,
            "record_sha256": sha, "case_sha256": case_sha, "python": sys.version.split()[0]}
    return json.dumps({"view": view, "record_text": record_text}, ensure_ascii=False)
