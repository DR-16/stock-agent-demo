"""Q15 decision layer - format check of everything the layer reads (contract §2: "判断层读到的每个字段先检查类型和有限性").

    errs = check(value, SPEC, "$.experts.fundamental.output")   # [] when the value is usable

A spec is a kind name ("num?", "str?", "dict", ...) or a dict: "." the node's own kind, "<key>" a child, "*" every value of a dict, "[]" every element
of a list. A key that is absent reads as None, so an optional kind ("...?") accepts it. Only the fields the layer reads are listed: an unknown extra
field is never an error. A malformed expert output is treated as missing (its dimension becomes 无法判断) and reported as a structured error; nothing
downstream ever sees a value of the wrong type, so the layer cannot crash on it.
"""
from __future__ import annotations

import math

KINDS = {"num?": {"int", "num", "none"}, "int?": {"int", "none"}, "str?": {"str", "none"}, "dict?": {"dict", "none"}, "list?": {"list", "none"},
         "dict": {"dict"}, "list": {"list"}, "str": {"str"}, "scalar?": {"str", "int", "num", "bool", "none"}, "any": None}
ZH = {"num?": "数字或空值", "int?": "整数或空值", "str?": "文字或空值", "dict?": "对象或空值", "list?": "列表或空值", "dict": "对象", "list": "列表", "str": "文字",
      "scalar?": "单个值或空值"}
KIND_ZH = {"none": "空值", "bool": "真假值", "int": "整数", "num": "数字", "nonfinite": "非有限数字（NaN 或无穷）", "str": "文字", "dict": "对象", "list": "列表"}
MAX_ERRORS = 8


def kind(v) -> str:
    if v is None:
        return "none"
    if isinstance(v, bool):
        return "bool"
    if isinstance(v, int):
        return "int" if abs(v) < 10 ** 300 else "nonfinite"      # review IB-03: an integer beyond float range is not a usable number
    if isinstance(v, float):
        return "num" if math.isfinite(v) and abs(v) < 1e300 else "nonfinite"     # review R2-ROB-06
    if isinstance(v, str):
        return "str"
    if isinstance(v, dict):
        return "dict"
    if isinstance(v, list):
        return "list"
    return type(v).__name__


def check(v, spec, path: str, errs: list | None = None, cap: int = MAX_ERRORS) -> list:
    errs = [] if errs is None else errs
    if len(errs) >= cap:
        return errs
    spec = {".": spec} if isinstance(spec, str) else spec
    allowed = KINDS[spec["."]]
    k = kind(v)
    if allowed is not None and k not in allowed:
        errs.append({"where": path, "problem": f"应为{ZH[spec['.']]}，实际是{KIND_ZH.get(k, k)}"})
        return errs
    if k == "dict":
        for key, sub in spec.items():
            if key not in (".", "*", "[]"):
                check(v.get(key), sub, f"{path}.{key}", errs, cap)
        if "*" in spec:
            for key, val in v.items():
                check(val, spec["*"], f"{path}.{key}", errs, cap)
    elif k == "list" and "[]" in spec:
        for i, x in enumerate(v):
            check(x, spec["[]"], f"{path}[{i}]", errs, cap)
    return errs


_EV_ITEM = {".": "dict", "metric": "str?", "interpretation": "str?", "value": "num?", "comment": "scalar?"}
OUTPUT_SPECS = {
    "fundamental": {".": "dict",
                    "data_status": {".": "dict?", "sufficiency": "str?", "latest_fiscal_year": "int?", "completeness": "scalar?", "currency": "str?"},
                    "findings": {".": "dict?",
                                 "risk_checks": {".": "dict?", "*": "str?"},
                                 "financial_growth": {".": "dict?", "classification": "str?", "latest_growth": "num?"},
                                 "financial_profitability": {".": "dict?", "loss_making": "str?",
                                                             "operating_margin": {".": "dict?", "classification": "str?", "prior": "num?", "latest": "num?", "change": "num?"}},
                                 "cash_flow_quality": {".": "dict?", "classification": "str?", "operating_cash_flow": "num?", "net_income": "num?", "free_cash_flow": "num?",
                                                       "cash_conversion": {".": "dict?", "value": "num?", "status": "str?"}},
                                 "balance_sheet_health": {".": "dict?", "leverage_trend": "str?", "debt_to_equity": {".": "dict?", "value": "num?"},
                                                          "debt_to_equity_prior": "num?"},
                                 "inputs_by_year": {".": "dict?", "*": {".": "dict?", "revenue": "num?", "net_income": "num?", "operating_income": "num?",
                                                                        "stockholders_equity": "num?", "interest_expense": "num?", "operating_cash_flow": "num?",
                                                                        "capex": "num?"}},
                                 "financial_risks": {".": "list?", "[]": {".": "dict", "flag": "str?", "evidence": "scalar?"}}}},
    "technical": {".": "dict",
                  "metadata": {".": "dict?", "metrics": {".": "dict?", "momentum_12m_1m": "num?", "sma50_sma200_ratio": "num?", "relative_strength_6m": "num?",
                                                         "max_drawdown_2y": "num?", "avg_dollar_volume_20d": "num?"},
                               "price_bars_used": "num?"},
                  "evidence": {".": "list?", "[]": _EV_ITEM}, "counter_evidence": {".": "list?", "[]": _EV_ITEM},
                  "data_freshness_days": "num?"},
    "macro": {".": "dict",
              "metadata": {".": "dict?", "regime_hint": "str?",
                           "features": {".": "dict?", "*": "num?"}},
              "data_freshness_days": "num?"},
    "valuation": {".": "dict",
                  "findings": {".": "dict?",
                               "methods": {".": "list?", "[]": {".": "dict", "method": "str?", "status": "str?", "observed_multiple": "num?"}},
                               "assumptions": "dict?",
                               "estimated_value_ranges": {".": "list?", "[]": {".": "dict", "method": "str?", "low": "num?", "high": "num?"}},
                               "stability_warnings": {".": "dict?", "state": "str?"}},
                  "calculation_or_extraction_trace": {".": "list?", "[]": {".": "dict", "step": "str?", "values": "dict?"}},
                  "warnings": {".": "list?", "[]": "any"}},
    "information": {".": "dict",
                    "data_status": {".": "dict?", "analysed": "int?", "documents_supplied": "int?"},
                    "findings": {".": "dict?",
                                 "all_extraction_records": {".": "list?", "[]": {".": "dict", "record_id": "scalar?",
                                                                                 "details": {".": "dict?", "role": "str?", "person": "scalar?", "action": "scalar?",
                                                                                             "effective_date": "scalar?"}}},
                                 "events_detected": {".": "list?", "[]": {".": "dict", "event_category": "str?", "evidence_status": "str?", "claim": "str?",
                                                                          "record_id": "scalar?", "current_status": "scalar?", "exact_evidence_span": "str?",
                                                                          "document_id": "scalar?"}},
                                 "conflicting_evidence": {".": "list?", "[]": "dict"}, "supersessions": {".": "list?", "[]": "dict"},
                                 "date_disagreements": {".": "list?", "[]": "dict"}, "within_document_inconsistencies": {".": "list?", "[]": "dict"},
                                 "documents_processed": {".": "list?", "[]": {".": "dict", "document_id": "scalar?", "status": "str?", "form_type": "scalar?",
                                                                              "codes": {".": "list?", "[]": {".": "dict", "code": "scalar?"}}}},
                                 "unresolved_mentions": {".": "list?", "[]": "dict"},
                                 "metadata_layer": {".": "dict?", "*": {".": "dict?", "raw_item_codes": {".": "list?", "[]": "str"}}}}},
}
# the derived-inputs step of Valuation's trace carries the price the multiples use
VALUATION_PRICE_SPEC = {".": "dict?", "price": "num?", "price_date": "scalar?"}

RECORD_SPEC = {".": "dict",
               "experts": {".": "dict?", "*": {".": "dict?", "execution_status": "scalar?", "output_contract_status": "scalar?",
                                               "status_reasons": {".": "list?", "[]": {".": "dict", "code": "scalar?"}},
                                               "implementation_version": "scalar?", "output_fingerprint": "scalar?"}},
               "context": {".": "dict?", "issuer": {".": "dict?", "industry_class": "str?", "name": "scalar?", "security": "scalar?", "issuer_id": "scalar?"},
                           "as_of_utc": "scalar?", "as_of_utc_date": "scalar?", "as_of": "scalar?"},
               "synthesis": {".": "dict?", "status": "scalar?", "D1_cross_expert_contradictions": {".": "list?", "[]": {".": "dict", "rule": "str?"}},
                             "section_status": {".": "dict?", "D1_cross_expert_contradictions": {".": "dict?", "not_compared": {".": "list?", "[]": {".": "dict", "rule": "str?", "why": "scalar?"}}}}},
               "run_id": "scalar?", "case_id": "scalar?", "data_kind": "str?", "labels": {".": "list?", "[]": "scalar?"}}
DECLARED_SPEC = {".": "dict?", "comparison_basis": "any", "document_coverage": "any"}     # each declared input is checked on its own (review EVS-05)
COVERAGE_SPEC = {".": "dict", "available": "int?", "supplied": "int?", "window_days": "int?", "source": "scalar?"}
