"""Q15 decision layer - frozen constants: versions, labels, tags, thresholds (each with its source). See Q15_DECISION_CONTRACT.md part II.

Self-contained (does not import the Q14 rules.py, which stays as the frozen 0.3.0 baseline). Nothing here is fitted or tuned on returns; every value
is a declared convention, an expert's own constant or a product assumption."""
from __future__ import annotations

import re

DECISION_VERSION = "q15-decision 0.4.0"
CONTRACT_VERSION = "q15-decision-contract 2.0.0"
SCHEMA = "Q15_DECISION_V2"

OE_LABELS = ("改善", "稳定", "分化", "恶化", "无法判断")
OE_BASIS = ("完整", "部分", "边缘")
IJ_LABELS = ("偏积极", "中性", "偏谨慎", "无法判断")
IJ_BASIS = ("充分", "有限", "不足")
TREND = ("上行", "下行", "混合", "无明显趋势", "无法判断")
TREND_EFFECT = ("支持", "反对", "不构成支持或反对", "无法判断")
ENV = ("偏支持", "中性", "偏紧张", "无法判断")
VAL_BASIS = ("有比较依据", "只有声明假设", "只有倍数", "无")
VAL_JUDGMENT = ("相对偏低", "相对适中", "相对偏高", "仅条件性", "无法判断")
EVENTS_STATUS = ("完成", "部分", "未检查")
RISK_STATUS = ("TRIGGERED", "NOT_TRIGGERED", "UNKNOWN", "NOT_APPLICABLE")
TAGS = ("OPS_TREND_CONFLICT", "PRICE_UP_OPS_DOWN", "HARD_RISK", "CASH_QUALITY_WEAK", "CASH_BELOW_EARNINGS", "LEVERAGE_RISING", "LOSS_MAKING", "DEEP_DRAWDOWN",
        "LIQUIDITY_RISK", "MACRO_STRESS_CONTEXT", "UNVERIFIED_MATERIAL_EVENT", "SOURCE_CONFLICT", "VALUATION_NO_BASIS", "VALUATION_NOT_ROBUST", "VALUATION_REL_HIGH",
        "VALUATION_REL_LOW", "STALE_PRICE", "STALE_FINANCIALS", "UNIT_SUSPECT_PRICE", "UNIT_SUSPECT_RATE", "INPUT_CONTRADICTION", "IDENTITY_CONFLICT",
        "EXPERT_MISSING", "INDUSTRY_LIMITED", "INDUSTRY_NOT_SUPPORTED", "TREND_NOT_ASSESSABLE", "EVENTS_NOT_CHECKED", "RISK_CHECKS_INCOMPLETE",
        "EVENTS_PARTIALLY_CHECKED", "EDGE_CHANGE", "PRICE_UNUSABLE", "INPUT_MALFORMED", "NO_VALUATION_COMPARISON")

THRESHOLDS = {
    "T-FRESH-PRICE": {"value": 10, "unit": "calendar days", "use": "最后一根日线距截止日的最大天数（价格、宏观）", "source": "工程约定",
                      "basis": "与 Valuation 的 PRICE_NOT_CURRENT（10 天）一致"},
    "T-FRESH-FIN": {"value": 486, "unit": "calendar days", "use": "最新财年（按 12 月 31 日计）距截止日的最大天数", "source": "工程约定",
                    "basis": "与 Valuation 的 FINANCIALS_STALE 一致（365 天 + 年报披露期）"},
    "T-RATE-UNIT": {"value": 0.25, "unit": "percent", "use": "10 年期利率水平低于此值视为疑似小数单位", "source": "外部依据 + 工程约定",
                    "basis": "美国 10 年期国债收盘收益率有记录以来未低于约 0.52%（2020 年 8 月）"},
    "T-CASH-CONV": {"value": 0.5, "unit": "经营现金流 / 净利润", "use": "盈利但经营现金流不到净利润一半：盈利缺少现金支撑（G_CASH = WEAK）",
                    "source": "产品假设", "basis": "Q14 开发轮看过开发集标注后定下；取整数中点，不是拟合值，也不是验证过的财务规律"},
    "T-EDGE": {"value": {"revenue_growth": 0.02, "operating_margin_change": 0.010}, "unit": "比例 / 比例点",
               "use": "推动经营评价的变化只略微越过专家持平带（收入 ±1%、利润率 0.5 个百分点）的两倍以内时，依据标为“边缘”",
               "source": "工程约定", "basis": "持平带宽度的两倍；未经验证"},
    "T-PERSISTENT-LOSS": {"value": 2, "unit": "连续财年", "use": "持续亏损：估值依据为“无”", "source": "产品假设", "basis": "最近两个连续财年净利润都为负"},
    "T-NEAR-EDGE": {"value": 0.05, "unit": "相对距离", "use": "观察倍数距比较区间边界不到 5% 时，相对估值不稳健", "source": "工程约定", "basis": "—"},
    "T-COMP-AGE": {"value": 365, "unit": "calendar days", "use": "比较依据日期距截止日的最大天数", "source": "产品假设", "basis": "—"},
    "T-MATERIAL-ROLES": {"value": "CEO / CFO / 总裁（President）/ 董事长（Chair of the Board）", "use": "判定重大管理层变动线索", "source": "产品假设",
                         "basis": "这些职位的变动通常被视为重大；未经验证"},
    "T-UNREAD-ITEMS": {"value": "8-K 第 1.01、1.02、1.03、1.05、2.01、2.03、2.04、2.05、2.06、3.01、3.03、4.01、4.02、5.01 项",
                       "use": "这些事项本系统不解读；出现时公告检查只能算“部分”", "source": "产品假设",
                       "basis": "可能直接影响财务或治理；2.02、5.03、5.05、5.07、7.01、8.01、9.01 等只记录存在"},
    "T-HARD-RISK": {"value": "H1 负股东权益；H2 营业亏损且有利息；H3 营业利润低于利息；H4 亏损且经营现金流为负；H5 流动负债超过流动资产且经营现金流为负",
                    "use": "硬性风险检查", "source": "会计定义 + 产品假设", "basis": "出现即不宜偏积极（未经验证）"},
    "INDUSTRY-SUPPORT": {"value": "支持：INDUSTRIAL CONSUMER TECHNOLOGY_SOFTWARE HEALTHCARE；有限：ENERGY UTILITY REIT OTHER；不支持：BANK INSURANCE",
                         "use": "行业闸门", "source": "专家常量 + 产品假设", "basis": "专家常量 constants.py:21-32 已声明的行业不适用规则"},
    "EXPERT-OWN": {"value": "收入平带 ±1%；利润率平带 0.5 个百分点；杠杆平带 0.05；Technical 动量 ±10% / 相对强弱 ±5% / SMA 1.02、0.98 / 回撤 -40% / 成交额 1000 万；"
                            "Macro 环境阈值；Valuation 稳定性 0.5 / 0.75",
                   "use": "判断层只读专家给出的分类", "source": "专家自带", "basis": "各专家声明为设计常数，未经验证"},
}

INDUSTRY_SUPPORT = {"INDUSTRIAL": "支持", "CONSUMER": "支持", "TECHNOLOGY_SOFTWARE": "支持", "HEALTHCARE": "支持",
                    "ENERGY": "有限支持", "UTILITY": "有限支持", "REIT": "有限支持", "OTHER": "有限支持", "BANK": "不支持", "INSURANCE": "不支持"}
INDUSTRY_NOTE = {"ENERGY": "能源企业的收入和利润率随商品价格周期波动，经营趋势未必是公司自身的",
                 "UTILITY": "公用事业受管制，杠杆天然偏高，通用的杠杆读法不可比",
                 "REIT": "REIT 的折旧扭曲盈利，P/E 只有有限参考价值；FFO/AFFO 不在输入里",
                 "OTHER": "行业类别未知，通用读法未必适用",
                 "BANK": "银行的毛利率、流动比率、利息覆盖、自由现金流、EV 倍数和 DCF 都不适用；需要的净息差、资本充足率、拨备不在输入里",
                 "INSURANCE": "保险公司的经营质量需要综合成本率、准备金等指标，不在输入里；EV 倍数和 DCF 不适用"}
INDUSTRY_ZH = {"INDUSTRIAL": "工业", "CONSUMER": "消费", "TECHNOLOGY_SOFTWARE": "科技 / 软件", "HEALTHCARE": "医疗", "ENERGY": "能源", "UTILITY": "公用事业",
               "REIT": "房地产信托（REIT）", "OTHER": "其他 / 未知", "BANK": "银行", "INSURANCE": "保险"}

OBJECT_CODES = {"IDENTITY_CONFLICT", "PRICE_DATASET_SECURITY_MISMATCH", "ISSUER_MISMATCH", "CASE_IDENTITY_MISMATCH"}
TREND_METRICS = ("momentum_12m_1m", "sma50_sma200_ratio", "relative_strength_6m")

# events (contract §11.4): titles are split first, then judged one by one
MATERIAL_ROLE = re.compile(r"chief\s+executive|chief\s+financial|\bceo\b|\bcfo\b|\bpresident\b|\bchair(?:man|woman|person)?\b", re.I)
NOT_MATERIAL_ROLE = re.compile(r"(?:vice|deputy)[\s-]+(?:president|chair)", re.I)
TITLE_SCOPE = re.compile(r"committee|division|segment|subsidiar|business|\bunit\b|\bgroup\b|\bregion(?:al|s)?\b", re.I)
TITLE_SPLIT = re.compile(r",|;|&|\band\b|/|\s[-–—]\s|[–—()]|(?<!vice)(?<!deputy)-(?=\s*(?:chief|ceo|cfo|chair|president)\b)", re.I)   # review CI-02 / EVS-01
# a key title MENTIONED anywhere in a sentence (truncation check §11.4 (3)): no splitting and no scope veto - over-inclusive on purpose
COMMITTEE_AFTER = re.compile(r"^(?:man|woman|person)?\s+of\s+(?:the\s+)?(?:[\w&,'-]+\s+){0,5}?committee\b", re.I)   # review R2-FC-01: a committee chair
MENTION_MATERIAL = re.compile(r"(?<!vice )(?<!vice-)(?<!deputy )\b(?:chief\s+executive|chief\s+financial|ceo|cfo|president|chair(?:man|woman|person)?)\b", re.I)
UNREAD_ITEMS = {"1.01": "签订重大协议", "1.02": "终止重大协议", "1.03": "破产或接管", "1.05": "重大网络安全事件", "2.01": "完成收购或资产处置",
                "2.03": "新增直接财务义务（如借款）", "2.04": "触发加速偿付等义务", "2.05": "退出或处置活动的成本", "2.06": "重大资产减值",
                "3.01": "退市或不满足上市标准的通知", "3.03": "证券持有人权利的重大变更", "4.01": "更换审计师", "4.02": "以前的财报不可再依赖", "5.01": "控制权变更"}
RECORDED_ITEMS = {"2.02": "经营业绩（财报发布）", "3.02": "未登记的股票发行", "5.03": "章程修订", "5.05": "道德准则", "5.07": "股东投票结果",
                  "7.01": "公平披露（Reg FD）", "8.01": "其他事项", "9.01": "财务报表与附件"}
DOC_EXEMPT_REASONS = {"DOCUMENT_AFTER_AS_OF", "DOCUMENT_DUPLICATE_IDENTICAL", "DOCUMENT_DUPLICATE_CONTENT"}

NOT_INCLUDED = ["买卖或仓位方面的任何建议", "涨跌的可能性大小或历史命中比例", "目标价、公允价格、安全边际", "评级、综合分",
                "个人化建议", "专家权重、多数票、任何把握程度的数字", "生产 Meta、Bull/Bear、Risk、校准器的任何输出"]
UNANSWERABLE_FIXED = ["未来 6–12 个月股价会涨还是跌、涨跌多少：没有经过验证的预测（判断层与各专家的预测有效性都未确立）",
                      "公允价格：本系统不给出",
                      "适不适合你：没有你的持仓、期限和风险承受信息，也不具备提供个性化建议的资质"]
ACTION_PREREQUISITES = [
    "有授权、可对外展示的真实行情、财报和公告数据（现在没有任何商业许可）",
    "在未打开的留出集上预注册、验证过预测有效性（不能用已消费的 2026_H1、V001、V002、MIC1 窗口）；现在 Fundamental 验证不合格、Meta 未验证、本判断层未验证",
    "概率只能来自拟合并检验过的校准器（现在是未拟合的恒等映射）",
    "涉及卖出的结论需要用户的持仓、成本、期限和风险承受信息（本轮不接受）",
    "合规：个性化建议需要相应资质，并在合规框架内输出",
    "本助手以外的复核",
]
FORBIDDEN = re.compile(r"买入|卖出|增持|减持|加仓|减仓|清仓|满仓|抄底|仓位|目标价|概率|胜率|置信度|评级|建议持有|持有建议|值得买|推荐|逢低|不妨|"
                       r"\bconfidence\b|\bprobability\b|\btarget\s+price\b|\bprice\s+target\b|\bPT\s*\$|\bbuy\b|\bsell\b|\boutperform\b|\boverweight\b|\bunderweight\b", re.I)
# only an explicit refusal phrase in the same clause lets a hit through ('不提供目标价'); single characters such as 不 / 非 never do (Q14 RV2-02)
NEGATION = re.compile(r"(?:不是|并非|不提供|不给出|不给|不构成|不代表|不等于|不做|不作|不含|不包括|没有任何|无法给出|不能给出)[^。；;，,\"]*$")
