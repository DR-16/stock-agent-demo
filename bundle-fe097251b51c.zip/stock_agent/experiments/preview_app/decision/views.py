"""Q15 views: the simple version (default) and the professional version of ONE decision (Q15_DECISION_V2), plus chart data and a
consistency check (contract §14).

    from decision.views import build_views
    v = build_views(decision, record, price_series=None)   # {"simple", "pro", "charts", "consistency"}

Both versions are built from the same decision output and the same run record; neither recomputes a conclusion. The simple version answers
four questions in plain language, says why each point matters, and marks every point as 事实 (a reading of the data), 规则 (how the system
judged), 假设 (a declared or product assumption) or 未知. It keeps the key counter-evidence, the key unknown and the conditions that would
change the judgement, and is never more certain than the professional version. Causes are never invented: a possible cause is written as
something to check.
"""
from __future__ import annotations

import copy
import math

from decision import rules15 as K
from decision.judge import _json_safe, forbidden_hits

DATA_KIND_ZH = {"SYNTHETIC": "合成演示数据（虚构公司）", "REAL_PUBLIC_DATA_INTERNAL_TEST": "Q15 真实试验 · 仅本机内部使用",
                "REAL_PUBLIC_DATA_USER_MODIFIED": "以真实数据为基础、经用户修改（用户声明）"}
GLOSSARY = {
    "营业利润率": ("每 100 元收入里，扣掉经营成本后剩下多少营业利润。", "它反映主业赚钱的效率；持续提高通常说明定价或成本控制在改善。"),
    "经营现金流": ("公司日常经营实际收到的现金减去付出的现金。", "利润是账面数字，经营现金流说明利润有没有真正收到手。"),
    "持平带": ("专家把很小的变化算作“基本持平”的范围：收入 ±1%，营业利润率 ±0.5 个百分点。", "避免把噪声当成趋势；这个范围是设计常数，未经验证。"),
    "边缘": ("变化只略微越过持平带（不到持平带的两倍）。", "换一个口径就可能变成“持平”，所以不能把正面结论建立在它上面。"),
    "估值比较依据": ("一个可以对比的倍数区间：同行、公司自己过去几年，或行业。", "只知道市盈率是多少，说不出它算高还是算低；有了可比区间才能说“相对”贵贱。"),
    "市盈率（P/E）": ("股价除以每股收益。这里用最近一个财年的年报数字，不是最近四个季度（TTM）。", "它把价格和盈利放在一起看，是最常用的相对估值指标之一。"),
    "硬性风险检查": ("五项会计上的危险信号：负股东权益、营业亏损且有利息、营业利润低于利息、亏损且经营现金流为负、流动负债超过流动资产且经营现金流为负。",
               "触发任一项通常说明财务压力大；“未触发”只说明这五项没出现，不代表没有别的风险。"),
    "价格趋势": ("过去约一年的股价走势：12-1 月动量、50 日 / 200 日均线比、6 个月相对大盘。", "它说明市场过去怎么反应，不是对未来的预测。"),
    "市场环境": ("利率、期限利差、信用和美元等整体环境。", "只作背景，不针对这家公司，也不改变本页的任何结论。"),
    "公告检查": ("本系统只解读 8-K 第 5.02 项（管理层变动）和 Form 4（内部人交易）。", "没解读的公告不等于没有重大事件。"),
    "依据充分度": ("充分：价格可用、有稳健的估值比较、风险检查和公告检查都完成，没有待核实线索和未解决的冲突，行业在支持范围内；有限：给出了结论但缺其中一项；不足：无法判断。",
              "它告诉你这条结论有多少依据，缺了什么。"),
}
KIND_ORDER = ("事实", "规则", "假设", "未知")


def _kind_label(k):
    """review IB-15: a missing data kind is never shown as synthetic (or as real)"""
    if not isinstance(k, str) or k not in DATA_KIND_ZH:
        return "数据类型未标明（不能当作合成，也不能当作真实）"
    return DATA_KIND_ZH[k]


def _isnum(x):
    return isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x)


def _pct(x, nd=1):
    if not _isnum(x):
        return "—"
    v = round(abs(x) * 100, nd)
    return f"{v:.{nd}f}%"


def _yuan(x):
    """a ratio as 'yuan per 100 yuan' (operating margin 0.173 -> 17.3)"""
    return "—" if not _isnum(x) else f"{round(x * 100, 1):.1f}"


def _pt(kind, text):
    return {"kind": kind, "text": text}


def _same_run(d, rec):
    return {"run_id": (d.get("trace") or {}).get("run_id"), "case_id": (d.get("trace") or {}).get("case_id"), "as_of": d.get("as_of"),
            "decision_fingerprint": d.get("core_fingerprint"), "decision_version": d.get("decision_layer_version"),
            "record_run_id": (rec or {}).get("run_id")}


# ------------------------------------------------------------------------------------------------------------------------------------ simple
def _spct(x, nd=1):
    """a signed percentage (review V-09: 'basically flat' keeps its sign)"""
    if not _isnum(x):
        return "—"
    v = round(x * 100, nd)
    return f"{0.0 if v == 0 else v:+.{nd}f}%"


def _ops_rule(lab, g, cash, basis, rule=""):
    """the rule sentence built from the readings that actually decided the label (review V-01 / CI-08: never a fixed sentence per label)"""
    rev = {"UP": "收入向好", "DOWN": "收入下滑", "FLAT": "收入基本持平", "UNKNOWN": "收入趋势未知"}[g.get("G_REV", "UNKNOWN")]
    opm = {"UP": "营业利润率向好", "DOWN": "营业利润率下滑", "FLAT": "营业利润率基本持平", "UNKNOWN": "营业利润率趋势未知"}[g.get("G_OPM", "UNKNOWN")]
    loss = g.get("G_LOSS") == "TRUE"
    cash_zh = {"GOOD": "利润有现金支撑", "MILD": "经营现金流为正但低于利润", "WEAK": "亏损且经营现金流为负" if loss else "利润缺少现金支撑",
               "LOSS_POS_OCF": "亏损（谈不上利润的现金支撑）", "UNKNOWN": "利润的现金支撑不知道"}.get(cash, "利润的现金支撑不知道")
    word = {"改善": "在变好", "稳定": "基本平稳", "分化": "好坏并存", "恶化": "在变差"}[lab]
    s_ = f"{rev}、{opm}，{cash_zh}：系统按规则算作“{word}”"
    if lab == "分化" and "+CASH" in str(rule):         # review R2V-01: only when the readings alone would have said 在变好
        s_ += "（收入和利润率的读数本身算“在变好”，但" + ("亏损且经营现金流为负" if loss else "利润没有现金支撑") + "，所以不算“在变好”）"
    if lab == "改善" and cash not in ("GOOD", "MILD"):
        s_ += "；但利润的现金支撑没有得到证实，所以这个“在变好”不能支撑偏积极的结论"
    return s_ + "。"


def _ops_answer(d):
    oe = d["operations_evaluation"]
    f = (d.get("dimensions") or {}).get("operations", {}).get("facts") or {}
    g = oe.get("groups") or {}
    pts, terms = [], ["营业利润率", "经营现金流", "持平带"]
    lab = oe["label"]
    if lab == "无法判断":
        obj = (d.get("object") or {})
        if obj.get("object_problems"):
            ans = "现在没法评价经营：分析对象不成立（" + "；".join(obj["object_problems"][:2]) + "）。"
            pts.append(_pt("未知", "数据里混进了别家公司的内容，或者研究输入的公共部分不可用；在确认数据都属于这家公司之前，两层结论都只能是“无法判断”。"))
        elif obj.get("industry_support") == "不支持":
            ans = f"现在没法评价经营：这家公司属于{obj.get('industry_zh')}，不在本系统的支持范围内。"
            pts.append(_pt("规则", f"{obj.get('industry_note') or '这个行业需要专门的指标'}；本系统不硬算，所以两层结论都是“无法判断”。"))
        else:
            notes = [n for n in oe.get("notes") or [] if n]
            ans = f"现在没法评价经营：{'；'.join(notes[:2]) or oe.get('why') or '没有可用的财报'}。"
            pts.append(_pt("未知", "没有可用、可信的财报读数，经营这个核心维度缺失；所以后面的投资研究判断也只能是“无法判断”。"))
        return ans, pts, terms
    rev = {"UP": f"收入比上年增长 {_pct(f.get('revenue_growth'))}", "DOWN": f"收入比上年下降 {_pct(f.get('revenue_growth'))}",
           "FLAT": f"收入和上年基本持平（变化 {_spct(f.get('revenue_growth'))}）", "UNKNOWN": "收入变化不知道（数据缺失）"}[g.get("G_REV", "UNKNOWN")]
    om = f.get("operating_margin") or {}
    opm = {"UP": f"每 100 元收入带来的营业利润从 {_yuan(om.get('prior'))} 元提高到 {_yuan(om.get('latest'))} 元",
           "DOWN": f"每 100 元收入带来的营业利润从 {_yuan(om.get('prior'))} 元降到 {_yuan(om.get('latest'))} 元",
           "FLAT": f"每 100 元收入带来的营业利润基本没变（{_yuan(om.get('prior'))} 元 → {_yuan(om.get('latest'))} 元）",
           "UNKNOWN": "营业利润率的变化不知道（数据缺失）"}[g.get("G_OPM", "UNKNOWN")]
    opener = {"改善": "经营在变好", "稳定": "经营基本平稳", "分化": "经营好坏并存", "恶化": "经营在变差"}[lab]
    fy = f.get("fiscal_year")
    ans = f"{opener}（FY{fy} 年报）：{rev}；{opm}。"
    pts.append(_pt("事实", f"{rev}；{opm}。"))
    conv = f.get("cash_conversion")
    cash = oe.get("cash_class")
    if cash == "GOOD":
        pts.append(_pt("事实", "利润有现金支撑：经营实际收到的现金比账面利润还多。"))
    elif cash == "MILD":
        pts.append(_pt("事实", f"利润转成现金的情况一般：经营现金流是正的，但只有净利润的约 {round(conv * 100):.0f}%。"))
        pts.append(_pt("未知", "值得继续核对回款和付款的变化；单凭这一项还不能断定经营变差。"))
    elif cash == "WEAK":
        if _isnum(f.get("net_income")) and f["net_income"] > 0:
            pts.append(_pt("事实", "利润没有足够的现金支撑：" + (f"经营现金流只有净利润的约 {round(conv * 100):.0f}%。" if _isnum(conv) and conv > 0 else "经营现金流是零或负的。")))
            pts.append(_pt("未知", "原因要看财报附注核实（例如回款、存货、预收或一次性项目的变化），这里不下结论。"))
        else:
            pts.append(_pt("事实", "公司亏损，经营现金流也是负的：钱在往外流。"))
    elif cash == "LOSS_POS_OCF":
        pts.append(_pt("事实", "公司亏损，但经营现金流是正的。"))
    else:
        pts.append(_pt("未知", "利润转成现金的情况不知道（缺净利润或经营现金流的数字）。"))
    pts.append(_pt("规则", _ops_rule(lab, g, cash, oe.get("basis"), oe.get("rule"))))
    if oe.get("basis") == "边缘":
        pts.append(_pt("规则", "提醒：这次的变化只比“基本持平”多一点点，换个算法可能就算持平，所以依据标为“边缘”。"))
        terms.append("边缘")
    if oe.get("basis") == "部分":
        pts.append(_pt("未知", "推动这个评价的读数有一项缺数据（趋势或变化幅度），评价只有部分依据。"))
    pts.append(_pt("假设", "“基本持平”的范围（收入 ±1%、利润率 ±0.5 个百分点）和现金支撑的界线（经营现金流不到净利润一半算不足）是设计约定，没有经过验证。"))
    if d.get("object", {}).get("industry_support") == "有限支持" and d["object"].get("industry_note"):
        pts.append(_pt("未知", f"行业提醒：{d['object']['industry_note']}。"))
    return ans, pts, terms


def _price_answer(d):
    ij, ch = d["investment_judgement"], d["checks"]
    dm = d.get("dimensions") or {}
    val, tr = dm.get("valuation") or {}, dm.get("trend") or {}
    pts, terms = [], ["估值比较依据", "市盈率（P/E）", "价格趋势"]
    ok_price = ch["price"]["status"] == "可用"
    has_cmp = ch["valuation_comparison"]["status"] == "有"
    unusable = [m for m in (ij.get("missing") or []) if m.startswith("估值比较：声明的比较依据不能使用") or m.startswith("估值比较：估值无法使用")]
    if not ok_price:
        why = "；".join(ch["price"].get("why") or []) or "价格数据缺失"
        pts.append(_pt("未知", f"价格数据不能用（{why}），系统看不到最近的价格变化。"))
    else:
        lab = tr.get("label")
        pts.append(_pt("事实", {"上行": "过去约一年股价在上行。", "下行": "过去约一年股价在下行。", "混合": "过去约一年股价的几个读数方向不一致。",
                               "无明显趋势": "过去约一年股价没有明显方向。"}.get(lab, "价格趋势无法判断。") + "股价走势只说明市场过去的反应，不是对未来的预测。"))
    obs = [o for o in val.get("observed") or [] if o.get("method") == "TRAILING_PE"]
    if has_cmp:
        for c in val.get("comparison") or []:
            kind = {"PEER_SET": "同行", "OWN_HISTORY": "公司自己过去几年", "INDUSTRY": "行业"}.get(c.get("basis_type"), "可比对象")
            where = {"INSIDE": "区间之内", "ABOVE": "区间之上", "BELOW": "区间之下"}[c["position"]]
            fmt = (lambda x: f"{round(x * 100, 1)}%") if c["metric"] == "FCF_YIELD" else (lambda x: f"{x:.1f}")
            pts.append(_pt("事实", f"和{kind}相比：现在的 {c['name']} 是 {fmt(c['observed'])}，可比区间是 {fmt(c['low'])}–{fmt(c['high'])}，处在{where}"
                                   f"（{c['relative']}）" + ("，但离边界很近，这个位置不稳定" if c.get("near_edge") else "") + "。"))
            if c.get("synthetic"):
                pts.append(_pt("假设", "这个可比区间是演示用的合成数据，不是真实市场数据。"))
            if c.get("basis_type") == "OWN_HISTORY":
                pts.append(_pt("规则", "和公司自己过去比，只能说明现在比过去贵还是便宜，不说明绝对便宜或贵。"))
        if val.get("judgment") == "无法判断":
            pts.append(_pt("规则", "几项比较给出的位置互相矛盾，所以说不出相对贵贱。"))
    else:
        if obs:
            pts.append(_pt("事实", f"系统只算出了倍数（例如市盈率约 {obs[0]['value']:.1f}），但没有可以用的对比区间（同行、公司自己过去或行业的水平）。"))
        pts.append(_pt("未知", (unusable[0].split("：", 1)[1] + "。") if unusable else "没有比较依据，所以说不出现在的价格算贵还是便宜。"))
        if val.get("conditional"):
            pts.append(_pt("假设", "你声明的估值假设下有一份条件性分析（见专业版），它完全取决于这些假设，不算比较依据。"))
    if ch["risk_checks"]["status"] != "完成":
        pts.append(_pt("未知", ch["risk_checks"]["statement"] + "。没查完不能当作没有风险。"))
    lab, basis = ij["label"], ij["basis"]
    gaps = (["价格数据不能用"] if not ok_price else []) + \
           ([unusable[0].split("：", 1)[1]] if not has_cmp and unusable else ["没有可以对比的估值区间"] if not has_cmp else [])
    if gaps:
        ans = "没有足够依据评价现在的价格：" + "，".join(gaps) + "。"
    else:
        rel = val.get("judgment")
        ans = "有一定依据：价格数据可用，也有可比较的估值区间" + (f"，比较结果是“{rel}”" if rel in ("相对偏低", "相对适中", "相对偏高") else "，但几项比较的结论不一致") + \
              ("" if val.get("robust") is True else "（不稳健）") + "。"
    if lab == "无法判断" and ij.get("rule") == "IJ5":
        ans += "投资研究判断是“无法判断”（依据不足），" + ij["why"].split("：", 1)[-1].join(["原因：", "。"])      # review R2V-02: the real reasons
    elif lab == "无法判断":
        ans += "投资研究判断是“无法判断”（依据不足），原因不在价格：" + ij["why"] + "。"
    else:
        ans += f"投资研究判断是“{lab}”（依据{basis}）：{ij['why']}。" + ("" if basis == "充分" else "依据有限，缺的部分见“还不知道的”。")
    pts.append(_pt("规则", "偏积极或中性需要三项检查都完成（价格可用、有估值比较依据、硬性风险查完）；偏谨慎只需要清楚的负面证据（硬性风险或经营变差）。公告检查是否完成，影响依据是否“充分”。"))
    return ans, pts, terms


def _worry_answer(d):
    pts, terms = [], ["硬性风险检查", "公告检查"]
    risks = [r for r in (d.get("risk_checks") or {}).values() if r.get("status") == "TRIGGERED"]
    for r in risks:
        pts.append(_pt("事实", f"硬性风险：{r['name']}。这是财务压力大的信号。"))
    for c in d.get("unresolved_conflicts") or []:
        if str(c).startswith("公告"):
            pts.append(_pt("未知", f"公告之间说法不一致（需要核实）：{c}"))
        else:
            pts.append(_pt("事实", f"方向相反的信号：{c}"))
    ops_opp = [r for r in d.get("opposing") or [] if r.get("dimension") == "operations" and r.get("strength") in ("core", "soft") and not str(r.get("text", "")).startswith("硬性风险")]
    for r in ops_opp[:2]:
        pts.append(_pt("事实", r["text"]))
    for r in [r for r in d.get("opposing") or [] if r.get("dimension") == "trend" and r.get("strength") == "risk"][:1]:
        pts.append(_pt("事实", r["text"]))
    for t in (d.get("conditions") or {}).get("to_verify", [])[:3]:
        pts.append(_pt("未知", t))
    for m in (d["investment_judgement"].get("missing") or [])[:2]:
        if not any(m in p["text"] for p in pts):
            pts.append(_pt("未知", m))
    if not risks:          # when a risk is triggered the statement repeats the fact above
        pts.append(_pt("规则", d["checks"]["risk_checks"]["statement"] + "。"))
    if d["checks"]["events"]["status"] != "完成":
        pts.append(_pt("未知", "公告" + ("没有检查" if d["checks"]["events"]["status"] == "未检查" else "只检查了一部分") + "：没检查到的公告不等于没有重大事件。"))
    first = next((p["text"] for p in pts if p["kind"] in ("事实", "未知")), None)
    ans = ("最值得注意的是：" + first) if first else "在已检查的范围内没有发现明显的反面信号；但下面列出的检查范围有限。"
    return ans, pts, terms


def _watch_answer(d):
    inv = d.get("invalidation") or {}
    lines = [f"投资研究判断：{x}" for x in list(inv.get("investment_judgement") or [])] + [f"经营评价：{x}" for x in list(inv.get("operations_evaluation") or [])]
    pts = [_pt("规则", x) for x in lines]
    pts.append(_pt("规则", "这些是会改变判断的条件，不是对未来的预测。"))
    ans = "下面这些变化会改变判断：" + (lines[0] if lines else "补齐缺失的信息后重新评估。")
    return ans, pts, []


def simple_view(d: dict, rec: dict | None = None) -> dict:
    oe, ij = d["operations_evaluation"], d["investment_judgement"]
    qa = []
    for qid, q, fn, why in (
            ("ops", "这家公司经营怎么样？", _ops_answer, "经营是判断的核心：收入和利润率说明生意本身在变好还是变差。但经营好不等于现在的价格值得买。"),
            ("price", "当前价格是否有足够依据评价？", _price_answer, "经营好的公司，如果价格已经很高，结果也可能不好；所以价格要单独看，而且需要可比较的依据。"),
            ("worry", "最值得担心或核实的是什么？", _worry_answer, "反面证据和没查清的事情最可能让判断出错，所以放在前面，不藏起来。"),
            ("watch", "接下来关注哪些变化？", _watch_answer, "知道什么会改变判断，才能在新信息出来时及时重新评估。")):
        ans, pts, terms = fn(d)
        pts.sort(key=lambda p: KIND_ORDER.index(p["kind"]))
        qa.append({"id": qid, "q": q, "answer": ans, "why_it_matters": why, "points": pts, "terms": terms})
    terms = list(dict.fromkeys(t for x in qa for t in x["terms"])) + ["依据充分度"]
    opp = [r["text"] for r in d.get("opposing") or [] if r.get("strength") in ("risk", "core", "soft")]
    ch = d.get("checks") or {}
    extra = ([("公告" + ("没有检查" if ch["events"]["status"] == "未检查" else "只检查了一部分") + "：没检查到的公告不等于没有重大事件")]
             if (ch.get("events") or {}).get("status") in ("部分", "未检查") else []) + \
            ([ch["risk_checks"]["statement"]] if (ch.get("risk_checks") or {}).get("status") == "未完成" else [])      # front-end request 2
    unknowns = list(dict.fromkeys(list(ij.get("missing") or []) + list((d.get("conditions") or {}).get("to_verify") or []) + extra))
    ops_plain = {"改善": "经营在变好", "稳定": "经营基本平稳", "分化": "经营好坏并存", "恶化": "经营在变差", "无法判断": "经营无法评价"}[oe["label"]]
    ij_plain = ij["label"]          # review V-08: one name for each label on every page
    return {
        "schema": "Q15_VIEW_SIMPLE_V1", "same_run": _same_run(d, rec),
        "company": {"name": (d.get("object") or {}).get("name"), "security": (d.get("object") or {}).get("security"),
                    "industry": (d.get("object") or {}).get("industry_zh"), "industry_support": (d.get("object") or {}).get("industry_support")},
        "as_of": d.get("as_of"), "data_kind": d.get("data_kind"), "data_kind_label": _kind_label(d.get("data_kind")),
        "headline": {
            "operations": {"label": oe["label"], "basis": oe.get("basis"), "plain": ops_plain + (f"（依据{oe['basis']}）" if oe.get("basis") else ""),
                           "meaning": "只看公司本身已报告的经营情况"},
            "investment": {"label": ij["label"], "basis": ij["basis"], "plain": f"投资研究判断：{ij_plain}（依据{ij['basis']}）",
                           "why": ij["why"], "meaning": "把价格、估值比较、风险检查和公告核查一起放进来；不是买卖建议"},
            "one_line": d.get("summary_zh"),
        },
        "questions": qa,
        "key_counter_evidence": opp[:3],
        "unknowns": unknowns,
        "risk_statement": d["checks"]["risk_checks"]["statement"],
        "key_risks": list(d.get("key_risks") or []),            # review V-07 / CI-06: the same key risks as the professional version
        "changes_to_watch": list((d.get("invalidation") or {}).get("investment_judgement") or []),
        "glossary": [{"term": t, "plain": GLOSSARY[t][0], "why": GLOSSARY[t][1]} for t in terms if t in GLOSSARY],
        "not_advice": "这是研究整理，不是买卖建议；没有你的持仓、期限和风险承受信息，也不判断是否适合你。",
        "horizon": (d.get("horizon") or {}).get("label"),
    }


# ------------------------------------------------------------------------------------------------------------------------------------ pro
RISK_STATUS_ZH = {"TRIGGERED": "触发", "NOT_TRIGGERED": "已检查，未触发", "UNKNOWN": "无法判定", "NOT_APPLICABLE": "不适用"}


def _display(value, unit):
    if not _isnum(value):
        return "—"
    if unit == "比例":
        return f"{round(value * 100, 1):.1f}%"
    if unit == "美元":
        a = abs(value)
        return f"{round(value / 1e8, 2):.2f} 亿美元" if a >= 1e8 else f"{round(value / 1e4):.0f} 万美元" if a >= 1e4 else f"{value:,.0f} 美元"
    return f"{round(value, 2):.2f}"


def pro_view(d: dict, rec: dict | None = None) -> dict:
    dm = d.get("dimensions") or {}
    f = (dm.get("operations") or {}).get("facts") or {}
    P = "$.experts.fundamental.output.findings"
    om = f.get("operating_margin") or {}
    fy = f.get("fiscal_year")
    metrics = [
        {"group": "经营", "name": "收入同比增长", "value": f.get("revenue_growth"), "unit": "比例", "period": f"FY{fy} 对 FY{fy - 1 if isinstance(fy, int) else '?'}（年报）",
         "source": f"{P}.financial_growth.latest_growth", "rule": "专家平带 ±1%"},
        {"group": "经营", "name": "营业利润率", "value": om.get("latest"), "prior": om.get("prior"), "change": om.get("change"), "unit": "比例", "period": f"FY{fy}（年报）",
         "source": f"{P}.financial_profitability.operating_margin", "rule": "专家平带 ±0.5 个百分点"},
        {"group": "经营", "name": "净利润", "value": f.get("net_income"), "unit": "美元", "period": f"FY{fy}", "source": f"{P}.cash_flow_quality.net_income"},
        {"group": "经营", "name": "经营现金流", "value": f.get("operating_cash_flow"), "unit": "美元", "period": f"FY{fy}", "source": f"{P}.cash_flow_quality.operating_cash_flow"},
        {"group": "经营", "name": "现金转化率（经营现金流 / 净利润）", "value": f.get("cash_conversion"), "unit": "倍", "period": f"FY{fy}",
         "source": "由上两项计算", "rule": "T-CASH-CONV 0.5（产品假设）"},
        {"group": "经营", "name": "自由现金流", "value": f.get("free_cash_flow"), "unit": "美元", "period": f"FY{fy}", "source": f"{P}.cash_flow_quality.free_cash_flow"},
        {"group": "经营", "name": "负债 / 权益", "value": f.get("debt_to_equity"), "prior": f.get("debt_to_equity_prior"), "unit": "倍", "period": f"FY{fy}",
         "source": f"{P}.balance_sheet_health.debt_to_equity", "rule": "专家杠杆平带 0.05"},
    ]
    tm = (dm.get("trend") or {}).get("metrics") or {}
    zh = {"momentum_12m_1m": ("12-1 月动量", "比例"), "sma50_sma200_ratio": ("50 日 / 200 日均线比", "倍"), "relative_strength_6m": ("6 个月相对大盘", "比例"),
          "max_drawdown_2y": ("两年最大回撤", "比例"), "avg_dollar_volume_20d": ("20 日日均成交额", "美元")}
    for k, (n, u) in zh.items():
        metrics.append({"group": "价格", "name": n, "value": tm.get(k), "unit": u, "period": f"截至 {str(d.get('as_of') or '')[:10]}", "source": f"$.experts.technical.output.metadata.metrics.{k}"})
    val = dm.get("valuation") or {}
    for o in val.get("observed") or []:
        metrics.append({"group": "估值", "name": o.get("name"), "value": o.get("value"), "unit": "比例" if o.get("method") == "FCF_YIELD" else "倍",
                        "period": f"价格 {val.get('price_date')}；FY{fy} 年报口径（不是 TTM）", "source": o.get("path")})
    for m in metrics:
        m["display"] = _display(m.get("value"), m.get("unit"))
        if "prior" in m:
            m["prior_display"] = _display(m.get("prior"), m.get("unit"))
    used = [t for t in sorted(K.THRESHOLDS) if t in ("T-FRESH-PRICE", "T-FRESH-FIN", "T-CASH-CONV", "T-EDGE", "T-NEAR-EDGE", "T-COMP-AGE", "T-MATERIAL-ROLES",
                                                       "T-UNREAD-ITEMS", "T-HARD-RISK", "T-RATE-UNIT", "INDUSTRY-SUPPORT", "EXPERT-OWN", "T-PERSISTENT-LOSS")]
    tr = d.get("trace") or {}
    return {
        "schema": "Q15_VIEW_PRO_V1", "same_run": _same_run(d, rec),
        "company": d.get("object"), "as_of": d.get("as_of"), "data_kind": d.get("data_kind"), "data_kind_label": _kind_label(d.get("data_kind")),
        "data_labels": d.get("data_labels"),
        "conclusions": {"operations_evaluation": d["operations_evaluation"], "investment_judgement": d["investment_judgement"], "checks": d["checks"]},
        "metrics": metrics,
        "financial_series": f.get("series") or [],
        "evidence": {"supporting": d.get("supporting") or [], "opposing": d.get("opposing") or [], "neutral": d.get("neutral_facts") or []},
        "risk_checks": [{"id": h, "name": r.get("name"), "status": r.get("status"), "status_zh": RISK_STATUS_ZH.get(r.get("status"), r.get("status")),
                         "source": r.get("source"), "note": r.get("note")} for h, r in (d.get("risk_checks") or {}).items()],
        "risk_statement": d["checks"]["risk_checks"]["statement"],
        "trend": dm.get("trend"), "environment": dm.get("environment"), "valuation": val, "events": dm.get("events"),
        "key_risks": d.get("key_risks") or [], "conflicts": d.get("unresolved_conflicts") or [],
        "invalidation": d.get("invalidation") or {}, "conditions": d.get("conditions") or {},
        "thresholds": [{"id": t, **copy.deepcopy(K.THRESHOLDS[t])} for t in used],      # review IB-21: never share the constants
        "unanswerable": d.get("unanswerable") or [], "not_included": d.get("not_included") or [], "action_mapping": d.get("action_mapping"),
        "sources": {"experts": [{"expert": e, **v} for e, v in (tr.get("experts") or {}).items()], "declared_inputs": tr.get("declared_inputs")},
        "details": {"rules_fired": tr.get("rules_fired"), "issue_tags": d.get("issue_tags"), "errors": d.get("errors") or [], "run_id": tr.get("run_id"),
                    "case_id": tr.get("case_id"), "decision_layer_version": d.get("decision_layer_version"), "contract_version": d.get("contract_version"),
                    "decision_fingerprint": d.get("core_fingerprint")},
        "horizon": d.get("horizon"),
    }


# ------------------------------------------------------------------------------------------------------------------------------------ charts
def charts(d: dict, rec: dict | None = None, price_series: list | None = None) -> dict:
    dm = d.get("dimensions") or {}
    f = (dm.get("operations") or {}).get("facts") or {}
    fin = []
    for row in f.get("series") or []:
        rev, oi = row.get("revenue"), row.get("operating_income")
        fin.append({"fiscal_year": row.get("fiscal_year"), "revenue": rev if _isnum(rev) else None,
                    "operating_margin": (oi / rev) if _isnum(rev) and _isnum(oi) and rev > 0 and _isnum(oi / rev) else None,
                    "net_income": row.get("net_income") if _isnum(row.get("net_income")) else None,
                    "operating_cash_flow": row.get("operating_cash_flow") if _isnum(row.get("operating_cash_flow")) else None})
    ev = dm.get("events") or {}
    timeline = [{"date": t.get("date"), "kind": "重大线索（待核实）" if t.get("material") else "人事线索（待核实）" if t.get("uncertain") else "已抽取的事件",
                 "text": t.get("claim"), "path": t.get("path")} for t in ev.get("timeline") or []]
    val = dm.get("valuation") or {}
    vchart = {"comparison": [{"name": c.get("name"), "observed": c.get("observed"), "low": c.get("low"), "high": c.get("high"), "basis_type": c.get("basis_type"),
                              "synthetic": c.get("synthetic"), "relative": c.get("relative")} for c in val.get("comparison") or []],
              "conditional": [{"name": c.get("name"), "low": (c.get("range") or [None, None])[0], "high": (c.get("range") or [None, None])[1], "position": c.get("position")}
                              for c in val.get("conditional") or []],
              "price": val.get("price"), "price_date": val.get("price_date"),
              "note": "区间来自声明的比较依据或你声明的假设；不是公允价格，也不是预测"}
    ps = [p for p in (price_series or []) if isinstance(p, dict) and _isnum(p.get("close"))]
    return {"financial_trend": fin, "price": ps, "price_note": "价格序列只用于显示走势；不是预测" if ps else "没有可显示的价格序列",
            "events_timeline": timeline, "valuation": vchart}


def price_series_from_dataset(doc: dict, security: str | None = None, weeks: int = 104, as_of: str | None = None) -> list:
    """weekly closes of the analysed security from a PRICE_DATASET_CONTRACT_V1 document (display only). Accepts dict rows ({date, close}) and
    list rows with a `columns` header ([date, Open, High, Low, Close, Volume]); rows after as_of are dropped (dev round 2, front-end request 1)"""
    try:
        series = doc.get("series") or {}
        s = series.get(security) if security in series else next(iter(series.values()))
        rows = s.get("bars") or s.get("rows") or []
        cols = [str(c).lower() for c in (s.get("columns") or [])]
        ci = cols.index("close") + 1 if "close" in cols else None
        pts = []
        for r in rows:
            if isinstance(r, dict):
                dt, c = r.get("date"), r.get("close")
            elif isinstance(r, list) and ci is not None and len(r) > ci:
                dt, c = r[0], r[ci]
            else:
                continue
            if dt is None or not _isnum(c) or (as_of and str(dt)[:10] > str(as_of)[:10]):
                continue
            pts.append({"date": str(dt)[:10], "close": c})
        out = [x for i, x in enumerate(pts) if i % 5 == 4 or i == len(pts) - 1]
    except (AttributeError, StopIteration, TypeError, ValueError):
        return []
    return out[-weeks:]


# ------------------------------------------------------------------------------------------------------------------------------------ consistency
def check_consistency(d: dict, simple: dict, pro: dict) -> list:
    """contract §14: problems found (empty = consistent)"""
    bad = []
    for k in ("run_id", "as_of", "decision_fingerprint"):
        if simple["same_run"].get(k) != pro["same_run"].get(k) or simple["same_run"].get(k) != _same_run(d, None).get(k):
            bad.append(f"same_run.{k} 不一致")
    if simple["company"]["name"] != (pro.get("company") or {}).get("name"):
        bad.append("公司不一致")
    oe, ij = d["operations_evaluation"], d["investment_judgement"]
    h = simple["headline"]
    if (h["operations"]["label"], h["operations"]["basis"]) != (oe["label"], oe.get("basis")):
        bad.append("经营评价不一致")
    if (h["investment"]["label"], h["investment"]["basis"]) != (ij["label"], ij["basis"]):
        bad.append("投资研究判断或依据充分度不一致")
    pc = pro["conclusions"]
    if (pc["operations_evaluation"]["label"], pc["investment_judgement"]["label"], pc["investment_judgement"]["basis"]) != (oe["label"], ij["label"], ij["basis"]):
        bad.append("专业版结论与判断输出不一致")
    if ij["basis"] != "充分" and ij["basis"] not in h["investment"]["plain"]:
        bad.append("简单版省略了依据充分度")
    if ij.get("missing") and not simple["unknowns"]:
        bad.append("简单版省略了缺项")
    if ij.get("missing") and ij["missing"][0] not in simple["unknowns"]:
        bad.append("简单版没有列出最关键的缺项")
    opp = [r["text"] for r in d.get("opposing") or [] if r.get("strength") in ("risk", "core", "soft")]
    if opp and opp[0] not in simple["key_counter_evidence"]:
        bad.append("简单版没有列出最关键的反面理由")
    inv = (d.get("invalidation") or {}).get("investment_judgement") or []
    if inv and not simple["changes_to_watch"]:
        bad.append("简单版省略了会改变判断的条件")
    if simple.get("key_risks") != (d.get("key_risks") or []) or pro.get("key_risks") != (d.get("key_risks") or []):
        bad.append("关键风险不一致")
    if simple["risk_statement"] != d["checks"]["risk_checks"]["statement"] or pro["risk_statement"] != d["checks"]["risk_checks"]["statement"]:
        bad.append("风险检查措辞不一致")
    for r in [r for r in (d.get("risk_checks") or {}).values() if r.get("status") == "TRIGGERED"]:
        if not any(r["name"] in p["text"] for q in simple["questions"] for p in q["points"]):
            bad.append(f"简单版没有提到触发的硬性风险：{r['name']}")
    hits = forbidden_hits({"summary_zh": [simple["headline"], [q["answer"] for q in simple["questions"]], [p["text"] for q in simple["questions"] for p in q["points"]]]})
    if hits:
        bad.append("简单版出现禁止用语：" + "、".join(hits))
    if any(x in "".join(q["answer"] for q in simple["questions"]) for x in ("一定会", "必然", "肯定会", "保证")):
        bad.append("简单版用了确定性措辞")
    return bad


def build_views(decision: dict, record: dict | None = None, price_series: list | None = None) -> dict:
    s = simple_view(decision, record)
    p = pro_view(decision, record)
    return _json_safe({"simple": s, "pro": p, "charts": charts(decision, record, price_series), "consistency": check_consistency(decision, s, p)}, [])   # strict JSON (long fuzz)
