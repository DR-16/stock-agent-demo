"""Q15 decision layer (q15-decision 0.4.0, isolated prototype): the five experts' contract-checked outputs + declared inputs -> two separate
conclusions (Q15_DECISION_V2):

  operations_evaluation   改善 / 稳定 / 分化 / 恶化 / 无法判断, basis 完整 / 部分 / 边缘 - the company's reported operations only
  investment_judgement    偏积极 / 中性 / 偏谨慎 / 无法判断, basis 充分 / 有限 / 不足 - operations + price + valuation comparison + risk checks + events

Contract: Q15_DECISION_CONTRACT.md (q15-decision-contract 2.0.0). The Q14 layer (decision/decide.py, 0.3.0) is kept unchanged as the baseline.

    from decision.judge import judge
    out = judge(run_record, declared={"comparison_basis": [...], "document_coverage": {...}})

Reads only experts whose execution_status is COMPLETED and whose output contract CONFORMS, after a format check of every field it reads
(decision/validate.py); plus the synthesis cross-checks of the same record. Never reads a confidence, a score, a weight, Meta / Bull-Bear / Risk /
calibrator output, or the network. Nothing is fitted; nothing is a forecast. Never raises: a malformed input gives structured errors.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import re
from datetime import date, datetime, timezone

from decision import rules15 as K
from decision import validate as V

EXPERTS = ("technical", "macro", "fundamental", "valuation", "information")
ZH_EXPERT = {"technical": "Technical（价格）", "macro": "Macro（市场环境）", "fundamental": "Fundamental（财报）", "valuation": "Valuation（估值）",
             "information": "Information（公告）"}
AFFECTS = {"technical": "价格趋势", "macro": "市场环境", "fundamental": "经营评价", "valuation": "估值", "information": "公告事件"}
STATUS_ZH = {"REJECTED": "输入被拒", "ABSTAINED": "弃权", "FAILED": "运行失败", "NOT_EXECUTED": "未运行", "NOT_APPLICABLE": "不适用", "COMPLETED": "已完成"}
CODE_ZH = {"SECTION_ABSENT_UNDECLARED": "没有提供这部分输入", "SECTION_ABSENT": "没有提供这部分输入", "IDENTITY_MISSING": "数据缺少身份字段",
           "IDENTITY_CONFLICT": "数据身份核对没有通过（可能属于别家公司，或时间、来源自相矛盾）", "REQUIRED_IDENTITY_UNIT_OR_TIME_MISSING": "缺少单位或时间", "PRICE_DATASET_MISSING": "没有价格数据",
           "PRICE_DATASET_UNKNOWN": "价格数据没有登记", "PRICE_CONTRACT_REJECTED": "价格数据不合契约", "NO_SIGNAL": "数据不足，模型弃权",
           "NO_USABLE_DOCUMENTS": "没有可分析的公告", "NO_RESULT": "没有可用期间", "NO_SUPPORTED_REQUEST": "没有支持的请求",
           "MARKET_DATA_NOT_AVAILABLE": "没有市场数据", "PRICE_DATASET_AFTER_AS_OF": "价格数据晚于截止日", "BLOCKED_BY_GUARD": "输出没有通过时间或身份核查",
           "PRICE_DATASET_SECURITY_MISMATCH": "价格数据属于别的证券", "ISSUER_MISMATCH": "数据属于别家公司", "CASE_IDENTITY_MISMATCH": "数据属于别家公司"}
RISK_NAMES = {"H1": "负股东权益", "H2": "营业亏损且有利息支出", "H3": "营业利润低于利息支出", "H4": "亏损且经营现金流为负", "H5": "流动负债超过流动资产且经营现金流为负"}
RISK_FLAG_ZH = {"NEGATIVE_EQUITY": "股东权益", "OPERATING_LOSS_INTEREST_UNCOVERED": "营业利润与利息支出", "INTEREST_NOT_COVERED": "营业利润与利息支出",
                "LOSS_MAKING": "净利润", "NEGATIVE_OPERATING_CASH_FLOW": "经营现金流", "CURRENT_LIABILITIES_EXCEED_CURRENT_ASSETS": "流动资产与流动负债"}
METRIC_METHOD = {"PE": "TRAILING_PE", "PB": "PRICE_TO_BOOK", "EV_EBITDA": "EV_EBITDA", "FCF_YIELD": "FCF_YIELD"}
METHOD_ZH = {"TRAILING_PE": "P/E", "PRICE_TO_BOOK": "P/B", "EV_EBITDA": "EV/EBITDA", "EV_SALES": "EV/Sales", "FCF_YIELD": "FCF 收益率", "DCF_FCF scenarios": "DCF 熊—牛情景"}
METRIC_ZH = {"PE": "P/E", "PB": "P/B", "EV_EBITDA": "EV/EBITDA", "FCF_YIELD": "FCF 收益率"}
BASIS_TYPE_ZH = {"PEER_SET": "同行", "OWN_HISTORY": "自身历史", "INDUSTRY": "行业"}
POS_ZH = {"BELOW": "之下", "INSIDE": "之内", "ABOVE": "之上"}


# ------------------------------------------------------------------------------------------------------------------------------------ helpers
def _isnum(x):
    if not isinstance(x, (int, float)) or isinstance(x, bool):
        return False
    try:
        return math.isfinite(x) and abs(x) < 1e300          # review IB-03: a huge integer is not a usable number (and never overflows here)
    except OverflowError:
        return False


def _z(x, nd):
    """rounds away a negative zero ('-0.0%' never appears; Q14 RV2-10)"""
    r = round(x, nd)
    return 0.0 if r == 0 else r


def _pct(x, nd=1):
    return "—" if not _isnum(x) else f"{_z(x * 100, nd):+.{nd}f}%"


def _lvl(x):
    return "—" if not _isnum(x) else f"{_z(x * 100, 1):.1f}%"


def _pp(x):
    return "—" if not _isnum(x) else f"{_z(x * 100, 1):+.1f} 个百分点"


def _plain(x, nd):
    t = f"{_z(x, nd):,.{nd}f}"
    return t.rstrip("0").rstrip(".") if "." in t else t


def _money(x):
    if not _isnum(x):
        return "—"
    return f"{_z(x / 1e8, 2):.2f} 亿" if abs(x) >= 1e8 else f"{_z(x / 1e4, 0):.0f} 万" if abs(x) >= 1e4 else _plain(x, 0)


def _num(x):
    if not _isnum(x):
        return "—"
    return _plain(x, 0) if abs(x) >= 1e4 else _plain(x, 2) if abs(x) >= 1 else _plain(x, 4)


def _src(eid, path, value=None):
    v = round(value, 6) if isinstance(value, float) and math.isfinite(value) else value
    return {"expert": eid, "path": path, "value": v}


def _reason(dimension, direction, strength, text, source, rule, dedup_key, kind="事实"):
    """kind: 事实 (a reading of the data) / 规则 (how the layer judged) / 假设 (a declared or product assumption) / 未知"""
    return {"dimension": dimension, "direction": direction, "strength": strength, "text": text, "source": source, "rule": rule, "dedup_key": dedup_key, "kind": kind}


def _quote(t):
    return "「" + str(t).replace("「", "『").replace("」", "』")[:240] + "」"


def _d(x):
    return x if isinstance(x, dict) else {}


def _l(x):
    return x if isinstance(x, list) else []


def _as_of_date(ctx):
    for s_ in (ctx.get("as_of_utc_date"), ctx.get("as_of_utc"), ctx.get("as_of")):
        try:
            return date.fromisoformat(str(s_)[:10])
        except (TypeError, ValueError):
            continue
    return None


def _utc_day(v):
    """the UTC calendar day of an as_of field (a date, or a date-time with or without an offset); None when unreadable"""
    if v is None:
        return None
    t = str(v).strip()
    try:
        if len(t) <= 10:
            return date.fromisoformat(t).isoformat()
        dt = datetime.fromisoformat(t.replace("Z", "+00:00"))
        return (dt.astimezone(timezone.utc) if dt.tzinfo else dt).date().isoformat()
    except (TypeError, ValueError):
        return None


def _under(path, root):
    """path is root itself or below it (review IB-16: '$.experts.fundamental' does not match '$.experts.fundamentalX')"""
    return path == root or path.startswith(root + ".") or path.startswith(root + "[")


# ------------------------------------------------------------------------------------------------------------------------------------ input
def _prepare(rec, declared):
    """format check (contract §2) -> (rec view, usable outputs, why-missing, malformed experts, declared, errors)"""
    errors = []
    if not isinstance(rec, dict):
        errors.append({"where": "$", "problem": f"运行记录应为对象，实际是{V.KIND_ZH.get(V.kind(rec), V.kind(rec))}", "affects": "全部"})
        rec = {"context": {"usable": False, "context_error": "运行记录格式异常"}}
    rerr = V.check(rec, V.RECORD_SPEC, "$", cap=10 ** 9)      # review R2-ROB-02: never cut short          # review IB-07: the record-level check is not cut short
    bad_paths = {e["where"] for e in rerr}
    for e in rerr:
        errors.append({**e, "affects": "对应部分按缺失处理"})
    experts = rec.get("experts") if isinstance(rec.get("experts"), dict) else {}
    ctx = rec.get("context")
    if not isinstance(ctx, dict) or any(_under(p_, "$.context") for p_ in bad_paths):
        ctx = {"usable": False, "context_error": "研究输入的公共部分格式异常"}
    dates = {x for x in (_utc_day(ctx.get(k)) for k in ("as_of_utc_date", "as_of_utc", "as_of")) if x is not None}
    if len(dates) > 1:                                          # review R2-ROB-01: compared as UTC days of real instants, not as text                                          # review IB-17: the as_of fields disagree -> the object of the analysis is not established
        errors.append({"where": "$.context", "problem": f"截止日字段互相矛盾：{sorted(dates)}", "affects": "全部"})
        ctx = {**ctx, "usable": False, "context_error": "截止日字段互相矛盾"}
    elif ctx.get("usable") is not False and _as_of_date(ctx) is None:
        errors.append({"where": "$.context.as_of_utc", "problem": "截止日不可读", "affects": "财报与价格新鲜度、比较依据日期都无法核对"})
    syn = rec.get("synthesis") if isinstance(rec.get("synthesis"), dict) else None
    syn_ok = (syn is not None and syn.get("status") == "COMPLETED" and not any(_under(p_, "$.synthesis") for p_ in bad_paths)
              and isinstance(syn.get("D1_cross_expert_contradictions"), list)
              and isinstance(_d(_d(syn.get("section_status")).get("D1_cross_expert_contradictions")).get("not_compared"), list))   # review R2-ROB-05
    if not syn_ok:                                              # review IB-01: no cross-check is not "no contradiction"
        errors.append({"where": "$.synthesis", "problem": "综合层没有完成、缺失或格式异常，交叉核对（X1–X5）没有进行", "affects": "估值、依据充分度"})
    d1 = [x for x in _l((syn or {}).get("D1_cross_expert_contradictions")) if isinstance(x, dict) and isinstance(x.get("rule"), str)] if syn_ok else []
    not_cmp = [x for x in _l(_d(_d(_d(syn).get("section_status")).get("D1_cross_expert_contradictions")).get("not_compared"))
               if isinstance(x, dict) and isinstance(x.get("rule"), str)] if syn_ok else []
    outs, why, malformed = {}, {}, set()
    for eid in EXPERTS:
        r = experts.get(eid)
        if any(_under(p_, f"$.experts.{eid}") for p_ in bad_paths):
            outs[eid], why[eid] = None, f"{ZH_EXPERT[eid]}的运行记录格式异常，不使用"
            malformed.add(eid)
            continue
        r = r if isinstance(r, dict) else {}
        st = r.get("execution_status")
        if st == "COMPLETED" and r.get("output_contract_status") == "CONFORMS" and isinstance(r.get("output"), dict):
            errs = V.check(r["output"], V.OUTPUT_SPECS[eid], f"$.experts.{eid}.output")
            if eid == "valuation" and not errs:
                for i, t in enumerate(_l(_d(r["output"]).get("calculation_or_extraction_trace"))):
                    if t.get("step") == "derived inputs":
                        V.check(t.get("values"), V.VALUATION_PRICE_SPEC, f"$.experts.valuation.output.calculation_or_extraction_trace[{i}].values", errs)
                names = [m.get("method") for m in _l(_d(_d(r["output"]).get("findings")).get("methods"))]
                if len(names) != len(set(names)):           # review IB-19: one method twice -> which one counts depends on order
                    errs.append({"where": "$.experts.valuation.output.findings.methods", "problem": "同一估值方法出现了不止一次"})
                rn = [m.get("method") for m in _l(_d(_d(r["output"]).get("findings")).get("estimated_value_ranges"))]
                if len(rn) != len(set(rn)):                 # review R2-ROB-04
                    errs.append({"where": "$.experts.valuation.output.findings.estimated_value_ranges", "problem": "同一估值方法的区间出现了不止一次"})
            if eid == "fundamental" and not errs:
                keys = list(_d(_d(_d(r["output"]).get("findings")).get("inputs_by_year")))
                bad = [k for k in keys if not re.fullmatch(r"[0-9]{4}", str(k))]
                if bad:                                     # review IB-04: a year key that is not four ASCII digits
                    errs.append({"where": "$.experts.fundamental.output.findings.inputs_by_year", "problem": f"财年键不是四位数字：{bad[:3]}"})
            if errs:
                outs[eid], why[eid] = None, f"{ZH_EXPERT[eid]}的输出格式异常（{len(errs)} 处，见“结构化错误”），不使用"
                malformed.add(eid)
                errors += [{**e, "expert": eid, "affects": AFFECTS[eid]} for e in errs]
                continue
            outs[eid], why[eid] = r["output"], None
            continue
        outs[eid] = None
        if st == "COMPLETED":
            why[eid] = f"{ZH_EXPERT[eid]}的输出不合输出契约，不使用"
        else:
            codes = sorted({str(x.get("code")) for x in _l(r.get("status_reasons")) if isinstance(x, dict) and x.get("code")})
            zh = "、".join(dict.fromkeys(CODE_ZH.get(c, "其他原因（代码见运行记录）") for c in codes)) or "没有记录原因"
            why[eid] = f"{ZH_EXPERT[eid]}{STATUS_ZH.get(st, '没有结果') if isinstance(st, str) else '没有结果'}（{zh}）"
    derr = V.check(declared, V.DECLARED_SPEC, "$.declared")
    if derr:
        errors += [{**e, "affects": "声明的输入不使用"} for e in derr]
        declared = {}
    try:
        declared = copy.deepcopy(declared or {})
    except RecursionError:                               # review R2-ROB-07
        errors.append({"where": "$.declared", "problem": "声明的输入嵌套过深，无法读取", "affects": "声明的输入不使用"})
        declared = {}
    if declared.get("comparison_basis") is not None and not isinstance(declared.get("comparison_basis"), list):     # review R2-ROB-08
        errors.append({"where": "$.declared.comparison_basis", "problem": "比较依据应为列表", "affects": "声明的比较依据不使用"})
    if declared.get("document_coverage") is not None:      # each declared input on its own: a bad coverage never drops a good comparison basis (review EVS-05)
        cov = declared["document_coverage"]
        cerr = V.check(cov, V.COVERAGE_SPEC, "$.declared.document_coverage")
        if not cerr and not (isinstance(cov.get("available"), int) and isinstance(cov.get("supplied"), int) and 0 <= cov["supplied"] <= cov["available"]):
            cerr = [{"where": "$.declared.document_coverage", "problem": "公告覆盖声明需要 available 和 supplied 两个非负整数，且 supplied 不大于 available"}]
        if cerr:
            errors += [{**e, "affects": "公告覆盖声明不可用：公告检查只能算部分"} for e in cerr]
            declared["document_coverage"] = {"_invalid": True}
    view = {"experts": experts, "context": ctx, "d1": d1, "not_compared": not_cmp, "synthesis_ok": syn_ok, "run_id": rec.get("run_id"),
            "case_id": rec.get("case_id"), "data_kind": rec.get("data_kind"), "labels": rec.get("labels")}
    return view, outs, why, malformed, declared, errors


# ------------------------------------------------------------------------------------------------------------------------------------ gates
def object_gate(view):
    """O1: another company's data offered for this analysis, or no usable common context"""
    ctx = view["context"]
    hits = []
    if ctx.get("usable") is False or ctx.get("context_error"):
        hits.append("研究输入的公共部分不可用，无法确定分析对象")
    for eid in EXPERTS:
        r = view["experts"].get(eid) if isinstance(view["experts"].get(eid), dict) else {}
        codes = {str(x.get("code")) for x in _l(r.get("status_reasons")) if isinstance(x, dict)}
        if codes & K.OBJECT_CODES:
            hits.append(f"{ZH_EXPERT[eid]}的数据身份核对没有通过（可能属于别家公司，或时间、来源自相矛盾），已被拒绝")      # review R2-FC-03: the code is shared
    return hits


def industry_gate(view):
    ind = _d(view["context"].get("issuer")).get("industry_class")
    return ind, K.INDUSTRY_SUPPORT.get(ind, "有限支持"), K.INDUSTRY_NOTE.get(ind)


# ------------------------------------------------------------------------------------------------------------------------------------ operations
OE_TABLE = {("UP", "UP"): ("改善", "完整"), ("UP", "FLAT"): ("改善", "完整"), ("UP", "DOWN"): ("分化", "完整"), ("UP", "UNKNOWN"): ("改善", "部分"),
            ("FLAT", "UP"): ("改善", "完整"), ("FLAT", "FLAT"): ("稳定", "完整"), ("FLAT", "DOWN"): ("恶化", "完整"), ("FLAT", "UNKNOWN"): ("稳定", "部分"),
            ("DOWN", "UP"): ("分化", "完整"), ("DOWN", "FLAT"): ("恶化", "完整"), ("DOWN", "DOWN"): ("恶化", "完整"), ("DOWN", "UNKNOWN"): ("恶化", "部分"),
            ("UNKNOWN", "UP"): ("改善", "部分"), ("UNKNOWN", "FLAT"): ("稳定", "部分"), ("UNKNOWN", "DOWN"): ("恶化", "部分"), ("UNKNOWN", "UNKNOWN"): ("无法判断", None)}


def g_cash(ni, ocf, conv_threshold):
    """contract §9.2: five exclusive classes from net income and operating cash flow"""
    if not _isnum(ni) or not _isnum(ocf):
        return "UNKNOWN", None
    if ni > 0:
        conv = ocf / ni
        if ocf <= 0 or conv < conv_threshold:
            return "WEAK", conv
        return ("MILD" if conv < 1 else "GOOD"), conv
    return ("WEAK" if ocf < 0 else "LOSS_POS_OCF"), None


def _risk_status(rc, flag):
    v = rc.get(flag)
    return {"TRUE": "TRIGGERED", "FALSE": "NOT_TRIGGERED", "NOT_APPLICABLE": "NOT_APPLICABLE"}.get(v, "UNKNOWN")


def risk_checks(rc):
    """contract §10: H1-H5"""
    P = "$.experts.fundamental.output.findings.risk_checks"
    out = {}
    for h, flag in (("H1", "NEGATIVE_EQUITY"), ("H2", "OPERATING_LOSS_INTEREST_UNCOVERED"), ("H3", "INTEREST_NOT_COVERED")):
        out[h] = {"name": RISK_NAMES[h], "status": _risk_status(rc, flag), "source": [_src("fundamental", f"{P}.{flag}", rc.get(flag))]}
    lm, no, cl = rc.get("LOSS_MAKING"), rc.get("NEGATIVE_OPERATING_CASH_FLOW"), rc.get("CURRENT_LIABILITIES_EXCEED_CURRENT_ASSETS")
    out["H4"] = {"name": RISK_NAMES["H4"], "status": "TRIGGERED" if lm == "TRUE" and no == "TRUE" else "NOT_TRIGGERED" if "FALSE" in (lm, no) else "UNKNOWN",
                 "source": [_src("fundamental", f"{P}.LOSS_MAKING", lm), _src("fundamental", f"{P}.NEGATIVE_OPERATING_CASH_FLOW", no)]}
    out["H5"] = {"name": RISK_NAMES["H5"], "status": ("TRIGGERED" if cl == "TRUE" and no == "TRUE" else "NOT_TRIGGERED" if "FALSE" in (cl, no)
                                                      else "NOT_APPLICABLE" if "NOT_APPLICABLE" in (cl, no) else "UNKNOWN"),
                 "source": [_src("fundamental", f"{P}.CURRENT_LIABILITIES_EXCEED_CURRENT_ASSETS", cl), _src("fundamental", f"{P}.NEGATIVE_OPERATING_CASH_FLOW", no)]}
    return out


INPUT_ZH = {"stockholders_equity": "股东权益", "operating_income": "营业利润", "interest_expense": "利息支出", "net_income": "净利润",
            "operating_cash_flow": "经营现金流", "current_assets": "流动资产", "current_liabilities": "流动负债"}
RISK_INPUTS = {"H1": ("stockholders_equity",), "H2": ("operating_income", "interest_expense"), "H3": ("operating_income", "interest_expense"),
               "H4": ("net_income", "operating_cash_flow"), "H5": ("current_assets", "current_liabilities", "operating_cash_flow")}


def _unknown_inputs(h, rc, latest_in):
    """the inputs of an undeterminable check that are really absent in the latest year (review V-12: only the missing ones are named)"""
    miss = [INPUT_ZH[k] for k in RISK_INPUTS[h] if not _isnum(latest_in.get(k))]
    if miss:
        return "、".join(miss)
    flags = {"H1": ["NEGATIVE_EQUITY"], "H2": ["OPERATING_LOSS_INTEREST_UNCOVERED"], "H3": ["INTEREST_NOT_COVERED"],
             "H4": ["LOSS_MAKING", "NEGATIVE_OPERATING_CASH_FLOW"], "H5": ["CURRENT_LIABILITIES_EXCEED_CURRENT_ASSETS", "NEGATIVE_OPERATING_CASH_FLOW"]}[h]
    return "、".join(dict.fromkeys(RISK_FLAG_ZH[f] for f in flags if rc.get(f) not in ("TRUE", "FALSE", "NOT_APPLICABLE")))


def operations(out, why_missing, malformed, ind_sup, asof, d1, obj=None):
    d = {"label": "无法判断", "basis": None, "rule": "OE0", "partial": False, "edge": False, "cash_class": "UNKNOWN", "why": "", "reasons": [], "tags": set(),
         "notes": [], "groups": {}, "persistent_loss": False, "usable": False, "facts": {}, "risk": None, "risk_missing": []}
    if out is None:
        d["notes"].append(why_missing)
        d["tags"].add("INPUT_MALFORMED" if malformed else "EXPERT_MISSING")
        d["why"] = "财报不可用：" + why_missing
        return d
    fi, ds = _d(out.get("findings")), _d(out.get("data_status"))
    P = "$.experts.fundamental.output"
    rc = _d(fi.get("risk_checks"))
    growth, prof = _d(fi.get("financial_growth")), _d(fi.get("financial_profitability"))
    opm = _d(prof.get("operating_margin"))
    cfq, bsh = _d(fi.get("cash_flow_quality")), _d(fi.get("balance_sheet_health"))
    fy = ds.get("latest_fiscal_year")
    iby = _d(fi.get("inputs_by_year"))
    latest_in = _d(iby.get(str(fy)))
    g_rev = {"EXPANDING": "UP", "CONTRACTING": "DOWN", "FLAT": "FLAT"}.get(growth.get("classification"), "UNKNOWN")
    g_opm = {"IMPROVING": "UP", "DETERIORATING": "DOWN", "STABLE": "FLAT"}.get(opm.get("classification"), "UNKNOWN")
    ni_path = f"{P}.findings.cash_flow_quality.net_income" if _isnum(cfq.get("net_income")) else f"{P}.findings.inputs_by_year.{fy}.net_income"
    ocf_path = f"{P}.findings.cash_flow_quality.operating_cash_flow" if _isnum(cfq.get("operating_cash_flow")) else f"{P}.findings.inputs_by_year.{fy}.operating_cash_flow"
    ni = cfq.get("net_income") if _isnum(cfq.get("net_income")) else latest_in.get("net_income")
    ocf = cfq.get("operating_cash_flow") if _isnum(cfq.get("operating_cash_flow")) else latest_in.get("operating_cash_flow")
    cash, conv = g_cash(ni, ocf, K.THRESHOLDS["T-CASH-CONV"]["value"])
    conv = conv if _isnum(conv) else None
    g_loss = prof.get("loss_making") if prof.get("loss_making") in ("TRUE", "FALSE") else "UNKNOWN"
    g_lev = "UP" if bsh.get("leverage_trend") == "INCREASING" else "NOT_UP"
    gl, chg = growth.get("latest_growth"), opm.get("change")
    d["groups"] = {"G_REV": g_rev, "G_OPM": g_opm, "G_CASH": cash, "G_LOSS": g_loss, "G_LEV": g_lev}
    d["cash_class"] = cash
    yrs = sorted((int(y) for y in iby if re.fullmatch(r"[0-9]{4}", str(y))), reverse=True)
    series = [{"fiscal_year": y, **{k: _d(iby.get(str(y))).get(k) for k in ("revenue", "operating_income", "net_income", "operating_cash_flow")}} for y in sorted(yrs)]
    d["facts"] = {"fiscal_year": fy, "revenue_growth": gl if _isnum(gl) else None, "operating_margin": {k: opm.get(k) if _isnum(opm.get(k)) else None for k in ("prior", "latest", "change")},
                  "net_income": ni if _isnum(ni) else None, "operating_cash_flow": ocf if _isnum(ocf) else None, "cash_conversion": conv,
                  "free_cash_flow": cfq.get("free_cash_flow") if _isnum(cfq.get("free_cash_flow")) else None,
                  "debt_to_equity": _d(bsh.get("debt_to_equity")).get("value") if _isnum(_d(bsh.get("debt_to_equity")).get("value")) else None,
                  "debt_to_equity_prior": bsh.get("debt_to_equity_prior") if _isnum(bsh.get("debt_to_equity_prior")) else None,
                  "series": series, "currency": ds.get("currency"), "unit": f"{ds.get('currency') or '币种未声明'}（按财报原值）；比率为小数", "period": "财年（年报口径，不是 TTM）",
                  "completeness": ds.get("completeness"), "sufficiency": ds.get("sufficiency")}
    nis = [_d(iby.get(str(y))).get("net_income") for y in yrs[:2]]
    persistent = len(nis) == 2 and yrs[0] - yrs[1] == 1 and all(_isnum(x) and x < 0 for x in nis)
    # reasons, one per fact group
    if g_rev != "UNKNOWN":
        d["reasons"].append(_reason("operations", {"UP": "SUPPORTS", "DOWN": "OPPOSES"}.get(g_rev, "NEUTRAL"), "core",
                                    f"收入{'增长' if g_rev == 'UP' else '下降' if g_rev == 'DOWN' else '基本持平'}：FY{fy} 同比 {_pct(gl)}（专家规则：变化在 ±1% 内算持平）",
                                    [_src("fundamental", f"{P}.findings.financial_growth.classification", growth.get("classification")),
                                     _src("fundamental", f"{P}.findings.financial_growth.latest_growth", gl)], "OE-G_REV", "G_REV"))
    if g_opm != "UNKNOWN":
        d["reasons"].append(_reason("operations", {"UP": "SUPPORTS", "DOWN": "OPPOSES"}.get(g_opm, "NEUTRAL"), "core",
                                    f"营业利润率{'提高' if g_opm == 'UP' else '下滑' if g_opm == 'DOWN' else '基本持平'}：{_lvl(opm.get('prior'))} → {_lvl(opm.get('latest'))}"
                                    f"（{_pp(chg)}；专家规则：变化在 0.5 个百分点内算持平）",
                                    [_src("fundamental", f"{P}.findings.financial_profitability.operating_margin.classification", opm.get("classification")),
                                     _src("fundamental", f"{P}.findings.financial_profitability.operating_margin.change", chg)], "OE-G_OPM", "G_OPM"))
    cash_src = [_src("fundamental", ocf_path, ocf), _src("fundamental", ni_path, ni)]
    h4_hit = rc.get("LOSS_MAKING") == "TRUE" and rc.get("NEGATIVE_OPERATING_CASH_FLOW") == "TRUE"     # review CI-07: H4 states the same numbers
    money = f"经营现金流 {_money(ocf)}，净利润 {_money(ni)}"
    if cash == "GOOD":
        d["reasons"].append(_reason("operations", "SUPPORTS", "soft", f"盈利有现金支撑：经营现金流高于净利润（{money}）", cash_src, "OE-G_CASH", "G_CASH"))
    elif cash == "MILD":
        d["tags"].add("CASH_BELOW_EARNINGS")
        d["reasons"].append(_reason("operations", "OPPOSES", "soft", f"经营现金流为正，但低于净利润：只有净利润的 {conv * 100:.0f}%（{money}）", cash_src, "OE-G_CASH", "G_CASH"))
    elif cash == "WEAK" and h4_hit and not (_isnum(ni) and ni > 0):
        d["tags"].add("CASH_QUALITY_WEAK")             # the reading is stated once, by the hard-risk check H4 below
    elif cash == "WEAK":
        d["tags"].add("CASH_QUALITY_WEAK")
        txt = (f"盈利但经营现金流为负或为零（{money}）" if _isnum(ni) and ni > 0 and ocf <= 0 else
               f"盈利缺少现金支撑：经营现金流只有净利润的 {conv * 100:.0f}%，不到一半（{money}）" if _isnum(ni) and ni > 0 else f"亏损，经营现金流也为负（{money}）")
        d["reasons"].append(_reason("operations", "OPPOSES", "core", txt, cash_src, "OE-G_CASH", "G_CASH"))
    elif cash == "LOSS_POS_OCF":
        d["reasons"].append(_reason("operations", "NEUTRAL", "soft", f"亏损，但经营现金流为正（{money}）", cash_src, "OE-G_CASH", "G_CASH"))
    if rc.get("NEGATIVE_FREE_CASH_FLOW") == "TRUE" and cash != "WEAK":
        d["reasons"].append(_reason("operations", "OPPOSES", "soft", f"自由现金流为负：{_money(cfq.get('free_cash_flow'))}（经营现金流减资本开支）",
                                    [_src("fundamental", f"{P}.findings.risk_checks.NEGATIVE_FREE_CASH_FLOW", "TRUE")], "OE-G_CASH", "G_CASH_FCF"))
    if g_loss == "TRUE" and h4_hit:
        d["tags"].add("LOSS_MAKING")
    elif g_loss == "TRUE":
        d["tags"].add("LOSS_MAKING")
        d["reasons"].append(_reason("operations", "OPPOSES", "soft", f"最近财年 FY{fy} 亏损" + ("（最近两个财年都亏损）" if persistent else ""),
                                    [_src("fundamental", f"{P}.findings.financial_profitability.loss_making", "TRUE")], "OE-G_LOSS", "G_LOSS"))
    if g_lev == "UP":
        d["tags"].add("LEVERAGE_RISING")
        d["reasons"].append(_reason("operations", "OPPOSES", "soft", f"杠杆上升：负债/权益 {_num(bsh.get('debt_to_equity_prior'))} → {_num(_d(bsh.get('debt_to_equity')).get('value'))}",
                                    [_src("fundamental", f"{P}.findings.balance_sheet_health.leverage_trend", "INCREASING")], "OE-G_LEV", "G_LEV"))
    risk = risk_checks(rc)
    fact = {"H1": f"股东权益 {_money(latest_in.get('stockholders_equity'))}", "H2": f"营业利润 {_money(latest_in.get('operating_income'))}，利息支出 {_money(latest_in.get('interest_expense'))}",
            "H3": f"营业利润 {_money(latest_in.get('operating_income'))}，利息支出 {_money(latest_in.get('interest_expense'))}",
            "H4": money + ("；最近两个财年都亏损" if persistent else ""), "H5": f"经营现金流 {_money(ocf)}"}
    for h, r in risk.items():
        if r["status"] == "TRIGGERED":
            d["reasons"].append(_reason("operations", "OPPOSES", "risk", f"硬性风险：{r['name']}（FY{fy}：{fact[h]}）", r["source"], "IJ3", f"RISK:{h}"))
    if rc.get("CURRENT_LIABILITIES_EXCEED_CURRENT_ASSETS") == "TRUE" and risk["H5"]["status"] != "TRIGGERED":
        d["reasons"].append(_reason("operations", "OPPOSES", "soft", "流动负债超过流动资产（经营现金流不为负，未构成硬性风险）",
                                    [_src("fundamental", f"{P}.findings.risk_checks.CURRENT_LIABILITIES_EXCEED_CURRENT_ASSETS", "TRUE")], "OE-G_LIQ", "G_LIQ"))
    for r_ in _l(fi.get("financial_risks")):
        if str(r_.get("flag") or "").startswith("OUTSIDE_USER_ASSUMPTION"):
            d["notes"].append(f"按你声明的分析假设：{str(r_.get('flag')).split(':', 1)[-1]} 超出（{r_.get('evidence')}）")
    # OE0
    fy_ok = isinstance(fy, int) and asof is not None and 1900 < fy <= asof.year
    stale = fy_ok and (asof - date(fy, 12, 31)).days > K.THRESHOLDS["T-FRESH-FIN"]["value"]
    x15 = [x for x in d1 if x.get("rule") in ("X1", "X5")]
    oe0 = []
    if obj:
        oe0.append("分析对象不成立：" + "；".join(obj))
    if ind_sup == "不支持":
        oe0.append("行业不在支持范围内")
    if ds.get("sufficiency") == "INSUFFICIENT":
        oe0.append("财报数据不足")
    elif ds.get("sufficiency") not in ("SUFFICIENT", "PARTIAL"):
        oe0.append("财报数据的完整度未知")
    if asof is None:
        oe0.append("截止日不可读，无法核对财报是否过旧")
    elif not fy_ok:
        oe0.append("最新财年不可读，或晚于截止日")
    if rc.get("ACCOUNTING_IDENTITY_MISMATCH") == "TRUE":
        oe0.append("财报的会计恒等式不成立（数字自相矛盾）")
    if stale:
        oe0.append(f"最新财年 FY{fy} 距截止日超过 {K.THRESHOLDS['T-FRESH-FIN']['value']} 天（财报过旧）")
        d["tags"].add("STALE_FINANCIALS")
    if x15:
        oe0.append("财报与估值两部分的同一输入数字或亏损状态互相矛盾")
        d["tags"].add("INPUT_CONTRADICTION")
    if oe0:
        d.update(label="无法判断", rule="OE0", why="经营无法判断：" + "；".join(oe0))
        d["notes"] = oe0 + d["notes"]
        mark = ("【分析对象不成立，只作描述，不用于判断】" if obj else "【行业不支持，只作描述，不用于判断】" if oe0 == ["行业不在支持范围内"]
                else "【财报数据有问题，不用于判断】")
        for r in d["reasons"]:
            r.update(direction="NEUTRAL", strength="soft", text=mark + r["text"], rule="OE0-UNUSED")
        d["tags"] &= {"STALE_FINANCIALS", "INPUT_CONTRADICTION"}
        why0 = ("分析对象不成立，检查不进行" if obj else "行业不在支持范围内，这几项检查不适用" if oe0 == ["行业不在支持范围内"] else "财报不能用于判断")
        d["risk"] = {h: {**r, "status": "UNKNOWN", "note": why0} for h, r in risk.items()}
        d["risk_missing"] = [why0]
        d["oe0_cause"] = "object" if obj else "industry" if oe0 == ["行业不在支持范围内"] else "financials"      # review R2V-03 / R2V-04
        return d
    d["usable"], d["persistent_loss"], d["risk"] = True, persistent, risk
    d["risk_missing"] = [f"{r['name']}（缺{_unknown_inputs(h, rc, latest_in)}）" for h, r in risk.items() if r["status"] == "UNKNOWN"]
    if any(r["status"] == "TRIGGERED" for r in risk.values()):
        d["tags"].add("HARD_RISK")
    if d["risk_missing"]:
        d["tags"].add("RISK_CHECKS_INCOMPLETE")
    label, basis = OE_TABLE[(g_rev, g_opm)]
    rule = "OE1" if label == "无法判断" else f"OE-T[{g_rev},{g_opm}]"
    d["partial"] = basis == "部分"
    if label == "改善" and cash == "WEAK":
        label, rule = "分化", rule + "+CASH"
    if label in ("改善", "恶化"):
        drive = "UP" if label == "改善" else "DOWN"
        band = K.THRESHOLDS["T-EDGE"]["value"]
        moves = ([("rev", gl, band["revenue_growth"])] if g_rev == drive else []) + ([("opm", chg, band["operating_margin_change"])] if g_opm == drive else [])
        if moves and any(not _isnum(v) for _, v, _b in moves):
            basis, rule = "部分", rule + "+NO-MAGNITUDE"
            d["partial"] = True
            d["notes"].append("推动这个评价的变化缺少幅度数字，无法确认它明显越过持平带，经营评价只有部分依据")
        elif moves and all(abs(v) <= b + 1e-12 for _, v, b in moves):
            d["edge"], basis, rule = True, "边缘", rule + "+EDGE"
            d["tags"].add("EDGE_CHANGE")
    d.update(label=label, basis=basis, rule=rule)
    parts = [f"收入{'增长' if g_rev == 'UP' else '下降' if g_rev == 'DOWN' else '基本持平' if g_rev == 'FLAT' else '趋势未知'}" + (f" {_pct(gl)}" if g_rev != "UNKNOWN" else ""),
             f"营业利润率{'提高' if g_opm == 'UP' else '下滑' if g_opm == 'DOWN' else '基本持平' if g_opm == 'FLAT' else '趋势未知'}" + (f" {_pp(chg)}" if g_opm != "UNKNOWN" else "")]
    cash_zh = {"GOOD": "盈利有现金支撑", "MILD": "经营现金流低于净利润", "WEAK": "盈利缺少现金支撑" if _isnum(ni) and ni > 0 else "亏损且经营现金流为负",
               "LOSS_POS_OCF": "亏损但经营现金流为正", "UNKNOWN": "现金质量未知"}[cash]
    d["why"] = f"FY{fy}：" + "，".join(parts + [cash_zh])
    if label == "无法判断":
        d["notes"].insert(0, "收入趋势和营业利润率趋势都无法判断")
        d["why"] = "收入趋势和营业利润率趋势都无法判断"
    if d["partial"] and "UNKNOWN" in (g_rev, g_opm):
        d["notes"].append(("收入" if g_rev == "UNKNOWN" else "营业利润率") + "趋势无法判断，经营评价只有部分依据")
    if cash in ("UNKNOWN", "LOSS_POS_OCF") and label == "改善":
        d["notes"].append("盈利的现金支撑" + ("未知（缺净利润或经营现金流）" if cash == "UNKNOWN" else "无从谈起（最近财年亏损）") + "：契约第一部分的“改善”要求盈利有现金支撑，所以不能据此给出偏积极")
    if d["edge"]:
        d["notes"].append("推动这个评价的变化只略微越过专家的持平带（不到持平带的两倍），换一个口径就可能变成“稳定”，依据标为“边缘”")
    if d["risk_missing"]:
        d["notes"].append("硬性风险检查未完成：" + "；".join(d["risk_missing"]))
    return d


# ------------------------------------------------------------------------------------------------------------------------------------ trend
def trend(out, why_missing, malformed, d1):
    d = {"label": "无法判断", "effect": "无法判断", "rule": "TR0", "reasons": [], "risk_reasons": [], "tags": set(), "notes": [], "metrics": {}, "usable": False}
    if out is None:
        d["notes"].append(why_missing)
        d["tags"] |= {"INPUT_MALFORMED" if malformed else "EXPERT_MISSING", "TREND_NOT_ASSESSABLE", "PRICE_UNUSABLE"}
        return d
    P = "$.experts.technical.output"
    m = _d(_d(out.get("metadata")).get("metrics"))
    d["metrics"] = {k: m.get(k) for k in K.TREND_METRICS + ("max_drawdown_2y", "avg_dollar_volume_20d")}
    items = [(x, "evidence", i) for i, x in enumerate(_l(out.get("evidence")))] + [(x, "counter_evidence", i) for i, x in enumerate(_l(out.get("counter_evidence")))]
    for x, where, i in items:
        if x.get("metric") == "max_drawdown_2y" and x.get("interpretation") == "negative":
            d["tags"].add("DEEP_DRAWDOWN")
            d["risk_reasons"].append(_reason("trend", "OPPOSES", "risk", f"两年内最大回撤 {_pct(x.get('value'))}（超过 40%）", [_src("technical", f"{P}.{where}[{i}]", x.get("value"))],
                                             "TR-RISK", "DRAWDOWN"))
        if x.get("metric") == "avg_dollar_volume_20d" and x.get("interpretation") == "negative":
            d["tags"].add("LIQUIDITY_RISK")
            d["risk_reasons"].append(_reason("trend", "OPPOSES", "risk", f"日均成交额偏低：{_money(x.get('value'))}（低于 1000 万）", [_src("technical", f"{P}.{where}[{i}]", x.get("value"))],
                                             "TR-RISK", "LIQUIDITY"))
    fresh = out.get("data_freshness_days")
    x2 = [x for x in d1 if x.get("rule") == "X2"]
    tr0 = []
    if not _isnum(fresh) or fresh < 0:            # review UAS-07: an unknown age is not a fresh price
        tr0.append("价格数据的日期距截止日多少天不可读，无法确认价格是当前的")
    elif fresh > K.THRESHOLDS["T-FRESH-PRICE"]["value"]:
        tr0.append(f"价格数据比截止日早 {fresh:g} 天（超过 {K.THRESHOLDS['T-FRESH-PRICE']['value']} 天，过旧）")
        d["tags"].add("STALE_PRICE")
    if m.get("momentum_12m_1m") is None and m.get("sma50_sma200_ratio") is None:
        tr0.append(f"价格历史太短（{_d(out.get('metadata')).get('price_bars_used')} 根日线），算不出 12-1 月动量和 50 日 / 200 日均线比")
    for x in x2:
        unit = bool(x.get("unit_scale_suspect") or _d(x.get("values")).get("unit_scale_suspect"))
        d["tags"].add("UNIT_SUSPECT_PRICE" if unit else "INPUT_CONTRADICTION")
        tr0.append("估值用的价格与价格序列相差约 100 倍，疑似单位错误" if unit else "估值用的价格与价格序列同日收盘价不一致")
    if tr0:
        d["notes"] = tr0
        d["tags"] |= {"TREND_NOT_ASSESSABLE", "PRICE_UNUSABLE"}
        return d
    d["usable"] = True
    reads = [(x.get("metric"), x.get("interpretation"), x.get("value"), f"{P}.{where}[{i}]") for x, where, i in items if x.get("metric") in K.TREND_METRICS]
    pos = [r for r in reads if r[1] == "positive"]
    neg = [r for r in reads if r[1] == "negative"]
    lab, rule = (("混合", "TR3") if pos and neg else ("上行", "TR1") if pos else ("下行", "TR2") if neg else ("无明显趋势", "TR4"))
    d.update(label=lab, rule=rule, effect={"上行": "支持", "下行": "反对"}.get(lab, "不构成支持或反对"))
    zh = {"momentum_12m_1m": "12-1 月动量", "sma50_sma200_ratio": "50 日 / 200 日均线比", "relative_strength_6m": "6 个月相对大盘"}
    shown = []
    for k in K.TREND_METRICS:
        v = m.get(k)
        r = next((x for x in reads if x[0] == k), None)
        txt = (f"{zh[k]} {v:.3f}" if k == "sma50_sma200_ratio" and _isnum(v) else f"{zh[k]} {_pct(v)}" if _isnum(v) else f"{zh[k]} 算不出")
        shown.append(txt + (f"（{'偏强' if r[1] == 'positive' else '偏弱'}）" if r and r[1] in ("positive", "negative") else "（中性带内）" if _isnum(v) else ""))
    d["reasons"].append(_reason("trend", {"上行": "SUPPORTS", "下行": "OPPOSES"}.get(lab, "NEUTRAL"), "core",
                                f"价格趋势{lab}（三项来自同一条价格序列，合起来只算一项）：" + "；".join(shown),
                                [_src("technical", f"{P}.metadata.metrics.{k}", m.get(k)) for k in K.TREND_METRICS] + [_src("technical", r[3], r[2]) for r in reads],
                                f"TR-{rule}", "TREND"))
    return d


# ------------------------------------------------------------------------------------------------------------------------------------ environment
def environment(out, why_missing, malformed):
    d = {"label": "无法判断", "rule": "EN0", "reasons": [], "tags": set(), "notes": [], "to_verify": [], "features_used": None}
    if out is None:
        d["notes"].append(why_missing)
        d["tags"].add("INPUT_MALFORMED" if malformed else "EXPERT_MISSING")
        return d
    P = "$.experts.macro.output"
    md = _d(out.get("metadata"))
    f = _d(md.get("features"))
    hint, tnx, fresh = md.get("regime_hint"), f.get("tnx_level"), out.get("data_freshness_days")
    if _isnum(tnx) and tnx < K.THRESHOLDS["T-RATE-UNIT"]["value"]:
        d["tags"].add("UNIT_SUSPECT_RATE")
        txt = f"10 年期利率水平 {tnx:g} 低于 {K.THRESHOLDS['T-RATE-UNIT']['value']}：疑似单位错误，把百分数写成了小数（4.3% 写成 0.043）"
        d["notes"].append(txt)
        d["to_verify"].append(txt)            # Q14 RV2-09: the rate-unit line now reaches the to-verify list
        return d
    if _isnum(fresh) and fresh > K.THRESHOLDS["T-FRESH-PRICE"]["value"]:
        d["notes"].append(f"宏观数据比截止日早 {fresh:g} 天（过旧）")
        return d
    if hint not in ("macro_supportive", "macro_neutral", "macro_stress"):
        d["notes"].append("Macro 没有给出市场环境提示")
        return d
    lab = {"macro_supportive": "偏支持", "macro_neutral": "中性", "macro_stress": "偏紧张"}[hint]
    n = sum(1 for v in f.values() if v is not None)
    d.update(label=lab, rule="EN1", features_used=n)
    if lab == "偏紧张":
        d["tags"].add("MACRO_STRESS_CONTEXT")
    d["reasons"].append(_reason("environment", {"偏支持": "CONTEXT_SUPPORTS", "偏紧张": "CONTEXT_OPPOSES"}.get(lab, "NEUTRAL"), "context",
                                f"市场环境{lab}（市场层面，不针对这家公司；不改变任何标签）：10 年期利率 {_num(tnx)}%，6 个月变化 {_num(f.get('tnx_change_6m'))} 个百分点，"
                                f"期限利差 {_num(f.get('yield_curve_slope'))} 个百分点" + (f"，VIX {_num(f.get('vix_level'))}" if f.get("vix_level") is not None else "，VIX 未使用")
                                + (f"（{n}/9 项特征可用）" if n < 9 else ""),
                                [_src("macro", f"{P}.metadata.regime_hint", hint)] + [_src("macro", f"{P}.metadata.features.{k}", f.get(k)) for k in ("tnx_level", "tnx_change_6m", "yield_curve_slope", "vix_level")],
                                "EN1", "ENVIRONMENT"))
    return d


# ------------------------------------------------------------------------------------------------------------------------------------ valuation
def _check_basis(entries, asof):
    ok, rejected = [], []
    if entries is None:
        return ok, rejected
    if not isinstance(entries, list):
        return ok, ["比较依据不是一个列表，全部拒收"]
    if entries and asof is None:
        return ok, ["截止日不可读，无法核对比较依据的日期，全部拒收"]
    for i, e in enumerate(entries):
        need = ("metric", "basis_type", "low", "high", "source", "as_of", "synthetic")
        miss = [k for k in need if not isinstance(e, dict) or e.get(k) in (None, "")]
        if miss:
            rejected.append(f"第 {i + 1} 条比较依据缺少字段（{'、'.join(miss)}），拒收")
            continue
        if not isinstance(e["metric"], str) or not isinstance(e["basis_type"], str) or not isinstance(e["synthetic"], bool) \
                or e["metric"] not in METRIC_METHOD or e["basis_type"] not in BASIS_TYPE_ZH:
            rejected.append(f"第 {i + 1} 条比较依据的指标、类型或“是否合成”字段不受支持，拒收")
            continue
        zh = METRIC_ZH[e["metric"]]
        if not _isnum(e["low"]) or not _isnum(e["high"]):          # review IB-10: a number written as text is not accepted
            rejected.append(f"第 {i + 1} 条比较依据（{zh}）的区间不是有限的数字，拒收")
            continue
        if not isinstance(e["source"], str) or not e["source"].strip():
            rejected.append(f"第 {i + 1} 条比较依据（{zh}）没有写成文字的来源，拒收")
            continue
        if not isinstance(e["as_of"], str) or not re.fullmatch(r"\d{4}-\d{2}-\d{2}(?:T\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:Z|[+-]\d{2}:\d{2})?)?", e["as_of"]):
            rejected.append(f"第 {i + 1} 条比较依据（{zh}）的日期不是 YYYY-MM-DD 格式，拒收")
            continue
        try:
            lo, hi, d_ = float(e["low"]), float(e["high"]), date.fromisoformat(e["as_of"][:10])
        except (TypeError, ValueError, OverflowError):
            rejected.append(f"第 {i + 1} 条比较依据（{zh}）的区间或日期不可读，拒收")
            continue
        if not (math.isfinite(lo) and math.isfinite(hi)):
            rejected.append(f"第 {i + 1} 条比较依据（{zh}）的区间不是有限的数，拒收")
            continue
        if not lo < hi:
            rejected.append(f"第 {i + 1} 条比较依据（{zh}）的区间下沿不小于上沿，拒收")
            continue
        if e["metric"] == "FCF_YIELD" and max(abs(lo), abs(hi)) > 1:
            rejected.append(f"第 {i + 1} 条比较依据（FCF 收益率 {lo:g}–{hi:g}）看起来写成了百分数；收益率应写成小数（0.05 表示 5%），拒收")
            continue
        if d_ > asof:
            rejected.append(f"第 {i + 1} 条比较依据（{zh}，{d_}）晚于截止日，属于未来数据，拒收")
            continue
        if (asof - d_).days > K.THRESHOLDS["T-COMP-AGE"]["value"]:
            rejected.append(f"第 {i + 1} 条比较依据（{zh}，{d_}）早于截止日超过 {K.THRESHOLDS['T-COMP-AGE']['value']} 天，过旧，不使用")
            continue
        ok.append({**e, "low": lo, "high": hi, "_i": i})
    return ok, rejected


def valuation(out, why_missing, malformed, declared, industry, persistent_loss, asof, d1, syn_ok=True, not_compared=()):
    d = {"basis": "无", "judgment": "无法判断", "robust": None, "rule": "VB0", "reasons": [], "tags": set(), "notes": [], "conditional": [], "comparison": [],
         "sensitivity": None, "assumptions": None, "rejected_basis": [], "observed": [], "conditional_text": None, "price": None, "price_date": None}
    basis_ok, d["rejected_basis"] = _check_basis(declared.get("comparison_basis"), asof)
    seen_b, dedup_b = set(), []
    for e in basis_ok:              # identical entries count once; every field is compared, the synthetic flag included (Q14 RV2-11)
        k = (e["metric"], e["basis_type"], e["low"], e["high"], str(e["source"]).strip(), str(e["as_of"])[:10], e["synthetic"], str(e.get("how_computed") or ""))
        if k in seen_b:
            d["rejected_basis"].append(f"第 {e['_i'] + 1} 条比较依据与前面一条相同（指标、类型、区间、来源、日期、是否合成、计算说明都一样），只算一次")
            continue
        seen_b.add(k)
        dedup_b.append(e)
    contra = [x for x in d1 if x.get("rule") in ("X1", "X2", "X5")]
    none_why = []
    if not syn_ok:                                  # review IB-01: without the cross-checks, the valuation inputs are unverified
        none_why.append("交叉核对（综合层）没有完成：估值用的价格和财务数字没有经过一致性核对")
    for nc in not_compared:                         # review UAS-03: a currency difference that stopped a cross-check is a unit problem
        if nc.get("rule") in ("X1", "X2") and "币种" in str(nc.get("why")):
            none_why.append(f"财报、估值与价格声明的币种不同或未声明，交叉核对 {nc['rule']} 没有进行（{_quote(nc.get('why'))}）")
            d["tags"].add("INPUT_CONTRADICTION")
    if out is None:
        none_why.append(why_missing)
        d["tags"].add("INPUT_MALFORMED" if malformed else "EXPERT_MISSING")
    if contra:
        none_why.append("估值输入与其他部分互相矛盾或单位可疑")
        for x in contra:
            d["tags"].add("UNIT_SUSPECT_PRICE" if (x.get("unit_scale_suspect") or _d(x.get("values")).get("unit_scale_suspect")) else "INPUT_CONTRADICTION")
    wcodes = {str(w.get("code")) for w in _l(_d(out).get("warnings")) if isinstance(w, dict)}
    if "FINANCIALS_STALE" in wcodes:
        none_why.append("估值所用的年报过旧：倍数是拿现价对比旧财报")
        d["tags"].add("STALE_FINANCIALS")
    if "PRICE_NOT_CURRENT" in wcodes:
        none_why.append(f"估值所用的价格比截止日早超过 {K.THRESHOLDS['T-FRESH-PRICE']['value']} 天")
        d["tags"].add("STALE_PRICE")
    if industry in ("BANK", "INSURANCE", "REIT"):
        none_why.append(K.INDUSTRY_NOTE[industry])
    if persistent_loss:
        none_why.append("持续亏损（最近两个连续财年都亏损）：盈利倍数没有意义，DCF 依赖正的自由现金流，本系统对持续亏损的公司不做估值比较")
    P = "$.experts.valuation.output"
    fi = _d(_d(out).get("findings"))
    mlist = [m for m in _l(fi.get("methods"))]
    methods = {m.get("method"): (i, m) for i, m in enumerate(mlist)}
    computed = [k for k, (_, m) in methods.items() if m.get("status") == "COMPUTED" and _isnum(m.get("observed_multiple"))]
    tr = _l(_d(out).get("calculation_or_extraction_trace"))
    ti = next((i for i, t in enumerate(tr) if t.get("step") == "derived inputs"), None)
    vals = _d(tr[ti].get("values")) if ti is not None else {}
    price, pdate = vals.get("price"), vals.get("price_date")
    d["price"], d["price_date"] = (price if _isnum(price) else None), (str(pdate) if pdate is not None else None)
    price_path = f"{P}.calculation_or_extraction_trace[{ti}].values.price"
    for k in computed:
        d["observed"].append({"method": k, "name": METHOD_ZH.get(k, k), "value": methods[k][1]["observed_multiple"], "path": f"{P}.findings.methods[{methods[k][0]}].observed_multiple"})
    if out is not None and not computed:
        none_why.append("Valuation 没有算出任何倍数")
    d["tags"].add("VALUATION_NO_BASIS")
    d["none_why"] = none_why
    d["declared_but_unusable"] = bool(dedup_b) and bool(none_why)     # review CI-04: a declared basis that cannot be used is said so
    if none_why:
        d["notes"] = none_why + d["rejected_basis"]
        if contra:
            d["observed"] = []
        return d
    obs_txt = "；".join(f"{METHOD_ZH.get(k, k)} {_num(methods[k][1]['observed_multiple'])}" if k != "FCF_YIELD" else f"FCF 收益率 {_lvl(methods[k][1]['observed_multiple'])}"
                       for k in computed if k in METHOD_ZH)
    d["notes"].append(f"观察到的倍数（价格 {_num(price)}，{pdate}；最近一个财年年报口径，不是 TTM）：{obs_txt}")
    d["notes"] += d["rejected_basis"]
    comps = []
    for e in dedup_b:
        mth = METRIC_METHOD[e["metric"]]
        if mth not in computed:
            d["notes"].append(f"比较依据 {METRIC_ZH[e['metric']]} 没有对应的观察值（Valuation 没有算出 {METHOD_ZH.get(mth, mth)}），不比较")
            continue
        v = float(methods[mth][1]["observed_multiple"])
        lo, hi = e["low"], e["high"]
        pos = "BELOW" if v < lo else "ABOVE" if v > hi else "INSIDE"
        rel = {"BELOW": "相对偏低", "INSIDE": "相对适中", "ABOVE": "相对偏高"}[pos]
        if e["metric"] == "FCF_YIELD":
            rel = {"BELOW": "相对偏高", "INSIDE": "相对适中", "ABOVE": "相对偏低"}[pos]
        scale = max(abs(lo), abs(hi)) or 1.0         # review IB-09: a bound of 0 is measured against the range's scale, never skipped
        edge = min(abs(v - lo) / (abs(lo) or scale), abs(v - hi) / (abs(hi) or scale))
        near = edge < K.THRESHOLDS["T-NEAR-EDGE"]["value"]
        comps.append({"metric": e["metric"], "name": METRIC_ZH[e["metric"]], "observed": v, "low": lo, "high": hi, "position": pos, "relative": rel, "near_edge": near,
                      "basis_type": e["basis_type"], "basis_type_zh": BASIS_TYPE_ZH[e["basis_type"]], "source": _quote(e["source"]), "as_of": str(e["as_of"])[:10],
                      "synthetic": bool(e["synthetic"]), "how_computed": _quote(e["how_computed"]) if e.get("how_computed") else None,
                      "path": f"$.declared.comparison_basis[{e['_i']}]", "obs_path": f"{P}.findings.methods[{methods[mth][0]}].observed_multiple"})
    d["comparison"] = comps
    if comps:
        d["tags"].discard("VALUATION_NO_BASIS")
        rels = {c["relative"] for c in comps}
        d["basis"] = "有比较依据"
        if len(rels) > 1:
            d.update(judgment="无法判断", robust=False, rule="VC4-MIXED")
            d["tags"].add("VALUATION_NOT_ROBUST")
            d["notes"].append("各项比较给出不同的相对位置：" + "；".join(f"{c['name']} {c['relative']}" for c in comps))
        else:
            rel = rels.pop()
            robust = not any(c["near_edge"] for c in comps)
            d.update(judgment=rel, robust=robust, rule="VC3" if robust else "VC4-EDGE")
            if not robust:
                d["tags"].add("VALUATION_NOT_ROBUST")
            if rel == "相对偏高":
                d["tags"].add("VALUATION_REL_HIGH")
            if rel == "相对偏低":
                d["tags"].add("VALUATION_REL_LOW")
        for c in comps:
            fmt = (lambda x: _lvl(x)) if c["metric"] == "FCF_YIELD" else _num
            d["reasons"].append(_reason("valuation", {"相对偏低": "SUPPORTS", "相对偏高": "OPPOSES"}.get(c["relative"], "NEUTRAL"), "core",
                                        f"{c['name']} {fmt(c['observed'])} 对比{c['basis_type_zh']}区间 {fmt(c['low'])}–{fmt(c['high'])}（来源 {c['source']}，{c['as_of']}"
                                        f"{'，合成数据' if c['synthetic'] else ''}）：{c['relative']}" + ("，距边界不到 5%，不稳健" if c["near_edge"] else "")
                                        + "。只是相对比较，不是绝对贵贱", [_src("valuation", c["obs_path"], c["observed"]), {"expert": "declared", "path": c["path"], "value": [c["low"], c["high"]]}],
                                        "VC3", f"VALUATION:{c['metric']}:{c['basis_type']}:{c['path']}"))
    assum = _d(fi.get("assumptions"))
    rlist = _l(fi.get("estimated_value_ranges"))
    ranges = {r.get("method"): (i, r) for i, r in enumerate(rlist)}
    cond = []
    for mname in ("TRAILING_PE", "PRICE_TO_BOOK", "EV_EBITDA", "DCF_FCF scenarios"):
        ir = ranges.get(mname)
        if not ir or not _isnum(price) or not _isnum(ir[1].get("low")) or not _isnum(ir[1].get("high")):
            continue
        r = ir[1]
        pos = "BELOW" if price < r["low"] else "ABOVE" if price > r["high"] else "INSIDE"
        cond.append({"method": mname, "name": METHOD_ZH[mname], "position": pos, "path": f"{P}.findings.estimated_value_ranges[{ir[0]}]", "range": [r["low"], r["high"]]})
    sens_ir = ranges.get("DCF_FCF sensitivity (base)")
    sens = sens_ir[1] if sens_ir else None
    stab = _d(fi.get("stability_warnings")).get("state")
    d["conditional"] = cond
    if cond:
        d["assumptions"] = {"reference_multiples": assum.get("reference_multiples"), "dcf": assum.get("dcf"), "note": "用户声明的假设，不是共识，也不是事实"}
        poss = {c["position"] for c in cond}
        straddle = bool(sens) and _isnum(sens.get("low")) and _isnum(sens.get("high")) and sens["low"] <= price <= sens["high"]
        robust_c = len(poss) == 1 and stab != "UNSTABLE" and not straddle
        why = ([] if len(poss) == 1 else ["各方法在你的假设下给出不同位置"]) + (["Valuation 判定估值不稳定（DCF 价值区间过宽或终值占比过高）"] if stab == "UNSTABLE" else []) + \
              (["基准情景的敏感性网格（折现率与永续增长各变动一档）本身就跨过现价"] if straddle else [])
        d["sensitivity"] = {"unstable": stab == "UNSTABLE", "grid_spans_price": straddle, "robust": robust_c, "why_not_robust": why,
                            "path": f"{P}.findings.stability_warnings.state"}
        if d["basis"] != "有比较依据":
            d.update(basis="只有声明假设", judgment="仅条件性", robust=robust_c, rule="VB2" if robust_c else "VB3")
            if not robust_c:
                d["tags"].add("VALUATION_NOT_ROBUST")
        one = poss.pop() if len(poss) == 1 else None
        txt = ("在你声明的假设下，现价位于各方法推出区间" + POS_ZH[one]) if one else \
              ("在你声明的假设下，各方法给出不同位置：" + "；".join(f"{c['name']}{POS_ZH[c['position']]}" for c in cond))
        txt += "（" + ("稳健" if robust_c else "不稳健：" + "；".join(why)) + "）。这是条件性分析，完全取决于你的假设，不判断贵贱，也不进入判断规则"
        d["reasons"].append(_reason("valuation", {"BELOW": "CONDITIONAL_SUPPORTS", "ABOVE": "CONDITIONAL_OPPOSES"}.get(one, "NEUTRAL"), "conditional", txt,
                                    [_src("valuation", price_path, price)] + [_src("valuation", c["path"], c["range"]) for c in cond] +
                                    ([_src("valuation", f"{P}.findings.estimated_value_ranges[{sens_ir[0]}]", [sens.get("low"), sens.get("high")])] if sens else []) +
                                    [_src("valuation", f"{P}.findings.stability_warnings.state", stab)], "VB1-VB4", "VALUATION_CONDITIONAL", kind="假设"))
        d["conditional_text"] = txt
    elif d["basis"] != "有比较依据":
        d.update(basis="只有倍数", judgment="无法判断", robust=None, rule="VB0-OBS")
        d["notes"].append("没有比较依据，也没有声明的假设：无法判断绝对贵贱")
    return d


# ------------------------------------------------------------------------------------------------------------------------------------ events
def _role_of(claim):
    """a role named in an extracted claim (word boundaries: a name ending in 'as' - Douglas, Thomas - is not 'as'; review EVS-02)"""
    m = re.search(r"\b(?:role of|appointed|serve as|continues to serve as|as)\s+(.+?)(?:\.|;|$|,? effective)", claim or "")
    return m.group(1).strip() if m else ""


def _issuer_core(name):
    n = re.sub(r"\(synthetic\)|\b(?:inc|incorporated|corp|corporation|co|company|ltd|limited|plc|llc|holdings?|n\.?v|s\.?a)\b\.?|[,.]", " ", str(name or ""), flags=re.I)
    n = re.sub(r"\s+", " ", n).strip()
    return n if len(n) >= 3 else ""


def material_role(role: str, issuer_name: str = "") -> bool:
    """contract §11.4: split into titles first, then judge each one; a scope word vetoes only its own title, and a scope word inside the issuer's own
    name is not a scope (Q14 RV2-06 / RV2-07)"""
    core = _issuer_core(issuer_name)
    for part in K.TITLE_SPLIT.split(role or ""):
        part = (part or "").strip()
        if not part or not K.MATERIAL_ROLE.search(part) or K.NOT_MATERIAL_ROLE.search(part):
            continue
        scoped = part if not core else re.sub(re.escape(core), " ", part, flags=re.I)
        if K.TITLE_SCOPE.search(scoped):
            continue
        return True
    return False


def mentions_material(text: str) -> bool:
    """§11.4 (3): the evidence sentence MENTIONS a key title - a plain mention test, so that a truncation is never hidden by splitting or scope words
    elsewhere in the sentence (review EVS-01)"""
    for m in K.MENTION_MATERIAL.finditer(text or ""):
        if m.group(0).lower().startswith("chair") and K.COMMITTEE_AFTER.match((text or "")[m.end():]):
            continue                                     # review R2-FC-01: the chair of a committee is not the chair of the board
        return True
    return False


def events(out, why_missing, malformed, declared, issuer_name):
    d = {"status": "未检查", "label": "未检查", "rule": "EV0", "items": [], "material": [], "uncertain": [], "unread_items": [], "recorded_items": [], "conflicts": [],
         "tags": set(), "notes": [], "insider": [], "partial_why": [], "documents": {}, "timeline": []}
    scope = "本系统只解读 8-K 第 5.02 项（管理层变动）和 Form 4（内部人交易）"
    d["scope"] = scope
    fi = _d(_d(out).get("findings"))
    docs = _l(fi.get("documents_processed"))
    n_analysed = sum(1 for x in docs if x.get("status") == "ANALYSED")
    analysed = _d(_d(out).get("data_status")).get("analysed") if out is not None else None
    if out is None or not isinstance(analysed, int) or analysed < 1 or n_analysed < 1:      # review IB-08: the count is not trusted on its own
        d["notes"].append(why_missing if out is None else "没有可分析的公告")
        d["tags"].add("EVENTS_NOT_CHECKED")
        if out is None:
            d["tags"].add("INPUT_MALFORMED" if malformed else "EXPERT_MISSING")
        return d
    P = "$.experts.information.output.findings"
    recs = {r.get("record_id"): r for r in _l(fi.get("all_extraction_records"))}
    meta = _d(fi.get("metadata_layer"))
    d["documents"] = {"supplied": len(docs), "analysed": n_analysed}
    for j, doc in enumerate(docs):
        st = doc.get("status")
        if st == "ANALYSED":
            if str(doc.get("form_type") or "").upper().startswith("8-K") and not _l(_d(meta.get(doc.get("document_id"))).get("raw_item_codes")):
                d["partial_why"].append(f"公告 {_quote(doc.get('document_id'))} 读不出 8-K 事项编号（标题格式不标准或没有标题），不知道它包含哪些事项")   # review UAS-01
            continue
        codes = {str(c.get("code")) for c in _l(doc.get("codes")) if isinstance(c, dict)}
        if st == "DUPLICATE" or (codes and codes <= K.DOC_EXEMPT_REASONS):
            continue
        d["partial_why"].append(f"公告 {_quote(doc.get('document_id'))} 未被分析（{st or '状态未知'}）")
    seen_leads, covered, span_checks = set(), set(), []
    for i, e in enumerate(_l(fi.get("events_detected"))):
        cat, st = str(e.get("event_category") or ""), e.get("evidence_status")
        det = _d(_d(recs.get(e.get("record_id"))).get("details"))
        role_raw = str(det.get("role") or "").strip()
        role = role_raw or _role_of(e.get("claim"))
        person = str(det.get("person") or "").strip().lower()
        item = {"category": cat, "claim": e.get("claim"), "evidence_status": st, "current_status": e.get("current_status"), "role": role,
                "path": f"{P}.events_detected[{i}]", "material": False, "uncertain": False, "document_id": e.get("document_id"),
                "effective_date": det.get("effective_date")}
        if cat.startswith("INSIDER_TRANSACTION"):
            d["insider"].append(item)
        elif cat == "MANAGEMENT_CHANGE" and st != "SUPERSEDED":
            claim = str(e.get("claim") or "")
            span = str(e.get("exact_evidence_span") or "")
            if material_role(role, issuer_name):
                item["material"] = True
                covered.add((str(e.get("document_id")), span, person))
                key = (person, role.lower(), str(det.get("action") or ""), str(det.get("effective_date") or "")) if person else (re.sub(r"\s+", " ", claim).lower(),)
                if key not in seen_leads:
                    seen_leads.add(key)
                    d["material"].append(item)
            elif not role_raw:                       # the expert gave no role (pairing left open, or no role named): §11.4 (2); review CI-09 / EVS-02
                item["uncertain"] = True
                item["why_uncertain"] = "公告没有写清这个人对应哪个职位（可能涉及关键职位）"
                d["uncertain"].append(item)
            elif mentions_material(span):
                item["uncertain"] = True
                item["why_uncertain"] = f"抽取到的职位是 {_quote(role)}，但原句提到了 CEO、CFO、总裁或董事长，职位可能被截断（可能涉及关键职位）"
                span_checks.append((item, (str(e.get("document_id")), span, person)))
        d["items"].append(item)
    for item, key in span_checks:      # the same person's key title in the same sentence is already a material record (dev round 1; review UAS-05: same person only)
        if key in covered:
            item["uncertain"] = False
            item.pop("why_uncertain", None)
        else:
            d["uncertain"].append(item)
    for u in _l(fi.get("unresolved_mentions")):
        txt = u.get("text") or u.get("span") or u.get("sentence") or u.get("kind")
        d["uncertain"].append({"category": "UNRESOLVED", "claim": str(txt)[:240] if txt else "", "why_uncertain": "公告里有一句可能是人事变动的话没能解析，或指代不明（可能涉及关键职位）",
                               "uncertain": True, "material": False, "path": f"{P}.unresolved_mentions"})
    if d["uncertain"]:
        d["partial_why"].append(f"有 {len(d['uncertain'])} 处人事变动的人和职位没能对上，或职位可能被截断")
    for did, m in meta.items():
        for code in _l(_d(m).get("raw_item_codes")):
            c = str(code).strip()
            if c in K.UNREAD_ITEMS:
                d["unread_items"].append({"document_id": did, "item": c, "meaning": K.UNREAD_ITEMS[c]})
            elif c in K.RECORDED_ITEMS:
                d["recorded_items"].append({"document_id": did, "item": c, "meaning": K.RECORDED_ITEMS[c]})
    if d["unread_items"]:
        d["partial_why"].append("有本系统不解读、但可能重大的 8-K 事项：" + "；".join(f"第 {x['item']} 项（{x['meaning']}）" for x in d["unread_items"]))
    cov = _d(declared.get("document_coverage"))

    def _dup(x):                                     # duplicates, and documents after as_of (outside the declared window; review R2-FC-02), are not counted
        cs = {str(c.get("code")) for c in _l(x.get("codes")) if isinstance(c, dict)}
        return x.get("status") == "DUPLICATE" or bool(cs & {"DOCUMENT_DUPLICATE_IDENTICAL", "DOCUMENT_DUPLICATE_CONTENT", "DOCUMENT_AFTER_AS_OF"})
    n_docs = sum(1 for x in docs if not _dup(x))     # dev round 2: every announcement supplied (8-K and Form 4), duplicates not counted (part I: 公告)
    if cov.get("_invalid"):
        d["partial_why"].append("公告覆盖声明不完整或自相矛盾，无法确认窗口内的公告是否都已提供")
    elif cov:
        if cov["supplied"] < cov["available"]:
            d["partial_why"].append(f"窗口内一共 {cov['available']} 份公告，只提供了 {cov['supplied']} 份")
        if cov["supplied"] != n_docs:                # review EVS-04: the declaration is checked against what was actually supplied
            d["partial_why"].append(f"公告覆盖声明说提供了 {cov['supplied']} 份，实际提供的公告（不含重复文件）是 {n_docs} 份，两者不一致")
    reason_zh = {"one document says the person is leaving the role, another that the person continues in it": "一份公告说此人离任，另一份说此人留任",
                 "a later document says the incumbent continues in the role another document says a successor was appointed to": "较晚的公告说现任继续担任，另一份公告说已任命继任者"}
    act_zh = {"DEPARTURE": "离任", "APPOINTMENT": "任命"}
    for k, zh in (("conflicting_evidence", "来源冲突"), ("supersessions", "被修正 / 取代"), ("date_disagreements", "日期不一致"), ("within_document_inconsistencies", "同一文件内不一致")):
        for j, c in enumerate(_l(fi.get(k))):
            who = f"{c.get('person')}（{c.get('role')}）"
            docs_ = "、".join(str(x) for x in _l(c.get("documents"))) or str(c.get("document_id") or "")
            txt = (f"{who}：{reason_zh.get(str(c.get('reason')), str(c.get('reason')))}（公告 {docs_}）" if k == "conflicting_evidence" else
                   f"公告 {c.get('supersedes_document')} 被 {c.get('amendment')} 修正" if k == "supersessions" else
                   f"{who}：不同公告写的{act_zh.get(str(c.get('action')), '变动')}生效日期不一致（{'、'.join(str(x) for x in _l(c.get('dates')))}；公告 {docs_}）" if k == "date_disagreements" else
                   f"{who}：同一份公告 {c.get('document_id')} 里既说离任又说继续任职")       # dev round 2 (front-end request): plain sentences, no raw JSON
            d["conflicts"].append({"kind": zh, "text": txt, "path": f"{P}.{k}[{j}]"})
    if d["material"] or d["unread_items"]:      # dev round 1: an unread T-UNREAD-ITEMS 8-K item is also an unverified material lead
        d["tags"].add("UNVERIFIED_MATERIAL_EVENT")
    if d["conflicts"]:
        d["tags"].add("SOURCE_CONFLICT")
    if d["partial_why"]:
        d["tags"].add("EVENTS_PARTIALLY_CHECKED")
        d["status"], d["rule"] = "部分", "EV-PARTIAL"
    else:
        d["status"], d["rule"] = "完成", "EV-COMPLETE"
    d["label"] = ("公告来源冲突" if d["conflicts"] else "有待核实的重大事件线索" if d["material"] else
                  "有未解读的重大公告事项（待核实）" if d["unread_items"] else "有需要核实的人事线索" if d["uncertain"] else
                  "已检查的范围内未发现重大事件线索" if d["status"] == "完成" else "部分检查，已检查的范围内未发现重大事件线索")    # review EVS-07
    for it in d["items"]:
        if it.get("effective_date") or it["category"]:
            d["timeline"].append({"date": str(it.get("effective_date") or "")[:10] or None, "category": it["category"], "claim": it["claim"],
                                  "material": it["material"], "uncertain": it["uncertain"], "path": it["path"]})
    return d


# ------------------------------------------------------------------------------------------------------------------------------------ investment judgement
def investment(obj, ind_sup, ops, tr, val, ev):
    """contract §12: conflicts first, then IJ0-IJ7 in order"""
    conflicts = []
    rel_high_robust = val["judgment"] == "相对偏高" and val["robust"] is True
    if not obj and ops["label"] != "无法判断":
        if ops["label"] == "改善" and tr["label"] == "下行":
            conflicts.append({"tag": "OPS_TREND_CONFLICT", "text": "经营在改善，但价格趋势下行：两者方向相反，未解决"})
        if ops["label"] == "恶化" and tr["label"] == "上行":
            conflicts.append({"tag": "PRICE_UP_OPS_DOWN", "text": "价格趋势上行，但经营在恶化：两者方向相反，未解决"})
        if ops["label"] == "改善" and rel_high_robust:
            conflicts.append({"tag": "VALUATION_REL_HIGH", "text": "经营在改善，但按比较依据估值相对偏高"})
    missing, codes = [], []
    if not obj and ind_sup != "不支持" and ops["usable"]:
        if not tr["usable"]:
            missing.append("价格：" + ("；".join(tr["notes"][:2]) or "价格数据不可用"))
            codes.append("PRICE_UNUSABLE")
        if val["basis"] != "有比较依据":
            if val.get("declared_but_unusable"):     # review CI-04: the user did give a basis; say why it cannot be used
                missing.append("估值比较：声明的比较依据不能使用——" + "；".join(val["none_why"][:2]))
            elif val.get("none_why"):
                missing.append("估值比较：估值无法使用——" + "；".join(val["none_why"][:2]))
            else:
                missing.append("估值比较：没有可用的比较依据（同行、自身历史或行业区间），无法判断现价相对贵贱")
            codes.append("NO_VALUATION_COMPARISON")
        if ops["risk_missing"]:
            missing.append("硬性风险检查：" + "；".join(ops["risk_missing"]) + " 无法判定")
            codes.append("RISK_CHECKS_INCOMPLETE")
    risks = [r["name"] for r in (ops["risk"] or {}).values() if r["status"] == "TRIGGERED"]
    if obj:
        return "无法判断", "IJ0", "分析对象不成立：" + "；".join(obj), conflicts, [], []
    if ind_sup == "不支持":
        return "无法判断", "IJ1", "行业不在支持范围内（银行、保险的经营与估值指标不在输入里）", conflicts, [], []
    if ops["label"] == "无法判断":
        return "无法判断", "IJ2", "经营无法判断，没有核心依据：" + ("；".join(ops["notes"][:2]) or "财报不可用"), conflicts, [], []
    if risks:
        return "偏谨慎", "IJ3", "硬性财务风险触发：" + "、".join(risks), conflicts, missing, codes
    if ops["label"] == "恶化" and ops["basis"] in ("完整", "部分"):
        return "偏谨慎", "IJ4", "经营在恶化" + ("（部分依据）" if ops["basis"] == "部分" else ""), conflicts, missing, codes
    if codes:
        names = {"PRICE_UNUSABLE": "价格数据不可用", "NO_VALUATION_COMPARISON": "缺少可靠的估值比较依据", "RISK_CHECKS_INCOMPLETE": "硬性风险检查未完成"}
        return "无法判断", "IJ5", "无法判断：" + "、".join(names[c] for c in codes), conflicts, missing, codes
    rel_ok = val["judgment"] in ("相对偏低", "相对适中") and val["robust"] is True
    cash_ok = ops["cash_class"] in ("GOOD", "MILD")      # review CI-03: part I's 改善 needs profit with cash support; unknown or a loss year is not that
    if ops["label"] == "改善" and ops["basis"] == "完整" and cash_ok and tr["label"] != "下行" and rel_ok and not conflicts:
        return "偏积极", "IJ6", ("经营完整改善，价格趋势" + ("上行" if tr["label"] == "上行" else f"{tr['label']}（不构成反对）") +
                              f"，按比较依据估值{val['judgment']}且稳健，硬性风险检查完成且未触发"), conflicts, missing, codes
    blockers = ijs_unmet(ops, tr, val, conflicts)
    return "中性", "IJ7", "检查已完成，但" + "；".join(blockers), conflicts, missing, codes


def ijs_unmet(ops, tr, val, conflicts):
    """the IJ6 conditions not met (used for IJ7's reason and for accurate invalidation lines; Q14 RV2-05)"""
    out = []
    if ops["label"] != "改善":
        out.append(f"经营{ops['label']}")
    elif ops["basis"] != "完整":
        out.append(f"经营改善只有{ops['basis']}依据")
    elif ops["cash_class"] not in ("GOOD", "MILD"):
        out.append("盈利的现金支撑" + ("未知" if ops["cash_class"] == "UNKNOWN" else "无从谈起（最近财年亏损）"))
    if tr["label"] == "下行":
        out.append("价格趋势下行")
    if val["judgment"] not in ("相对偏低", "相对适中"):
        out.append("估值比较" + ("给出不同的相对位置" if val["judgment"] == "无法判断" else f"显示{val['judgment']}"))
    elif val["robust"] is not True:
        out.append("估值比较不稳健（离区间边界太近）")
    # the three registered conflicts (§12) need 改善 + 下行, 恶化 + 上行 or 改善 + robust 偏高: each is already named above
    return out


# ------------------------------------------------------------------------------------------------------------------------------------ invalidation
def _inv_investment(rule, ops, tr, val, ev, conflicts, codes):
    common = (["待核实的公告被证实或否认后，需要重新评估（公告本身不决定方向）"] if ev["material"] or ev["uncertain"] or ev["conflicts"] else []) + \
             (["看过未解读的公告事项原文后，需要重新评估（公告本身不决定方向）"] if ev["unread_items"] else [])      # review R2V-06
    to_caution = "收入或营业利润率转为下滑（越过专家的持平带，且不只是边缘变化），或出现硬性财务风险 → 偏谨慎"
    if rule == "IJ0":
        return ["确认数据都属于这家公司后重新分析"]
    if rule == "IJ1":
        return ["行业不在支持范围内，补齐数据也不能改变；需要专门的银行 / 保险分析方法"]
    if rule == "IJ2":
        hit = [r["name"] for r in (ops["risk"] or {}).values() if r["status"] == "TRIGGERED"]
        return ["取得可用、不过旧、不自相矛盾的财报，并且收入或营业利润率至少有一项趋势可知后，才能给出投资研究判断"] + \
               ([f"注意：已触发硬性风险（{'、'.join(hit)}）；经营可以评价之后，判断会是偏谨慎"] if hit else []) + common     # review CI-10
    if rule == "IJ3":
        names = "、".join(r["name"] for r in ops["risk"].values() if r["status"] == "TRIGGERED")
        return [f"硬性风险解除（{names}）后重新评估；在此之前，其他方面再好也维持偏谨慎"] + common
    if rule == "IJ4":
        return ["收入和营业利润率止跌（不再下滑）且没有硬性风险 → 不再因经营恶化而偏谨慎；之后能否给出中性或偏积极，还要看价格、估值比较和风险检查"] + common
    if rule == "IJ5":
        fix = {"PRICE_UNUSABLE": "取得可用、当前的价格数据", "NO_VALUATION_COMPARISON": "取得带来源的估值比较依据（同行、自身历史或行业区间）",
               "RISK_CHECKS_INCOMPLETE": "补齐硬性风险检查需要的数据"}
        never = [x for x in (val.get("none_why") or []) if any(w in x for w in ("REIT", "银行", "保险", "持续亏损"))]
        lines = []
        for c in codes:
            if c == "NO_VALUATION_COMPARISON" and never:     # review CI-04 / R2-FC-04: the permanent reason itself is named
                lines.append("这家公司的估值比较本系统不做（" + never[0] + "），所以补齐比较依据也不能给出偏积极或中性")
            elif c == "NO_VALUATION_COMPARISON" and val.get("none_why"):
                lines.append("估值部分目前不可用（" + val["none_why"][0] + "）；问题解决、并有带来源的比较依据之后 → 才能给出偏积极或中性")
            else:
                lines.append(f"{fix[c]} → 才能给出偏积极或中性")
        return lines + ["补齐之前，如果经营转为恶化（不只是边缘变化）或出现硬性风险 → 偏谨慎"] + common
    if rule == "IJ6":
        return ["收入转为下降，或营业利润率下滑超过 0.5 个百分点 → 经营不再是完整改善 → 中性；明显恶化时 → 偏谨慎",
                "盈利失去现金支撑（经营现金流转负，或不到净利润的一半）→ 经营转为分化 → 中性",
                "改善幅度缩小到只略微越过持平带 → 依据变为边缘 → 中性",
                "价格趋势转为下行 → 中性",
                "按比较依据估值转为相对偏高，或比较变得不稳健 → 中性",
                "出现硬性财务风险 → 偏谨慎",
                "价格数据变得不可用，或比较依据失效 → 无法判断"] + common
    unmet = ijs_unmet(ops, tr, val, conflicts)
    out = []
    def plus(item):
        rest = [u for u in unmet if u != item]
        return "（还需要：" + "；".join(rest) + "）" if rest else ""
    for u in unmet:
        if u.startswith("经营") and ops["label"] == "稳定":
            out.append("收入或营业利润率明显向好（超过持平带两倍），且盈利有现金支撑 → 经营转为完整改善 → 可能转为偏积极" + plus(u))
        elif u.startswith("经营") and ops["label"] == "分化" and ops["cash_class"] == "WEAK" and ops["groups"].get("G_REV") != "DOWN" and ops["groups"].get("G_OPM") != "DOWN":
            out.append(("盈利恢复现金支撑（经营现金流不低于净利润的一半）" if ops["groups"].get("G_LOSS") == "FALSE" else "恢复盈利、且经营现金流不低于净利润的一半")
                       + " → 经营转为改善 → 可能转为偏积极" + plus(u))
        elif u.startswith("经营") and ops["label"] == "分化":
            out.append("收入与营业利润率变得同向向好 → 可能转为偏积极" + plus(u) + "；同向下滑 → 偏谨慎")
        elif u.startswith("经营改善只有边缘"):
            out.append("改善幅度变大，明显越过持平带（收入增长超过 2% 或营业利润率提高超过 1 个百分点）→ 可能转为偏积极" + plus(u))
        elif u.startswith("经营改善只有部分"):
            out.append("补齐缺失的收入或营业利润率数据，确认两项都不下滑 → 可能转为偏积极" + plus(u))
        elif u.startswith("经营") and ops["label"] == "恶化":
            out.append("经营止跌 → 判断可能改变" + plus(u))
        elif u == "价格趋势下行":
            out.append("价格趋势不再下行 → 可能转为偏积极" + plus(u))
        elif u.startswith("估值比较"):
            out.append("估值比较变得一致、稳健，并显示相对适中或偏低 → 可能转为偏积极" + plus(u))
        elif u.startswith("盈利的现金支撑"):
            out.append("取得经营现金流和净利润，确认盈利有现金支撑 → 可能转为偏积极" + plus(u) if ops["cash_class"] == "UNKNOWN" else
                       "恢复盈利且经营现金流支撑利润 → 可能转为偏积极" + plus(u))
    return out + [to_caution, "价格数据变得不可用，或比较依据失效 → 无法判断"] + common


def _inv_operations(ops):
    lab = ops["label"]
    if lab == "无法判断":
        cause = ops.get("oe0_cause")
        if cause == "object":
            return ["确认所有数据都属于这家公司、身份核对通过后 → 可以重新评价"]
        if cause == "industry":
            return ["行业不在支持范围内：补齐财报也不能评价，需要专门的行业分析方法"]
        return ["取得可用、不过旧、不自相矛盾的财报，并且收入或营业利润率至少有一项趋势可知 → 可以评价"]
    out = {"改善": ["收入转为下降，或营业利润率下滑超过 0.5 个百分点 → 分化或恶化", "盈利失去现金支撑（经营现金流为负或不到净利润的一半）→ 分化"],
           "稳定": ["收入或营业利润率越过持平带（收入 ±1%、利润率 0.5 个百分点）→ 改善或恶化"],
           "分化": ["收入与营业利润率变得同向 → 改善或恶化" if ops["cash_class"] != "WEAK" or "DOWN" in (ops["groups"].get("G_REV"), ops["groups"].get("G_OPM"))
                  else "盈利恢复现金支撑（经营现金流不低于净利润的一半）→ 改善" if ops["groups"].get("G_LOSS") == "FALSE"
                  else "恢复盈利、且经营现金流不低于净利润的一半 → 改善"],      # review R2V-10: a loss year cannot recover 'cash support' alone
           "恶化": ["收入和营业利润率止跌（回到持平带内或转为增长）→ 稳定或改善"]}[lab]
    if ops["basis"] == "边缘":
        out.append("变化只略微越过持平带：下一期幅度稍有回落就会变成“稳定”")
    if ops["basis"] == "部分":
        out.append("补齐缺失的那一项趋势后，评价可能改变")
    return out


# ------------------------------------------------------------------------------------------------------------------------------------ assembly
def _json_safe(o, hits):
    """dev round 2 (long fuzz): a value echoed from a malformed record (NaN, infinity, a huge integer) never leaves the layer - the output is
    always strict JSON; each replacement is reported"""
    if isinstance(o, dict):
        return {k: _json_safe(v, hits) for k, v in o.items()}
    if isinstance(o, list):
        return [_json_safe(v, hits) for v in o]
    if isinstance(o, float) and not math.isfinite(o) or isinstance(o, int) and not isinstance(o, bool) and abs(o) >= 10 ** 300:
        hits.append(1)
        return None
    return o


def judge(rec, declared=None) -> dict:
    try:
        out = _judge(rec, declared)
    except Exception as e:                    # last-resort guard: the page always gets a refusal, and the tests count every INTERNAL_ERROR as a failure
        out = _internal_error(rec, e)
    hits = []
    out = _json_safe(out, hits)
    if hits:
        out.setdefault("errors", []).append({"where": "$", "problem": f"输入里有 {len(hits)} 个非有限或超大的数值被原样带到输出，已替换为空值", "affects": "只影响显示"})
    return out


def _internal_error(rec, e):
    ctx = _d(_d(rec).get("context"))
    out = {"schema": K.SCHEMA, "decision_layer_version": K.DECISION_VERSION, "contract_version": K.CONTRACT_VERSION,
           "experimental": "实验性原型 · 未经金融验证 · 不是投资建议", "data_kind": _d(rec).get("data_kind"),
           "object": {"name": _d(ctx.get("issuer")).get("name"), "security": _d(ctx.get("issuer")).get("security")}, "as_of": ctx.get("as_of_utc"),
           "operations_evaluation": {"label": "无法判断", "basis": None, "rule": "ERR", "why": "判断层内部错误"},
           "investment_judgement": {"label": "无法判断", "basis": "不足", "rule": "ERR", "missing": ["判断层内部错误"], "missing_codes": [], "why": "判断层内部错误，不给出判断"},
           "errors": [{"where": "$", "problem": "INTERNAL_ERROR", "detail": f"{type(e).__name__}: {str(e)[:160]}", "affects": "全部"}],
           "issue_tags": ["INPUT_MALFORMED"], "action_mapping": {"available": False}}
    out["summary_zh"] = "经营评价：无法判断。投资研究判断：无法判断（判断层内部错误）。"
    return out


def _judge(rec, declared):
    view, outs, why, malformed, declared, errors = _prepare(rec, declared)
    ctx = view["context"]
    iss = _d(ctx.get("issuer"))
    asof = _as_of_date(ctx)
    obj = object_gate(view)
    ind, ind_sup, ind_note = industry_gate(view)
    m = lambda e: e in malformed  # noqa: E731
    ops = operations(outs["fundamental"], why["fundamental"], m("fundamental"), ind_sup, asof, view["d1"], obj)      # review CI-01: O1 -> both layers 无法判断
    tr = trend(outs["technical"], why["technical"], m("technical"), view["d1"])
    env = environment(outs["macro"], why["macro"], m("macro"))
    val = valuation(outs["valuation"], why["valuation"], m("valuation"), declared, ind, ops["persistent_loss"] if ops["usable"] else False, asof, view["d1"],
                    view["synthesis_ok"], view["not_compared"])
    ev = events(outs["information"], why["information"], m("information"), declared, iss.get("name"))
    label, rule, ij_why, conflicts, ij_missing, ij_codes = investment(obj, ind_sup, ops, tr, val, ev)
    tags = set().union(ops["tags"], tr["tags"], env["tags"], val["tags"], ev["tags"])
    if rule == "IJ5" and "NO_VALUATION_COMPARISON" in ij_codes:
        tags.add("NO_VALUATION_COMPARISON")
    if obj:
        tags.add("IDENTITY_CONFLICT")
    if ind_sup == "不支持":
        tags.add("INDUSTRY_NOT_SUPPORTED")
    elif ind_sup == "有限支持":
        tags.add("INDUSTRY_LIMITED")
    for c in conflicts:
        tags.add(c["tag"])
    for eid in EXPERTS:
        if outs[eid] is None:
            tags.add("INPUT_MALFORMED" if eid in malformed else "EXPERT_MISSING")
    # reasons, deduplicated by fact group
    allr, seen = [], set()
    for r in ops["reasons"] + tr["reasons"] + tr["risk_reasons"] + env["reasons"] + val["reasons"]:
        if r["dedup_key"] in seen:
            continue
        seen.add(r["dedup_key"])
        allr.append(r)
    for i, r in enumerate(allr):
        r["id"] = f"R{i + 1:02d}"
    order = {"risk": 0, "core": 1, "soft": 2, "conditional": 3, "context": 4}
    sup = sorted([r for r in allr if r["direction"] in ("SUPPORTS", "CONTEXT_SUPPORTS", "CONDITIONAL_SUPPORTS")], key=lambda r: order[r["strength"]])
    opp = sorted([r for r in allr if r["direction"] in ("OPPOSES", "CONTEXT_OPPOSES", "CONDITIONAL_OPPOSES")], key=lambda r: order[r["strength"]])
    neutral = [r for r in allr if r["direction"] == "NEUTRAL"]
    key_risks = [r["text"] for r in opp if r["strength"] in ("risk", "soft") or (r["strength"] == "core" and r["dimension"] == "operations")] + \
                ([f"行业限制：{ind_note}"] if ind_note else []) + [r["text"] for r in env["reasons"] if r["direction"] == "CONTEXT_OPPOSES"]
    unresolved = [c["text"] for c in conflicts] + [f"公告{c['kind']}：{_quote(c['text'])}" for c in ev["conflicts"]]
    if val["judgment"] == "无法判断" and len({c["relative"] for c in val["comparison"]}) > 1:
        unresolved.append("各项估值比较给出不同的相对位置")
    # checks (contract §3)
    risk = ops["risk"] or {h: {"name": n, "status": "UNKNOWN", "source": [], "note": "财报不可用"} for h, n in RISK_NAMES.items()}
    risk_done = ops["usable"] and not ops["risk_missing"]
    if not risk_done:          # dev round 1: the status tag also when the financials are missing or unusable (contract §6: 有硬性风险检查无法判定)
        tags.add("RISK_CHECKS_INCOMPLETE")
    triggered = [r["name"] for r in risk.values() if r["status"] == "TRIGGERED"]
    risk_statement = (("硬性风险触发：" + "、".join(triggered) + ("；另有检查未完成：" + "；".join(ops["risk_missing"]) if ops["risk_missing"] else "")) if triggered else
                      "本次检查的五项硬性风险都未触发（不代表没有风险）" if risk_done else
                      "硬性风险检查未完成：" + ("；".join(ops["risk_missing"]) if ops["risk_missing"] else "财报不可用"))
    checks = {"price": {"status": "可用" if tr["usable"] else "不可用", "why": tr["notes"]},
              "valuation_comparison": {"status": "有" if val["basis"] == "有比较依据" else "无", "level": val["basis"], "robust": val["robust"], "judgment": val["judgment"]},
              "risk_checks": {"status": "完成" if risk_done else "未完成", "missing": ops["risk_missing"], "statement": risk_statement},
              "events": {"status": ev["status"], "why": ev["partial_why"] + (ev["notes"] if ev["status"] == "未检查" else []), "scope": ev["scope"]}}
    # sufficiency (§12.1)
    suff_missing = []
    if label == "无法判断":
        basis = "不足"
        suff_missing = list(ij_missing) or [ij_why]
    else:
        if not tr["usable"]:
            suff_missing.append("价格不可用")
        if not (val["basis"] == "有比较依据" and val["robust"] is True):
            suff_missing.append("没有稳健的估值比较依据" if val["basis"] == "有比较依据" else "没有估值比较依据")
        if not risk_done:
            suff_missing.append("硬性风险检查未完成")
        if ev["status"] != "完成":
            suff_missing.append("公告只检查了一部分：" + "；".join(ev["partial_why"]) if ev["status"] == "部分" else "公告未检查")
        if ev["material"] or ev["uncertain"]:
            suff_missing.append("有待核实的关键职位线索")
        if ev["unread_items"]:
            suff_missing.append("有未解读的重大公告事项")
        if not view["synthesis_ok"]:
            suff_missing.append("交叉核对（综合层）没有完成")
        if ops["label"] == "改善" and ops["cash_class"] not in ("GOOD", "MILD"):
            suff_missing.append("盈利的现金支撑" + ("未知" if ops["cash_class"] == "UNKNOWN" else "无从谈起（最近财年亏损）"))      # review R2V-07
        if unresolved:
            suff_missing.append("有未解决的冲突")
        if ind_sup != "支持":
            suff_missing.append(f"行业{ind_sup}：{ind_note}" if ind_note else f"行业{ind_sup}")
        basis = "有限" if suff_missing else "充分"
    # conditions
    to_meet = []
    if val["basis"] != "有比较依据":
        to_meet.append("估值需要有比较依据：同行、自身历史或行业的倍数区间，写明来源和日期")
    elif val["robust"] is not True:
        to_meet.append("估值比较需要稳健：各项比较一致，且离区间边界不太近")
    if not tr["usable"]:
        to_meet.append("取得当前、单位正确的价格数据")
    elif tr["label"] == "下行":
        to_meet.append("价格趋势不再下行")
    if triggered:
        to_meet.append("硬性财务风险解除：" + "、".join(triggered))
    if ops["usable"] and ops["risk_missing"]:
        to_meet.append("补齐硬性风险检查需要的数据：" + "；".join(ops["risk_missing"]))
    if ops["label"] in ("恶化", "分化", "稳定") or ops["basis"] in ("部分", "边缘") or (ops["label"] == "改善" and ops["cash_class"] not in ("GOOD", "MILD")):
        to_meet.append("经营出现完整的改善证据（收入与营业利润率向好，盈利有现金支撑，变化不只是边缘）")
    if ops["label"] == "无法判断" and ops.get("oe0_cause") not in ("object", "industry"):
        to_meet.append("取得可用、不过旧、不自相矛盾的财报")
    elif ops["label"] == "无法判断" and ops.get("oe0_cause") == "object":
        to_meet.append("确认所有数据都属于这家公司（身份核对通过）")
    if ev["status"] != "完成":
        to_meet.append("把没检查到的公告看完（见“需要核实”）")
    if val["conditional_text"]:
        to_meet.append("（条件性，基于你自己声明的假设）" + val["conditional_text"])
    to_meet.append("了解你自己的持仓、期限和风险承受（个人化部分不在本系统范围内）")
    to_verify = [f"关键管理层变动线索（未核实；公告原文摘录）：{_quote(x['claim'])}" for x in ev["material"]] + \
                [f"可能涉及关键职位（待核实；公告原文摘录）：{_quote(x['claim'])}；{x['why_uncertain']}" for x in ev["uncertain"]] + \
                [f"未解读的公告事项：公告 {_quote(x['document_id'])} 第 {x['item']} 项（{x['meaning']}）——本系统不解读，需要看原文" for x in ev["unread_items"]] + \
                [f"公告{c['kind']}：{_quote(c['text'])}" for c in ev["conflicts"]]
    for x in view["d1"]:
        unit = bool(x.get("unit_scale_suspect") or _d(x.get("values")).get("unit_scale_suspect"))
        what = {"X1": "财报与估值两部分的同一财务数字不一致", "X2": "估值用的价格与价格序列疑似单位不同（约 100 倍）" if unit else "估值用的价格与价格序列同日收盘价不一致",
                "X5": "财报与估值对是否亏损的判断不一致"}.get(x.get("rule"), "两个专家的输入互相矛盾")
        to_verify.append(f"{what}（详见专业版的来源路径）")
    to_verify += env["to_verify"]
    to_verify += [n for n in ops["notes"] if "恒等式" in n]
    to_verify += obj
    to_verify = list(dict.fromkeys(to_verify))
    unans = list(K.UNANSWERABLE_FIXED)
    if val["basis"] != "有比较依据":
        unans.append("现价贵不贵：没有比较依据，无法判断")
    if ev["items"] or ev["conflicts"]:
        unans.append("公告事件是否属实：抽取到的事件是待核实线索，真伪未判定")
    if ind_note and ind_sup == "不支持":
        unans.append(f"这家公司的经营质量：{ind_note}")
    experts_trace = {}
    for eid in EXPERTS:
        r = _d(view["experts"].get(eid))
        experts_trace[eid] = {"status": r.get("execution_status"), "output_contract": r.get("output_contract_status"),
                              "version": str(r.get("implementation_version") or "").split(" (")[0] or None, "output_fingerprint": r.get("output_fingerprint"),
                              "used": outs[eid] is not None, "malformed": eid in malformed}
    oe = {"label": ops["label"], "basis": ops["basis"], "rule": ops["rule"], "why": ops["why"], "partial": ops["partial"], "edge": ops["edge"],
          "cash_class": ops["cash_class"], "groups": ops["groups"], "notes": ops["notes"], "persistent_loss": ops["persistent_loss"],
          "meaning": "只看已报告的经营情况，不代表现在值得买"}
    ij = {"label": label, "basis": basis, "rule": rule, "why": ij_why, "missing": suff_missing if label != "无法判断" else (ij_missing or [ij_why]), "missing_codes": ij_codes,
          "meaning": "把价格、估值比较、风险检查、事件核查一起放进来的研究判断；不是买卖建议"}
    out = {
        "schema": K.SCHEMA, "decision_layer_version": K.DECISION_VERSION, "contract_version": K.CONTRACT_VERSION,
        "experimental": "实验性原型 · 只在隔离工作区 · 未经金融验证 · 不是投资建议",
        "data_kind": view["data_kind"], "data_labels": view["labels"],
        "object": {"issuer_id": iss.get("issuer_id"), "name": iss.get("name"), "security": iss.get("security"), "industry_class": ind,
                   "industry_zh": K.INDUSTRY_ZH.get(ind, "其他 / 未知"), "industry_support": ind_sup, "industry_note": ind_note, "object_problems": obj},
        "as_of": ctx.get("as_of_utc") or ctx.get("as_of"),
        "horizon": {"label": "约 6–12 个月的观察角度", "note": "产品的观察角度，不是经过验证的预测期限"},
        "operations_evaluation": oe,
        "investment_judgement": ij,
        "checks": checks,
        "risk_checks": risk,
        "dimensions": {
            "operations": {"label": ops["label"], "basis": ops["basis"], "facts": ops["facts"]},
            "trend": {"label": tr["label"], "effect": tr["effect"], "rule": tr["rule"], "notes": tr["notes"], "metrics": tr["metrics"]},
            "environment": {"label": env["label"], "scope": "市场层面，不针对这家公司；不改变任何标签", "rule": env["rule"], "notes": env["notes"],
                            "features_used": env["features_used"]},
            "valuation": {"basis": val["basis"], "judgment": val["judgment"], "robust": val["robust"], "rule": val["rule"], "notes": val["notes"],
                          "conditional": val["conditional"], "comparison": val["comparison"], "sensitivity": val["sensitivity"], "assumptions": val["assumptions"],
                          "observed": val["observed"], "price": val["price"], "price_date": val["price_date"]},
            "events": {"status": ev["status"], "label": ev["label"], "rule": ev["rule"], "scope": ev["scope"], "material": ev["material"], "uncertain": ev["uncertain"],
                       "unread_items": ev["unread_items"], "recorded_items": ev["recorded_items"], "conflicts": ev["conflicts"], "insider_rows": ev["insider"],
                       "other_items": [x for x in ev["items"] if not x["material"] and not x["uncertain"] and not x["category"].startswith("INSIDER")],
                       "partial_why": ev["partial_why"], "notes": ev["notes"], "documents": ev["documents"], "timeline": ev["timeline"],
                       "role": "只进入“需要核实”和依据充分度，不决定方向"},
        },
        "supporting": sup, "opposing": opp, "neutral_facts": neutral,
        "key_risks": key_risks, "unresolved_conflicts": unresolved,
        "conditions": {"to_meet": to_meet, "to_verify": to_verify},
        "invalidation": {"investment_judgement": _inv_investment(rule, ops, tr, val, ev, conflicts, ij_codes), "operations_evaluation": _inv_operations(ops)},
        "unanswerable": unans,
        "action_mapping": {"available": False, "why": "前提一个都不满足；两层结论都不改名为买 / 持 / 卖", "prerequisites": list(K.ACTION_PREREQUISITES)},
        "not_included": list(K.NOT_INCLUDED),
        "issue_tags": sorted(tags, key=K.TAGS.index),
        "errors": errors,
        "trace": {"experts": experts_trace, "rules_fired": [f"O1:{bool(obj)}", f"INDUSTRY:{ind_sup}", ops["rule"], tr["rule"], env["rule"], val["rule"], ev["rule"], rule],
                  "thresholds": sorted(K.THRESHOLDS),
                  "declared_inputs": {"comparison_basis": len(declared.get("comparison_basis") or []) if isinstance(declared.get("comparison_basis"), list) else 0,
                                      "rejected": val["rejected_basis"], "document_coverage": declared.get("document_coverage")},
                  "run_id": view["run_id"], "case_id": view["case_id"]},
    }
    out["summary_zh"] = summary(out)
    out["core_fingerprint"] = hashlib.sha256(json.dumps(core(out), ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()
    return out


def core(out: dict) -> dict:
    """the parts that must not change under order / wording / irrelevant changes (invariance tests)"""
    dm = out.get("dimensions") or {}
    oe, ij = out["operations_evaluation"], out["investment_judgement"]
    return {"oe": [oe["label"], oe["basis"]], "ij": [ij["label"], ij["basis"], ij["rule"]], "trend": (dm.get("trend") or {}).get("label"),
            "environment": (dm.get("environment") or {}).get("label"), "valuation": [(dm.get("valuation") or {}).get("basis"), (dm.get("valuation") or {}).get("judgment")],
            "events": (dm.get("events") or {}).get("status"), "tags": out.get("issue_tags")}


def summary(o):
    oe, ij = o["operations_evaluation"], o["investment_judgement"]
    s = f"经营评价：{oe['label']}" + (f"（{oe['basis']}依据）" if oe.get("basis") else "") + "。"
    s += f"投资研究判断：{ij['label']}（依据{ij['basis']}）" + ("，" + ij["why"].split("：", 1)[-1] if ij["label"] == "无法判断" else "") + "。"
    return s


def forbidden_hits(out: dict) -> list:
    """forbidden wording in the judgement-bearing fields; refusal lists (unanswerable / not_included / action_mapping) are not scanned"""
    keep = {k: out.get(k) for k in ("operations_evaluation", "investment_judgement", "checks", "dimensions", "supporting", "opposing", "neutral_facts", "key_risks",
                                     "unresolved_conflicts", "conditions", "invalidation", "summary_zh", "horizon")}
    txt = re.sub(r"「[^」]*」", "「」", json.dumps(keep, ensure_ascii=False))
    hits = set()
    for mm in K.FORBIDDEN.finditer(txt):
        if K.NEGATION.search(txt[max(0, mm.start() - 16):mm.start()]):
            continue
        hits.add(mm.group(0))
    return sorted(hits)
