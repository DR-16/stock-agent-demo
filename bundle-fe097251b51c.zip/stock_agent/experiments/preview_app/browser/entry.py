"""Q15 public demo - the Python side of one analysis in the browser (Pyodide in a Web Worker started for this one analysis and ended after it).

analyze(case_id) runs the five experts on one SYNTHETIC case of the demo list (DEMO_CASES; nothing else can be named), through the same
orchestrator.run_q8 the local workbench uses (the subprocess calls run in this interpreter: browser/inprocess.py), then the Q15 judgement layer
(decision.judge.judge, q15-decision) on THAT run record plus the case's declared (synthetic) inputs, then decision.views.build_views on the same
decision and record. It returns one JSON text:

  view          a small header (run id, case, record SHA-256, decision fingerprint) - what the page needs before it trusts the record
  record_text   the analysis record (Q15_DEMO_ANALYSIS_RECORD_V1): the run record, the declared inputs, the decision, the simple / professional
                views, the chart data and the page facts (expert statuses, timings). The page renders FROM this text after checking its SHA-256,
                so the page, the full report, the download and the history entry are the same run by construction.

No network, no real data: the bundle has no real-data files and no data-fetching module. Q14's decide() path is gone from the page.
The price chart reads the case's registered synthetic price dataset (hash-checked against the registry, rows after the as-of date dropped) and
passes it through decision.views.price_series_from_dataset (display only; not an input of any conclusion).
"""
from __future__ import annotations

import copy
import hashlib
import json
import re
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
APP = HERE.parent
sys.path.insert(0, str(APP))
sys.path.insert(0, str(HERE))
import inprocess  # noqa: E402

inprocess.install()
from orchestrator import q8_input as Q, run as RUN, context as C  # noqa: E402
from workbench import beginner as BG  # noqa: E402
from adapters import registry as R  # noqa: E402
from decision.judge import judge  # noqa: E402   # Q15: the two-layer judgement (q15-decision; isolated prototype)
from decision.views import build_views, price_series_from_dataset  # noqa: E402

RECORD_SCHEMA = "Q15_DEMO_ANALYSIS_RECORD_V1"
_CASES = json.loads((HERE / "demo_cases.json").read_text(encoding="utf-8"))["cases"]                  # synthetic only
DEMO_CASES = {c["case_id"]: {k: v for k, v in c.items() if k not in ("case_id", "decision_inputs")} for c in _CASES}
DECISION_INPUTS = {c["case_id"]: c.get("decision_inputs") or {} for c in _CASES}
EXPERT_ZH = {"technical": "技术面", "macro": "宏观", "fundamental": "基本面", "valuation": "估值", "information": "公告"}
EXPERT_SCOPE = {"technical": "价格走势", "macro": "市场环境", "fundamental": "财报", "valuation": "估值倍数", "information": "管理层变动、内部人交易"}
STATUS_ZH = {"COMPLETED": "已运行", "COMPLETED_NO_RESULT": "已运行，没有结果", "REJECTED": "输入被拒绝", "NOT_APPLICABLE": "不适用", "NOT_EXECUTED": "没有运行",
             "FAILED": "运行失败", "ABSTAINED": "弃权"}
EXPERT_WORD = {"Technical": "技术面", "Macro": "宏观", "Fundamental": "基本面", "Valuation": "估值", "Information": "公告专家"}


def _names_zh(t: str) -> str:
    for k, v in EXPERT_WORD.items():
        t = re.sub(rf"(?<![A-Za-z_]){k}(?![A-Za-z_])", v, t)
    return t


def _short_version(v) -> str:
    """the version name only - the long development notes inside version strings are not shown on the page"""
    return str(v or "").split(" (")[0][:60]


def cases() -> str:
    return json.dumps([{"case_id": k, **v} for k, v in DEMO_CASES.items()], ensure_ascii=False)


def _price_series(model: dict, security: str, as_of: str):
    """(weekly closes for the chart, where they came from) - display only. The registered synthetic dataset is checked against its SHA-256;
    rows after the as-of date are dropped. PRICE_DATASET_CONTRACT_V1 keeps rows as lists under 'columns'; views.price_series_from_dataset reads
    dict rows, so the rows are handed over as {date, close} (records/q15_web/VIEW_REQUESTS.md)."""
    pid = model.get("price_dataset")
    src = {"dataset_id": pid, "synthetic": True, "points": 0, "problem": None}
    try:
        reg = C.registry()["price_datasets"].get(pid) if isinstance(pid, str) else None
        if not reg:
            src["problem"] = "价格数据集没有登记"
            return [], src
        raw = (C.Q7 / reg["file"]).read_bytes()
        if hashlib.sha256(raw).hexdigest() != reg.get("sha256"):
            src["problem"] = "价格数据集和登记的校验值不一致，不显示"
            return [], src
        doc = json.loads(raw)
        s = (doc.get("series") or {}).get(security) or {}
        cols = list(s.get("columns") or [])
        if "Close" not in cols:
            src["problem"] = "价格数据集里没有这只证券的收盘价"
            return [], src
        ci = cols.index("Close") + 1
        day = str(as_of or "")[:10]
        rows = [{"date": str(r[0])[:10], "close": r[ci]} for r in s.get("rows") or [] if isinstance(r, list) and len(r) > ci and str(r[0])[:10] <= day]
        ps = price_series_from_dataset({"series": {security: {"rows": rows}}}, security)
        src.update({"sha256": reg.get("sha256"), "points": len(ps), "first": ps[0]["date"] if ps else None, "last": ps[-1]["date"] if ps else None,
                    "note": "合成数据：开发者为演示生成的价格序列，不是任何真实证券的行情；每 5 个交易日取一个收盘价，只用于显示走势"})
        return ps, src
    except (OSError, ValueError, KeyError, TypeError, IndexError) as e:
        src["problem"] = f"价格序列读取失败（{type(e).__name__}）"
        return [], src


def _experts(rec: dict, beg: dict) -> list:
    plain = {x.get("expert"): x.get("text") for x in beg.get("experts") or []}
    out = []
    for eid in R.ORDER:
        r = rec["experts"][eid]
        st = r.get("execution_status")
        out.append({"expert": eid, "name": EXPERT_ZH.get(eid, eid), "scope": EXPERT_SCOPE.get(eid, ""), "status": st, "status_zh": STATUS_ZH.get(st, str(st)),
                    "contract": r.get("output_contract_status"), "version": _short_version(r.get("implementation_version")),
                    "tier": "生产在用（原样调用）" if R.EXPERTS[eid]["tier"] == "PRODUCTION_ACTIVE" else "实验版本（生产中未激活）",
                    "plain": plain.get(eid),
                    "reasons": [{"meaning": _names_zh(str(x.get("meaning"))) if x.get("meaning") else None, "detail": _names_zh(str(x.get("detail") or ""))[:300]}
                                for x in (r.get("status_reasons") or [])][:6]})
    return out


def analyze(case_id: str) -> str:
    if case_id not in DEMO_CASES:
        return json.dumps({"ok": False, "error": "这个演示只支持列出的合成公司和场景。"}, ensure_ascii=False)
    t = time.time()
    model, kind, _, case_sha = Q.load_case(case_id)
    rec = RUN.run_q8(model, None, "REGISTERED_CASE")
    subject = model.get("subject") or {}
    as_of = model.get("as_of") or rec.get("as_of")
    declared = copy.deepcopy(DECISION_INPUTS.get(case_id) or {})
    decision = judge(rec, declared)                                     # never raises: a malformed input gives structured errors
    ps, ps_src = _price_series(model, subject.get("security") or "", str(as_of))
    try:
        views = build_views(decision, rec, ps)
        views_error = None
    except Exception as e:                                              # the record still carries the decision; the page says the views failed
        views, views_error = None, f"{type(e).__name__}: {str(e)[:160]}"
    beg = BG.build(rec, subject.get("security") or "", subject.get("name") or "", str(as_of), {})
    seconds = round(time.time() - t, 2)
    case = {"case_id": case_id, **DEMO_CASES[case_id]}
    bundle = {
        "schema": RECORD_SCHEMA,
        "data_kind": rec.get("data_kind") or "SYNTHETIC",
        "run_id": rec["run_id"],
        "case": case,
        "subject": subject,
        "as_of": as_of,
        "decision_inputs": declared,
        "price_series_source": ps_src,
        "page": {"experts": _experts(rec, beg), "seconds": seconds, "started_at": rec.get("started_at_utc") or rec.get("started_at"),
                 "finished_at": rec.get("finished_at_utc") or rec.get("finished_at"), "python": sys.version.split()[0], "case_sha256": case_sha},
        "decision": decision,
        "views": views,
        "views_error": views_error,
        "run_record": rec,
    }
    record_text = json.dumps(bundle, ensure_ascii=False, sort_keys=True, allow_nan=False, default=str)
    sha = hashlib.sha256(record_text.encode("utf-8")).hexdigest()
    view = {"ok": True, "schema": "Q15_DEMO_VIEW_V1", "run_id": rec["run_id"], "case_id": case_id, "title": case.get("title"), "kind": case.get("kind"),
            "record_sha256": sha, "decision_fingerprint": decision.get("core_fingerprint"),
            "consistency": (views or {}).get("consistency") if views else ["视图没有生成"]}
    return json.dumps({"view": view, "record_text": record_text}, ensure_ascii=False)
