"""Q11 successor (q11-information 0.4.0): general rules, each written from the sentence form (no company, name or fixed sentence): names with a
suffix (Jr., Sr., II, III, IV) and with a curly or straight apostrophe or a Mc / Mac prefix ('O’Brien', 'McDonald'); 'Jr.' / 'Sr.' do not end a
sentence; 'intention to' / 'intent to' / 'notice of his intention' are tentative; advisory and chair titles are roles (Senior Advisor, Executive
Chair, Vice Chair); a role followed by 'of the Company' keeps its adjacent 'on DATE'; the end of a continuation ('through DATE', 'until DATE') is
read; titles the person is said to hold in an appositive of the same sentence ('X, currently the Company's President, ...') are returned so that an
'appointment' to an already-held title is not made an event.

Q10 successor (q10-information 0.3.0): general rules added for real 8-K wording, each written from the sentence form and never for a company, a
name or a fixed sentence: an honorific before a named object ('appointed Mr. Richard B. Lewis'); an object after the role ('elected as a director of
the Company Mr. X'); curly apostrophes and a company's own possessive before a role ('the Company’s', 'Acme's'); the abbreviations CEO / CFO / COO;
'remain with the Company as ROLE'; a Board committee as a role; 'his current role' resolved to the role the same person is said to hold earlier in
the section (role basis NEIGHBOUR_SENTENCE), with 'on DATE' read after that phrase; tentative wording before the subject ('expects that X will');
a completed past predicate dated by a bare year ('in 2018') is historical; the Item 5.02(d) disclosure template ('There is no arrangement or
understanding ... pursuant to which ... was selected') is not an event; elections AT an annual meeting are routine, 'until the next annual meeting'
is not.

Information V2.1 (q5-information-v21 0.2.0; Q5_INFORMATION_V21_CONTRACT.json) - successor of Q4 V2 0.1.1 (whose copy in baseline/ is unchanged).
Q5 changes, each a general rule (no name-, date- or case-specific rule): subject scope (reporting verbs, parentheticals, possessives, coordination
needs 'and'), honorific / pronoun gender conflicts, nearest-subject inheritance, no person x role cross product without 'respectively',
coordinated objects, non-factual contexts, historical relative clauses kept apart from the main predicate, 'on DATE' adjacency, 'May' the month,
departure / appointment forms, and the Q5 date semantics (event / narrative / effective dates, sentence-initial governing dates).

Information V2 (q4-information-v2 0.1.0) - stages A and B for synthetic 8-K Item 5.02 text: evidence localisation (sentences -> clauses, with
document offsets) and structured event extraction (predicate, voice, subject, role, polarity, modality, clause-owned effective date).

Design (Q4_INFORMATION_V2_CONTRACT.json): a lexical matcher only proposes predicates; the subject, the role and the date are each resolved by an
explicit scope rule inside the clause, and anything that cannot be resolved stays unresolved (AMBIGUOUS record or unresolved mention) - nothing
is filled in by a fallback. No issuer-, name-, date- or fixture-specific rule exists here.
"""
from __future__ import annotations

import re
from datetime import date

MONTHS = {m: i for i, m in enumerate(("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"), 1)}
MONTH_ABBR = {"Jan.": 1, "Feb.": 2, "Mar.": 3, "Apr.": 4, "Jun.": 6, "Jul.": 7, "Aug.": 8, "Sep.": 9, "Sept.": 9, "Oct.": 10, "Nov.": 11, "Dec.": 12}
STOP = {"The", "Company", "Company's", "Board", "Directors", "Chief", "Officer", "Financial", "Executive", "Operating", "President", "Item", "On", "At", "This", "Exhibit",
        "Form", "Effective", "Mr", "Ms", "Mrs", "Dr", "Vice", "Senior", "Treasurer", "Secretary", "General", "Counsel", "Committee", "Audit", "Compensation", "Chair",
        "Chairman", "Chairwoman", "Interim", "Acting", "Accounting", "Technology", "Marketing", "Medical", "Information", "Legal", "Human", "Resources", "Supply", "Chain",
        "Risk", "Investment", "Strategy", "Revenue", "Product", "Commercial", "Communications", "In", "As", "Following", "Also", "Upon", "After", "Before", "Until", "Each",
        "Both", "Registrant", "Report", "Current", "Inc", "Corp", "Holdings", "Group", "Synthetic", "Departure", "Directors", "Election", "Appointment", "Certain",
        "Officers", "Compensatory", "Arrangements", "Lead", "Independent", "Director", "Controller", "Operations", "Global", "Corporate", "Chief", "Grid", "Data",
        "Science", "Digital", "Sales", "People", "Administrative", "Transformation", "Innovation", "Research", "Development", "Engineering", "Manufacturing",
        "Quality", "Regulatory", "Affairs", "Compliance", "Security", "Customer", "Experience", "Brand", "Growth", "Treasury", "Tax", "Investor", "Relations",
        "Nominating", "Governance", "Executive's", "He", "She", "They", "His", "Her", "Their", "It", "Its", "SEC", "Amendment", "No", "Annual", "Meeting",
        "Stockholders", "Shareholders", "Today", "Further", "However", "Accordingly", "Additionally", "Subsequently", "Meanwhile", "Mr.", "Ms.", "Dr.",
        "If", "Unless", "Neither", "Nor", "Rumors", "Rumours", "Reports", "Whether", "When", "While", "Although", "Because", "Since", "Prior", "During",
        "Under", "Pursuant", "According", "Despite", "Once", "Then", "Thereafter", "Previously", "Formerly", "Actuary", "Rumor", "Speculation",
        "Transition", "Date", "Agreement", "Plan", "Policy", "Program", "Award", "Exhibit",
        "Asia", "Pacific", "North", "South", "East", "West", "Central", "America", "Americas", "Europe", "European", "EMEA", "APAC", "Latin", "Middle", "Africa",
        "International", "Region", "Regional", "Worldwide", "Canada", "Mexico", "China", "Japan", "India", "United", "States", "Kingdom", "Northeast", "Southeast",
        "Northwest", "Southwest", "Midwest", "Atlantic", "Nordic", "Iberia", "Benelux", "Australia", "Zealand",
        "Markets", "Market", "Region", "Regions", "Division", "Divisions", "Segment", "Segments", "Business", "Unit", "Units", "Territories"} | set(MONTHS)     # Q12 C10: units     # 0.4.6 (4th review H11 / H15): regions     # Q10: defined terms ('the CEO Transition Date') are not names
TOKEN = r"(?:[A-Z]['\u2019])?(?:Ma?c|De|Di|Da|Du|La|Le|Van|Von)?[A-Z\u00c0-\u00d6\u00d8-\u00de][a-z\u00df-\u00f6\u00f8-\u00ff]+(?:[-'\u2019][A-Z\u00c0-\u00d6\u00d8-\u00de][a-z\u00df-\u00f6\u00f8-\u00ff]+)*(?:-[a-z]{2,4}\b)?"   # 0.4.6: 'Min-jun'   # Q11 0.4.3: accented letters (Desirée, Søren, Zoë)     # Q11: O’Brien / O'Brien, McDonald, Smith-Jones
PARTICLE = r"(?:van|von|de|der|den|del|della|degli|di|da|das|dos|du|la|le|ter|ten|bin|ibn|al|el|y)"      # 0.4.6: lower-case family-name particles
RE_CAPSEQ = re.compile(rf"{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})*")       # 0.4.6: 'Pieter van der Berg', 'Maria de la Cruz'
_ROLEWORD = r"(?:Chief|President|Treasurer|Secretary|General|Controller|Director|Chair|Vice|Senior|Executive|Principal|Head|Member|CEO|CFO|COO|Interim|Acting)\b"
DESC = rf"(?:[A-Z][a-z&]+ ?(?:(?:and|&) (?!{_ROLEWORD})(?=[A-Z]))?){{1,4}}"     # 0.4.6 (4th review): a title's description ('Tax and Treasury', 'Investor Relations')
ROLE_HEAD = (r"(?:Chief (?:[A-Z][a-z]+ ){1,3}(?:Officer|Executive)\b|Chief (?:[A-Z][a-z]+ ){0,2}[A-Z][a-z]+\b|"
             rf"President(?:, (?!{_ROLEWORD}){DESC}(?=,|\.|;| effective| of the| \(|$))?|"       # 0.4.6: 'President, North America' (not 'President, Chief ...')
             rf"Executive Vice President(?:,? (?:of )?{DESC})?|Senior Vice President(?:,? (?:of )?{DESC})?|"
             rf"Vice President(?: of {DESC}|,? {DESC})?|"
             r"Treasurer|(?:Corporate )?Secretary|General Counsel|(?:Corporate )?Controller|"
             r"Chair(?:man|woman|person)?(?: of the Board(?: of Directors)?)?(?! of (?:the )?(?:[A-Z][a-z&]+,? (?:and )?){1,6}Committee)|Lead Independent Director|[Ii]ndependent [Dd]irector|[Dd]irector|member of the [Bb]oard(?: of [Dd]irectors)?|"
             r"[Bb]oard of [Tt]rustees|[Tt]rustee|[Bb]oard member|CEO|CFO|COO|[Pp]rincipal (?:[Ee]xecutive|[Ff]inancial|[Aa]ccounting|[Oo]perating) [Oo]fficer|(?:Senior |Special |Strategic )?Advisor(?: to the (?:Chief Executive Officer|CEO|Board(?: of Directors)?))?|"
             r"Executive Chair(?:man|woman|person)?(?: of the Board(?: of Directors)?)?|Vice Chair(?:man|woman|person)?(?: of the Board(?: of Directors)?)?|"
             r"(?:(?:a )?member of (?:both )?|(?:the )?[Cc]hair(?:man|woman|person)? of )?(?:the )?(?:[A-Z][a-z&]+,? (?:and )?){1,6}Committee(?: of the [Bb]oard)?)")
ROLE = rf"(?:(?:[Ii]nterim|[Aa]cting) )?(?:[Cc]o-)?{ROLE_HEAD}"      # 0.4.6: 'Co-Chief Executive Officer'
ROLE_PRE = r"(?:(?:the |a |an )?(?:Company['\u2019]s |Registrant['\u2019]s |its |our |his |her |their |[A-Z][A-Za-z&.]+(?: [A-Z][A-Za-z&.]+)?['\u2019]s )?(?:new |next |permanent |additional )?)"   # 0.4.6: 'its new CFO'   # Q10: curly apostrophe; a company's own possessive
NEG = re.compile(r"\b(?:not|never|no longer|n't|no plans to|declined to|does not intend to)\b", re.I)
TENT = re.compile(r"\b(?:(?-i:may)(?!\s+[0-9])|might|could|would|is expected to|are expected to|(?:is|are) (?:also |currently |now )?(?:expected|anticipated) to|expects to|is anticipated to|intends to|plans to|is considering|are considering|"
                  r"intention to|intent to|intends? to|planned to|"
                  r"upon (?:the )?(?:closing|completion|consummation) of|subject to (?:the )?(?:closing|completion|consummation|approval|receipt)|"
                  r"conditioned (?:up)?on|contingent (?:up)?on|if the (?:merger|transaction|acquisition) (?:closes|is completed)|"   # Q11: a change conditional on a future closing                     # Q11: 'notice of his intention to retire', 'informed ... of her intention to'"
                  r"is likely to|is in discussions to|has been asked to|may be asked to|is contemplating|potential(?:ly)?)\b", re.I)
ADV = r"(?:also|since|recently|formally|now|subsequently|additionally|further|unanimously|then|officially|today|effectively)"
TENT_PRE = re.compile(r"\b(?:expects?|expected|anticipates?|anticipated|intends?|plans?|hopes?|believes?|is likely|it is expected)\b[^.;]{0,60}\bthat,?\s+(?:[^,;.]{1,40},\s+)?$", re.I)   # Q11: 'expects that, in 2027, X will'   # Q10: '... expects that X will'
RE_COND_PRE = re.compile(r"\b(?:(?:effective )?(?:upon|as of|at|following) (?:the )?(?:closing|completion|consummation|effective time) of (?:the )?(?:merger|transaction|acquisition|"
                         r"offering|IPO|separation|spin-off|distribution|business combination)|subject to (?:the )?(?:closing|completion|consummation|approval|receipt)|"
                         r"if (?:the )?(?:merger|transaction|acquisition) (?:closes|is completed)|in the event (?:that )?|"
                         r"(?:effective )?(?:upon|following|after|at) (?:the )?(?:receipt|grant|issuance|satisfaction|obtaining) of|"      # 0.4.6 (3rd review C3): classes, not phrases
                         r"(?:effective )?(?:upon|following|after|at) (?:the )?(?:[a-z-]+ ){0,3}(?:closing|completion|consummation|effective time|pricing) of|"
                         r"subject to (?:the )?(?:[A-Za-z'\u2019-]+ ){0,3}(?:approval|closing|completion|consummation|receipt|satisfaction)|"
                         r"(?:contingent|conditioned|conditional) (?:up)?on)\b", re.I)
RE_COND_ANY_TENSE = re.compile(r"^\s*(?:subject to (?:the )?(?:[A-Za-z'\u2019-]+ ){0,3}(?:approval|receipt|satisfaction)|(?:contingent|conditioned|conditional) (?:up)?on)\b", re.I)   # 0.4.6: governs a past-tense predicate too
RE_REPORTED = re.compile(r"\b(?:announced|disclosed|reported|stated|confirmed|said|(?:mutually )?agreed|determined|decided|resolved)\s+that\s+$")   # 0.4.6 (3rd review C1): a reported decision     # Q11 0.4.3: 'announced that X would retire' - reported speech
RE_STAY_EMPLOYED = re.compile(r"^\s*(?:employed (?:by|with) the (?:Company|Registrant)|with the (?:Company|Registrant))\b")    # Q11 0.4.3: 'remain employed by / with the Company'
RE_ADVISORY = re.compile(r"^\s*with the (?:Company|Registrant)\s+in an? (?:[a-z]+ )?(?:advisory|consulting|transition(?:al)?|non-executive|non-officer|employee) (?:role|capacity|position)\b")
RE_SUCC_AS = None                                    # set after ROLE_PRE / ROLE (below)
RE_NON_OFFICER = re.compile(r"\b(?:[Aa]dvis[oe]r|[Cc]onsultant|advisory (?:role|capacity|position)|consulting (?:role|capacity)|transition(?:al)? (?:role|capacity)|non-executive (?:role|capacity|position)|non-officer|[Ss]pecial [Aa]ssistant|employee)\b")   # Q11 0.4.3: an officer title (e.g. 'Senior Vice President, X') stays a continuation
TENT_ADJ = re.compile(r"\b(?:(?:his|her|their|[A-Z][a-z]+['\u2019]s) (?:plan|wish|desire|intention|intent) to|(?:has |have |had )?asked (?:(?:Mr|Ms|Mrs|Dr)\. )?(?:[A-Z][\w.'\u2019-]+ ){1,3}to|"
                      r"(?:preferred |leading )?candidate (?:for|to)|nominee (?:for|to))\s+(?:\S+\s+){0,2}$")      # 0.4.5 (2nd review N3): only when it governs THIS predicate
TENT_CLAUSE = re.compile(r"\b(?:recommended that|has been nominated|proposed (?:to|that)|preferred candidate|"
                         r"(?:will |to |shall )?vote (?:on|upon|for|to)|proposals? (?:to|for|regarding)|proposals?(?=\s*$)|stand(?:s|ing)? for (?:re-?)?election|nominat(?:ed|es|e|ing))\b")   # 0.4.6 (3rd review C2)     # 0.4.5: in the predicate's own clause
TENT_STRONG = re.compile(r"\b(?:(?:preferred |leading )?candidate for|nominee for|preferred candidate|recommended that|(?:has |have |had )?asked (?=[A-Z])|(?:his|her|their) plan to|(?:his|her|their) (?:wish|desire) to|"
                         r"wish(?:es)? to|desire[sd]? to|is (?:being )?considered|candidate (?:for|to)|has been nominated|proposed (?:to|that))\b")   # 0.4.4 (review E5)
RE_COND_POST = re.compile(r"\b(?:upon|following|after|at) (?:the )?(?:closing|completion|consummation|effective time) of (?:the |its |a |an )?(?:proposed |pending |planned )?"
                          r"(?:merger|transaction|acquisition|offering|IPO|separation|spin-off|distribution|business combination|sale)\b|"
                          r"\bonce (?:the )?(?:merger|transaction|acquisition|offering|deal|closing) (?:is |has been )?(?:completed|closed|consummated|closes|occurs)\b|"
                          r"\bpending (?:the )?(?:[a-z]+ ){0,2}(?:approval|closing|completion|consummation)\b|\bassuming (?:that )?(?:the )?(?:merger|transaction|acquisition|deal|closing)\b|"
                          r"\bif (?:the )?(?:Company['\u2019]s )?(?:merger|transaction|acquisition|offering|stockholders|shareholders|regulators?|closing)\b|"
                          r"\bsubject to (?:the )?(?:[A-Za-z'\u2019-]+ ){0,3}(?:approval|closing|completion|consummation|receipt|satisfaction)\b|"
                          r"\bconditioned (?:up)?on\b|\bcontingent (?:up)?on\b|\bprovided that\b|\bin the event (?:that )?\b", re.I)   # 0.4.4 (review E5) / 0.4.5 (2nd review N2, N3)
RE_COND_STRONG_POST = re.compile(r"\bsubject to (?:the )?(?:[A-Za-z'\u2019-]+ ){0,3}(?:approval|ratification|receipt|consummation|closing)\b|\b(?:contingent|conditioned|conditional) (?:up)?on\b", re.I)
RE_SEG_END = re.compile(r",?\s+(?:and|but|while)\s+(?:her|his|their|its|the|will|shall|would|is|are|was|were|he|she|they|which|receive|be)\b|;|,\s+(?:who|which|succeeding|replacing|while)\b")


def _segment(t: str) -> str:
    """the event's own part of the text after its predicate: up to a coordinated clause, a relative clause or a semicolon (0.4.5, 2nd review N3 / N4)"""
    m = RE_SEG_END.search(t)
    return t[:m.start()] if m else t
RE_BARE_YEAR = re.compile(r"\b(?:in|from|since|during) (?:19|20)[0-9]{2}\b(?! *[-/])")       # Q10: 'appointed COO (of Beta Inc.) in 2018' - a bare year, no month, no day
RE_TEMPLATE = re.compile(r"^\s*(?:There (?:is|are|was|were) no|No) (?:other )?(?:arrangements?|understandings?|family relationships?|transactions?|related[- ]party)\b|"
                         r"\bpursuant to which (?:he|she|they|[A-Z][a-z]+(?: [A-Z][a-z.]+)*) (?:was|were|is|are|has been|have been) (?:selected|elected|appointed|named)\b", re.I)
RE_CUR_ROLE = re.compile(r"^\s*(?:from |in )?(?:(?:his|her|their) (?:current |existing |present |officer |executive )?|that |this |these |those |such |the )(?:role|position|title|post|office|function|duties)s?\b")   # Q11: 'that title', 'his officer positions'
AUX = rf"(?:(?:has|have|had|will|shall|would|did|does|do|is|are|was|were)(?: {ADV})?(?: not| never| no longer)?(?: {ADV})? )?"
DEP_V = (r"(?:resign(?:ed|s)?|retire[ds]?|retiring|step(?:s|ped)? (?:down|away)|stepping (?:down|away)|stood down|stand(?:s)? down|standing down|depart(?:ed|s)?|left|"
         r"(?<!medical )(?<!a )(?<!an )(?<!paid )(?<!family )(?<!his )(?<!her )(?<!their )leave[s]?(?! of absence)|cease[ds]? to serve|"     # Q11: 'a medical leave of absence' is not leaving"
         r"stop(?:s|ped)? serving|cease[ds]? serving|transition(?:s|ed)? out of (?:his|her|their) (?:role|position)s?|"     # Q11 0.4.3
         r"stop(?:s|ped)? performing(?= (?:this|that|these|those|the|his|her|their) (?:function|duties|role)s?)|cease[ds]?(?= (?:this|that|his|her|their) (?:role|position|function|employment)s?)|"   # 0.4.5: the role words stay for RE_CUR_ROLE
         r"passed away|died|separate[ds]? from the (?:Company|Registrant)|"      # 0.4.6 (3rd review M2): death; 'separated from the Company'
         r"relinquish(?:ed|es)?|vacate[ds]?|exit(?:ed|s)?|gave up|give[s]? up|conclude[ds]? (?:his|her|their) (?:service|tenure)|end(?:ed|s)? (?:his|her|their) (?:service|tenure)|"
         r"(?:tender(?:ed|s)?|submit(?:ted|s)?)(?:,? and the [Bb]oard (?:has )?accepted,)? (?:his|her|their) resignation)")
APP_V = r"(?:appointed|named|elected|promoted|designated|selected|hired|tapped|chosen|picked|installed|assigned)"
CON_V = (rf"(?:continue[sd]? to hold,(?= (?:his|her|their) )|keep(?:s)? serving|kept serving|continue[sd]? (?:his|her|their) (?:tenure|service|term)(?= as)|continue[sd]? to maintain (?:his|her|their) (?:position|role|title|post)s?|"   # Q11 0.4.3
         rf"continue[sd]? to be(?= (?:a |an |the |its |our )?(?:member of the [Bb]oard|{ROLE_HEAD}))|"
         r"continuing (?:(?:his|her|their) (?:role|position|service|tenure)s?|to serve)(?= as)|"      # 0.4.5: 'is continuing her role as a trustee'
         r"continue[sd]?(?: to (?:serve|hold (?:his|her|their|the) (?:position|role|title|post)s?))?(?! to (?!serve\b|hold\b))|remain(?:s|ed)?|stay(?:s|ed)? on|stay(?:s|ed)? in (?:his|her|their|the) (?:position|role|post)|"
         r"keep[s]? (?:his|her|their) (?:position|role|title|post)|retain(?:s|ed)? (?:his|her|their) (?:position|role|title|post))")
TITLE_PRE = r"(?:the )?(?:Honorable|Hon\.)\s+|(?:Senator|Judge|Justice|Professor|Ambassador|Governor|Admiral|Reverend|Sir|Dame)\s+"   # Q13-G: 'appointed the Honorable X', 'elected Senator X'
PREDICATES = [                                      # (rule id, action, voice, pattern) - voice SUBJ: the clause subject is the person; OBJ: the object after the verb
    ("V2-DEP-ACT", "DEPARTURE", "SUBJ", re.compile(rf"\b{AUX}(?:formally )?{DEP_V}\b")),
    ("V2-DEP-PAS", "DEPARTURE", "SUBJ", re.compile(rf"\b(?:(?:was|were)(?: {ADV})?|(?:has|have|had)(?: {ADV})? been(?: {ADV})?|(?:will|shall)(?: {ADV})? be(?: {ADV})?)(?: not| never)? (?:removed|terminated|dismissed|relieved of (?:his|her|their) duties)\b")),
    ("V2-DEP-ACC", "DEPARTURE", "OBJ", re.compile(rf"\baccepted (?P<obj>(?:(?:Mr|Ms|Mrs|Dr)\. {TOKEN})|{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})+)['\u2019]s resignation\b")),
    ("V2-DEP-OBJ", "DEPARTURE", "OBJ", re.compile(rf"\b(?:removed|terminated|dismissed|(?<=voted )to (?:remove|dismiss)|terminated the employment of) (?:(?:Mr|Ms|Mrs|Dr)\.\s+|{TITLE_PRE})?(?P<obj>{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})+)")),   # 0.4.6 (3rd review M2) / Q13-G
    ("V2-DEP-NLS", "DEPARTURE", "SUBJ", re.compile(rf"\b(?:will|shall|would|is to)? ?no longer (?:serve|be employed|hold (?:the|his|her|their) (?:position|role|title)s?)(?= as |\b)")),   # 0.4.6: 'would no longer serve as COO' is a departure, not a negation
    ("V2-DEP-NSR", "DEPARTURE", "SUBJ", re.compile(r"\b(?:(?:will|would|shall|has decided|had decided|decided|has determined|determined|has elected|elected|has chosen|chose)(?: not to| not)|(?:will|would|shall) not) (?:stand|run|seek|be a candidate) for re-?election\b")),   # 0.4.6: not standing for re-election (the seat ends at the meeting)
    ("V2-APP-OBJ", "APPOINTMENT", "OBJ", re.compile(rf"\b{APP_V}(?: by the [Bb]oard(?: of [Dd]irectors)?)? (?:(?:Mr|Ms|Mrs|Dr)\.\s+|{TITLE_PRE})?(?P<obj>{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})+|(?<=\. ){TOKEN}\b)")),   # Q13-G
    ("V2-APP-INV", "APPOINTMENT", "OBJ", re.compile(rf"\b{APP_V} as (?:a |an |the )?(?P<role>{ROLE}|[Dd]irector)(?: of (?:the |its )?(?:Company|Registrant|[Bb]oard))?,? (?:(?:Mr|Ms|Mrs|Dr)\.\s+|{TITLE_PRE})?(?P<obj>{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})+)")),   # Q13-G
    ("V2-APP-PAS", "APPOINTMENT", "SUBJ", re.compile(rf"\b(?:(?:was|were|is|are)(?: {ADV})?|(?:has|have|had)(?: {ADV})? been(?: {ADV})?|(?:will|shall|to)(?: {ADV})? be(?: {ADV})?|(?:is|are) being)(?: not| never)? {APP_V}\b")),   # 0.4.6: 'is expected to be named' (tentative from the context)
    ("V2-APP-SUC", "APPOINTMENT", "SUBJ", re.compile(rf"\b{AUX}(?:succeed(?:s|ed)?|replace[sd]?) (?P<succ>(?:Mr|Ms|Mrs|Dr)\. {TOKEN}|{TOKEN}(?:(?: [A-Z]\.)? (?!(?:Jr|Sr)\b){TOKEN})+(?:,? (?:Jr\.|Sr\.|II|III|IV)(?![A-Za-z]))?)")),   # Q10: middle initials; Q11: a suffix
    ("V2-APP-SUCP", "APPOINTMENT", "SUBJ", re.compile(rf"\b{AUX}succeed(?:s|ed)? (?P<pro>him|her)(?= as )")),     # 0.4.5: 'Ms. Doyle will succeed him as Chief Executive Officer'
    ("V2-APP-ACT", "APPOINTMENT", "SUBJ", re.compile(rf"\b{AUX}(?:assume[ds]? the (?:(?:additional|new|expanded|added) )?(?:role|position|title|duties|responsibilities)s? of|(?:take[s]?|took|taking) (?:up|on) the (?:role|position|title|post)s? of|"     # Q11 0.4.3: 'will take up the role of'
                                                         rf"commence[sd]? (?:(?:his|her|their) )?(?:role|service|tenure|duties)(?= as)|commence[sd]? employment with the (?:Company|Registrant)(?= (?:as|in the role of))|"
                                                         rf"(?:become[s]?|became)(?! effective)|(?:re)?join(?:ed|s)? the Company|rejoin(?:ed|s)? the [Bb]oard(?: of [Dd]irectors)?)\b")),   # 0.4.6: 'rejoined the Board as a director'
    ("V2-CON-ACT", "CONTINUATION", "SUBJ", re.compile(rf"\b{AUX}{CON_V}\b")),
    ("V2-APP-TKO", "APPOINTMENT", "SUBJ", re.compile(r"\b(?:will |shall |is to |would )?(?:take|takes|took|taking) over as\b")),       # Q11: 'will take over as Chair'
    ("V2-DEP-VAC", "DEPARTURE", "OBJ", re.compile(rf"\b(?:position|role|office|post) of (?P<role>{ROLE}) (?:was|has been|will be) vacated by (?:(?:Mr|Ms|Mrs|Dr)\.\s+|{TITLE_PRE})?(?P<obj>{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})+)")),   # Q11 / Q13-G
    ("V2-DEP-END", "DEPARTURE", "OBJ", re.compile(rf"\b(?:conclusion|end) of (?:(?:Mr|Ms|Mrs|Dr)\.\s+|{TITLE_PRE})?(?P<obj>{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})*)['\u2019]s (?:tenure|service|term) as (?P<role>{ROLE})")),   # Q11 / Q13-G
    ("V2-COM-SRV", "APPOINTMENT", "SUBJ", re.compile(rf"\b(?:will|shall|is to|has been appointed to|was appointed to|has been named to)(?: also)? serve (?=(?:on|as (?:a )?member of) (?:the |its |the Company['\u2019]s |the [Bb]oard['\u2019]s )?(?:[A-Z][A-Za-z&]*,? (?:and )?)*?[A-Z][A-Za-z&]* Committees?\b)")),   # Q11: 'will also serve on the Board’s Audit and Finance Committees' (committees only)
    ("V2-DEP-NOM", "DEPARTURE", "OBJ", re.compile(rf"\b(?:resignation|retirement|departure) of (?:(?:Mr|Ms|Mrs|Dr)\.\s+|{TITLE_PRE})?(?P<obj>{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})+|(?<=\. ){TOKEN}\b)")),   # 0.4.5: 'of Ms. Alvarez' / Q13-G
    ("V2-DEP-POSS", "DEPARTURE", "SUBJ", re.compile(r"\bof (?:his|her|their) (?:resignation|retirement|departure)\b(?! of)|\b(?:following|after|upon) (?:his|her|their) (?:resignation|retirement|departure)(?= as )")),   # 0.4.6 (3rd review C03)   # Q11: 'X notified the Company of her resignation as R'
    ("V2-APP-SRV", "APPOINTMENT", "SUBJ", re.compile(rf"\b(?:will|shall|is to|has agreed to|agreed to)(?: also| then| thereafter)? (?:serve|act) as (?=(?:the |its |our |a |an |the Company['\u2019]s )?(?:Class [IVX]+ )?(?:(?:[Ii]nterim|[Aa]cting) )?{ROLE_HEAD})")),   # Q11: 'will serve as interim CFO'
    ("V2-APP-TRN", "APPOINTMENT", "SUBJ", re.compile(rf"\b(?:will |shall |is to )?transition(?:s|ed)? to (?=(?:the (?:role|position) of |serve as |become )?(?:the |its |our |a |an )?(?:(?:[Ii]nterim|[Aa]cting|[Ee]xecutive|[Nn]on-[Ee]xecutive) )?{ROLE_HEAD})")),   # 0.4.4 (review E14): a title must follow   # Q11: 'will transition to the role of Executive Chair'
    ("V2-APP-INF", "APPOINTMENT", "OBJ", re.compile(rf"\bto (?:appoint|name|elect|designate|promote) (?:(?:Mr|Ms|Mrs|Dr)\.\s+|{TITLE_PRE})?(?P<obj>{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})+|(?<=\. ){TOKEN}\b)")),   # 0.4.6: 'to appoint Ms. Harper as COO' / Q13-G
    ("V2-APP-NMN", "APPOINTMENT", "OBJ", re.compile(rf"\bnominated (?:(?:Mr|Ms|Mrs|Dr)\.\s+|{TITLE_PRE})?(?P<obj>{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})+|(?<=\. ){TOKEN}\b)(?= for (?:re-?)?election)")),   # 0.4.6 (3rd review F01): a nomination (always tentative)   # Q11: 'plans to appoint X as R' (tentative from the context) / Q13-G
    ("V2-APP-CAND", "APPOINTMENT", "OBJ", re.compile(rf"\b(?:identified|selected|named|chosen|nominated) (?:(?:Mr|Ms|Mrs|Dr)\.\s+|{TITLE_PRE})?(?P<obj>{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})+) as "   # Q13-G
                                                     rf"(?:its|the Board['\u2019]s|our|a|the) (?:preferred |leading |selected )?(?:candidate|nominee) (?=for (?:the (?:role|position|office) of )?|to (?:become|serve as) )")),   # 0.4.5 (tentative: TENT_STRONG)
    ("V2-COM-JOIN", "APPOINTMENT", "SUBJ", re.compile(rf"\b{AUX}(?:to )?join(?:s|ed|ing)? (?=(?:the |its |the Company['\u2019]s |the [Bb]oard['\u2019]s )?(?:[A-Z][A-Za-z&]*,? (?:and )?)*?[A-Z][A-Za-z&]* Committees?\b)")),   # 0.4.5: 'is expected to join the Board's Risk Committee'
    ("V2-APP-PRO", "APPOINTMENT", "OBJ", re.compile(rf"\b{APP_V} (?P<pro>him|her) (?=to |as )")),     # Q11 0.4.3: 'elected X as a director and appointed him to the Audit Committee'
    ("V2-APP-NOM", "APPOINTMENT", "OBJ", re.compile(rf"\b(?:appointment|election|promotion|transition) of (?:(?:Mr|Ms|Mrs|Dr)\.\s+|{TITLE_PRE})?(?P<obj>{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})+|(?<=\. ){TOKEN}\b)")),   # 0.4.5: 'of Ms. Alvarez', 'the transition of Mr. X to R' / Q13-G
]
DATE_ANY = (r"(?:[A-Z][a-z]+\.? [0-9]{1,2}(?:st|nd|rd|th)?, [0-9]{1,6}(?![0-9])|(?:the )?[0-9]{1,2}(?:st|nd|rd|th)? (?:day of )?[A-Z][a-z]+,? [0-9]{4}(?![0-9])|"
            r"[0-9]{4}-[0-9]{2}-[0-9]{2}|[0-9]{1,2}/[0-9]{1,2}/[0-9]{2,4})")      # 0.4.6 (4th review): ordinals, 'the 30th day of September, 2026', '15 October 2026'
RE_ROLE_AFTER = re.compile(
    rf"^\s*(?:,[^,]{{0,100}}(?:,[^,]{{1,40}})?,\s*)?(?:by the [Bb]oard(?: of [Dd]irectors)?(?: of [^,()]{{1,80}}?(?:,? (?:Inc|Corp|Co|LLC|Ltd)\.?)?(?: \((?:the )?[\"\u201c]Company[\"\u201d]\))?)?(?:,? on {DATE_ANY},?)?\s*)?(?:to the (?:additional |new |expanded |interim )?roles? of (?:both )?)?(?:the (?:Company|Registrant)\s+)?(?:employed (?:by|with) the (?:Company|Registrant)\s+)?(?:with the (?:Company|Registrant) (?:in the role of )?)?(?:(?:to serve )?(?:on |as (?:both )?)|to (?:be|become) (?:both )?|for (?:membership|service|a seat|roles?|positions?) (?:on|in) (?:both )?|for (?:the (?:role|position|office) of )?|(?:roles?|positions?|seats?) (?:on|in) (?:both )?|to join (?:both )?|to (?:serve on )?(?:the (?:position|role|office) of )?|from (?:(?:his|her|their|the) (?:(?:current|former|existing|present) )?(?:positions?|roles?|posts?|offices?|seats?|duties) (?:as |of )?)?|for (?:re-?)?election as (?:a |an |the )?|"
    rf"in (?:the|his|her|their) (?:(?:current|existing|present) )?(?:role|position|capacity) (?:of |as )?|(?:his|her|their) (?:(?:current|existing|present) )?(?:position|role|post|title) as |the (?:role|position|title)s? of |on (?=the [Bb]oard)|of )?"
    rf"{ROLE_PRE}(?P<role>{ROLE}|the [Bb]oard(?: of [Dd]irectors)?|(?<=['\u2019]s )[Bb]oard(?: of [Dd]irectors)?|(?<=the )[Bb]oard(?: of [Dd]irectors)?(?! of (?!the Company|the Registrant)[A-Z]))")   # 0.4.4      # Q11: 'to the Company's Board of Directors'
RE_ROLE_DATE = None                                     # set below, after DATE_ANY
RE_SUCC_AS = re.compile(rf"\b(?:to succeed|will succeed|shall succeed|succeeds|succeeded|succeeding|to replace|will replace|shall replace|replaces|replaced|replacing)\s+(?P<n>(?:(?:Mr|Ms|Mrs|Dr)\.\s+)?{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})*)"
                        rf"(?:,? (?:Jr\.|Sr\.|II|III|IV))?\s+as\s+{ROLE_PRE}(?P<r>{ROLE})")     # 0.4.5
RE_ROLE_MORE = None
RE_ROLE_DATE = re.compile(rf"^,? (?:[Ee]ffective (?:as of |on )?(?P<raw>{DATE_ANY}))")
RE_ROLE_MORE = re.compile(rf"^\s*(?:,? [Ee]ffective (?:as of |on )?{DATE_ANY})?(?:,\s*(?:and )?|\s*\band )(?:as )?{ROLE_PRE}(?P<role>{ROLE})")   # 0.4.6: 'CEO, President and a member of the Board'   # Q10: a role that ends in a space
RE_APPOSITIVE_ROLE = re.compile(rf"^,\s*(?:the |our |its |the Company['\u2019]s |a |currently (?:the |its |our |the Company['\u2019]s )?)?(?P<role>{ROLE})"
                                rf"(?: of (?:the Company|[^,()]{{1,80}}?)(?:,? (?:Inc|Corp|Co|LLC|Ltd|Corporation|Company)\.?)?(?: \((?:the )?[\"“]Company[\"”]\))?)?,\s*$")   # Q11: 'X, CFO of Acme, Inc. (the "Company"), resigned'
RE_EFF = re.compile(rf"\b(?:[Ee]ffective(?: (?:at|as of) [0-9]{{1,2}}:[0-9]{{2}} ?[ap]\.?m\.?(?:,? (?:[A-Z][a-z]+ ){{0,2}}[Tt]ime)?,?(?= on))?|commencing|beginning|starting(?: from)?|with effect from|from(?= {DATE_ANY} (?:through|until|to)\b)|with (?:his|her|their) (?:role|service|term|appointment|tenure) (?:commencing|beginning|starting)|"
                    rf"with an? effective date (?:set )?(?:for|of)|effective date of) (?:as of |on |from )?(?:(?:at |as of )?the close of business on )?(?P<raw>{DATE_ANY})")   # Q11: 'commencing November 3, 2026'
RE_EFF_PARTIAL = re.compile(r"\b[Ee]ffective (?:in |as of |during )?(?P<raw>(?:January|February|March|April|May|June|July|August|September|October|November|December) [0-9]{4})\b")
RE_EFF_NOT_DATE = re.compile(r"\b[Ee]ffective (?:immediately|upon|at the end of|as of the end of|on the date|following|after)\b")
RE_ON = re.compile(rf"\b(?:on|as of) (?P<raw>{DATE_ANY})")
RE_STRICT = re.compile(r"(?P<m>[A-Z][a-z]+\.?) (?P<d>[0-9]{1,2}), (?P<y>[0-9]{4})")
RE_SPLIT = re.compile(r"(?:; |, and |, but |, while |, whereas | and | but | while )")
RE_CLAUSE_START = re.compile(rf"^(?:(?:the|The) [Bb]oard|(?:the|The) Company|(?:he|she|they|He|She|They)\b|(?:Mr|Ms|Mrs|Dr)\. {TOKEN}(?:,| (?:also|will|shall|would|was|were|is|are|has|have|had|may|might|could)\b| {DEP_V}| {CON_V}| {APP_V})|{TOKEN}(?: [A-Z]\.)?(?: {TOKEN})+(?:,| (?:each|both|also|has|have|had|will|shall|would|was|were|is|are|did|does|may|might|could|succeeds|succeeded)\b| {DEP_V}| {CON_V}| {APP_V})|"
                             rf"(?:has|have|had|will|shall|would|was|were|is|are|did|does|may|might|could)\b|{DEP_V}\b|{CON_V}\b|{APP_V}\b|(?:[Ee]ffective)\b)")
RE_PRONOUN = re.compile(r"^(?:he|she|they|He|She|They)\b")
NONFACT = re.compile(r"\b(?:den(?:ied|ies|y)(?: (?:the )?(?:reports?|rumou?rs?|claims?|allegations?|speculation))?(?: that)?|(?:was|were|has been|had been|is being|are being) "
                     r"(?:asked|requested|urged|invited|pressed) to|offered to|rumou?rs?(?: that)?|it is not true that|neither|if|unless|whether|in the event that)\b", re.I)
RE_RUMOUR_REPORT = re.compile(r"\b(?:an?|the|this|that|such|these|those|certain|recent|press|media|news)\s+(?:[a-z-]+\s+){0,3}(?:article|report|story|stories|publication|speculation|rumou?r)s?\b"
                              r"[^.;]{0,200}?\b(?:reporting|stating|claiming|suggesting|alleging|asserting|indicating|that)\b")   # Q12 C10: a report as a NOUN ('a report ... stating that'; not 'to report that', not 'Current Report')
RE_HIST_REL = re.compile(r"(?:,\s*|(?<=[a-z]) )who\b(?P<body>[^,;]*?)(?=,|;|$)")      # 0.4.6 (3rd review C5): also 'the former CEO who retired in 2023' (no comma)
RE_PAST_YEAR = re.compile(r"\b(?:in|since|until|from|during) (?:19|20)[0-9]{2}\b")
REPORTING = re.compile(r"\b(?:announced|disclosed|reported|said|stated|confirmed|notified|informed|advised|told|approved|determined|agreed|decided|resolved)\b", re.I)
RELATION_APPOSITIVE = re.compile(r"^\s*,\s*(?:his|her|their|the)\s+(?:spouse|wife|husband|son|daughter|brother|sister|father|mother|relative|partner|sibling)\b")
RE_HISTORICAL = re.compile(r"\b(?:previously|formerly|most recently) (?:served|held|was|acted)|\bhad (?:previously )?served\b|\bserved (?:previously|formerly)\b", re.I)
RE_ROUTINE = re.compile(r"\b(?:at|during)\s+(?:the|its|our|this|this year['\u2019]s)\s+(?:[0-9]{4}\s+)?annual\s+meeting\b|\bre-elected\b", re.I)   # Q10: not 'until the next annual meeting'
MGMT_WORDS = re.compile(rf"\b(?:{ROLE}|resign|retire|appoint|serve|serving|role|position|board|officer|step|depart|leave|left|succe|elect|name|remain|continu|transition)", re.I)


TITLE_LEAD = {"Emeritus", "Honorable", "Hon", "Senator", "Judge", "Justice", "Professor", "Prof", "Ambassador", "Governor", "Admiral", "Reverend", "Rev", "Sir", "Dame"}   # Q13-G
RE_HON = re.compile(rf"\b(?P<h>(?:Mr|Ms|Mrs|Dr)\.)\s+(?P<s>(?:{PARTICLE} )*{TOKEN})\b(?!\s+[A-Z][a-z])")   # Q12 C10: 'Judge Abara'      # 0.4.6: 'Mr. van der Berg'     # Q11: O’Brien, McDonald
RE_SUFFIX = re.compile(r"(?:,)?\s(?:Jr\.|Sr\.|II|III|IV)(?![A-Za-z])")     # (a degree such as M.D. or Ph.D. is not part of the name)


def surname(full: str) -> str:
    """the family name of a full name: the last word that is not a suffix (Jr., Sr., II, III, IV)"""
    toks = [t for t in re.split(r"[\s,]+", str(full or "")) if t]
    while len(toks) > 1 and toks[-1].rstrip(".") in ("Jr", "Sr", "II", "III", "IV"):
        toks.pop()
    if not toks:
        return ""
    k = len(toks) - 1
    while k > 1 and re.fullmatch(PARTICLE, toks[k - 1]):         # 0.4.6: 'van der Berg' is the family name of 'Pieter van der Berg'
        k -= 1
    return " ".join(toks[k:])
RE_HON_ONLY = re.compile(r"^(?:(?:Mr|Ms|Mrs|Dr)\.|Judge|Justice|Senator|Professor|Ambassador|Governor|Admiral) ")   # Q12 C10: 'Judge Abara' is a short form, not a full name
_KNOWN: list = []          # full names already named in the current section; set by analyse_sentence for the duration of one call (single-threaded)
_CUES: dict = {}           # text gender evidence of those names (same lifetime)
_ORGS: list = []           # 0.4.4: organisation names / short names the document defines (same lifetime)
HON_GENDER = {"Mr": "M", "Ms": "F", "Mrs": "F"}


def names(text: str) -> list:
    """(start, end, name) of every personal-name candidate: runs of capitalised tokens, split at non-name words, two tokens or more; and an honorific
    short form ('Mr. Ortiz'), mapped to the one full name with that surname already named in the section, else kept as 'Mr. Ortiz' (unresolved)"""
    out = []
    for m in RE_CAPSEQ.finditer(text):
        toks, pos = [], m.start()
        for t in re.finditer(r"[A-Z]\.|" + TOKEN, m.group(0)):
            toks.append((m.start() + t.start(), m.start() + t.end(), t.group(0)))
        run = []
        for i_, t in enumerate(toks + [(None, None, None)]):
            nxt_ = toks[i_ + 1] if i_ + 1 < len(toks) else None
            month_name = t[2] in MONTHS and not run and nxt_ is not None and nxt_[0] == t[1] + 1 and nxt_[2] not in STOP and not re.fullmatch(r"[A-Z]\.", nxt_[2]) \
                and not re.search(r"\b(?:[Ii]n|[Dd]uring|[Ss]ince|[Uu]ntil|[Bb]y|[Oo]f|[Ff]rom|[Tt]hrough|[Bb]efore|[Aa]fter|[Ee]arly|[Ll]ate|[Mm]id-?|[Ll]ast|[Nn]ext|[Tt]his)\s*$", text[max(0, t[0] - 12):t[0]])
            if (t[2] is None or t[2] in STOP or t[2].rstrip("'s") in STOP) and not month_name:      # 0.4.6: 'June Ortiz' - a month word that starts a name
                while run and run[0][2].rstrip(".") in TITLE_LEAD and len([x for x in run[1:] if not re.fullmatch(r"[A-Z]\.", x[2])]) >= 2:
                    run = run[1:]                             # Q13-G: 'the Honorable Marguerite Abara', 'Senator Harold Bright' - the title is not part of the name
                if len([x for x in run if not re.fullmatch(r"[A-Z]\.", x[2])]) >= 2:
                    out.append((run[0][0], run[-1][1], text[run[0][0]:run[-1][1]]))
                run = []
            else:
                run.append(t)
        del pos
    out = [(a, b, nm) for a, b, nm in out if not _organisation(text, a, b, nm)]    # Q11: 'Varden Cold Storage, Inc.' is a company, not a person
    for nk in re.finditer(rf"(?P<g>{TOKEN}(?: {TOKEN})*) [\"\u201c](?P<n>{TOKEN})[\"\u201d] (?P<s>{TOKEN}(?:(?: {PARTICLE})* {TOKEN})*)", text):   # 0.4.6 (4th review H09)
        if nk.group("g").split()[-1] in STOP or nk.group("s").split()[0] in STOP:
            continue
        out = [x for x in out if not (x[0] < nk.end() and nk.start() < x[1])] + [(nk.start(), nk.end(), f"{nk.group('g')} {nk.group('s')}")]   # 'Mary Elizabeth "Beth" Calloway'
    ext = []
    for a, b, nm in out:                                    # Q11: a suffix belongs to the name ('Colin Delgado III', 'Ann Lee, Jr.')
        if nm.split()[-1] in ("Jr", "Sr") and text[b:b + 1] == ".":
            b += 1
        else:
            sm = RE_SUFFIX.match(text[b:])
            if sm:
                b += sm.end()
        ext.append((a, b, text[a:b]))
    out = ext
    for m in RE_HON.finditer(text):
        if any(a < m.end() and m.start() < b for a, b, _ in out):
            continue
        g = HON_GENDER.get(m.group("h").rstrip("."))
        earlier = [nm for a, b, nm in out if b <= m.start()]                     # Q11: a full name written earlier in the same sentence
        full = list(dict.fromkeys(k for k in list(_KNOWN) + earlier if surname(k) == m.group("s") and not (g and _CUES.get(k) not in (None, g))))   # Q5: never against text evidence
        related = bool(RELATION_APPOSITIVE.match(text[m.end():]))          # Q5: 'Mrs. Kane, his spouse, ...' is another person
        out.append((m.start(), m.end(), full[0] if len(full) == 1 and not related else f"{m.group('h')} {m.group('s')}"))
    return sorted(out)


ORG_SUFFIX = re.compile(r"^(?:,?\s*(?:Inc|Incorporated|Corp|Corporation|Co|Company|LLC|L\.L\.C|Ltd|Limited|plc|PLC|N\.A|L\.P|LP|S\.A|AG|N\.V|Bancorp|Bancshares|"
                        r"Holdings|Group|Trust|Partners|Fund)\b\.?(?![-\u2013\w])(?!\s+(?:CEO|CFO|COO|CTO|Chief|President|Vice|Treasurer|Secretary|Controller|General|Head|Executive|Managing|Senior|Director)\b)|\s*\((?:the |collectively, the )?[\"“](?:Company|Registrant|Corporation|Bank)[\"”]\)|['’]s\s+(?:Board|subsidiary|parent))")
ORG_WORDS = {"Systems", "Technologies", "Technology", "Industries", "Industrial", "Holdings", "Group", "Partners", "Bank", "Bancorp", "Foods", "Logistics", "Instruments",
             "Networks", "Payments", "Insurance", "Health", "Healthcare", "Pharmaceuticals", "Therapeutics", "Energy", "Capital", "Financial", "Mills", "Products",
             "Aerospace", "Utilities", "Beverages", "Hospitality", "Marine", "Freight", "Storage", "Chemicals", "Devices", "Medical", "Grain", "Supply", "Castings",
             "Alloy", "Works", "Equipment", "Motors", "Labs", "Laboratories", "Solutions", "Services", "Software", "Brands", "Textiles", "Textile", "Paper", "Mutual",
             "Insurers", "Airlines", "Railroad", "Properties", "Realty", "Resources", "Minerals", "Mining", "Steel", "Metals", "Plastics", "Ceramics", "Precision",
             "Specialty", "Manufacturing", "Distribution", "Retail", "Stores", "Restaurants", "Media", "Communications", "Entertainment", "Semiconductor", "Electronics"}


def _organisation(text: str, a: int, b: int, nm: str) -> bool:
    """a capitalised run that names a company: followed by a legal form or a '(the "Company")' definition, or ending in a typical company word"""
    if ORG_SUFFIX.match(text[b:]):
        return True
    if re.match(r"^\s+(?:[A-Z][\w&\u2019'.-]*\s+){0,3}(?:Inc|Incorporated|Corp|Corporation|Co|Company|LLC|Ltd|Limited|plc|PLC|Holdings|Group|Bancorp)\b(?![-\u2013])", text[b:]):
        return True                                         # 0.4.4: 'Marrowgate Industrial Supply Co.' - the run continues into a legal form
    if re.match(r"^\s*(?:,\s*(?:[0-9]{1,3},|a director|our |its |the Company['\u2019]s |who\b)|(?:was|were|has been|had been|will be|is|is being) (?:appointed|named|elected|promoted|designated)\b|"
                r"(?:has |had )?(?:resigned|retired|stepped|will (?:resign|retire|step|serve|become|join|continue|remain)))", text[b:]):
        return False                                        # 0.4.5 (2nd review N8): the run is the subject of a personnel predicate - a person
    if any(nm == o or (len(o.split()) > 1 and nm.startswith(o + " ")) for o in _ORGS):
        return True                                         # 0.4.5: a defined organisation; a one-word short name only as the whole name ('Harper' is not 'Harper Lee')
    toks = nm.split()                                       # 0.4.4 (review E13): a company word alone marks a company only in a run of three words or more ('Karen Mills' is a person)
    return (len(toks) >= 3 and toks[-1] in ORG_WORDS) or (len(toks) >= 2 and toks[-2] in ORG_WORDS and toks[-1] in ("Corp", "Inc", "Co"))


RE_DMY = re.compile(r"(?:the )?(?P<d>[0-9]{1,2})(?:st|nd|rd|th)? (?:day of )?(?P<m>[A-Z][a-z]+\.?),? (?P<y>[0-9]{4})")
RE_ISO_D = re.compile(r"(?P<y>[0-9]{4})-(?P<mo>[0-9]{2})-(?P<d>[0-9]{2})")
RE_MDY_NUM = re.compile(r"(?P<mo>[0-9]{1,2})/(?P<d>[0-9]{1,2})/(?P<y>[0-9]{4})")      # US order, four-digit year only (a two-digit year is not guessed)


def parse_date(raw: str) -> dict:
    """VALID / INVALID / UNREADABLE (never guessed, never substituted). 0.4.6 (4th review): also 'October 5th, 2026', '15 October 2026', 'the 30th day
    of September, 2026', '2026-10-05', '10/5/2026' (US order; '10/5/26' stays UNREADABLE)"""
    raw = str(raw)
    num = RE_ISO_D.fullmatch(raw) or RE_MDY_NUM.fullmatch(raw)
    if num:
        y, mo, d = int(num.group("y")), int(num.group("mo")), int(num.group("d"))
        if not 1900 <= y <= 2100:
            return {"state": "INVALID", "value": None, "raw": raw}
        try:
            return {"state": "VALID", "value": date(y, mo, d).isoformat(), "raw": raw}
        except ValueError:
            return {"state": "INVALID", "value": None, "raw": raw}
    s = RE_STRICT.fullmatch(re.sub(r"(?<=[0-9])(?:st|nd|rd|th)(?=,)", "", raw)) or RE_DMY.fullmatch(raw)
    if not s:
        return {"state": "UNREADABLE", "value": None, "raw": raw}
    mo = MONTHS.get(s.group("m")) or MONTH_ABBR.get(s.group("m"))
    if mo is None:
        return {"state": "UNREADABLE", "value": None, "raw": raw}
    y, d = int(s.group("y")), int(s.group("d"))
    if not 1900 <= y <= 2100:
        return {"state": "INVALID", "value": None, "raw": raw}
    try:
        return {"state": "VALID", "value": date(y, mo, d).isoformat(), "raw": raw}
    except ValueError:
        return {"state": "INVALID", "value": None, "raw": raw}


def _has_pred(t: str) -> bool:
    return any(rx.search(t) for _, _, _, rx in PREDICATES)


CO_VP = r"(?:transition(?:s|ed)? to|serve[sd]? as|step(?:s|ped)? down|remain(?:s|ed)?\b|continue[sd]? to serve|retire[sd]?\b|resign(?:s|ed)?\b|join(?:s|ed)?\b)"   # 0.4.6: a coordinated predicate of the same subject ('... and transition to R2')


def split_clauses(sent: str) -> list:
    """(start, end) of each clause. A boundary splits only when the left part already holds a predicate, and: it is a semicolon; or the right part
    starts a new clause - a person's name, 'the Board' / 'the Company', a pronoun, an auxiliary or a predicate - AND holds its own predicate.
    Coordinated names and coordinated roles are never split (their right part has no predicate of its own or does not start a clause)"""
    cuts, last = [0], 0
    for m in RE_SPLIT.finditer(sent):
        left, right = sent[last:m.start()], sent[m.end():]
        if not _has_pred(left) and m.group(0) != "; ":         # 0.4.5: a semicolon separates clauses even when the left part has no predicate of ours
            continue
        ok = m.group(0) == "; " and _has_pred(right[:200])
        if not ok and _has_pred(right[:160]):
            st = RE_CLAUSE_START.match(right) or re.match(rf"(?:{APP_V}|succeed(?:s|ed)?|assume[ds]?|become[s]?|became|{CO_VP})\b", right)
            if st and re.match(TOKEN, right) and not re.match(r"(?:[Tt]he|He|She|They|Effective)\b", right):
                nn = names(right[:120])
                st = st if (nn and nn[0][0] == 0) or re.match(rf"(?:{APP_V}|succeed(?:s|ed)?|assume[ds]?|become[s]?|became)\b", right) else None
            ok = bool(st)
        if ok:
            cuts.append(m.end())
            last = m.end()
    spans = []
    for i, a in enumerate(cuts):
        b = cuts[i + 1] if i + 1 < len(cuts) else len(sent)
        e = b
        if i + 1 < len(cuts):                                   # trim the connector from the end of the left clause
            mm = list(RE_SPLIT.finditer(sent, a, b))
            e = mm[-1].start() if mm else b
        spans.append((a, e))
    return spans


RE_LEGAL_COMMA = re.compile(r",(?=\s+(?:Inc|Incorporated|Corp|Corporation|Co(?!\s*[-\u2010\u2011\u2012\u2013\u2014])|LLC|L\.L\.C|Ltd|Limited|plc|PLC|N\.A|L\.P|LP|LLP)\b\.?)")   # Q13-A (C13: any dash) 'Co-Chair' is a title, not the legal form 'Co'
RE_ORG_TAIL = re.compile(r"(?:\s+(?:[A-Z][\w&\u2019'.-]*|&|and|of))*?\s*,?\s*(?:Inc|Incorporated|Corp|Corporation|Co(?!\s*[-\u2010\u2011\u2012\u2013\u2014])|LLC|L\.L\.C|Ltd|Limited|plc|PLC|N\.A|L\.P|LP|LLP)\b|(?:\s+(?:[A-Z][\w&\u2019'.-]*|&|and|of))*?\s*\((?:the |collectively, the )?[\"\u201c](?:Company|Registrant|Corporation|Bank|Trust|Partnership)[\"\u201d]\)")   # Q13-A (C13: any dash) 'Co-Chair' is a title, not the legal form 'Co'
TP_NOUN = (r"(?:(?:[Mm]edia|[Nn]ews|[Pp]ress) (?:outlets?|organi[sz]ations?|reports?|accounts?|coverage)|[Nn]ewspapers?|[Jj]ournalists?|[Rr]eporters?|[Cc]ommentators?|"
           r"(?:[Ss]ome |[Cc]ertain |[Ss]everal )?(?:[Ii]ndustry |[Ss]ell-side |[Ee]quity )?[Aa]nalysts?(?: notes?| reports?)?|(?:an?|the) (?:[a-z-]+ )?(?:analyst|research) (?:note|report)|"
           r"(?:[Aa]|[Tt]he|[Cc]ertain) (?:[a-z-]+ )?(?:publication|news outlet|media outlet|blog|newsletter|trade journal))")
TP_LEAD = rf"^\s*(?:On {DATE_ANY},\s*)?"   # Q13-I (C14): the third party opens the sentence (after an optional date)
RE_THIRD_PARTY = re.compile(rf"{TP_LEAD}(?:(?:[Ss]everal|[Ss]ome|[Cc]ertain|[Mm]any|[Aa] number of|[Tt]wo|[Tt]hree|[Aa]n?|[Tt]he) )?(?P<tp>{TP_NOUN})"   # Q13-I (C14, C13 adversarial review: anchored)
                            rf"(?:\s+(?:published|issued|released|dated|circulated|written)(?:\s+(?:on|in|by|last|earlier|this)\s+(?:{DATE_ANY}|[^,;.]{{1,30}}?))?,?)?"
                            rf"(?:\s+(?:have|has|had|also|recently|reportedly|previously|widely))*\s+"
                            rf"(?:reported|said|stated|claimed|suggested|speculated|wrote|indicated|alleged|asserted)(?:,\s+[^,;]{{1,60}},)?(?:\s+(?:on|in|last|earlier|this)\s+(?:{DATE_ANY}|[^,;.]{{1,30}}?),?)?\s+that\b|"
                            rf"{TP_LEAD}[Aa]ccording to (?:(?:a|an|the|certain|recent|several|some|press|media|news|unnamed|anonymous|newspaper|industry|trade|unconfirmed|published) )*(?:[A-Z][\w&.'-]* ){{0,4}}"
                            r"(?:report|reports|article|articles|story|stories|publication|sources?|people familiar|analysts?|commentators?)\b")   # Q13-I (C14)
RE_ISSUER_CLAUSE = re.compile(rf";|,?\s+(?:and|but|while|whereas)\s+(?:on (?:{DATE_ANY}|[^,;]{{1,30}}),?\s+)?(?:the Company|the Board|the Registrant|we)\b")   # Q13-I (C14): where the issuer speaks again
RE_TP_OWN = re.compile(r"\b(?:Company|Registrant|Corporation|Board|management|filed|filing|Form 8-K|SEC|Securities and Exchange Commission|its|our|we)\b")   # Q13-I (C14)
RE_COND_WORD = re.compile(r"(?:upon (?:the )?(?:closing|completion|consummation) of|subject to\b|conditioned (?:up)?on|contingent (?:up)?on|conditional (?:up)?on|if the (?:merger|transaction|acquisition) (?:closes|is completed))", re.I)
RE_EXCLUDED = re.compile(r"\b(?:other than|except(?: for)?|excluding|with the exception of|apart from)\s+(?:(?:the |our |its )?(?:[A-Z][\w.'\u2019-]*|of|and|the|Company['\u2019]s)\s+){0,8}$")
RE_ADJ_RETIRED = re.compile(r"\b(?:a|an|the|as a|as an)\s+(?:[a-z]+\s+)?$")


RE_ORG_ANNOUNCES = re.compile(r"(?P<org>(?:[A-Z][\w&'.\u2019-]*,?\s+){1,5}?(?:Inc|Incorporated|Corp|Corporation|Co|LLC|Ltd|Limited|plc|PLC|Holdings|Group|Partners|L\.P|LP)\.?)"
                              r"(?P<def>\s*\((?:the |collectively, the )?[\"\u201c][^)]{1,40}[\"\u201d]\))?,?\s+(?:announced|disclosed|reported|said|stated|confirmed)\s+that\s+(?:it|they)\b")


def _third_party(sent: str, issuers=()):
    """Q13-I (C14, C13 adversarial review): a third party's claim only when the sentence OPENS with the third party as the subject of the reporting
    verb ('Media outlets reported that ...'), or with 'According to <a report / article / sources>' that is not the issuer's own filing or report"""
    m = RE_THIRD_PARTY.match(sent)
    if m is None:
        return None
    if m.group("tp") is None:                                        # Q13-I: 'According to ...' - whose report?
        k_ = sent.find(",", m.end())
        phrase_ = sent[m.start():k_ if k_ >= 0 else len(sent)]
        if RE_TP_OWN.search(phrase_) or any(_core(x).split()[:1] and _core(x).split()[0] in _core(phrase_).split() for x in issuers if x):
            return None                                              # Q13-I: 'According to the report the Company filed', 'According to Fastenal's report'
    return m


ORG_EXTRA_OK = {"holdings", "holding", "group", "company", "companies", "corporation", "incorporated", "inc", "co", "the"}   # Q13-I (C13)


def _same_org(org: str, x: str) -> bool:
    """Q13-I (C13, re-review R-5): the issuer under another legal form ('Fastenal Holdings, Inc.' = 'Fastenal Company'): equal cores, or one core a
    prefix of the other with only holding / legal words added - never a shared first word alone ('First Solar' is not 'First Harbor')"""
    a, b = _core(org).split(), _core(x).split()
    if not a or not b:
        return False
    if a == b:
        return True
    s_, l_ = (a, b) if len(a) < len(b) else (b, a)
    return l_[:len(s_)] == s_ and set(l_[len(s_):]) <= ORG_EXTRA_OK


def _other_company_announcement(sent: str, issuers: list):
    """Q13-I: '<another company>, Inc. announced that it had appointed X ... as its CEO' - that company's event, not the issuer's (the issuer
    itself, named with its legal form, defined as '(the "Company")' or matching an issuer name, is not 'another company')"""
    m = RE_ORG_ANNOUNCES.search(sent)
    if not m or m.group("def"):
        return None
    org = m.group("org").strip(" ,")
    if any(_same_org(org, x) for x in issuers if x):     # Q13-I (C13, re-review R-5): the issuer under another legal form, not a shared first word
        return None
    own_ = RE_ISSUER_CLAUSE.split(sent[m.end():], maxsplit=1)[0]   # Q13-I (C14): that company's own clause
    if not re.search(r"\b(?:as its|its new|to its|its (?:Chief|President|Chair))\b", own_):
        return None                                   # Q13 C12: only when the role is that company's own ('as its Chief Executive Officer')
    return m


def _cond_phrase(sent: str, trigger: str) -> str:
    """Q13-E: the condition as written - the trigger and what follows it, up to the end of its phrase (about 90 characters at most)"""
    k = sent.lower().find(trigger.lower().strip())
    if k < 0:
        return re.sub(r"\s+", " ", trigger).strip()
    tail = re.split(r"[.;]|,\s+(?:the|its|our)\s+(?:Board|Company)\b", sent[k:])[0]
    tail = re.sub(r"\s+", " ", re.sub(r"\((?:the |a |an )?[\"\u201c][^)]{0,40}[\"\u201d]\)", "", tail)).strip(" ,")
    return tail if len(tail) <= 90 else tail[:90].rsplit(" ", 1)[0] + " ..."


def _subject(clause: str, pstart: int, cs: int = 0) -> dict | None:
    """the person(s) who are the grammatical subject of the predicate starting at pstart (Q5 subject scope). Spans are absolute (cs = the clause's
    offset in the sentence). A possessive name is never a subject; names inside a comma parenthetical right before the predicate are not the subject
    ('X, after consulting Y, resigned'; 'X, Y's predecessor, resigned'; 'X, who ..., was appointed'); a name followed by a complement or a reporting
    verb ('X told Y that he ...', 'X informed Y that she will ...') is not the subject of the embedded predicate; a group of names is coordinated only
    when it is joined by 'and'. Anything that cannot be resolved returns None (abstention, never a guess)"""
    ns = [n for n in names(clause) if n[1] <= pstart and not re.match(r"['\u2019]s\b", clause[n[1]:])]
    if not ns:
        return None
    pre = clause[:pstart]
    parenthetical = False
    pre_ = RE_LEGAL_COMMA.sub(" ", pre)                   # Q13-A: the comma before a legal form ('Products, Inc.') does not end the appositive
    par = re.search(r",(?P<par>[^,]{1,160}),\s*$", pre_)
    if par:
        head = [n for n in ns if n[1] <= par.start()]
        if head and re.fullmatch(r"\s*", pre[head[-1][1]:par.start()]):
            ns, parenthetical = head, True
    group = [ns[-1]]
    joins = []
    k = len(ns) - 2
    while k >= 0 and re.fullmatch(r"(?:,|, and| and|,and)\s*", clause[ns[k][1]:group[0][0]]):
        joins.insert(0, clause[ns[k][1]:group[0][0]])
        group.insert(0, ns[k])
        k -= 1
    if len(group) > 1 and not any("and" in j for j in joins):       # 'X, Y resigned' (no 'and'): apposition or an unclear list - not resolved
        return None
    gap = pre[group[-1][1]:]
    rel_who = re.match(r"^\s*,\s*who\b", gap)
    if not parenthetical:
        if len(gap) > 160 or (not rel_who and (any(rx.search(gap) for _, _, _, rx in PREDICATES) or re.search(rf"\b{APP_V}\b", gap))):
            return None
        if not rel_who and (re.search(r"\bthat\b", gap, re.I) or re.search(r"\b(?:he|she|they)\b", gap, re.I)):
            return None                                     # a finite complement ('... that he will ...') or a new subject pronoun sits between: not this subject
    before = clause[:group[0][0]]
    if re.search(rf"\b(?:{APP_V}|succeed(?:s|ed)?|replac(?:e|es|ed)|by|with|to|from|of|than|for|and|after|before|alongside|including|joined by|thanked|told|informed|"
                 rf"advised|notified|congratulated|[a-z]+ing)\s*$", before) and not parenthetical and not rel_who:
        return None                                         # the name is an object or sits in a prepositional / participial phrase
    if parenthetical:
        kind = "SUBJECT" if len(group) == 1 else "COORDINATED"
    elif rel_who:
        kind = "RELATIVE"                                   # the predicate is inside the relative clause: its antecedent is its subject
    else:
        kind = "COORDINATED" if len(group) > 1 else "SUBJECT"
    return {"persons": [g[2] for g in group], "kind": kind, "spans": [[cs + g[0], cs + g[1]] for g in group]}


RE_FROM_TO = None


RE_ISSUER_DEF = re.compile(r"[^;()]{0,90}?\((?:the |collectively, the )?[\"\u201c](?:Company|Registrant|Corporation|Bank|Trust|Partnership)[\"\u201d]\)")


def _other_company(sent: str, k: int, issuers=()) -> bool:
    return _other_company_basis(sent, k, issuers) is not None


def _other_company_basis(sent: str, k: int, issuers=()) -> str | None:
    """0.4.6: why the role is at another organisation (SUBSIDIARY / DEFINED_ORG / DESCRIBED / LEGAL_FORM), or None. Text of 0.4.4: a role written as 'ROLE of / at <an organisation>' where the organisation is not the issuer. 0.4.4 (review E10): the words after 'of' must
    look like an organisation (a legal form, a company word ending a run of names) - 'President of International Operations' is a title; the issuer
    is 'the Company / Registrant / Trust', its pronoun, a name the sentence defines as '(the "Company")', or a name the DOCUMENT defines so"""
    if k > 0 and sent[k - 1] == " ":                       # 0.4.6: a title read with its trailing space ('Vice President, Finance ')
        k -= 1
    if re.match(r"\s*,?\s+of (?:the Company['\u2019]s|its|our) (?:[\w-]+ ){0,3}(?:subsidiary|subsidiaries|affiliate|joint venture)\b", sent[k:]):     # 0.4.6: a division / segment is part of the issuer (W2-036)
        return "SUBSIDIARY"                                 # 0.4.5 (2nd review N1): a role at a subsidiary is not the issuer's officer role
    m = re.match(r"\s*,?\s+(?:of (?:[Dd]irectors|[Tt]rustees|[Mm]anagers)\s+)?(?:of|at|with) (?!the Company\b|the Registrant\b|the Trust\b|the Bank\b|the Corporation\b|its\b|our\b|the [Bb]oard\b)(?:the )?"
                 r"(?P<org>[A-Z][\w&\u2019'.-]*(?:,? (?:[A-Z][\w&\u2019'.-]*|&|and|of)){0,6})", sent[k:])
    if not m:
        return None
    org = m.group("org").rstrip(",. ")
    if any(_core(org) == _core(x) or _n_org(org).startswith(_n_org(x)) or _n_org(x).startswith(_n_org(org)) for x in issuers if x):
        return None
    if any(org == o or org.startswith(o + " ") for o in _ORGS):
        return "DEFINED_ORG"                                # 0.4.4: another organisation the document defines ('... Chair of the Board of Lumencoat')
    if RE_ISSUER_DEF.match(sent[k + m.start():]):
        return None
    after_ = sent[k + m.end():]
    if re.match(r"\s*,\s*a (?![a-z ]*business unit)(?:[\w-]+ ){0,5}(?:company|corporation|firm|bank|organization|entity|insurer|partnership)\b", after_):
        return "DESCRIBED"                                  # 0.4.5 (2nd review N9): 'CEO of Fenwick, a privately held logistics company'
    return "LEGAL_FORM" if re.search(r"\b(?:Inc|Incorporated|Corp|Corporation|Co|LLC|Ltd|Limited|plc|PLC|N\.A|L\.P|LP|AG|Bancorp|Bancshares)\b", org) else None   # 0.4.5: a legal form (a company word alone is a business unit)


_LEGAL = r"(?:inc|incorporated|corp|corporation|co|company|ltd|limited|llc|plc|lp|l p|n a|ag)"


def _core(x: str) -> str:
    """0.4.6: an organisation name without punctuation, case and a trailing legal form ('FASTENAL CO' = 'Fastenal Company')"""
    y = re.sub(r"[^a-z0-9]+", " ", str(x).casefold()).strip()
    return re.sub(rf"(?:\s+{_LEGAL})+$", "", y).strip()


def _n_org(x: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(x).casefold()).replace(" inc", "").replace(" corp", "").replace(" co ", " ").strip()


def _held_in(app: str, issuers=()) -> list:
    """0.4.4 (review E3 / E4): the titles an appositive says the person HOLDS at this issuer now - not a former title ('formerly', 'previously',
    'from 2015 to 2019'), not a title at another company; 'our CFO', 'the current CFO', 'who has served as President since 2019' are held"""
    a = re.sub(r"^\s*(?:currently |now |presently |who is (?:currently |presently )?|who currently serves as |who (?:has|have) (?:been|served as) |the current |our current )", "", app)
    if re.search(r"\b(?:formerly|former|previously|most recently|prior|until|had been|had served|served as|from (?:19|20)[0-9]{2})\b", app) and not re.search(r"\bhas served as\b", app):
        return []
    if not re.match(rf"^\s*{ROLE_PRE}{ROLE}", a):
        return []
    out = []
    for x in re.finditer(rf"\b{ROLE}\b", a):
        pre_ = a[:x.start()]
        if re.search(r"[A-Z][\w.&-]*['\u2019]s\s*$", pre_) and not re.search(r"\b(?:Company|Registrant|Trust|Bank)['\u2019]s\s*$", pre_):
            continue                                          # 0.4.5 (2nd review N7): 'Corvane Corp.'s Chief Financial Officer' is another employer's title
        if re.match(r"\s*,?\s+(?:of|at|with) (?!the Company\b|the Registrant\b|the Trust\b|the Bank\b|its\b|our\b)(?:the )?[A-Z]", a[x.end():]):
            continue                                          # 0.4.5: 'Chief Financial Officer of Corvane' / 'of Lumencoat' - another employer, with or without a legal form
        if not _other_company(a, x.end(), issuers):
            out.append(norm_role(x.group(0)))
    return out


def _roles(after: str) -> tuple[list, int]:
    """[(role, own date raw or None)], end - coordinated roles, each with the effective date written right after it (if any)"""
    global RE_FROM_TO
    if RE_FROM_TO is None:
        RE_FROM_TO = re.compile(rf"^\s*from (?:the (?:role|position) of )?{ROLE_PRE}{ROLE}(?:,? [A-Z][A-Za-z&]+(?: [A-Z][A-Za-z&]+)*)? to (?:the (?:role|position) of )?{ROLE_PRE}(?P<role>{ROLE})")
    suc = re.match(rf"^\s*(?:,[^;]{{0,100}}?,\s*)?to succeed (?:(?:Mr|Ms|Mrs|Dr)\.\s+)?{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})*(?:,? (?:Jr\.|Sr\.|II|III|IV))? as {ROLE_PRE}(?P<role>{ROLE})", after)
    if suc:                                                  # Q11: 'appointed X, its SVP, Supply Chain, to succeed Y as Chief Operating Officer'
        dm = RE_ROLE_DATE.match(after[suc.end():])
        return [(suc.group("role").strip(), dm.group("raw") if dm else None)], suc.end()
    vac = re.match(r"^\s*to fill (?:the |a )(?:resulting |newly created |new )?vacanc(?:y|ies)(?: on the [Bb]oard(?: of [Dd]irectors)?)?", after)
    if vac:                                                  # Q11: 'elected X to fill the resulting vacancy' (on the Board) - a director
        dm = RE_ROLE_DATE.match(after[vac.end():])
        return [("director", dm.group("raw") if dm else None)], vac.end()
    ft = RE_FROM_TO.match(after)                             # Q11: 'promoted X from Vice President, Investor Relations to Treasurer' - the new title
    if ft:
        dm = RE_ROLE_DATE.match(after[ft.end():])
        return [(ft.group("role").strip(), dm.group("raw") if dm else None)], ft.end()
    m = RE_ROLE_AFTER.match(after)
    if not m:
        return [], 0
    end = m.end()
    out = []
    role = m.group("role")
    while True:
        dm = RE_ROLE_DATE.match(after[end:])
        out.append((role.strip(), dm.group("raw") if dm else None))
        mm = RE_ROLE_MORE.match(after[end:])
        if not mm:
            break
        role = mm.group("role")
        end += mm.end()
    if len(out) > 1 and out[-1][1] and not any(d for _, d in out[:-1]):     # a date written only after the last coordinated role governs them all
        out = [(r, out[-1][1]) for r, _ in out]
    return out, end


def norm_role(r: str | None, verb_text: str = "") -> str | None:
    if r is None:
        return None
    if re.fullmatch(r"(?:the )?[Bb]oard(?: of [Dd]irectors)?|member of the [Bb]oard(?: of [Dd]irectors)?|[Bb]oard member|(?:[Ii]ndependent )?[Dd]irector", r):
        return "Director"
    if re.fullmatch(r"(?:(?:a )?member of )?(?:the )?[Bb]oard of [Tt]rustees|[Tt]rustee", r):          # Q11: a trust's board
        return "Trustee"
    m = re.fullmatch(r"(?:(?:a )?member of |(?P<chair>(?:the )?[Cc]hair(?:man|woman|person)? of ))?(?:the )?(?P<c>.+? Committee)(?: of the [Bb]oard)?", r)
    if m:                                                   # Q10: a Board committee is a committee role, never a management role
        return ("Chair of the " if m.group("chair") else "Member of the ") + m.group("c")
    return {"CEO": "Chief Executive Officer", "CFO": "Chief Financial Officer", "COO": "Chief Operating Officer"}.get(r, r)


def _clause_date(sent: str, cs: int, ce: int, pend: int, shared: dict | None, wstart: int | None = None, wend: int | None = None,
                 anchor: int | None = None) -> dict:
    """the clause's own effective date: 'effective [as of | on] DATE' inside the clause (EFFECTIVE_EXPLICIT); else 'on DATE' right after the predicate
    or its role phrase (Q5: adjacency - only white space or a comma between; ON_ADJACENT); else a shared date that explicitly governs this clause;
    two different own dates make ownership ambiguous (NOT_STATED + DATE_OWNERSHIP_AMBIGUOUS)"""
    each_ = re.search(rf"\b(?:each|both|in each case)(?:,)? effective (?:as of |on )?(?P<raw>{DATE_ANY})", sent[cs:ce])
    if each_ and wstart is not None:                        # 0.4.5: '... appointment of X as R1 and the transition of Y to R2, each effective D' - one date for all
        d_ = parse_date(each_.group("raw"))
        return {**d_, "span": [cs + each_.start(), cs + each_.end()], "basis": "EFFECTIVE_EXPLICIT"}
    if wstart is not None:                                  # several predicates in one clause: each owns only the text from itself to the next one
        cs, ce = wstart, wend
    clause = sent[cs:ce]
    eff = list(RE_EFF.finditer(clause))
    if len({m.group("raw") for m in eff}) > 1:
        return {"state": "NOT_STATED", "value": None, "raw": None, "span": None, "note": "DATE_OWNERSHIP_AMBIGUOUS", "basis": "NONE"}
    if eff:
        m = eff[0]
        d = parse_date(m.group("raw"))
        return {**d, "span": [cs + m.start(), cs + m.end()], "basis": "EFFECTIVE_EXPLICIT"}
    pm = RE_EFF_PARTIAL.search(clause)
    if pm:
        return {"state": "UNREADABLE", "value": None, "raw": pm.group("raw"), "span": [cs + pm.start(), cs + pm.end()], "basis": "EFFECTIVE_EXPLICIT"}
    if RE_EFF_NOT_DATE.search(clause):
        return {"state": "NOT_STATED", "value": None, "raw": None, "span": None, "basis": "NONE"}
    a = anchor if anchor is not None else pend
    on = [m for m in RE_ON.finditer(clause) if cs + m.start() >= pend and re.fullmatch(r"[\s,]*(?:[a-z]+ly[\s,]*)?(?:(?:of|from|with) (?:the )?(?:Company|Registrant|Board(?: of Directors)?)[\s,]*)?",     # 0.4.6: one adverb between ('died unexpectedly on D')     # Q11: 'as President of the Company on DATE', 'retire from the Company on DATE'
                                                                                       sent[a:cs + m.start()] if cs + m.start() >= a else "x")]
    if len({m.group("raw") for m in on}) > 1:
        return {"state": "NOT_STATED", "value": None, "raw": None, "span": None, "note": "DATE_OWNERSHIP_AMBIGUOUS", "basis": "NONE"}
    if on:
        m = on[0]
        d = parse_date(m.group("raw"))
        return {**d, "span": [cs + m.start(), cs + m.end()], "basis": "ON_ADJACENT"}
    if shared:
        return dict(shared)
    return {"state": "NOT_STATED", "value": None, "raw": None, "span": None, "basis": "NONE"}


def _shared_dates(sent: str, clauses: list) -> dict:
    """a final 'each / both / in each case effective DATE' governs every clause of the sentence (SHARED_EACH). The sentence-initial governing date is
    handled per event by _initial_date (Q5 contract date_semantics rules 1, 3, 5)"""
    out = {}
    m2 = re.search(rf"\b(?:each|both|in each case|respectively)(?:,)? effective (?:as of |on )?(?P<raw>{DATE_ANY})", sent)
    if m2:
        d = {**parse_date(m2.group("raw")), "span": [m2.start(), m2.end()], "basis": "SHARED_EACH"}
        for i in range(len(clauses)):
            out[i] = d
        return out
    m3 = re.search(rf",\s+effective (?:as of |on )?(?P<raw>{DATE_ANY})\.?\s*$", sent)      # 0.4.6 (3rd review W31): 'X will step down as R1 and transition to R2,
    if m3 and len(clauses) > 1 and all(not re.match(r"\s*(?:[A-Z]|he\b|she\b|they\b)", sent[cs:ce]) for cs, ce in clauses[1:]):   # effective D' - one subject,
        d = {**parse_date(m3.group("raw")), "span": [m3.start(), m3.end()], "basis": "SHARED_EACH"}   # coordinated predicates, a comma before the final date
        for i in range(len(clauses)):
            out[i] = d
    return out


RE_INITIAL = re.compile(rf"^\s*(?:(?P<eff>[Ee]ffective (?:as of |on )?(?:(?:at |as of )?the close of business on )?(?:(?:at |as of )?[0-9]{{1,2}}:[0-9]{{2}} ?[ap]\.?m\.?(?:,? (?:[A-Z][a-z]+ ){{0,2}}[Tt]ime)?,? on )?)|(?P<on>On |As of ))(?P<raw>{DATE_ANY})"
                        rf"(?:\s*\((?:the )?[\"\u201c][^\"\u201d]{{2,40}}[\"\u201d]\))?,")      # 0.4.6: 'On D (the "Effective Date"),' / 'Effective 12:01 a.m. on D,'
NOM_RULES = ("V2-DEP-NOM", "V2-APP-NOM")


def _initial_date(sent: str) -> dict | None:
    m = RE_INITIAL.match(sent)
    if not m:
        return None
    return {"kind": "EFFECTIVE" if m.group("eff") else "ON", "date": {**parse_date(m.group("raw")), "span": [m.start("raw") - (len(m.group("eff") or m.group("on"))), m.end() - 1]},
            "end": m.end(), "semicolon": sent.find("; ")}


def _completed(action: str, rule: str, text_pred: str) -> bool:
    """a past-tense, completed departure or appointment (Q5 date rule 1); a continuation, a nominalisation, a future or modal form is not"""
    return action in ("DEPARTURE", "APPOINTMENT") and rule not in NOM_RULES and \
        not re.match(r"\s*(?:will|shall|would|may|might|could|is|are|am|plans?|expects?|intends?)\b", text_pred, re.I)


def _apply_initial(date_: dict, ini: dict | None, sent: str, cs: int, ps_abs: int, action: str, rule: str, text_pred: str, subject_kind: str | None) -> dict:
    """Q5 date rules 1, 3, 5: a sentence-initial 'Effective DATE,' governs every main clause before the first ';' that has no own date; a sentence-initial
    'On DATE,' gives an EVENT date to a past-tense completed change it governs, and is only a NARRATIVE date before a reporting verb or a future /
    modal / continuation predicate; neither enters a relative clause"""
    out = dict(date_)
    out.setdefault("event_date", out["value"] if out.get("basis") == "ON_ADJACENT" and _completed(action, rule, text_pred) else None)
    out.setdefault("narrative_date", None)
    if not ini or subject_kind == "RELATIVE" or (ini["semicolon"] >= 0 and cs > ini["semicolon"]):
        return out
    own = out.get("basis") in ("EFFECTIVE_EXPLICIT", "ON_ADJACENT", "SHARED_EACH")
    if ini["kind"] == "EFFECTIVE":
        if not own:
            out.update({**ini["date"], "basis": "SHARED_SENTENCE_INITIAL", "event_date": None, "narrative_date": None})
        return out
    reporting = bool(REPORTING.search(sent[ini["end"]:ps_abs]))
    if reporting or not _completed(action, rule, text_pred):
        out["narrative_date"] = ini["date"]["value"]
        return out
    if not own:
        out.update({**ini["date"], "basis": "EVENT_DATE", "event_date": ini["date"]["value"], "narrative_date": None})
    else:
        out["event_date"] = ini["date"]["value"]
    return out


def _end_date(raw: str) -> dict:
    """the end of a continuation: a full date (VALID), a month and year (the month's last day, MONTH_ONLY), or a relative end (RELATIVE)"""
    d = parse_date(raw)
    if d["state"] == "VALID":
        return {**d, "kind": "DATE"}
    mm = re.fullmatch(r"(?P<m>[A-Z][a-z]+) (?P<y>[0-9]{4})", raw)
    if mm and mm.group("m") in MONTHS:
        import calendar
        y, mo = int(mm.group("y")), MONTHS[mm.group("m")]
        return {"state": "VALID", "value": date(y, mo, calendar.monthrange(y, mo)[1]).isoformat(), "raw": raw, "kind": "MONTH_ONLY"}
    return {"state": "RELATIVE", "value": None, "raw": raw, "kind": "RELATIVE"}


def _roles_in(text: str) -> list:
    return list(dict.fromkeys(norm_role(m.group(0)) for m in re.finditer(rf"\b{ROLE}\b", text)))


RE_GENDER_M = re.compile(r"\b(?:he|him|his|himself)\b", re.I)
RE_GENDER_F = re.compile(r"\b(?:she|her|hers|herself)\b", re.I)


def _text_gender_cues(sent: str, cues: dict) -> dict:
    """gender evidence written in the text itself, never inferred from a name: an honorific (Mr. / Ms. / Mrs. + surname); conflicting evidence clears
    the cue. Q5 (review R2-02): a gendered pronoun is NOT taken as evidence any more - the pronoun being resolved would be its own evidence"""
    out = dict(cues)
    ns = {n[2] for n in names(sent)}
    for p in ns:
        last = surname(p)
        if re.search(rf"\bMr\.\s+(?:[A-Z][\w.'-]*\s+){{0,2}}{re.escape(last)}\b", sent):
            out[p] = "M" if out.get(p, "M") == "M" else None
        if re.search(rf"\bM(?:s|rs)\.\s+(?:[A-Z][\w.'-]*\s+){{0,2}}{re.escape(last)}\b", sent):
            out[p] = "F" if out.get(p, "F") == "F" else None
    return out


def _resolve_pronoun(pron: str, window: list, cues: dict) -> str | None:
    """a pronoun is resolved only when its referent is unambiguous: exactly one distinct person named in the window (every earlier sentence of the
    section and the current sentence before the pronoun), or a gendered pronoun whose gender, as evidenced in the text, fits exactly one of them while
    every other person's text evidence is the other gender. 'they' is never resolved. Otherwise None (AMBIGUOUS_REFERENCE)."""
    cands = list(dict.fromkeys(window))
    if pron.lower() == "they" or not cands:
        return None
    if len(cands) == 1:                                       # Q5: a single candidate whose text evidence is the other gender is not the referent
        g1 = "M" if pron.lower() == "he" else "F"
        return cands[0] if cues.get(cands[0]) in (None, g1) else None
    g = "M" if pron.lower() == "he" else "F"
    fit = [p for p in cands if cues.get(p) == g]
    if len(fit) == 1 and all(cues.get(p) not in (None, g) for p in cands if p != fit[0]):
        return fit[0]
    return None


def analyse_sentence(sent: str, context: dict) -> dict:
    """stage B for one sentence: events (resolved or AMBIGUOUS), hazards (negated, tentative, non-factual, historical, ambiguous reference) and
    unresolved mentions (with the roles they mention). context: {"seen": [every person named earlier in the section], "known": [the full names among
    them], "cues": {person: "M"|"F"|None from text evidence}} - pass the returned next_context to the following sentence of the same section"""
    global _KNOWN, _CUES, _ORGS
    _KNOWN = list(context.get("known") or [])
    _CUES = dict(context.get("cues") or {})
    _ORGS = list(context.get("orgs") or [])
    sent = re.sub(r"(?<=\bCo)[\u2010\u2011\u2012\u2013\u2014](?=[A-Z])", "-", sent)   # Q13-A (C13, re-review R-4): 'Co\u2013Chief Executive Officer' - the same length, so every offset holds
    try:
        return _analyse(sent, context)
    finally:
        _KNOWN, _CUES, _ORGS = [], {}, []


CHANGE_WORDS = re.compile(r"\b(?:resign|retir|depart|leav|left|step(?:s|ped|ping)? (?:down|away)|st(?:oo|a)nd(?:s)? down|transition|succe|replac|remain|continu|"
                          r"appoint|elect|named|promot|terminat|remov|join|exit|vacat|relinquish)", re.I)
COMP_WORDS = re.compile(r"\b(?:salary|award|equity|grant|bonus|compensation|stock|units|options?|severance|agreement|retention|incentive|fees?)\b", re.I)


def _kind(why: str, text: str) -> str:
    """Q5: what an unresolved mention is - only the first four kinds are unresolved EVIDENCE for the completeness gate (G5 / G6)"""
    if why.startswith("pronoun"):
        return "AMBIGUOUS_REFERENCE"
    if why.startswith("a short-form name"):
        return "SHORT_NAME_UNRESOLVED"
    if "predicate without a resolvable person" in why:
        return "UNRESOLVED_SUBJECT"
    if TENT.search(text) or NEG.search(text) or RE_HISTORICAL.search(text) or NONFACT.search(text) or re.search(r"\bhas no plans\b|\bconsidering\b", text, re.I):
        return "NON_CHANGE_STATEMENT"
    if COMP_WORDS.search(text) and not re.search(r"\b(?:resign|retir|depart|step|left|leav|terminat|remov)", text, re.I):
        return "NON_CHANGE_STATEMENT"
    return "UNPARSED_CHANGE_STATEMENT" if CHANGE_WORDS.search(text) else "NON_CHANGE_STATEMENT"


def _unresolved(span, persons, why, text) -> dict:
    return {"span": span, "persons": persons, "roles": _roles_in(text), "why": why, "kind": _kind(why, text)}


RE_APP_LIST = None


def _sentence_roles(sent: str) -> dict:
    """Q11: the titles the sentence itself gives each named person - an appositive ('X, the Company's EVP and CFO,'; 'X, CEO and a director of
    Acme, Inc. (the "Company"),') or 'X has been / has served as / currently serves as ROLE' - coordinated titles kept apart"""
    global RE_APP_LIST
    if RE_APP_LIST is None:
        RE_APP_LIST = re.compile(rf"^(?:,\s*[0-9]{{1,3}},)?(?:,\s*(?:currently |now |in (?:his|her|their) capacity as |who (?:currently )?holds the (?:position|role|title|office)s? of |holding the (?:position|role|title|office)s? of |"   # Q11 0.4.3
                                 rf"who is (?:presently |currently )?(?:serving as )?|who currently serves as |who has (?:been|served as) )?|\s+(?:has been serving as|has been acting as|is serving as|is acting as|has been|has served as|currently serves as|serves as|is currently) )"
                                 rf"{ROLE_PRE}(?P<list>{ROLE}(?:(?:,| and|, and) (?:as )?{ROLE_PRE}{ROLE}){{0,3}})(?=[,.]| of | since\b| and will\b| will\b)")
    out = {}
    for a, b, nm in names(sent):
        if RE_HON_ONLY.match(nm):
            continue
        m = RE_APP_LIST.match(sent[b:])
        if m:
            if _other_company(sent, b + m.end()):             # 0.4.4 (review E10): 'Jane Doe, CEO of Corvane Corp., resigned' - not a title at the issuer
                continue
            out[nm] = [norm_role(x.group(0).strip()) for x in re.finditer(rf"{ROLE}", m.group("list"))]
            out[nm] = [x for x in out[nm] if x]
    return out


def _analyse(sent: str, context: dict) -> dict:
    issuers = list(context.get("issuers") or [])             # 0.4.4 (review E10): names the document defines as '(the "Company")'
    cues = _text_gender_cues(sent, context.get("cues") or {})
    sroles = _sentence_roles(sent)
    recent = list(context.get("seen") or [])
    clauses = split_clauses(sent)
    shared = _shared_dates(sent, clauses)
    ini = _initial_date(sent)
    p0 = min((mm.start() for _r, _a, _v, rx_ in PREDICATES for mm in [rx_.search(sent)] if mm), default=None)
    lead_cond = bool(p0 is not None and RE_COND_PRE.search(sent[:p0]))    # Q11 0.4.3: a condition written before the sentence's first predicate governs its later clauses too
    hist = [(m.start(), m.end()) for m in RE_HIST_REL.finditer(sent)                       # historical relative clauses: kept apart from the main predicate
            if (RE_HISTORICAL.search(m.group("body")) or (RE_PAST_YEAR.search(m.group("body")) and
                re.search(r"\b(?:was|were|had|served|resigned|retired|joined|held|left|stepped|became)\b", m.group("body"))))
            and not re.search(r"\beffective\b", m.group("body"), re.I)]
    restated = bool(re.match(r"^\s*As (?:previously|earlier|was) (?:reported|disclosed|announced)\b", sent))   # Q11 0.4.3: a restatement of an earlier report
    nonfact_sentence = re.match(r"^\s*(?:If|Unless|Whether|In the event that|Neither|Rumou?rs?|It is not true that)\b", sent)
    rumour_m = RE_RUMOUR_REPORT.search(sent)               # Q12 C10: 'aware of a report ... stating that X had stepped down' - what the report says is not an event
    template_sentence = bool(RE_TEMPLATE.search(sent))      # Q10: the Item 5.02(d) disclosure template restates a selection; it is not an event
    events, hazards, unresolved, used_names = [], [], [], set()
    prev_subject = None
    for ci, (cs, ce) in enumerate(clauses):
        clause = sent[cs:ce]
        masked = "".join(" " if any(a <= cs + j < b for a, b in hist) else ch for j, ch in enumerate(clause))
        found = []
        for rule, action, voice, rx in PREDICATES:
            for m in rx.finditer(clause):
                found.append((m.start(), m.end(), rule, action, voice, m))
        found.sort(key=lambda x: (x[0], -x[1]))
        kept = []
        for f in found:                                       # overlapping predicate matches: keep the longest earliest one
            if not any(f[0] < k[1] and k[0] < f[1] for k in kept):
                kept.append(f)
        clause_subject = None
        consumed = -1                                         # Q11 0.4.3: the end of the role phrase an earlier predicate of this clause read ('selected X, ..., to become R')
        for ps, pe, rule, action, voice, m in kept:
            text_pred = m.group(0)
            if ps < consumed:                                 # a predicate word inside that role phrase is part of it, not a second event
                continue
            if any(a <= cs + ps < b for a, b in hist) or RE_HISTORICAL.search(masked[max(0, ps - 40):pe + 5]):
                hazards.append({"kind": "HISTORICAL", "span": [cs + ps, cs + pe]})
                continue
            if nonfact_sentence or NONFACT.search(clause[:ps]) or (rumour_m and cs + ps > rumour_m.start()):     # Q5: denied / asked to / offered to / if / rumors / neither ... (no event); Q12 C10: reported claims
                hazards.append({"kind": "NON_FACTUAL", "span": [cs + ps, cs + pe], "persons": [n[2] for n in names(clause)]})
                continue
            if template_sentence:
                hazards.append({"kind": "TEMPLATE", "span": [cs + ps, cs + pe], "persons": [n[2] for n in names(clause)]})
                continue
            actor = None
            if voice == "OBJ" and rule == "V2-APP-PRO":           # Q11 0.4.3: a pronoun object resolved only to the one full name before it in the sentence
                before = list(dict.fromkeys(n[2] for n in names(sent[:cs + ps]) if not RE_HON_ONLY.match(n[2])))
                g_ = "M" if m.group("pro") == "him" else "F"
                who = before[0] if len(before) == 1 and cues.get(before[0]) in (None, g_) else None
                if not who:
                    hazards.append({"kind": "AMBIGUOUS_REFERENCE", "span": [cs, ce], "persons": None})
                    unresolved.append(_unresolved([cs, ce], before, f"pronoun '{m.group('pro')}' without an unambiguous referent", clause))
                    continue
                subj = {"persons": [who], "kind": "PRONOUN", "spans": []}
                obj_end = m.end()
            elif voice == "OBJ":
                if rule == "V2-DEP-ACC":
                    on = [n for n in names(clause) if n[0] == m.start("obj")]
                else:                                         # Q10: 'Mr. Watts' - the name span starts at the honorific, the object at the surname
                    on = [n for n in names(clause) if n[0] <= m.start("obj") < n[1] and not re.match(r"['\u2019]s\b", clause[n[1]:])]
                if not on:                                    # the words after the verb are not a person's name (a role, a title, a possessive): no object
                    continue
                objs = [on[0]]                                # Q5: coordinated objects 'appointed X and Y as A and B, respectively'
                if rule != "V2-DEP-ACC":
                    pos = on[0][1]
                    for n in [n for n in names(clause) if n[0] >= on[0][1]]:
                        if re.fullmatch(r"(?:,|, and| and|,and)\s*", clause[pos:n[0]]) and not re.match(r"['\u2019]s\b", clause[n[1]:]):
                            objs.append(n)
                            pos = n[1]
                        else:
                            break
                    if len(objs) > 1 and not any("and" in clause[objs[j][1]:objs[j + 1][0]] for j in range(len(objs) - 1)):
                        objs = objs[:1]
                subj = {"persons": [o[2] for o in objs], "kind": "OBJECT", "spans": [[cs + o[0], cs + o[1]] for o in objs]}
                actor = _subject(clause, ps, cs)
                if actor:
                    clause_subject = actor                    # Q5: the nearest subject is the one a later subject-less clause inherits
                    used_names.update(actor["persons"])
                elif re.search(r"\b(?:[Tt]he [Bb]oard|[Tt]he Company|[Tt]he [Cc]ommittee)\b", clause[:ps]):
                    clause_subject = {"persons": [], "kind": "NON_PERSON", "spans": []}
                obj_end = m.end() if rule in ("V2-DEP-ACC", "V2-APP-CAND") else objs[-1][1]       # 0.4.5: for a candidate the role follows the word candidate
            else:
                subj = _subject(clause, ps, cs)
                comp = re.search(r"\bthat (?P<p>he|she|they)(?:\s+(?:plans?|intends?|expects?|wish(?:es)?|hopes?|has decided|decided|agreed|is (?:going|scheduled|expected)|"
                                 r"would like)(?:\s+to)?)?\s+$", clause[:ps]) if subj is None else None      # 0.4.5: "that he plans to retire"
                if comp:                                      # Q5: 'X notified the Board that he will retire' - the complement's pronoun subject
                    before = list(dict.fromkeys(n[2] for n in names(sent[:cs + comp.start()]) if not (RE_ORG_TAIL.match(sent[n[1]:]) and not re.match(r"\s+of\s", sent[n[1]:]))))   # Q13-A: a company named with its legal form is no referent (C13: 'X of Y, LLC' is a person)
                    gp = "M" if comp.group("p") == "he" else "F" if comp.group("p") == "she" else None
                    who = before[0] if (len(before) == 1 and gp and cues.get(before[0]) in (None, gp)) else None
                    if who:
                        subj = {"persons": [who], "kind": "PRONOUN", "spans": []}
                    else:
                        hazards.append({"kind": "AMBIGUOUS_REFERENCE", "span": [cs, ce], "persons": None})
                        unresolved.append(_unresolved([cs, ce], before, f"pronoun '{comp.group('p')}' without an unambiguous referent", clause))
                        continue
                if subj is None:
                    pm = RE_PRONOUN.match(re.sub(r"^(?:,?\s*(?:and|but|while)\s+)", "", clause.strip()))
                    if pm:                                    # a pronoun subject: resolved only when unambiguous, never by plain inheritance
                        before = list(dict.fromkeys(n[2] for n in names(sent[:cs])))
                        g_ = "M" if pm.group(0).lower() == "he" else "F" if pm.group(0).lower() == "she" else None
                        if len(before) == 1 and prev_subject and prev_subject.get("persons") == before and g_ and cues.get(before[0]) in (None, g_):
                            who = before[0]
                        elif len(set(recent + before)) == 1 and g_ and cues.get(before[0] if before else recent[0]) in (None, g_):
                            who = (before or recent)[0]           # 0.4.5: one person named in the section so far - 'X has served as interim CEO; he will ...'
                        else:
                            who = _resolve_pronoun(pm.group(0), recent + before, cues)
                        if who:
                            subj = {"persons": [who], "kind": "PRONOUN", "spans": []}
                        else:
                            hazards.append({"kind": "AMBIGUOUS_REFERENCE", "span": [cs, ce], "persons": None})
                            unresolved.append(_unresolved([cs, ce], list(dict.fromkeys(recent + [n[2] for n in names(sent[:cs])])),
                                                          f"pronoun '{pm.group(0)}' without an unambiguous referent", clause))
                            continue
                    elif not names(clause[:ps]) and prev_subject and prev_subject["persons"] and prev_subject["kind"] in ("SUBJECT", "COORDINATED", "PRONOUN", "INHERITED", "RELATIVE"):
                        subj = {**prev_subject, "kind": "INHERITED"}
                if subj:
                    clause_subject = subj                     # Q5: the nearest (latest) subject, not the clause's first
            rbase = pe if voice != "OBJ" else obj_end
            roles, rend = _roles(clause[rbase:])
            held = []                                         # Q11: titles the person is said to hold already, in an appositive of this clause
            if voice == "OBJ":
                am_ = re.match(r"^\s*,(?P<app>[^,]{1,100}(?:, (?:Inc|Corp|Co|LLC|Ltd)\.?)?),\s*(?:as|to serve as|to be|to become|to take on|to (?:the )?(?:role|position)s? of)\b", clause[rbase:])
                if am_:
                    held = _held_in(am_.group("app"), issuers)
            elif subj and subj.get("spans") and subj["spans"][-1][1] - cs <= ps:
                am_ = re.match(r"^\s*,\s*(?P<app>[^,]{1,80}(?:, (?:Inc|Corp|Co|LLC|Ltd)\.?)?),\s*$", clause[subj["spans"][-1][1] - cs:ps])
                if am_:
                    held = _held_in(am_.group("app"), issuers)
            if voice != "OBJ" or True:
                prior_ = (context.get("held_of") or {}).get(((subj or {}).get("persons") or [None])[0])     # 0.4.5 (2nd review N6): only a title stated as the issuer's, still held
                if prior_ and action == "APPOINTMENT":        # 0.4.4 (review E4): a title the person is said to hold in an earlier sentence ('X currently serves as President')
                    held = list(held) + [norm_role(prior_)]
            end_ = None
            if action == "CONTINUATION":                      # Q11: the end of a continuation ('through May 2026', 'until December 31, 2026', 'until his retirement')
                em = re.search(rf"\b(?:through|until|till)\s+(?:and including\s+)?(?P<raw>{DATE_ANY}|(?:January|February|March|April|May|June|July|August|September|October|November|"
                               rf"December) [0-9]{{4}}|(?:his|her|their) retirement|the (?:appointment|hiring) of (?:a|his|her|their) successor|"
                               rf"(?:a|his|her|their) successor (?:is|has been|was|shall have been) (?:appointed|named|elected|hired)(?: and qualified)?)", clause[pe:])   # 0.4.4
                if em:
                    end_ = _end_date(em.group("raw"))
            if len(roles) == 1 and norm_role(roles[0][0]) == "Chair" and re.match(r"^\s*(?:as )?its [Cc]hair(?:man|woman|person)?\b", clause[rbase:]):
                cm_ = list(dict.fromkeys(x.group(1) for x in re.finditer(r"\b((?:[A-Z][a-z&]+,? (?:and )?){1,6}Committee)\b", clause)))   # Q13-E
                if len(cm_) == 1:                             # Q11 0.4.3: 'X, who has served on the Compensation Committee, was appointed its Chair'   # Q13-E
                    roles = [(f"Chair of the {cm_[0]}", roles[0][1])]   # Q13-E
            if action == "APPOINTMENT" and end_ is None:          # 0.4.4 (review E6): 'appointed X as Interim CEO, to serve until June 30, 2026'
                em = re.search(rf"\b(?:to serve |serving |and (?:will )?serve |who will serve )?(?:until|through)\s+(?:and including\s+)?(?P<raw>{DATE_ANY}|(?:January|February|March|April|May|June|"
                               rf"July|August|September|October|November|December) [0-9]{{4}})", _segment(clause[pe:]))
                seg_ = clause[:pe] + _segment(clause[pe:])
                if em and (re.search(r"\b(?:serve|serving)\b", clause[pe:pe + em.start() + 12]) or re.search(rf"\bfrom {DATE_ANY} $", clause[pe:pe + em.start()])
                           or re.search(r"\b(?:[Ii]nterim|[Aa]cting|[Aa]dvis[oe]r|[Cc]onsultant)\b", seg_)):
                    end_ = _end_date(em.group("raw"))
                    ext_ = re.search(rf"\bextended (?:her|his|their|the) (?:term|service|appointment|tenure)(?: as [^,.;]{{0,60}})? (?:through|until) (?P<raw>{DATE_ANY})", sent)
                    if ext_:                                  # 0.4.5 (2nd review N4): 'and the Board extended her term through December 31, 2026'
                        end_ = _end_date(ext_.group("raw"))
            if rule in ("V2-APP-INV", "V2-DEP-VAC", "V2-DEP-END"):     # Q10: the role is written before the object (Q11: vacated / tenure ended)
                roles, rend = [(m.group("role"), None)], 0
            extra_pair = None
            if voice == "OBJ" and roles and rule != "V2-APP-INV":     # Q11: 'appointed X as R1 and Y as R2' - a second person with a second title
                m2 = re.match(rf"^\s*(?:,?\s*[Ee]ffective (?:as of |on )?{DATE_ANY})?\s*,?\s*and (?:(?:Mr|Ms|Mrs|Dr)\.\s+)?(?P<n>{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})+) (?:as|to be) {ROLE_PRE}(?P<r>{ROLE})"
                              rf"(?:,? [Ee]ffective (?:as of |on )?(?P<d2>{DATE_ANY}))?", clause[rbase + rend:])     # 0.4.5: each with its own date
                if m2:
                    extra_pair = (m2.group("n"), m2.group("r"), m2.group("d2"))
            role_basis = "SAME_SENTENCE" if roles else None
            cur = RE_CUR_ROLE.match(clause[rbase:]) if not roles else None
            if cur:                                           # Q10: 'his current role' - the role the same person is said to hold earlier in the section
                who_ = ((subj or {}).get("persons") or [None])[0]
                known_role = ((context.get("roles_of") or {}).get(who_) or ((sroles.get(who_) or [None])[0] if who_ else None)) if voice != "OBJ" else None
                rend = cur.end()
                if known_role:
                    parts_ = [x.strip() for x in re.split(r",? and ", known_role)]
                    roles = [(x, None) for x in parts_] if len(parts_) > 1 and all(re.fullmatch(ROLE, x) for x in parts_) else [(known_role, None)]   # 0.4.5: "EVP and CFO" are two titles
                    role_basis = "NEIGHBOUR_SENTENCE"
            if not roles and subj and subj.get("spans") and voice != "OBJ":     # a role given as an appositive of the subject: 'X, our CFO, resigned'
                am = RE_APPOSITIVE_ROLE.match(clause[subj["spans"][-1][1] - cs:ps]) if subj["spans"][-1][1] - cs <= ps else None
                if am:
                    roles = [(am.group("role"), None)]
            if not roles and subj and len(subj.get("persons") or []) == 1 and sroles.get(subj["persons"][0]) and action in ("DEPARTURE", "CONTINUATION") \
                    and not re.match(r"\s*(?:from (?:the |its )?Board|as (?:a )?(?:director|member))", clause[rbase:]):
                roles = [(r_, None) for r_ in sroles[subj["persons"][0]]]          # Q11: the titles the same sentence gives this person (coordinated: one record each)
                role_basis = "SAME_SENTENCE_APPOSITIVE"
            if rule == "V2-APP-SUC" and m.group("succ"):
                used_names.add(m.group("succ"))
                used_names.update(n[2] for n in names(clause) if n[0] == m.start("succ"))   # Q5: the full name a short form maps to
            if voice == "OBJ":                                # negation / tentativeness of an object-type predicate are read from the clause start (or its actor)
                actor_end = (max(sp[1] for sp in actor["spans"]) - cs) if actor and actor.get("spans") else 0
                window = clause[max(0, actor_end):pe]
            else:
                subj_end = (max(sp[1] for sp in subj["spans"]) - cs) if subj and subj.get("spans") else 0
                window = clause[max(0, min(subj_end, ps)):pe]
            if voice == "SUBJ" and subj and subj.get("spans") and subj.get("kind") != "RELATIVE" and RE_EXCLUDED.search(clause[:min(sp[0] for sp in subj["spans"]) - cs]):   # Q13 C12: 'except X, who will continue' keeps X
                hazards.append({"kind": "NON_FACTUAL", "span": [cs + ps, cs + pe]})      # Q13-B: 'each of the directors other than CEO X will resign' - X is the exception
                continue
            if action == "DEPARTURE" and re.match(r"retired\b", text_pred) and RE_ADJ_RETIRED.search(clause[:ps]):
                hazards.append({"kind": "NON_FACTUAL", "span": [cs + ps, cs + pe]})      # Q13-C: 'X, a retired judge of the court of appeals' - an adjective, not a departure
                continue
            if voice == "SUBJ" and re.search(r"\b(?:until|unless|before|once|when)\s+(?:a|an|the|his|her|their|its|such)\b[^,.;]{0,80}$", clause[:ps]):
                hazards.append({"kind": "NON_FACTUAL", "span": [cs + ps, cs + pe]})      # 0.4.6 (4th review C02): 'until a permanent CFO is appointed' - a time clause
                continue
            negated = bool(NEG.search(text_pred) or NEG.search(window)) and rule not in ("V2-DEP-NLS", "V2-DEP-NSR")     # 0.4.6: their 'not' / 'no longer' is the change itself
            first = min([sp[0] for sp in ((actor if voice == "OBJ" else subj) or {}).get("spans") or []] or [cs + ps]) - cs
            tent_hits = [x.group(0) for x in TENT.finditer(window)]
            tentative = bool(tent_hits) or bool(TENT_PRE.search(clause[:max(0, first)]))      # Q10: 'expects that X will be appointed'
            cond_src = tent_hits[0] if tent_hits and all(RE_COND_WORD.match(h_) for h_ in tent_hits) and not TENT_PRE.search(clause[:max(0, first)]) else None   # Q13-E
            if tentative and not TENT_PRE.search(clause[:max(0, first)]) and {x.group(0).lower() for x in TENT.finditer(window)} == {"would"} \
                    and RE_REPORTED.search(sent[:cs + max(0, first)]) and not re.search(r"\b(?:if|unless|subject to|upon|conditioned|contingent|provided that)\b", clause, re.I):
                tentative = False                             # Q11 0.4.3: 'the Company announced that X would retire ... effective D' - reported speech of a decided change
            if tentative and not cond_src:   # Q13-E
                cond_src = None   # Q13-E
            if not tentative and (re.search(r"\b(?:anticipates?|expects?|intends?|plans?|hopes?|believes?)(?: that)\b", sent[:cs + ps]) or
                                  re.search(rf"\b(?:anticipates?|expects?|intends?|plans?)(?: that)? (?:(?:Mr|Ms|Mrs|Dr)\.\s+)?{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})+", clause[:ps])):
                tentative = True                              # 0.4.5: 'The Board anticipates that X will take over as Chair when Ms. Y steps down' - both are expected
                cond_src = None   # Q13-E
            tc_ = list(TENT_CLAUSE.finditer(clause[:ps]))
            tc_ok = bool(tc_) and not re.search(r",\s+and\s+(?:on |then |thereafter |subsequently |the Board|it )", clause[tc_[-1].end():ps])   # 0.4.5: a new main clause after ', and on DATE'
            if not tentative and (TENT_ADJ.search(clause[:ps]) or tc_ok or rule in ("V2-APP-CAND", "V2-APP-NMN")):
                tentative = True                              # 0.4.4 (review E5) / 0.4.5 (2nd review N3): the phrase governs this predicate, in its own clause
                cond_src = None   # Q13-E
            if not tentative and RE_COND_STRONG_POST.search(_segment(clause[pe:])):
                tentative = True                              # 0.4.6 (4th review T05 / T10): 'approved the appointment of X, subject to approval by the shareholders' - any tense
                cond_src = RE_COND_STRONG_POST.search(_segment(clause[pe:])).group(0)   # Q13-E
            if not tentative and re.search(r"\b(?:will|shall|is to|are to|would|to be)\b", clause[max(0, first):pe]) and RE_COND_POST.search(_segment(clause[pe:])):
                tentative = True                              # 0.4.4 (review E5): 'will be appointed CFO upon the closing of the merger', '..., subject to stockholder approval'
                cond_src = RE_COND_POST.search(_segment(clause[pe:])).group(0) if not re.search(r"\bwould\b", clause[max(0, first):pe]) else None   # Q13-E
            if not tentative and (RE_COND_ANY_TENSE.search(clause[:max(0, first)]) or (ci > 0 and RE_COND_ANY_TENSE.search(sent))):
                tentative = True                              # 0.4.6 (3rd review W05): 'Subject to stockholder approval, the Board has approved the appointment of X'
                cond_src = (RE_COND_ANY_TENSE.search(clause[:max(0, first)]) or RE_COND_ANY_TENSE.search(sent)).group(0).strip()   # Q13-E
            if not tentative and re.match(r"\s*(?:will|shall|is to|are to|would)\b", text_pred) and (RE_COND_PRE.search(clause[:max(0, first)]) or (lead_cond and ci > 0)):
                tentative = True                              # Q11: 'upon the closing of the merger, X will resign' - conditional on a future closing
                cm_ = RE_COND_PRE.search(clause[:max(0, first)]) or RE_COND_PRE.search(sent)   # Q13-E
                cond_src = cm_.group(0) if cm_ and not re.match(r"\s*would\b", text_pred) else None   # Q13-E
            conditional = None   # Q13-E
            if tentative and cond_src and not NEG.search(window):   # Q13-E
                own_ = RE_COND_POST.search(_segment(clause[pe:]))       # Q13 C12 (review #8): the event's own condition first
                conditional = _cond_phrase(clause[pe:], own_.group(0)) if own_ else _cond_phrase(clause if cond_src.lower().strip() in clause.lower() else sent, cond_src)    # Q13-E: the condition a tentative change depends on, quoted (modality unchanged: the development sets disagree on decided vs tentative - records/q13_info/round2.json)
            if rule in NOM_RULES and (RE_BARE_YEAR.search(clause[pe:pe + 60]) or re.search(r"\b(?:since|following|after) the (?:retirement|resignation|departure) of\s*$", clause[:pe - len(text_pred) + len(text_pred.split(" of ")[0]) + 4][-60:] if False else "") or
                                    re.search(r"\b(?:since|following|after) the\s*$", clause[max(0, ps - 30):ps])):
                hazards.append({"kind": "HISTORICAL", "span": [cs + ps, cs + pe]})        # Q11: 'vacant since the retirement of X in 2024'
                continue
            yr_ = re.match(r"^\s*(?:,\s*)?(?:In|During) (?:early |late |mid-)?(?P<y>(?:19|20)[0-9]{2}),", clause) or re.search(r",\s*in (?P<y>(?:19|20)[0-9]{2}),\s*$", clause[:ps])
            if yr_ and context.get("doc_year") and int(yr_.group("y")) >= int(context["doc_year"]):
                yr_ = None                                    # 0.4.5 (2nd review N14): 'In 2026, the Board appointed ...' in a 2026 filing is current
            if not negated and not tentative and _completed(action, rule, text_pred) and yr_ and not RE_EFF.search(clause):
                hazards.append({"kind": "HISTORICAL", "span": [cs + ps, cs + pe]})        # 0.4.4 (review E14)
                continue
            if not negated and not tentative and _completed(action, rule, text_pred) and RE_BARE_YEAR.search(clause[pe:]) and not RE_EFF.search(clause) \
                    and not RE_ON.search(clause) and not ini:     # a full date in the clause ('on May 3, 2026') or at the sentence start (0.4.5) makes it the current event
                hazards.append({"kind": "HISTORICAL", "span": [cs + ps, cs + pe]})        # Q10: 'was appointed Chief Operating Officer in 2018'
                continue
            if negated:
                hazards.append({"kind": "NEGATED", "span": [cs + ps, cs + pe], "persons": (subj or {}).get("persons")})
                continue
            if roles and rend:
                consumed = max(consumed, rbase + rend)
            nxt = [k_[0] for k_ in kept if k_[0] > ps and k_[0] >= consumed]
            anchor = cs + rbase + rend if (roles or cur) else cs + pe
            date_ = _clause_date(sent, cs, ce, cs + pe, shared.get(ci), (cs + ps) if len(kept) > 1 else None,
                                 (cs + min(nxt)) if (len(kept) > 1 and nxt) else (ce if len(kept) > 1 else None), anchor)
            persons = (subj or {}).get("persons") or []
            if any(RE_HON_ONLY.match(p_) for p_ in persons):    # an honorific short form with no unique full name: an unresolved mention
                unresolved.append(_unresolved([cs, ce], persons, "a short-form name without a unique full name in the section", clause))
                continue
            if not persons:                                   # no resolved person: an unresolved mention, never an event
                unresolved.append(_unresolved([cs, ce], [n[2] for n in names(clause)], f"{action.lower()} predicate without a resolvable person", clause))
                continue
            role_end_abs = cs + rbase + rend if (roles and rend) else None
            pairing = None
            if len(persons) > 1 and len(roles) > 1:
                if re.search(r"\brespectively\b", clause) and len(persons) == len(roles):    # 'X and Y ... A and B, respectively': pairwise
                    pairs = list(zip(persons, roles))
                else:                                         # Q5: no cross product - the pairing is undetermined (AMBIGUOUS, role unknown)
                    pairs = [(p_, (None, None)) for p_ in persons]
                    pairing = "PERSON_ROLE_PAIRING_UNDETERMINED"
            else:
                pairs = [(p_, r_) for p_ in persons for r_ in (roles or [(None, None)])]
            if extra_pair and len(persons) == 1:
                pairs.append((extra_pair[0], (extra_pair[1], extra_pair[2])))
            for person, (role, role_date) in pairs:
                    if person:
                        used_names.add(person)
                    ob_ = _other_company_basis(sent, role_end_abs, issuers) if role and role_end_abs is not None else None
                    if ob_:
                        hazards.append({"kind": "OTHER_COMPANY", "span": [cs + ps, cs + pe], "persons": [person], "role": norm_role(role)})   # Q11: a role at another company
                        if ob_ == "LEGAL_FORM":                   # 0.4.6 (3rd review M1): only a legal form says so - shown as an unresolved mention, never dropped silently
                            unresolved.append(_unresolved([cs, ce], [person], "a role at a named company that is not the registrant on file (the "
                                                          "document does not define it as the Company): not read as the issuer's change", clause))
                        continue
                    if role and action == "APPOINTMENT" and norm_role(role) in held:     # Q11: an 'appointment' to a title already held is not a change
                        hazards.append({"kind": "ALREADY_HELD", "span": [cs + ps, cs + pe], "persons": [person], "role": norm_role(role)})
                        continue
                    act_, trans = action, False
                    if action == "CONTINUATION" and RE_STAY_EMPLOYED.match(clause[pe:]):
                        capacity_ = False
                        if role is None and RE_ADVISORY.match(clause[pe:]):
                            role = re.search(r"(?:advisory|consulting|transition(?:al)?|non-executive|non-officer|employee) (?:role|capacity|position)", clause[pe:]).group(0)   # 0.4.5: as written
                            capacity_ = True                  # no title: a continuation of employment in that capacity, marked (the real-set annotation reads it so)
                        known = {norm_role(x) for x in (sroles.get(person) or [])} | ({norm_role((context.get("roles_of") or {}).get(person))} - {None})
                        if capacity_:
                            trans = True
                        elif role and norm_role(role) not in known and RE_NON_OFFICER.search(role):     # Q11 0.4.3: 'will remain employed by the Company as Senior Advisor' (a title not held before): a new, non-officer transition role
                            act_, trans = "APPOINTMENT", True
                    own_date = {**parse_date(role_date), "span": None, "basis": "EFFECTIVE_EXPLICIT"} if role_date else None
                    if own_date is not None:
                        rd = re.search(rf"[Ee]ffective (?:as of |on )?{re.escape(role_date)}", sent[cs:ce])
                        own_date["span"] = [cs + rd.start(), cs + rd.end()] if rd else None
                    base_date = own_date if own_date is not None else (date_ if not (len(roles) > 1 and any(r_[1] for r_ in roles)) else
                                                                       {"state": "NOT_STATED", "value": None, "raw": None, "span": None, "basis": "NONE"})
                    if re.search(rf"(?:[Ee]ffective|with effect from) (?:as of |on |from )?{DATE_ANY},? and (?:on |as of |from )?{DATE_ANY}(?!,? respectively)", clause):
                        base_date = {"state": "NOT_STATED", "value": None, "raw": None, "span": None, "note": "DATE_OWNERSHIP_AMBIGUOUS", "basis": "NONE"}   # 0.4.4 (review E13): two dates, no 'respectively'
                    if len(persons) == 1 and len(roles) == 2:      # 0.4.4 (review E13): 'appointed CFO and Treasurer, effective D1 and D2, respectively'
                        rr_ = re.search(rf"(?:[Ee]ffective|with effect from) (?:as of |on |from )?(?P<a>{DATE_ANY}),? and (?:on |from )?(?P<b>{DATE_ANY}),? respectively", clause)
                        if rr_:
                            raw_ = rr_.group("a") if role == roles[0][0] else rr_.group("b")
                            base_date = {**parse_date(raw_), "span": [cs + rr_.start(), cs + rr_.end()], "basis": "EFFECTIVE_EXPLICIT"}
                    if len(persons) > 1:                         # Q11: 'X and Y ..., effective D1 and D2, respectively' - one date per person, in order
                        rm_ = re.search(rf"(?:[Ee]ffective|with effect from) (?:as of |on |from )?(?P<a>{DATE_ANY}),? and (?:on |from )?(?P<b>{DATE_ANY}),? respectively", clause)
                        if rm_ and len(persons) == 2:
                            raw_ = rm_.group("a") if person == persons[0] else rm_.group("b")
                            base_date = {**parse_date(raw_), "span": [cs + rm_.start(), cs + rm_.end()], "basis": "EFFECTIVE_EXPLICIT"}
                    ev_date = _apply_initial(base_date, ini, sent, cs, cs + ps, action, rule, text_pred, (subj or {}).get("kind"))
                    unit_ = re.match(r"\s*of (?:the Company['\u2019]s|its|our) (?P<u>(?:[A-Z][\w&-]*,? (?:and )?){1,5}(?:segment|division|business unit|business|unit|group|region))\b",
                                     sent[role_end_abs:]) if role and role_end_abs is not None else None
                    role_shown = f"{role} of the {unit_.group('u')}" if unit_ else role      # 0.4.6 (4th review A05): 'President of the Industrial Solutions segment'
                    events.append({"rule": rule if not trans else "V2-CON-NEW", "action": act_, "person": person, "transition_role": trans, "role": (f"{norm_role(role)} of the {unit_.group('u')}" if unit_ and norm_role(role) else norm_role(role)), "role_text": role_shown, "role_basis": role_basis if role else None,
                                   "succ": next((n[2] for n in names(clause) if n[0] == m.start("succ")), m.group("succ")) if rule == "V2-APP-SUC" and m.group("succ") else None,
                                   "subject_kind": (subj or {}).get("kind"),
                                   "subject_spans": list((subj or {}).get("spans") or []),
                                   "modality": "TENTATIVE" if tentative else "ASSERTED", "conditional": conditional, "clause": [cs, ce], "clause_index": ci, "pred": [cs + ps, cs + pe],   # Q13-E
                                   "role_end": cs + rbase + rend if roles else None, "pairing": pairing, "date": ev_date, "end": end_, "held_titles": held, "restated": restated})
        if clause_subject and clause_subject.get("kind") != "OBJECT":
            prev_subject = clause_subject
        if not kept:
            ns = [n for n in names(clause)]
            if ns and MGMT_WORDS.search(clause) and not RE_HISTORICAL.search(clause):
                unresolved.append(_unresolved([cs, ce], [n[2] for n in ns], "names a person with a management word but no supported predicate", clause))
    for n in names(sent):
        if n[2] not in used_names and MGMT_WORDS.search(sent) and not any(n[2] in (u.get("persons") or []) for u in unresolved) \
                and not any(n[2] in (h.get("persons") or []) for h in hazards) and not any(h["kind"] in ("HISTORICAL", "NON_FACTUAL") for h in hazards):
            unresolved.append(_unresolved([0, len(sent)], [n[2]], "a named person not resolved into an event, a hazard or a non-event", sent))
    roles_of = dict(context.get("roles_of") or {})
    held_of = dict(context.get("held_of") or {})
    for nm_, rl_ in sroles.items():                          # Q11: a title the sentence gives a person ('X, the CIO of Acme, Inc. (the "Company"), ...')
        if rl_:
            roles_of.setdefault(nm_, rl_[0])
    for n in names(sent):
        tail = sent[n[1]:]
        rm = re.match(rf",\s+(?:the |our |its |the Company['\u2019]s )?(?P<role>{ROLE}(?: and {ROLE})?)[,.]", tail) or re.match(rf"\s+(?:currently |now )?serves as (?:the |our |its )?(?:Company['\u2019]s )?(?P<role>{ROLE})\b", tail)   # Q11: also at the end of a sentence
        if rm and not RE_HON_ONLY.match(n[2]):
            roles_of[n[2]] = rm.group("role")
            issuer_ = re.match(r",\s+(?:our |its |the Company['\u2019]s )", tail) or re.match(rf"\s+(?:currently |now )?serves as (?:the |our |its )?(?:Company['\u2019]s )?{ROLE}(?: of the (?:Company|Registrant))?\.", tail) \
                or re.match(rf",\s+(?:the )?{ROLE}(?: and {ROLE})? of the (?:Company|Registrant)\b", tail)
            if issuer_:                                       # 0.4.5: a title stated as the issuer's (our / its / the Company's / of the Company)
                held_of[n[2]] = rm.group("role")
        cm_ = re.match(rf"['\u2019]s current (?:title|role|position) is (?:the |its |our )?(?P<role>{ROLE})\b", tail)   # Q13-E
        if cm_ and not RE_HON_ONLY.match(n[2]):   # Q13-E
            held_of[n[2]] = cm_.group("role")                 # 0.4.5 (2nd review N14): "Mr. Halloway's current title is President."   # Q13-E
    for e in events:                                          # 0.4.5 (2nd review N6): a title the person leaves is no longer held
        if e["action"] == "DEPARTURE" and e.get("role") and held_of.get(e["person"]) and norm_role(held_of[e["person"]]) in (e["role"], None):
            held_of.pop(e["person"], None)
    succ_hits = [(sm_.start("n"), sm_.end("n"), None, sm_.group("r")) for sm_ in RE_SUCC_AS.finditer(sent)]
    for pm_ in re.finditer(rf"\bsucceed(?:s|ed)? (?P<pro>him|her) as {ROLE_PRE}(?P<r>{ROLE})", sent):     # 0.4.5: the pronoun is the one other person named before it
        app_ = next((e for e in events if e["rule"] == "V2-APP-SUCP"), None)
        others = list(dict.fromkeys([k_ for k_ in _KNOWN] + [n_[2] for n_ in names(sent[:pm_.start()]) if not RE_HON_ONLY.match(n_[2])]))
        others = [o_ for o_ in others if app_ is None or o_ != app_["person"]]      # the one other person named so far in the section
        g_ = "M" if pm_.group("pro") == "him" else "F"
        if len(others) == 1 and _CUES.get(others[0]) in (None, g_):
            succ_hits.append((pm_.start("pro"), pm_.end("pro"), others[0], pm_.group("r")))
    for a_, b_, who_, r_raw in succ_hits:                    # 0.4.5: 'X will succeed / to succeed Y as R' - Y leaves R (implied; same date and modality; marked)
        ys = [n_[2] for n_ in names(sent) if n_[0] == a_]
        y = who_ or (ys[0] if ys else sent[a_:b_])
        r_ = norm_role(r_raw)
        app = next((e for e in events if e["action"] == "APPOINTMENT" and e.get("role") == r_ and e["person"] != y), None)
        if app is None or RE_HON_ONLY.match(y) or any(e["person"] == y and e.get("role") == r_ for e in events):
            continue
        events.append({**app, "rule": "V2-DEP-IMPL", "action": "DEPARTURE", "person": y, "role_text": r_raw, "role_basis": "IMPLIED_BY_SUCCESSION",
                       "succ": None, "subject_kind": "OBJECT", "subject_spans": [[a_, b_]], "implied_by_succession": app["person"],
                       "transition_role": False, "held_titles": [], "end": None})
    for e in [e for e in events if e["rule"] == "V2-APP-SUC" and e["role"] is None and e.get("succ")]:   # Q10: 'X succeeds Y, who ... retire as R' - X takes Y's stated role
        rs = [x for x in events if x["action"] == "DEPARTURE" and x["role"] and (x["person"] == e["succ"] or surname(x["person"]) == surname(e["succ"]))]
        if rs:
            events.remove(e)
            for x in rs:
                events.append({**e, "role": x["role"], "role_text": x["role_text"], "role_basis": "SUCCESSION_SAME_SENTENCE"})
    for m in re.finditer(rf"(?P<n>(?:(?:Mr|Ms|Mrs|Dr)\.\s+)?{TOKEN}(?:(?: [A-Z]\.)?(?: {PARTICLE})* {TOKEN})*)['\u2019]s (?:service|tenure|term) as {ROLE_PRE}(?P<r>{ROLE})\s+(?:ended|terminated|concluded|ceased)\b", sent):
        who = next((n[2] for n in names(sent) if n[0] <= m.start("n") < n[1] or n[0] == m.start("n")), None)   # Q11: "Ms. X's service as interim CEO ended on that date"
        if who and not RE_HON_ONLY.match(who) and not NEG.search(sent[m.start():m.end()]):
            d_on = RE_ON.search(sent, m.end())
            dd = {**parse_date(d_on.group("raw")), "span": [d_on.start(), d_on.end()], "basis": "ON_ADJACENT"} if d_on and d_on.start() - m.end() < 4 else \
                {"state": "NOT_STATED", "value": None, "raw": None, "span": None, "basis": "NONE"}
            dd.setdefault("event_date", None)
            dd.setdefault("narrative_date", None)
            events.append({"rule": "V2-DEP-SVC", "action": "DEPARTURE", "person": who, "role": norm_role(m.group("r")), "role_text": m.group("r"), "role_basis": "SAME_SENTENCE",
                           "succ": None, "subject_kind": "SUBJECT", "subject_spans": [[m.start("n"), m.end("n")]], "modality": "ASSERTED", "clause": [m.start(), m.end()],
                           "clause_index": 0, "pred": [m.start(), m.end()], "role_end": m.end("r"), "pairing": None, "date": dd, "end": None, "held_titles": []})
            used_names.add(who)
    single = [e["person"] for e in events if e["person"] and e["subject_kind"] in ("SUBJECT", "PRONOUN", "INHERITED", "RELATIVE")]
    return {"events": events, "hazards": hazards, "unresolved": unresolved, "routine": bool(RE_ROUTINE.search(sent)),
            "last_subject": single[-1] if single and len(set(single)) == 1 else None,
            "next_context": {"seen": list(dict.fromkeys(list(context.get("seen") or []) + [n[2] for n in names(sent)])), "cues": cues, "roles_of": roles_of,
                             "known": list(dict.fromkeys(list(context.get("known") or []) + [n[2] for n in names(sent) if not RE_HON_ONLY.match(n[2])])),
                             "issuers": issuers, "orgs": list(context.get("orgs") or []), "held_of": held_of, "doc_year": context.get("doc_year")}}
