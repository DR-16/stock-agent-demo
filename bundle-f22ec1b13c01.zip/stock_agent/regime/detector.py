"""Regime Detector — 独立组件,不与 Meta 或 Risk 层耦合。

原则:
  * 输入是原始市场数据(SPY/VIX 价格历史)
  * 输出是 RegimeSnapshot(dataclass,serializable)
  * detect() 只读 <= as_of 的 bar,任何 leakage 会被 test 抓到
"""
from __future__ import annotations

import math
from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Optional

import numpy as np
import pandas as pd

TRADING_DAYS = 252


@dataclass
class RegimeSnapshot:
    detector_version: str
    as_of: datetime
    trend_regime: str          # "uptrend" | "sideways" | "downtrend" | "unknown"
    volatility_regime: str     # "low" | "medium" | "high" | "extreme" | "unknown"
    overall_stance: str        # "risk_on" | "risk_off" | "neutral"
    features: dict = field(default_factory=dict)
    data_quality: float = 0.0  # 0-1,依据可得指标数

    def to_dict(self) -> dict:
        d = asdict(self)
        d["as_of"] = self.as_of.isoformat() if isinstance(self.as_of, datetime) else str(self.as_of)
        return d


class RegimeDetector(ABC):
    version: str = "0.0.0"

    @abstractmethod
    def detect(self, as_of: datetime,
               benchmark_history: pd.DataFrame,
               vix_history: Optional[pd.DataFrame] = None) -> RegimeSnapshot:
        ...

    def _empty(self, as_of: datetime, reason: str) -> RegimeSnapshot:
        return RegimeSnapshot(
            detector_version=self.version,
            as_of=as_of,
            trend_regime="unknown",
            volatility_regime="unknown",
            overall_stance="neutral",
            features={"reason": reason},
            data_quality=0.0,
        )


class SimpleTrendVolatilityRegime(RegimeDetector):
    """V0:SPY vs 200MA/50MA + VIX 分档。

    features:
      spy_close, spy_sma50, spy_sma200
      trend_strength_200 = spy / sma200 - 1
      trend_strength_50 = spy / sma50 - 1
      vix_close(若有)
      spy_realized_vol_63d_ann(fallback)
    """
    version = "0.1.0-trend-vix"

    # 阈值(可未来学习/tune)
    TREND_UP_THRESHOLD = 0.03      # spy 高于 200MA 3% 以上算 uptrend
    TREND_DOWN_THRESHOLD = -0.03
    VIX_LOW = 15.0
    VIX_HIGH = 25.0
    VIX_EXTREME = 35.0
    REALIZED_VOL_LOW = 0.12         # 年化 12% 以下 low
    REALIZED_VOL_HIGH = 0.25
    REALIZED_VOL_EXTREME = 0.40

    def detect(self, as_of, benchmark_history, vix_history=None):
        if benchmark_history is None or benchmark_history.empty:
            return self._empty(as_of, "no benchmark history")
        bench = _slice_to(benchmark_history, as_of)
        if len(bench) < 200:
            return self._empty(as_of, f"benchmark bars < 200 (got {len(bench)})")

        close = bench["Close"].dropna()
        spy_now = float(close.iloc[-1])
        sma50 = float(close.iloc[-50:].mean())
        sma200 = float(close.iloc[-200:].mean())
        ret = close.pct_change().dropna()
        rv_63d_ann = float(ret.iloc[-63:].std() * math.sqrt(TRADING_DAYS)) if len(ret) >= 63 else None

        trend_strength_200 = spy_now / sma200 - 1 if sma200 > 0 else 0.0
        trend_strength_50 = spy_now / sma50 - 1 if sma50 > 0 else 0.0

        if trend_strength_200 >= self.TREND_UP_THRESHOLD:
            trend_regime = "uptrend"
        elif trend_strength_200 <= self.TREND_DOWN_THRESHOLD:
            trend_regime = "downtrend"
        else:
            trend_regime = "sideways"

        vix_now = None
        vol_source = "spy_realized"
        if vix_history is not None and not vix_history.empty:
            vix_slice = _slice_to(vix_history, as_of)
            if not vix_slice.empty and "Close" in vix_slice.columns:
                vix_now = float(vix_slice["Close"].dropna().iloc[-1])
                vol_source = "vix"

        if vix_now is not None:
            if vix_now >= self.VIX_EXTREME:
                vol_regime = "extreme"
            elif vix_now >= self.VIX_HIGH:
                vol_regime = "high"
            elif vix_now < self.VIX_LOW:
                vol_regime = "low"
            else:
                vol_regime = "medium"
        elif rv_63d_ann is not None:
            if rv_63d_ann >= self.REALIZED_VOL_EXTREME:
                vol_regime = "extreme"
            elif rv_63d_ann >= self.REALIZED_VOL_HIGH:
                vol_regime = "high"
            elif rv_63d_ann < self.REALIZED_VOL_LOW:
                vol_regime = "low"
            else:
                vol_regime = "medium"
        else:
            vol_regime = "unknown"

        # 综合 stance
        stance = "neutral"
        if trend_regime == "uptrend" and vol_regime in ("low", "medium"):
            stance = "risk_on"
        elif trend_regime == "downtrend" or vol_regime in ("high", "extreme"):
            stance = "risk_off"

        features = {
            "spy_close": spy_now,
            "spy_sma50": sma50,
            "spy_sma200": sma200,
            "trend_strength_vs_200ma": round(trend_strength_200, 4),
            "trend_strength_vs_50ma": round(trend_strength_50, 4),
            "spy_realized_vol_63d_ann": round(rv_63d_ann, 4) if rv_63d_ann else None,
            "vix_close": round(vix_now, 3) if vix_now is not None else None,
            "volatility_source": vol_source,
            "bars_used": len(bench),
        }

        # data quality:有 SPY 200 bars=0.6,加 VIX=0.9,加 realized vol=0.7-0.8
        dq = 0.6
        if vix_now is not None:
            dq = 0.9
        elif rv_63d_ann is not None:
            dq = 0.75

        return RegimeSnapshot(
            detector_version=self.version,
            as_of=as_of,
            trend_regime=trend_regime,
            volatility_regime=vol_regime,
            overall_stance=stance,
            features=features,
            data_quality=round(dq, 2),
        )


def _slice_to(df: pd.DataFrame, as_of: datetime) -> pd.DataFrame:
    """截断到 <= as_of;去 tz。"""
    if df is None or df.empty:
        return pd.DataFrame()
    idx = df.index
    if getattr(idx, "tz", None) is not None:
        df = df.copy()
        df.index = idx.tz_localize(None)
    cutoff = pd.Timestamp(as_of.date() if hasattr(as_of, "date") else as_of)
    return df.loc[:cutoff]
