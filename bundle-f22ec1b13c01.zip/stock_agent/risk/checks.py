"""独立 Risk Checks — 每个是纯函数,输入具体维度,输出 RiskFlag(或 None)。

设计:
  * 每 check 只关心一个维度
  * 阈值来自经验/常识,后续可 tune
  * checks 返回 None → 该维度无 flag
  * 阈值单调:extreme > high > medium
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd


@dataclass(frozen=True)
class RiskFlag:
    dimension: str
    level: str            # "medium" | "high" | "extreme"
    value: Optional[float]
    threshold: Optional[float]
    rationale: str

    LEVEL_ORDER = ("medium", "high", "extreme")

    def penalty(self) -> float:
        """conviction score 扣减量。"""
        return {"medium": 0.10, "high": 0.20, "extreme": 0.40}.get(self.level, 0.0)

    def to_dict(self) -> dict:
        return {
            "dimension": self.dimension,
            "level": self.level,
            "value": self.value,
            "threshold": self.threshold,
            "rationale": self.rationale,
        }


# -------- 每个 check(输入是最原始 feature,输出 RiskFlag 或 None) --------


def check_volatility(realized_vol_ann: Optional[float]) -> Optional[RiskFlag]:
    if realized_vol_ann is None:
        return None
    if realized_vol_ann > 0.80:
        return RiskFlag("volatility", "extreme", realized_vol_ann, 0.80,
                        f"63d 年化波动 {realized_vol_ann:.0%} 远高于市场均值")
    if realized_vol_ann > 0.60:
        return RiskFlag("volatility", "high", realized_vol_ann, 0.60,
                        f"63d 年化波动 {realized_vol_ann:.0%}")
    if realized_vol_ann > 0.40:
        return RiskFlag("volatility", "medium", realized_vol_ann, 0.40,
                        f"63d 年化波动 {realized_vol_ann:.0%}")
    return None


def check_liquidity(avg_dollar_volume: Optional[float]) -> Optional[RiskFlag]:
    if avg_dollar_volume is None:
        return None
    if avg_dollar_volume < 1_000_000:
        return RiskFlag("liquidity", "extreme", avg_dollar_volume, 1e6,
                        f"日均成交额 ${avg_dollar_volume/1e6:.2f}M,极低流动性")
    if avg_dollar_volume < 5_000_000:
        return RiskFlag("liquidity", "high", avg_dollar_volume, 5e6,
                        f"日均成交额 ${avg_dollar_volume/1e6:.2f}M")
    if avg_dollar_volume < 20_000_000:
        return RiskFlag("liquidity", "medium", avg_dollar_volume, 2e7,
                        f"日均成交额 ${avg_dollar_volume/1e6:.2f}M,中小盘流动性")
    return None


def check_drawdown(max_drawdown_2y: Optional[float]) -> Optional[RiskFlag]:
    if max_drawdown_2y is None:
        return None
    if max_drawdown_2y < -0.60:
        return RiskFlag("drawdown", "extreme", max_drawdown_2y, -0.60,
                        f"2Y 最大回撤 {max_drawdown_2y:.0%}")
    if max_drawdown_2y < -0.40:
        return RiskFlag("drawdown", "high", max_drawdown_2y, -0.40,
                        f"2Y 最大回撤 {max_drawdown_2y:.0%}")
    if max_drawdown_2y < -0.25:
        return RiskFlag("drawdown", "medium", max_drawdown_2y, -0.25,
                        f"2Y 最大回撤 {max_drawdown_2y:.0%}")
    return None


def check_tail_risk(daily_returns: pd.Series) -> Optional[RiskFlag]:
    """负偏或厚尾:skewness < -1 或 kurtosis > 6。"""
    if daily_returns is None or len(daily_returns) < 60:
        return None
    r = daily_returns.dropna()
    if len(r) < 60 or r.std() == 0:
        return None
    skew = float(_skewness(r))
    kurt = float(_kurtosis(r))
    if skew < -1.5 or kurt > 10:
        return RiskFlag("tail_risk", "high", min(skew, kurt), None,
                        f"负偏 skew={skew:.2f} / 厚尾 kurt={kurt:.2f}")
    if skew < -1.0 or kurt > 6:
        return RiskFlag("tail_risk", "medium", min(skew, kurt), None,
                        f"偏度 skew={skew:.2f} / 峰度 kurt={kurt:.2f}")
    return None


def check_disagreement(expert_signals: list[float]) -> Optional[RiskFlag]:
    if len(expert_signals) < 2:
        return None
    std = float(np.std(expert_signals, ddof=0))
    if std > 0.7:
        return RiskFlag("expert_disagreement", "high", std, 0.7,
                        f"5 专家 signal std={std:.2f}")
    if std > 0.5:
        return RiskFlag("expert_disagreement", "medium", std, 0.5,
                        f"5 专家 signal std={std:.2f}")
    return None


def check_bull_bear_conflict(bull_signal: Optional[float],
                             bear_signal: Optional[float]) -> Optional[RiskFlag]:
    """Bull 和 Bear 都很强 → 论据两面都够强 → 结果不确定。"""
    if bull_signal is None or bear_signal is None:
        return None
    bull = abs(bull_signal)
    bear_pos = abs(bear_signal)
    both = min(bull, bear_pos)
    if both > 0.5:
        return RiskFlag("bull_bear_conflict", "high", both, 0.5,
                        f"Bull={bull:.2f} 与 Bear={bear_pos:.2f} 双方均强,论据两面对峙")
    if both > 0.3:
        return RiskFlag("bull_bear_conflict", "medium", both, 0.3,
                        f"Bull/Bear 两侧均有实质论据(min={both:.2f})")
    return None


def check_data_quality(mean_expert_data_quality: Optional[float]) -> Optional[RiskFlag]:
    if mean_expert_data_quality is None:
        return None
    if mean_expert_data_quality < 0.4:
        return RiskFlag("data_quality", "high", mean_expert_data_quality, 0.4,
                        f"专家平均 data quality {mean_expert_data_quality:.0%}")
    if mean_expert_data_quality < 0.6:
        return RiskFlag("data_quality", "medium", mean_expert_data_quality, 0.6,
                        f"专家平均 data quality {mean_expert_data_quality:.0%}")
    return None


def check_data_freshness(max_freshness_days: Optional[int]) -> Optional[RiskFlag]:
    if max_freshness_days is None:
        return None
    if max_freshness_days > 200:
        return RiskFlag("data_freshness", "high", float(max_freshness_days), 200.0,
                        f"最陈旧数据 {max_freshness_days} 天前")
    if max_freshness_days > 120:
        return RiskFlag("data_freshness", "medium", float(max_freshness_days), 120.0,
                        f"最陈旧数据 {max_freshness_days} 天前")
    return None


def check_meta_uncertainty(meta_confidence: Optional[float]) -> Optional[RiskFlag]:
    if meta_confidence is None:
        return None
    if meta_confidence < 0.20:
        return RiskFlag("prediction_uncertainty", "high", meta_confidence, 0.20,
                        f"Meta confidence {meta_confidence:.2f}")
    if meta_confidence < 0.35:
        return RiskFlag("prediction_uncertainty", "medium", meta_confidence, 0.35,
                        f"Meta confidence {meta_confidence:.2f}")
    return None


def check_regime_hostility(overall_stance: Optional[str],
                           volatility_regime: Optional[str],
                           signal_direction: Optional[float]) -> Optional[RiskFlag]:
    """regime = risk_off 且 signal > 0 → 顺风逆的情况。extreme 波动无论方向都 flag。"""
    if volatility_regime == "extreme":
        return RiskFlag("market_regime", "high", None, None,
                        "波动极端 regime,建议减小仓位")
    if overall_stance == "risk_off" and signal_direction is not None and signal_direction > 0:
        return RiskFlag("market_regime", "medium", None, None,
                        "market regime = risk_off 但持看多 signal,顺风逆")
    if volatility_regime == "high":
        return RiskFlag("market_regime", "medium", None, None,
                        "波动 high regime")
    return None


# 组合层留 stub,单资产场景下不激活
def check_concentration(*_args, **_kwargs) -> Optional[RiskFlag]:
    return None  # Portfolio 层:Phase 5


def check_correlation(*_args, **_kwargs) -> Optional[RiskFlag]:
    return None  # Portfolio 层:Phase 5


def check_event_risk(*_args, **_kwargs) -> Optional[RiskFlag]:
    return None  # 需要 calendar API:Phase 5


# -------- helpers --------


def _skewness(x: pd.Series) -> float:
    x = x.dropna().values.astype(float)
    n = len(x)
    if n < 3:
        return 0.0
    mean = x.mean()
    std = x.std(ddof=0)
    if std == 0:
        return 0.0
    return float(np.mean(((x - mean) / std) ** 3))


def _kurtosis(x: pd.Series) -> float:
    x = x.dropna().values.astype(float)
    n = len(x)
    if n < 4:
        return 0.0
    mean = x.mean()
    std = x.std(ddof=0)
    if std == 0:
        return 0.0
    return float(np.mean(((x - mean) / std) ** 4) - 3)  # excess kurtosis
