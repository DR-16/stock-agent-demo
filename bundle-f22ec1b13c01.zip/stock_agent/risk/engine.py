"""Risk Engine — 消费 Meta+Expert+Regime,输出 RiskAdjustedDecision。

不变式(强制):
  * raw_signal_preserved == meta_output.signal_score
  * raw_probability_preserved == meta_output.probability_positive
  * raw_confidence_preserved == meta_output.confidence
  * 未修改任何 ExpertOutput / MetaOutput 对象
  * 未修改任何底层数据(context 只读)
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Optional

import numpy as np
import pandas as pd

from ..models.base import ModelOutput
from ..regime.detector import RegimeSnapshot
from .checks import (
    RiskFlag,
    check_volatility, check_liquidity, check_drawdown, check_tail_risk,
    check_disagreement, check_bull_bear_conflict,
    check_data_quality, check_data_freshness,
    check_meta_uncertainty, check_regime_hostility,
    check_concentration, check_correlation, check_event_risk,
)


class RiskLevel(str, Enum):
    HIGH = "high"          # conviction 高
    MEDIUM = "medium"
    LOW = "low"
    AVOID = "avoid"

    @classmethod
    def from_score(cls, score: float) -> "RiskLevel":
        if score >= 0.7:
            return cls.HIGH
        if score >= 0.4:
            return cls.MEDIUM
        if score >= 0.2:
            return cls.LOW
        return cls.AVOID


@dataclass
class RiskAdjustedDecision:
    """Risk Engine 输出。原始预测在 preserved 字段里回填,不覆盖。"""
    engine_version: str
    asset: str
    as_of: datetime

    # ---- 保留的原始 Meta 字段(spec 强制不可覆盖)----
    raw_signal_preserved: Optional[float]
    raw_probability_preserved: Optional[float]
    raw_confidence_preserved: Optional[float]

    # ---- Risk 决策 ----
    conviction: RiskLevel                        # high / medium / low / avoid
    conviction_score: float                       # 0-1
    position_size_hint: float                     # 0-1,仅提示
    risk_flags: list[RiskFlag] = field(default_factory=list)
    aggregate_risk_score: float = 0.0             # 0-1
    notes: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "engine_version": self.engine_version,
            "asset": self.asset,
            "as_of": self.as_of.isoformat() if isinstance(self.as_of, datetime) else str(self.as_of),
            "raw_signal_preserved": self.raw_signal_preserved,
            "raw_probability_preserved": self.raw_probability_preserved,
            "raw_confidence_preserved": self.raw_confidence_preserved,
            "conviction": self.conviction.value,
            "conviction_score": self.conviction_score,
            "position_size_hint": self.position_size_hint,
            "risk_flags": [f.to_dict() for f in self.risk_flags],
            "aggregate_risk_score": self.aggregate_risk_score,
            "notes": self.notes,
        }


class RiskEngine:
    """独立组件。evaluate() 只读输入,输出 decision。"""

    version = "0.1.0-phase4"

    def evaluate(self,
                 meta_output: ModelOutput,
                 expert_outputs: list[ModelOutput],
                 challenge_outputs: list[ModelOutput],
                 price_history: pd.DataFrame,
                 regime: Optional[RegimeSnapshot] = None) -> RiskAdjustedDecision:

        asset = meta_output.asset
        as_of = meta_output.as_of

        # ---- 收集技术风险 features(用副本,不动 price_history) ----
        realized_vol = None
        max_dd = None
        avg_dv = None
        tail_flag = None

        if price_history is not None and not price_history.empty and "Close" in price_history.columns:
            close = price_history["Close"].dropna()
            ret = close.pct_change().dropna()
            if len(ret) >= 63:
                realized_vol = float(ret.iloc[-63:].std() * np.sqrt(252))
            if len(close) >= 60:
                w = close.iloc[-min(len(close), 504):]
                peak = w.cummax()
                dd = (w / peak - 1)
                max_dd = float(dd.min())
            if "Volume" in price_history.columns and len(close) >= 20:
                vol = price_history["Volume"].dropna()
                if len(vol) >= 20:
                    avg_dv = float((close.iloc[-20:] * vol.iloc[-20:]).mean())
            tail_flag = check_tail_risk(ret)

        # ---- expert-level features ----
        expert_signals = [o.signal_score for o in expert_outputs
                          if o.signal_score is not None]
        expert_dqs = [o.data_quality for o in expert_outputs if o.data_quality is not None]
        mean_dq = float(np.mean(expert_dqs)) if expert_dqs else None
        freshness = [o.data_freshness_days for o in expert_outputs
                     if o.data_freshness_days is not None]
        max_fresh = int(max(freshness)) if freshness else None

        # ---- challenge features ----
        bull = next((o for o in challenge_outputs if o.model_name == "bull_challenge"), None)
        bear = next((o for o in challenge_outputs if o.model_name == "bear_challenge"), None)
        bull_s = bull.signal_score if bull else None
        bear_s = bear.signal_score if bear else None

        # ---- regime features ----
        stance = regime.overall_stance if regime else None
        vol_regime = regime.volatility_regime if regime else None

        # ---- 汇总所有 checks ----
        candidates = [
            check_volatility(realized_vol),
            check_liquidity(avg_dv),
            check_drawdown(max_dd),
            tail_flag,
            check_disagreement(expert_signals),
            check_bull_bear_conflict(bull_s, bear_s),
            check_data_quality(mean_dq),
            check_data_freshness(max_fresh),
            check_meta_uncertainty(meta_output.confidence),
            check_regime_hostility(stance, vol_regime, meta_output.signal_score),
            check_concentration(),
            check_correlation(),
            check_event_risk(),
        ]
        flags = [f for f in candidates if f is not None]

        # ---- conviction 派生 ----
        base_conviction = meta_output.confidence or 0.0
        total_penalty = sum(f.penalty() for f in flags)
        conviction_score = max(0.0, base_conviction - total_penalty)
        conviction = RiskLevel.from_score(conviction_score)

        # position hint:只对看多 signal 给正数;看空或无 signal 给 0
        sig = meta_output.signal_score
        if sig is None or sig <= 0:
            pos_hint = 0.0
        else:
            base_hint = {
                RiskLevel.HIGH: 1.0,
                RiskLevel.MEDIUM: 0.5,
                RiskLevel.LOW: 0.25,
                RiskLevel.AVOID: 0.0,
            }[conviction]
            # signal 强度也参与:signal=1 → 1.0,signal=0.3 → 0.3
            pos_hint = round(base_hint * min(1.0, abs(sig)), 3)

        aggregate_risk = _aggregate_risk_score(flags)

        notes = [
            "Risk Engine 只调整 conviction 与仓位提示;未修改任何 Expert 或 Meta 的原始预测。",
            "position_size_hint 仅为可读性建议,不构成买卖信号;仓位决策由用户自行承担。",
        ]
        if not flags:
            notes.append("当前规则集未触发任何风险 flag,不等同于无风险。")

        decision = RiskAdjustedDecision(
            engine_version=self.version,
            asset=asset,
            as_of=as_of,
            raw_signal_preserved=meta_output.signal_score,
            raw_probability_preserved=meta_output.probability_positive,
            raw_confidence_preserved=meta_output.confidence,
            conviction=conviction,
            conviction_score=round(conviction_score, 3),
            position_size_hint=pos_hint,
            risk_flags=flags,
            aggregate_risk_score=round(aggregate_risk, 3),
            notes=notes,
        )

        # ---- 不变式自检(spec #8)----
        assert decision.raw_signal_preserved == meta_output.signal_score
        assert decision.raw_probability_preserved == meta_output.probability_positive
        assert decision.raw_confidence_preserved == meta_output.confidence

        return decision


def _aggregate_risk_score(flags: list[RiskFlag]) -> float:
    """把 flag levels 归一到 0-1 综合风险分。"""
    if not flags:
        return 0.0
    # 每 flag: medium=0.15, high=0.3, extreme=0.5
    weight = {"medium": 0.15, "high": 0.30, "extreme": 0.50}
    total = sum(weight.get(f.level, 0) for f in flags)
    # 用饱和函数控制上限
    return min(1.0, total)
