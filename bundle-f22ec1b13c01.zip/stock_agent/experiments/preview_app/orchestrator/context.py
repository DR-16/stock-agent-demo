"""Q7 - the unified research context of ONE case, built fresh for every run (nothing is shared between cases or runs).

A case (q7-case-1.0.0) wraps one research input in the experts' own input contract te-input-1.1.0 (issuer, as_of, provenance, the three
experimental sections, the id of a synthetic price dataset) plus the case's NOT_APPLICABLE declarations. The context keeps identity, sources,
times, currencies / units and data gaps, and gives each expert ONLY the part its contract allows:

  technical, macro   -> the price dataset (PRICE_DATASET_CONTRACT_V1 file), after its security, as_of date and the availability of EVERY series in it
                        (the security, the benchmark, the macro proxies) are checked against as_of
  fundamental / valuation / information -> its own section + the common block (fixture_id, as_of, issuer, provenance, data_source)

Checks made here (before any expert runs): strict JSON (no NaN / Infinity / duplicate keys), the te-input top level (a problem confined to one
section refuses only that expert), the price dataset's identity, and an audit of times (as UTC instants; Q7's declared 21:00Z availability of daily
closes), issuers (declared issuer_id and the identity written in the text), currencies, scales and percent-like rates. Audit values echoed into the
record are sanitised (text, small integers, finite numbers only). Nothing is filled in: a missing value stays missing.
"""
from __future__ import annotations

import copy
import hashlib
import json
import math
import re
import sys
import unicodedata
from datetime import datetime, timedelta, timezone
from pathlib import Path

Q7 = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Q7 / "adapters/impl/information_q10"))    # Q9: the te-input contract / strict JSON of the Q9 successor roots (byte-identical in all three)
from shared import contract as TE  # noqa: E402
from shared import strict_json  # noqa: E402
from shared import schema as TE_SCHEMA  # noqa: E402

CASES = Q7 / "fixtures/cases"
INDEX = Q7 / "fixtures/q7_index.json"
DECLARATIONS = Q7 / "fixtures/q7_price_declarations.json"
CASE_VERSION = "q7-case-1.0.0"
CONTEXT_VERSION = "q9-context-1.0.0"   # Q9 successor of q8-context-1.3.0 (real price datasets: no synthetic currency / time convention); Q8: a registrant NAME no longer decides identity
REAL_INDEX = Q7 / "data/real/price_index.json"       # Q9: real price datasets built by realdata/build.py (file, hash, security, as_of_date, declaration)
REAL_KIND = "PUBLIC_SOURCE_INTERNAL_TEST"
CASE_KEYS = {"q7_case_version", "case_id", "label", "purpose", "research_input", "applicability"}
SECTIONS = ("fundamental", "valuation", "information")
RATE_FIELDS = ("discount_rate", "terminal_growth", "stage_growth")
ISSUER_SEPARATORS = "|｜:："
RE_SYN_ID = re.compile(r"\bsynthetic[\s-]+issuer[\s:：]+(SYN-[A-Z0-9][A-Z0-9-]*)", re.I)
RE_ID_TOKEN = re.compile(r"^(SYN-[A-Z0-9][A-Z0-9-]*)\b", re.I)
COMMON_PATHS = ("$.contract_version", "$.fixture_id", "$.data_source", "$.provenance", "$.as_of", "$.issuer")
SAFE_INT = 2 ** 53


class CaseError(Exception):
    def __init__(self, code: str, detail: str = ""):
        super().__init__(f"{code}: {detail}")
        self.code, self.detail = code, detail


def sha256_of(o) -> str:
    b = o if isinstance(o, bytes) else (o.encode("utf-8") if isinstance(o, str) else
                                         json.dumps(o, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False).encode("utf-8"))
    return hashlib.sha256(b).hexdigest()


def _echo(x):
    """a value copied from the input into the record: text (at most 300 characters), a safe integer, a finite number, a boolean or null; anything
    else is replaced by a marker (it is never rounded or guessed)"""
    if x is None or isinstance(x, bool):
        return x
    if isinstance(x, str):
        return x[:300]
    if isinstance(x, int):
        return x if abs(x) <= SAFE_INT else f"<UNSAFE_INTEGER {len(str(abs(x)))} digits>"
    if isinstance(x, float):
        return x if math.isfinite(x) else "<NON_FINITE>"
    return f"<{type(x).__name__}>"


def registry() -> dict:
    """the synthetic price datasets (Q7 index) and, in Q9, the real ones (data/real/price_index.json)"""
    reg = json.loads(INDEX.read_text(encoding="utf-8"))
    if REAL_INDEX.exists():
        real = json.loads(REAL_INDEX.read_text(encoding="utf-8"))["price_datasets"]
        reg["price_datasets"] = {**reg["price_datasets"], **real}
    return reg


def list_cases() -> list:
    """every case file, each read on its own: a file that cannot be read or parsed is listed as unreadable, it never hides the others"""
    out = []
    for p in sorted(CASES.glob("*.json")):
        try:
            d = parse_case_text(p.read_text(encoding="utf-8"))
            out.append({"case_id": d["case_id"], "label": d.get("label"), "purpose": d.get("purpose"), "file": p.name})
        except (CaseError, OSError, UnicodeDecodeError) as e:
            out.append({"case_id": None, "label": f"无法读取：{p.name}（{getattr(e, 'code', type(e).__name__)}）", "purpose": None, "file": p.name, "unreadable": True})
    return out


def parse_case_text(text: str) -> dict:
    """strict: duplicate keys, NaN / Infinity, BOM and over-deep input are refused (the experts' own strict_json)"""
    try:
        doc = strict_json.loads(text)
    except strict_json.StrictJSONError as e:
        raise CaseError(e.code, e.detail)
    return check_case(doc)


def check_case(doc) -> dict:
    if not isinstance(doc, dict):
        raise CaseError("CASE_NOT_OBJECT", type(doc).__name__)
    extra = sorted(set(doc) - CASE_KEYS)
    if extra:
        raise CaseError("CASE_UNKNOWN_FIELD", ", ".join(extra))
    for k in ("q7_case_version", "case_id", "research_input"):
        if k not in doc:
            raise CaseError("CASE_FIELD_MISSING", k)
    if doc["q7_case_version"] != CASE_VERSION:
        raise CaseError("CASE_VERSION", str(doc["q7_case_version"])[:40])
    if not isinstance(doc["case_id"], str) or not doc["case_id"] or len(doc["case_id"]) > 80:
        raise CaseError("CASE_ID_INVALID", str(doc["case_id"])[:80])
    for k, n in (("label", 200), ("purpose", 1000)):
        if k in doc and (not isinstance(doc[k], str) or len(doc[k]) > n):
            raise CaseError("CASE_FIELD_INVALID", f"{k}: a text of at most {n} characters")
    app = doc.get("applicability", {})
    if not isinstance(app, dict):
        raise CaseError("APPLICABILITY_NOT_OBJECT", type(app).__name__)
    for e, v in app.items():
        if e not in ("technical", "macro") + SECTIONS or not isinstance(v, dict) or set(v) != {"status", "reason"} or v.get("status") != "NOT_APPLICABLE" \
                or not isinstance(v.get("reason"), str) or not v["reason"].strip() or len(v["reason"]) > 500:
            raise CaseError("APPLICABILITY_INVALID", f"{e}: a declaration is exactly {{'status': 'NOT_APPLICABLE', 'reason': '<why, at most 500 characters>'}} for a known expert")
    return doc


def load_case(case_id: str) -> tuple:
    """(case document, its raw text): read fresh each time, from ONE read of the file's bytes, which must parse strictly and, when the case is in
    fixtures/q7_index.json, have the registered SHA-256 (a changed case file is refused, never silently used)"""
    reg = registry().get("cases", {})
    for p in sorted(CASES.glob("*.json")):
        try:
            raw = p.read_bytes()
            text = raw.decode("utf-8")
            doc = parse_case_text(text)
        except (CaseError, OSError, UnicodeDecodeError):
            continue
        if doc.get("case_id") == case_id:
            if case_id in reg and hashlib.sha256(raw).hexdigest() != reg[case_id]:
                raise CaseError("CASE_IDENTITY_MISMATCH", f"{p.name} differs from its registered hash")
            return doc, text
    raise CaseError("CASE_UNKNOWN", case_id)


def registered_case_sha(case_id: str) -> str | None:
    """sha256_of the registered case document with this id (None when there is none): lets a run say whether its input was edited"""
    try:
        return sha256_of(load_case(case_id)[0])
    except CaseError:
        return None


def _dt(s):
    """an aware datetime by the experts' own contract rule (te-input parse_datetime), or None: a naive, date-only or malformed timestamp is never
    guessed into a time zone, so it is reported as unreadable and never compared"""
    return TE_SCHEMA.parse_datetime(s)


def _day(s):
    """a calendar date written YYYY-MM-DD, as an aware midnight UTC (used only for dates that the contracts define as dates)"""
    return TE_SCHEMA.parse_datetime(f"{s}T00:00:00Z") if isinstance(s, str) and len(s) == 10 else None


def _declarations() -> dict:
    """Q7's conventions for the synthetic datasets, plus each real dataset's own declaration (currency as inferred, daily-bar availability unknown)"""
    d = json.loads(DECLARATIONS.read_text(encoding="utf-8"))
    if REAL_INDEX.exists():
        for k, v in json.loads(REAL_INDEX.read_text(encoding="utf-8"))["price_datasets"].items():
            d["datasets"][k] = v["declaration"]
    return d


def _bar_available(day, hhmmss: str) -> datetime | None:
    """the UTC instant at which a daily close dated `day` counts as available (Q7's declared convention for synthetic data)"""
    d = _day(day)
    if d is None:
        return None
    h, m, s_ = (int(x) for x in hhmmss.split(":"))
    return d + timedelta(hours=h, minutes=m, seconds=s_)


def _price_dataset(ri: dict, issuer: dict, as_of_utc: datetime, app: dict) -> dict:
    pid = ri.get("price_dataset")
    sec = issuer.get("security")
    if pid is None:
        if sec is None:
            return {"state": "NOT_APPLICABLE", "code": "NO_LISTED_SECURITY", "path": "$.research_input.issuer.security",
                    "reason": "发行人没有可交易证券代码（security = null），基于价格的专家不适用"}
        if "technical" in app and "macro" in app:
            return {"state": "NOT_APPLICABLE", "code": "DECLARED_NOT_APPLICABLE", "path": "$.applicability",
                    "reason": "案例没有提供价格数据集，并声明 Technical、Macro 都不适用（各自的理由见各自的状态原因）"}
        return {"state": "MISSING", "code": "PRICE_DATASET_MISSING", "path": "$.research_input.price_dataset",
                "reason": f"发行人有证券代码 {_echo(sec)}，但案例没有提供价格数据集"}
    reg = registry()["price_datasets"].get(pid) if isinstance(pid, str) else None
    decl = _declarations()["datasets"].get(pid) if isinstance(pid, str) else None
    if reg is None or decl is None:
        return {"state": "REJECTED", "code": "PRICE_DATASET_UNKNOWN", "path": "$.research_input.price_dataset", "reason": f"价格数据集 {_echo(pid)} 不在登记表或声明表里"}
    path = Q7 / reg["file"]
    raw = path.read_bytes() if path.exists() else b""
    actual = hashlib.sha256(raw).hexdigest() if raw else None
    if actual != reg["sha256"]:
        return {"state": "REJECTED", "code": "PRICE_DATASET_IDENTITY_MISMATCH", "path": "$.research_input.price_dataset", "reason": f"{pid} 的文件哈希与登记不符"}
    if reg["security"] != sec:
        return {"state": "REJECTED", "code": "PRICE_DATASET_SECURITY_MISMATCH", "path": "$.research_input.price_dataset",
                "reason": f"价格数据集属于 {reg['security']}，发行人证券是 {_echo(sec)}"}
    if reg["as_of_date"] != as_of_utc.date().isoformat():
        return {"state": "REJECTED", "code": "PRICE_DATASET_AS_OF_MISMATCH", "path": "$.research_input.price_dataset",
                "reason": f"价格数据集 as_of_date {reg['as_of_date']} 与案例 as_of 的 UTC 日期 {as_of_utc.date().isoformat()} 不同"}
    doc = json.loads(raw.decode("utf-8"))
    series_last = {}
    for name, ser in (doc.get("series") or {}).items():
        dates = [r[0] for r in ((ser or {}).get("rows") or []) if isinstance(r, list) and r and isinstance(r[0], str)]
        series_last[name] = max(dates) if dates else None                           # the latest date, whatever the row order
    late = {}
    for name, d in series_last.items():
        if d is None:
            continue
        if decl.get("daily_bar_available_utc") is None:          # Q9 real data: the availability time is unknown; only the bar date can be compared
            dd = _day(d)
            if dd is None or dd.date() > as_of_utc.date():
                late[name] = {"last_row": d, "available_utc": None, "rule": "bar date after the as_of date (availability time unknown)"}
            continue
        avail = _bar_available(d, decl["daily_bar_available_utc"])
        if avail is None or avail > as_of_utc:
            late[name] = {"last_row": d, "available_utc": avail.isoformat() if avail else None}
    if late:
        return {"state": "REJECTED", "code": "PRICE_DATASET_AFTER_AS_OF", "path": "$.research_input.price_dataset",
                "reason": f"数据集里这些序列的最后一根日线按约定（{decl['daily_bar_available_utc']}Z 可得）晚于 as_of {as_of_utc.isoformat()} 或日期不可读：" +
                          "；".join(f"{k} {v['last_row']}" for k, v in sorted(late.items())), "late_series": late}
    ser = (doc.get("series") or {}).get(sec) or {}
    rows, cols = ser.get("rows") or [], ser.get("columns") or []
    last = rows[-1] if rows else None
    close = last[1 + cols.index("Close")] if last and "Close" in cols else None
    return {"state": "OK", "dataset_id": pid, "file": reg["file"], "sha256": actual, "security": reg["security"], "as_of_date": reg["as_of_date"],
            "provenance": doc.get("provenance"), "series": sorted(series_last), "series_last_row": series_last, "n_rows_security": len(rows),
            "last_row_date": last[0] if last else None, "last_close": close,
            "last_bar_available_utc": (_bar_available(last[0], decl["daily_bar_available_utc"]).isoformat() if last and decl.get("daily_bar_available_utc") else None),
            "availability": decl.get("availability", "Q7_CONVENTION"), "currency": decl["currency"],
            "currency_source": decl.get("currency_basis") or "fixtures/q7_price_declarations.json（Q7 对合成数据的声明；数据文件本身不声明币种）"}


def _norm_name(s) -> str:
    """NFKC + casefold, the '(synthetic ...)' / '(test fixture)' marker removed, letters and digits of every script kept"""
    s = unicodedata.normalize("NFKC", str(s))
    s = re.sub(r"\((?:synthetic|test fixture|合成)[^)]*\)", " ", s, flags=re.I)
    return re.sub(r"[\W_]+", "", s.casefold())


def _header_value(s: str, word: str):
    """the value of a header line '<word><sep><value>' (sep: | ｜ : ：), or None"""
    if not s.casefold().startswith(word):
        return None
    rest = s[len(word):].lstrip()
    if not rest or rest[0] not in ISSUER_SEPARATORS:
        return None
    return re.split(r"[|｜]", rest[1:].strip(), maxsplit=1)[0].strip() or None


def _text_identity(d: dict) -> dict:
    """issuer identity written in a document's HEADER lines, read line by line (linear time): 'Issuer' and 'Registrant' lines with any common
    separator. A value that starts with a SYN-... id is an id (only that token); any other value is a name. 'synthetic issuer SYN-...' is read on
    those header lines only (a counterparty mentioned in the body is not the document's issuer)"""
    ids, names = set(), set()
    for ln in str(d.get("text") or "").splitlines():
        s = unicodedata.normalize("NFKC", ln).replace("\u00a0", " ").strip()
        for word in ("issuer", "registrant"):
            val = _header_value(s, word)
            if val is None:
                continue
            for m in RE_SYN_ID.finditer(val):
                ids.add(m.group(1).upper())
            tok = RE_ID_TOKEN.match(val)
            if tok:
                ids.add(tok.group(1).upper())
            else:
                names.add(val.split("(")[0].strip()[:160] or val[:160])
    return {"ids": sorted(ids), "registrant_names": sorted(names)}


def _audit_fundamental(f, as_of_utc, times, units, gaps) -> None:
    if not isinstance(f.get("periods"), list):
        gaps.append({"code": "AUDIT_SKIPPED_MALFORMED_SECTION", "path": "$.research_input.fundamental.periods", "detail": "periods 不是列表：审计跳过，由 Fundamental 自己的契约检查处理"})
        return
    for per in f["periods"]:
        if isinstance(per, dict):
            av = _dt(per.get("available_at"))
            pe = _day(per.get("period_end"))
            times.append({"where": f"fundamental.periods[FY{_echo(per.get('fiscal_year'))}]", "occurred": _echo(per.get("period_end")), "published": None,
                          "available": _echo(per.get("available_at")), "after_as_of": bool(av and av > as_of_utc), "unreadable": av is None,
                          "order_inconsistent": bool(pe and av and pe > av)})
            units.append({"where": f"fundamental.periods[FY{_echo(per.get('fiscal_year'))}]", "currency": _echo(per.get("currency")), "scale": _echo(per.get("scale"))})
    if isinstance(f.get("currency"), str):
        units.append({"where": "fundamental", "currency": _echo(f["currency"]), "section": "fundamental"})


def _audit_information(i, issuer, as_of_utc, times, issuers, gaps) -> None:
    if not isinstance(i.get("documents"), list):
        gaps.append({"code": "AUDIT_SKIPPED_MALFORMED_SECTION", "path": "$.research_input.information.documents", "detail": "documents 不是列表：审计跳过，由 Information 自己的契约检查处理"})
        return
    want_name = _norm_name(issuer.get("name", ""))
    for d in i["documents"]:
        if not isinstance(d, dict):
            continue
        did = d.get("document_id") if isinstance(d.get("document_id"), str) else _echo(d.get("document_id"))
        av, pub = _dt(d.get("availability_timestamp")), _dt(d.get("document_timestamp"))
        times.append({"where": f"information.documents[{did}]", "occurred": None, "published": _echo(d.get("document_timestamp")),
                      "available": _echo(d.get("availability_timestamp")), "after_as_of": bool(av and av > as_of_utc), "unreadable": av is None,
                      "order_inconsistent": bool(pub and av and pub > av),
                      "note": None if av else "可得时间缺失或不是带时区的时间戳：不猜测，由专家按其契约处理"})
        ti = _text_identity(d)
        names_ok = [n for n in ti["registrant_names"] if want_name and _norm_name(n) == want_name]
        names_bad = [n for n in ti["registrant_names"] if n not in names_ok]          # Q8: advisory only - identity is never decided from a company NAME in text
        if d.get("issuer_id") != issuer["issuer_id"] or any(x != issuer["issuer_id"] for x in ti["ids"]):
            state = "FOREIGN"
        elif ti["ids"]:
            state = "MATCH"
        elif names_ok:                   # Q8 review: a name in the text agrees - advisory, never an identity match
            state = "TEXT_NAME_AGREES"
        else:
            state = "TEXT_IDENTITY_NOT_FOUND"
        if names_bad:
            gaps.append({"code": "TEXT_NAME_DIFFERS", "path": f"information.documents[{did}]",
                         "detail": f"正文页眉里的公司名称 {names_bad} 与分析对象名称不同：只作提示，不据此判断身份（身份以结构化字段为准），请人工核对"})
        issuers.append({"where": f"information.documents[{did}]", "document_id": did, "issuer_id": _echo(d.get("issuer_id")),
                        "text_issuer_ids": ti["ids"], "registrant_names": ti["registrant_names"], "state": state, "matches_case_issuer": state == "MATCH"})


def _audit_valuation(v, as_of_utc, sec, times, units, gaps, real: bool = False) -> None:
    m = v.get("market") if isinstance(v.get("market"), dict) else None
    vf = v.get("financials") if isinstance(v.get("financials"), dict) else None
    if m is None or vf is None:
        gaps.append({"code": "AUDIT_SKIPPED_MALFORMED_SECTION", "path": "$.research_input.valuation", "detail": "market 或 financials 不是对象：审计跳过，由 Valuation 自己的契约检查处理"})
    if m is not None:
        pd_ = _day(m.get("price_date"))
        if real:          # Q9: the time a real closing price became available is unknown; only its date is compared (never Q7's 21:00Z convention)
            times.append({"where": "valuation.market.price_date", "occurred": _echo(m.get("price_date")), "published": None, "available": None,
                          "availability": "UNKNOWN_DATE_ONLY", "after_as_of": bool(pd_ and pd_.date() > as_of_utc.date()), "unreadable": pd_ is None,
                          "stale_days": (as_of_utc.date() - pd_.date()).days if pd_ else None})
        else:
            pav = _bar_available(m.get("price_date"), _declarations()["valuation_market_price"]["daily_price_available_utc"])
            times.append({"where": "valuation.market.price_date", "occurred": _echo(m.get("price_date")), "published": None, "available": pav.isoformat() if pav else None,
                          "after_as_of": bool(pav and pav > as_of_utc), "unreadable": pav is None,
                          "stale_days": (as_of_utc.date() - pd_.date()).days if pd_ else None})
        units.append({"where": "valuation.market", "price_currency": _echo(m.get("price_currency")), "shares_scale": _echo(m.get("shares_scale")), "section": "valuation"})
        if sec is None and m.get("price") is not None:
            gaps.append({"code": "MARKET_PRICE_WITHOUT_SECURITY", "path": "$.research_input.valuation.market.price",
                         "detail": "发行人没有证券代码（security = null），估值部分却给了市价：这个价格的来源无法和任何价格序列核对"})
    if vf is not None:
        vav = _dt(vf.get("available_at")) if vf.get("available_at") else None
        times.append({"where": "valuation.financials", "occurred": f"FY{_echo(vf.get('fiscal_year'))}", "published": None, "available": _echo(vf.get("available_at")),
                      "after_as_of": bool(vav and vav > as_of_utc), "unreadable": vav is None})
        units.append({"where": "valuation.financials", "currency": _echo(vf.get("currency")), "scale": _echo(vf.get("scale")), "section": "valuation"})
    if isinstance(v.get("currency"), str):
        units.append({"where": "valuation", "currency": _echo(v["currency"]), "section": "valuation"})
    a = v.get("assumptions") if isinstance(v.get("assumptions"), dict) else {}
    dcf = a.get("dcf") if isinstance(a.get("dcf"), dict) else {}
    sc = dcf.get("scenarios") if isinstance(dcf.get("scenarios"), dict) else {}
    for name, s_ in sc.items():
        for k in RATE_FIELDS:
            x = s_.get(k) if isinstance(s_, dict) else None
            if isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(float(x)) and abs(x) > 1:
                gaps.append({"code": "PERCENT_SCALE_SUSPECT", "path": f"$.research_input.valuation.assumptions.dcf.scenarios.{_echo(name)}.{k}",
                             "detail": f"{_echo(x)}：比率字段大于 1，像是把百分数当成了小数；Q7 不改写，由 Valuation 自己的边界检查决定是否拒绝"})


def build(case: dict) -> dict:
    """the unified context of one case. Top-level problems that make the common block unknowable (issuer, as_of, provenance, data source) make it
    unusable; a problem confined to one section only refuses that section's expert. The audits never raise on a malformed section: they skip it
    with a gap, and the expert's own contract check decides"""
    ri = case["research_input"]
    probs = TE.fixture_problems(ri)
    def in_sec(path: str, s: str) -> bool:
        return path == f"$.{s}" or path.startswith(f"$.{s}.") or path.startswith(f"$.{s}[")
    sec_probs = {s: [p for p in probs if in_sec(str(p.get("path", "")), s)] for s in SECTIONS}
    price_probs = [p for p in probs if in_sec(str(p.get("path", "")), "price_dataset")]
    top_probs = [p for p in probs if p not in price_probs and not any(p in v for v in sec_probs.values())]
    if not top_probs:
        try:
            _dt(ri.get("as_of")).astimezone(timezone.utc)
        except (OverflowError, AttributeError, ValueError) as e:
            top_probs = [{"code": "AS_OF_OUT_OF_RANGE", "path": "$.as_of", "detail": f"{type(e).__name__}: as_of cannot be expressed as a UTC instant"}]
    ctx = {"context_version": CONTEXT_VERSION, "case_id": case["case_id"], "label": case.get("label"), "purpose": case.get("purpose"),
           "case_sha256": sha256_of(case), "top_level_problems": [{k: _echo(v) for k, v in p.items()} for p in top_probs],
           "section_problems": {s: [{k: _echo(v) for k, v in p.items()} for p in ps] for s, ps in sec_probs.items() if ps},
           "price_dataset_problems": [{k: _echo(v) for k, v in p.items()} for p in price_probs],
           "applicability": copy.deepcopy(case.get("applicability") or {})}
    if top_probs:
        ctx["usable"] = False
        ctx["input_fingerprint"] = sha256_of({"case": case})
        return ctx
    split_src = {k: v for k, v in ri.items() if not (k in SECTIONS and sec_probs[k]) and not (k == "price_dataset" and price_probs)}
    sp = TE.split(split_src)
    for s in SECTIONS:                            # a section with a contract problem reaches its expert only as the problem (see run.py), never repaired
        if sec_probs[s]:
            sp[s] = None
    common = sp["common"]
    issuer, as_of = common["issuer"], common["as_of"]
    as_of_utc = _dt(as_of).astimezone(timezone.utc)
    app = case.get("applicability") or {}
    pdx = _price_dataset(ri, issuer, as_of_utc, app) if not price_probs else {
        "state": "REJECTED", "code": "PRICE_DATASET_FIELD_INVALID", "path": "$.research_input.price_dataset",
        "reason": "price_dataset 字段不合输入契约：" + "；".join(f"{_echo(p.get('code'))} {_echo(p.get('path'))}" for p in price_probs)}
    inputs = {s: {"section": copy.deepcopy(sp[s]), "common": copy.deepcopy(common)} for s in SECTIONS}
    pinput = {"price_dataset": {k: pdx.get(k) for k in ("state", "code", "reason", "dataset_id", "file", "sha256", "security", "as_of_date")}}
    inputs["technical"] = copy.deepcopy(pinput)
    inputs["macro"] = copy.deepcopy(pinput)
    times, issuers, units, gaps = [], [], [], []
    f, v, i = sp["fundamental"], sp["valuation"], sp["information"]
    for name, sec_, fn in (("fundamental", f, lambda: _audit_fundamental(f, as_of_utc, times, units, gaps)),
                           ("information", i, lambda: _audit_information(i, issuer, as_of_utc, times, issuers, gaps)),
                           ("valuation", v, lambda: _audit_valuation(v, as_of_utc, issuer.get("security"), times, units, gaps, common.get("data_source") == REAL_KIND))):
        if isinstance(sec_, dict):
            try:
                fn()
            except Exception as e:            # an audit defect is recorded; it never stops the experts
                gaps.append({"code": "AUDIT_ERROR", "path": f"$.research_input.{name}", "detail": f"Q7 审计出错（{type(e).__name__}）：该部分的审计不完整"})
    for s, ps in sec_probs.items():
        for p in ps:
            gaps.append({"code": "SECTION_CONTRACT_PROBLEM", "path": _echo(p.get("path")), "detail": f"{_echo(p.get('code'))}：只有 {s} 专家的输入受影响"})
    if pdx["state"] == "OK":
        ld = _day(pdx["last_row_date"])
        stale = (as_of_utc.date() - ld.date()).days if ld else None
        times.append({"where": f"price_dataset[{pdx['dataset_id']}].last_row", "occurred": pdx["last_row_date"], "published": None,
                      "available": pdx["last_bar_available_utc"], "after_as_of": False, "stale_days": stale})
        if stale and stale > 0:
            gaps.append({"code": "PRICE_SERIES_ENDS_BEFORE_AS_OF", "path": "$.research_input.price_dataset",
                         "detail": f"证券价格序列最后一行是 {pdx['last_row_date']}，比 as_of 的 UTC 日期早 {stale} 天"})
        vp = next((t for t in times if t["where"] == "valuation.market.price_date"), None)
        if vp and vp.get("occurred") and vp["occurred"] != pdx["last_row_date"]:
            gaps.append({"code": "PRICE_DATE_DIFFERS", "path": "$.research_input.valuation.market.price_date",
                         "detail": f"估值市价日期 {vp['occurred']} 与价格序列最后一行 {pdx['last_row_date']} 不同：两个专家看的不是同一天的价格"})
    vp = next((t for t in times if t["where"] == "valuation.market.price_date"), None)
    if vp and isinstance(vp.get("stale_days"), int) and vp["stale_days"] > 0:
        gaps.append({"code": "VALUATION_PRICE_BEFORE_AS_OF", "path": "$.research_input.valuation.market.price_date",
                     "detail": f"估值市价日期 {vp['occurred']} 比 as_of 的 UTC 日期早 {vp['stale_days']} 天"})
    sec_curs = sorted({u.get("currency") for u in units if isinstance(u.get("currency"), str)} | {u.get("price_currency") for u in units if isinstance(u.get("price_currency"), str)})
    if len(sec_curs) > 1:
        gaps.append({"code": "CROSS_SECTION_CURRENCY_MISMATCH", "path": "$.research_input", "detail": f"案例的不同部分声明了不同币种 {sec_curs}：综合层不会跨部分比较金额"})
    vpc = next((u.get("price_currency") for u in units if u.get("where") == "valuation.market"), None)
    if pdx["state"] == "OK" and isinstance(vpc, str) and vpc != pdx["currency"]:
        gaps.append({"code": "PRICE_DATASET_CURRENCY_DIFFERS", "path": "$.research_input.valuation.market.price_currency",
                     "detail": f"估值市价币种 {vpc} 与 Q7 对价格数据集的币种声明 {pdx['currency']} 不同：不比较两者的价格"})
    if f is not None or v is not None:
        gaps.append({"code": "SECTION_ISSUER_UNVERIFIED", "path": "$.research_input.fundamental / valuation",
                     "detail": "te-input-1.1.0 的 Fundamental / Valuation 部分没有发行人字段，Q7 无法核实这些财务数字属于本案例发行人"})
    conflicts = {}
    for e, decl in app.items():
        present = (ri.get(e) is not None) if e in SECTIONS else (ri.get("price_dataset") is not None)
        if present:
            conflicts[e] = {"code": "APPLICABILITY_CONTRADICTS_INPUT", "path": f"$.applicability.{e}",
                            "detail": f"案例声明 {e} 不适用（{decl['reason'][:200]}），却又提供了它的输入：自相矛盾，Q7 不猜哪一个对"}
            gaps.append(conflicts[e])
    for s_ in SECTIONS:
        if sp[s_] is None and not sec_probs[s_]:
            decl = app.get(s_)
            gaps.append({"code": "SECTION_DECLARED_NOT_APPLICABLE" if decl else "SECTION_ABSENT", "path": f"$.research_input.{s_}",
                         "detail": decl["reason"][:300] if decl else f"案例没有提供 {s_} 输入，也没有声明不适用"})
    if pdx["state"] != "OK":
        gaps.append({"code": pdx["code"], "path": pdx["path"], "detail": pdx["reason"]})
    for t in times:
        if t.get("after_as_of"):
            gaps.append({"code": "INPUT_AFTER_AS_OF", "path": t["where"], "detail": f"可得/发生时间 {t.get('available') or t.get('occurred')} 晚于 as_of {as_of}：专家必须排除它（运行后核查）"})
        if t.get("order_inconsistent"):
            gaps.append({"code": "TIME_ORDER_INCONSISTENT", "path": t["where"],
                         "detail": f"发生/发布时间 {t.get('occurred') or t.get('published')} 晚于声明的可得时间 {t.get('available')}：时间字段自相矛盾"})
    for x in issuers:
        if x["state"] == "FOREIGN":
            gaps.append({"code": "FOREIGN_ISSUER_DOCUMENT", "path": x["where"],
                         "detail": f"文件声明发行人 {x['issuer_id']}，正文发行人标识 {x['text_issuer_ids']}，注册人 {x['registrant_names']}，与案例发行人 {issuer['issuer_id']} 不一致：专家必须排除它（运行后核查）"})
        elif x["state"] == "TEXT_IDENTITY_NOT_FOUND":
            gaps.append({"code": "ISSUER_TEXT_HEADER_ABSENT", "path": x["where"],
                         "detail": "正文页眉里没有发行人标识行：身份只依据结构化字段（见身份核对），正文不提供额外的核对"})
    fps = {e: sha256_of(inputs[e]) for e in inputs}
    fys = f.get("periods") if isinstance(f, dict) and isinstance(f.get("periods"), list) else []
    vfin = v.get("financials") if isinstance(v, dict) and isinstance(v.get("financials"), dict) else {}
    vfy = vfin.get("fiscal_year")
    ctx.update({"usable": True, "issuer": {k: _echo(x) for k, x in issuer.items()}, "as_of": as_of, "as_of_utc": as_of_utc.isoformat(),
                "as_of_utc_date": as_of_utc.date().isoformat(), "fixture_id": common["fixture_id"], "data_source": common["data_source"],
                "valuation_price_available_utc": None if common["data_source"] == REAL_KIND else _declarations()["valuation_market_price"]["daily_price_available_utc"],
                "sources": [{"source_id": f"research_input:{common['fixture_id']}", "kind": "TE_INPUT_1_1_0", "data_source": common["data_source"],
                             "provenance": common["provenance"], "sha256": sha256_of(ri)}] +
                           ([{"source_id": f"price_dataset:{pdx['dataset_id']}", "kind": "PRICE_DATASET_CONTRACT_V1",
                              "data_source": (pdx.get("provenance") or {}).get("source_kind") or "SYNTHETIC",
                              "provenance": pdx["provenance"], "sha256": pdx["sha256"]}] if pdx["state"] == "OK" else []),
                "section_identity": {"valuation_financials_fiscal_year": vfy if isinstance(vfy, int) and not isinstance(vfy, bool) and 1900 <= vfy <= 2100 else None,
                                     "fundamental_fiscal_years": sorted(p_["fiscal_year"] for p_ in fys if isinstance(p_, dict) and isinstance(p_.get("fiscal_year"), int)
                                                                        and not isinstance(p_.get("fiscal_year"), bool) and 1900 <= p_["fiscal_year"] <= 2100)},
                "price_input": pdx, "time_audit": times, "issuer_audit": issuers, "units_audit": units, "data_gaps": gaps, "applicability_conflicts": conflicts,
                "inputs": inputs, "expert_input_fingerprints": fps, "input_fingerprint": sha256_of({"case_sha256": ctx["case_sha256"], "experts": fps})})
    return ctx
