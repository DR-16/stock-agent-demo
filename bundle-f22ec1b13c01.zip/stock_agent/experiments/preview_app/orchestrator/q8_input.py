"""Q8 input adapter (q8-input 1.0.0): ONE input model for the form, the JSON editor and the run; data identity bound per item; conversion to the
experts' unchanged te-input-1.1.0. The experts' financial rules are not touched.

Case format q8-case-1.0.0 (a Q7 case keeps working as a LEGACY replay):
  case_id, label, purpose, as_of, subject {issuer_id, name, security, industry_class}, provenance, price_dataset, applicability,
  fundamental {currency, requests, assumptions, periods[ {... te period fields ..., identity} ]} | null,
  valuation {currency, requests, market {... , identity}, financials {..., identity}, assumptions} | null,
  information {requests, claims_to_verify, documents[ {... te document fields without issuer_id ..., identity} ]} | null,
  migration (optional: where a migrated case came from and what was added)
  identity = {issuer_id, source_id?, source_type (SYNTHETIC | USER_PROVIDED | AUTHORIZED_OTHER), security? (market only)}

Identity of one item (never 'verified'; the strongest state is consistency with the SYNTHETIC source registry):
  MATCH_SOURCE_REGISTRY   the item names a source in fixtures/q8_source_registry.json; that entry, the item's own declaration and the analysis subject
                          all name the same issuer, and the registered currency / scale / dates / security agree with the item
  MODIFIED_FROM_REGISTRY  the item names a registered source of the subject and its attributes agree, but its CONTENT differs from the registered
                          content (fixtures/q8_source_content.json): treated as user-modified data, not verified (the expert still runs)
  MATCH_USER_DECLARED     the item declares the subject's issuer, but no registered source backs it (a user statement, not checked against a source)
  MISSING                 a required identity field is absent (new-format cases: the expert is refused)
  CONFLICT                any of the above disagree (the expert is refused; the other experts still run)
  LEGACY_UNVERIFIED       a Q7-format case replayed: no identity field exists; nothing is filled in or upgraded
Nothing is inferred from the text of a document: identity comes only from these structured fields. A structured issuer id written in a document
header ('synthetic issuer SYN-...') that differs from the declared issuer is a CONFLICT (it never assigns an identity); company names in the text
are advisory only. Content equal to a registered source of ANOTHER issuer is a CONFLICT whatever the item declares. A source id may back one item
only. A case is a legacy replay only when it is, unchanged, a Q7 case file (a 'legacy' key in any other model is ignored, with a warning).
Q8 review fixes (one review round): registry kind / all attributes / content fingerprint / uniqueness / document id = source id / header ids /
market security registry / legacy authenticity / shares scale / source id type / big numbers / list shapes / valuation fiscal-year end.
"""
from __future__ import annotations

import copy
import hashlib
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

Q8 = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(Q8))
from orchestrator import context as C  # noqa: E402

VERSION = "q9-input 1.1.0"      # Q9 successor of q8-input 1.1.0: real-source registry + four-way identity display; 1.1.0 after the Q9 review; synthetic path unchanged
REAL_REGISTRY = Q8 / "data/real/source_registry.json"
REAL_KIND = "PUBLIC_SOURCE_INTERNAL_TEST"
CASE_FORMAT = "q8-case-1.0.0"
CASES_DIR = Q8 / "fixtures/q8_cases"
USER_DIR = Q8 / "fixtures/user_cases"
LEGACY_DIR = Q8 / "fixtures/cases"
REAL_DIR = Q8 / "data/real/cases"           # Q9: cases built from real snapshots by realdata/build.py
REAL_INDEX = Q8 / "data/real/case_index.json"
Q8_INDEX = Q8 / "fixtures/q8_index.json"
SOURCE_REGISTRY = Q8 / "fixtures/q8_source_registry.json"
SOURCE_CONTENT = Q8 / "fixtures/q8_source_content.json"
CONTENT_DROP = {"ANNUAL_STATEMENTS": ("identity", "source_document_id"), "VALUATION_FINANCIALS": ("identity",), "MARKET_QUOTE": ("identity",),
                "DOCUMENT": ("identity", "issuer_id")}
KIND_ATTRS = {"ANNUAL_STATEMENTS": ("fiscal_year", "currency", "scale", "available_at"), "VALUATION_FINANCIALS": ("fiscal_year", "currency", "scale", "available_at"),
              "MARKET_QUOTE": ("security", "currency", "price_date"), "DOCUMENT": ("document_timestamp", "availability_timestamp")}
FORM_SPEC = Q8 / "workbench/static/form_spec.json"
TOP_KEYS = {"case_format", "case_id", "label", "purpose", "as_of", "subject", "provenance", "price_dataset", "applicability", "fundamental", "valuation", "information", "migration"}
SECTIONS = ("fundamental", "valuation", "information")
SOURCE_TYPES = ("SYNTHETIC", "USER_PROVIDED", "AUTHORIZED_OTHER", "PUBLIC_SOURCE")
STATE_ZH = {"MATCH_SOURCE_REGISTRY": "与合成来源登记一致（合成登记，不是外部验证）", "MATCH_USER_DECLARED": "用户声明（没有来源登记可核对，未核实）",
            "MISSING": "身份字段缺失", "CONFLICT": "身份冲突", "LEGACY_UNVERIFIED": "旧格式／身份未核实",
            "MODIFIED_FROM_REGISTRY": "来源编号已登记，但内容与登记不同（视为用户修改，未核实）"}
SAFE_ID = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,79}$")


class InputError(Exception):
    def __init__(self, problems: list):
        super().__init__("; ".join(f"{p['path']}: {p['message']}" for p in problems)[:500])
        self.problems = problems


def _spec() -> dict:
    return json.loads(FORM_SPEC.read_text(encoding="utf-8"))


def _labels() -> dict:
    """path (with [] for list items) -> label, from the one form spec the page also uses"""
    out = {}
    for s in _spec()["sections"]:
        for f in s.get("fields", []):
            out[f["path"]] = f["label"]
        for lst in s.get("lists", []):
            for f in lst["fields"]:
                out[f"{lst['path']}[].{f['path']}"] = f["label"]
    return out


def label_of(path: str) -> str:
    generic = re.sub(r"\[\d+\]", "[]", path)
    lab = _labels().get(generic)
    if lab:
        return lab
    return generic.split(".")[-1]


def _p(path: str, code: str, message: str, fix: str, expert: str | None = None, severity: str = "ERROR") -> dict:
    return {"path": path, "label": label_of(path), "code": code, "message": message, "fix": fix, "expert": expert, "severity": severity}


def source_registry() -> dict:
    """the synthetic registry and, in Q9, the real-source registry (data/real/source_registry.json: what the system fetched, with its own checks)"""
    reg = json.loads(SOURCE_REGISTRY.read_text(encoding="utf-8"))
    if REAL_REGISTRY.exists():
        real = json.loads(REAL_REGISTRY.read_text(encoding="utf-8"))
        reg = {**reg, "sources": {**reg["sources"], **real["sources"]}, "securities": {**reg["securities"], **real["securities"]}}
    return reg


def content_sha(obj: dict, kind: str) -> str:
    """the fingerprint of one data item's own content (its identity fields left out; numbers by value)"""
    return C.sha256_of(_num_norm({k: v for k, v in obj.items() if k not in CONTENT_DROP[kind]}))


def source_content() -> dict:
    """source id -> {kind, sha256} of the registered content: synthetic (fixtures/q8_source_content.json) and real (what the system extracted)"""
    c = json.loads(SOURCE_CONTENT.read_text(encoding="utf-8"))["contents"]
    if REAL_REGISTRY.exists():
        c = {**c, **json.loads(REAL_REGISTRY.read_text(encoding="utf-8"))["contents"]}
    return c


REAL_STATE_ZH = {"MATCH_SOURCE_REGISTRY": "与本次取得的来源快照一致（系统核对内容；发行人归属取自来源提供的 CIK，不是外部验证）",
                 "MODIFIED_FROM_REGISTRY": "来源编号对应本次取得的快照，但内容与快照提取结果不同（视为用户修改，未核实）"}


REAL_REGISTRY_NOTE = ("真实来源登记：由 realdata/build.py 从本轮取得、记录在 network_log.jsonl 里的快照生成。与它一致只说明案例内容与系统从快照提取的结果"
                      "相同；发行人归属取自 SEC 提供的 CIK，不是外部验证")


def four_way(src: dict | None, state: str) -> dict:
    """the four kinds of statement the report keeps apart: what the source says, what the system checked, what the user declared, what is not verified
    (plus how the item was obtained - the selection rule, not a check). For content that differs from the snapshot, the source's statements are
    about the snapshot, not about this content, and none of the system's checks applies to it"""
    if not src or src.get("registry_kind") != "REAL_SNAPSHOT":
        return {}
    if state == "MODIFIED_FROM_REGISTRY":
        return {"source_says": [f"（修改前的快照）{x}" for x in src.get("source_says") or []], "system_checked": [],
                "user_declared": ["内容与快照提取结果不同：改动来自用户（或别处），系统没有核实"],
                "not_verified": ["系统对快照做的核对不适用于修改后的内容"] + list(src.get("not_verified") or []),
                "how_obtained": [f"（修改前的快照）{x}" for x in src.get("how_obtained") or []]}
    return {"source_says": list(src.get("source_says") or []),
            "system_checked": list(src.get("system_checked") or []) + ["案例里的内容与系统从快照提取的结果一致（本次运行时核对内容指纹；只证明内容相同，不证明发行人归属）"],
            "user_declared": [], "not_verified": list(src.get("not_verified") or []), "how_obtained": list(src.get("how_obtained") or [])}


def registered_model(case_id) -> tuple | None:
    """(model sha, kind) of the case file with this id: a registered Q8 case, a user-saved case or a Q7 case; None when there is none"""
    if not isinstance(case_id, str):
        return None
    try:
        m, kind, _, _ = load_case(case_id)
    except Exception:
        return None
    return model_sha(m), kind


def is_legacy(m) -> bool:
    """a legacy replay is a Q7 case file, unchanged: a 'legacy' key on any other model does not switch the identity checks off"""
    if not isinstance(m, dict) or not m.get("legacy"):
        return False
    reg = registered_model(m.get("case_id"))
    return reg is not None and reg[1] == "LEGACY_Q7" and reg[0] == model_sha(m)


def origin_of(model: dict) -> str:
    reg = registered_model(model.get("case_id")) if isinstance(model, dict) else None
    if reg and reg[0] == model_sha(model):
        return "SAVED_USER_CASE" if reg[1] == "USER" else "REAL_DATA_CASE" if reg[1] == "REAL" else "REGISTERED_CASE"
    return "EDITED_IN_WORKBENCH"


def _lst(x) -> list:
    return x if isinstance(x, list) else []


def _dt(s):
    return C._dt(s)


def blank_case() -> dict:
    """a new case: identity fields are required, nothing is pre-filled with numbers"""
    return {"case_format": CASE_FORMAT, "case_id": "NEW-CASE", "label": "新案例", "purpose": "", "as_of": "",
            "subject": {"issuer_id": "", "name": "", "security": None},
            "provenance": {"kind": "SYNTHETIC", "generator": "Q8 workbench form (case written by the user)"},
            "price_dataset": None, "fundamental": None, "valuation": None, "information": None}


# ------------------------------------------------------------------------------------------------------------- loading / legacy replay
def list_cases() -> list:
    out = []
    for kind, d in (("REAL", REAL_DIR), ("Q8", CASES_DIR), ("USER", USER_DIR), ("LEGACY_Q7", LEGACY_DIR)):
        for p in sorted(d.glob("*.json")) if d.exists() else []:
            try:
                doc = json.loads(p.read_text(encoding="utf-8"))
                out.append({"case_id": doc.get("case_id"), "label": doc.get("label"), "purpose": doc.get("purpose"), "kind": kind, "file": f"{d.name}/{p.name}"})
            except (ValueError, OSError) as e:
                out.append({"case_id": None, "label": f"无法读取：{p.name}（{type(e).__name__}）", "kind": kind, "file": f"{d.name}/{p.name}", "unreadable": True})
    return out


def from_q7_case(q7: dict) -> dict:
    """a Q7 case as a Q8 model, marked LEGACY: the te-input fields are carried over as they are; no identity field is created"""
    ri = q7["research_input"]
    m = {"case_format": CASE_FORMAT, "case_id": q7["case_id"], "label": q7.get("label"), "purpose": q7.get("purpose"), "as_of": ri.get("as_of"),
         "subject": copy.deepcopy(ri.get("issuer")), "provenance": copy.deepcopy(ri.get("provenance")), "price_dataset": ri.get("price_dataset"),
         "legacy": {"from_format": q7.get("q7_case_version"), "note": "旧格式回放：Q7 案例没有逐项身份字段；所有底层数据的身份显示为“旧格式／身份未核实”，系统没有补写或升级任何身份"}}
    if q7.get("applicability"):
        m["applicability"] = copy.deepcopy(q7["applicability"])
    for s in SECTIONS:
        m[s] = copy.deepcopy(ri.get(s)) if s in ri else None
    for k in ("title", "description", "contract_version", "fixture_id", "data_source"):
        if k in ri:
            m.setdefault("legacy", {})[f"te_{k}"] = ri[k]
    return m


def load_case(case_id: str) -> tuple:
    """(model, kind, raw text, file sha256) for a registered Q8 case, a user-saved case or a Q7 legacy case; read fresh, one read per file"""
    reg = json.loads(Q8_INDEX.read_text(encoding="utf-8")).get("cases", {}) if Q8_INDEX.exists() else {}
    for kind, d in (("REAL", REAL_DIR), ("Q8", CASES_DIR), ("USER", USER_DIR), ("LEGACY_Q7", LEGACY_DIR)):
        for p in sorted(d.glob("*.json")) if d.exists() else []:
            raw = p.read_bytes()
            try:
                text = raw.decode("utf-8")
                doc = json.loads(text)
            except (ValueError, UnicodeDecodeError):
                continue
            if doc.get("case_id") != case_id:
                continue
            sha = hashlib.sha256(raw).hexdigest()
            if kind == "REAL":
                ridx = json.loads(REAL_INDEX.read_text(encoding="utf-8")).get("cases", {}) if REAL_INDEX.exists() else {}
                if ridx.get(case_id) != sha:
                    raise InputError([_p("case_id", "CASE_IDENTITY_MISMATCH", f"真实数据案例文件 {p.name} 与构建时记录的哈希不同", "重新“获取数据”生成；不要直接改这个文件，改好后用“另存为”")])
            if kind == "Q8" and case_id in reg and reg[case_id] != sha:
                raise InputError([_p("case_id", "CASE_IDENTITY_MISMATCH", f"案例文件 {p.name} 与登记的哈希不同", "不要直接改登记的案例文件；改好后用“另存为”保存成新案例")])
            if kind == "LEGACY_Q7":
                q7, _ = C.load_case(case_id)        # the Q7 registered-hash check applies
                return from_q7_case(q7), kind, text, sha
            return parse_text(text), kind, text, sha
    raise InputError([_p("case_id", "CASE_UNKNOWN", f"找不到案例 {case_id}", "从案例列表里选择一个")])


def parse_text(text: str) -> dict:
    """strict JSON (no NaN / Infinity / duplicate keys) via the experts' own parser"""
    try:
        from shared import strict_json
        doc = strict_json.loads(text)
    except Exception as e:
        raise InputError([_p("$", getattr(e, "code", "JSON_INVALID"), f"不是合法的严格 JSON：{getattr(e, 'detail', str(e))[:200]}",
                             "检查高级 JSON 编辑框里的括号、逗号和引号；NaN / Infinity 不允许")])
    if isinstance(doc, dict) and "q7_case_version" in doc:
        return from_q7_case(C.check_case(doc))
    return doc


def _num_norm(o):
    """1.0 and 1 are the same number: JSON that passed through a browser cannot keep the difference, so the model fingerprint compares numbers by value"""
    if isinstance(o, dict):
        return {k: _num_norm(v) for k, v in o.items()}
    if isinstance(o, list):
        return [_num_norm(v) for v in o]
    if isinstance(o, float) and o.is_integer() and abs(o) < 2 ** 53:
        return int(o)
    return o


def model_sha(model: dict) -> str:
    return C.sha256_of(_num_norm(model))


def registered_model_sha(case_id: str) -> str | None:
    reg = registered_model(case_id)
    return reg[0] if reg else None


# ------------------------------------------------------------------------------------------------------------- structural checks (field level)
def _req(problems, obj, key, path, label_fix, expert=None):
    v = obj.get(key) if isinstance(obj, dict) else None
    if v is None or (isinstance(v, str) and not v.strip()):
        problems.append(_p(path, "REQUIRED_FIELD_MISSING", f"缺少「{label_of(path)}」", label_fix or f"在表单里填写「{label_of(path)}」；系统不会补 0 或猜测", expert))
        return False
    return True


def _datetime_ok(problems, obj, key, path, expert=None, required=True):
    v = obj.get(key) if isinstance(obj, dict) else None
    if v is None or v == "":
        if required:
            problems.append(_p(path, "REQUIRED_FIELD_MISSING", f"缺少「{label_of(path)}」", "填写带时区的时间，例如 2026-10-19T21:00:00Z；系统不会猜测时间", expert))
        return
    if _dt(v) is None:
        problems.append(_p(path, "DATETIME_INVALID_OR_WITHOUT_TIMEZONE", f"「{label_of(path)}」不是带时区的时间：{str(v)[:60]}", "写成 2026-10-19T21:00:00Z 这样的格式（结尾的 Z 表示 UTC）", expert))


def check_structure(m) -> list:
    """problems that stop the whole case (the common block) or a section; each names its field and how to fix it"""
    P = []
    if not isinstance(m, dict):
        return [_p("$", "CASE_NOT_OBJECT", "案例必须是一个 JSON 对象", "从模板开始，或用“新建案例”")]
    legacy = is_legacy(m)
    if m.get("legacy") and not legacy:
        P.append(_p("legacy", "LEGACY_FLAG_IGNORED", "这个输入不是原样的 Q7 案例，旧格式标记不生效：按新格式检查（每项数据都要有身份字段）",
                    "在每一期财报、市价、估值用财务和每份公告上填写身份；不需要删掉这个标记", None, "WARNING"))
    extra = sorted(set(m) - TOP_KEYS - {"legacy"})
    for k in extra:
        P.append(_p(k, "UNKNOWN_FIELD", f"不认识的顶层字段「{k}」", "删除它，或把内容放到对应的部分里"))
    if m.get("case_format") != CASE_FORMAT:
        P.append(_p("case_format", "CASE_FORMAT", f"案例格式应为 {CASE_FORMAT}", "用“新建案例”开始，或加载已有案例"))
    cid = m.get("case_id")
    if not isinstance(cid, str) or not SAFE_ID.match(cid or ""):
        P.append(_p("case_id", "CASE_ID_INVALID", "案例编号只能用字母、数字、短横线、点或下划线（1–80 个字符）", "例如 MY-CASE-1"))
    _datetime_ok(P, m, "as_of", "as_of")
    s = m.get("subject")
    if not isinstance(s, dict):
        P.append(_p("subject", "REQUIRED_FIELD_MISSING", "缺少分析对象", "填写公司标识、名称和行业"))
    else:
        _req(P, s, "issuer_id", "subject.issuer_id", "填写公司标识，例如 SYN-ORCHARD")
        _req(P, s, "name", "subject.name", "填写公司名称")
        if _req(P, s, "industry_class", "subject.industry_class", "选择行业类别；系统不会默认") and s.get("industry_class") not in _spec()["enums"]["industry_class"]:
            P.append(_p("subject.industry_class", "VALUE_NOT_ALLOWED", "行业类别不在可选范围内", "从下拉框里选一个"))
    for sec in SECTIONS:
        if m.get(sec) is not None and not isinstance(m.get(sec), dict):
            P.append(_p(sec, "TYPE_OBJECT_EXPECTED", f"「{sec}」部分应是一个对象（或留空表示不提供）", "在表单里重新开启这一部分", sec))
    for sec, key in (("fundamental", "periods"), ("information", "documents")):
        v = m.get(sec).get(key) if isinstance(m.get(sec), dict) else None
        if v is not None and not isinstance(v, list):
            P.append(_p(f"{sec}.{key}", "TYPE_ARRAY_EXPECTED", f"「{label_of(sec + '.' + key)}」应是一个列表", "在表单里用“添加”按钮增加条目，或在 JSON 里改成 [ ... ]", sec))
        for n, it in enumerate(_lst(v)):
            if not isinstance(it, dict):
                P.append(_p(f"{sec}.{key}[{n}]", "TYPE_OBJECT_EXPECTED", f"第 {n + 1} 项不是一个对象", "删除这一项，用“添加”按钮重新添加", sec))

    def big(o, path):
        if isinstance(o, dict):
            for k, v in o.items():
                big(v, f"{path}.{k}" if path else str(k))
        elif isinstance(o, list):
            for n, v in enumerate(o):
                big(v, f"{path}[{n}]")
        elif isinstance(o, (int, float)) and not isinstance(o, bool) and abs(o) >= 2 ** 53:
            P.append(_p(path, "NUMBER_NOT_REPRESENTABLE", f"「{label_of(path)}」数字太大，无法精确表示：{o}", "检查数量级和量纲（例如用“百万”作量纲后填较小的数）"))
    big(m, "")
    if not legacy:
        _identity_field_checks(m, P)
    return P


def _source_id_ok(P, ident: dict, path: str, expert: str) -> None:
    v = ident.get("source_id")
    if v is not None and not (isinstance(v, str) and SAFE_ID.match(v)):
        P.append(_p(path, "SOURCE_ID_INVALID", f"「{label_of(path)}」应是一个编号（字母、数字、短横线），现在是：{str(v)[:60]}", "填写来源编号，或留空", expert))


def _identity_field_checks(m: dict, P: list) -> None:
    """new-format cases: the identity, unit and time fields each data item needs"""
    f = m.get("fundamental")
    if isinstance(f, dict):
        for n, per in enumerate(_lst(f.get("periods"))):
            base = f"fundamental.periods[{n}]"
            if not isinstance(per, dict):
                continue
            ident = per.get("identity") if isinstance(per.get("identity"), dict) else {}
            _req(P, ident, "issuer_id", f"{base}.identity.issuer_id", "填写这期财报属于哪家公司（公司标识）；缺失时 Fundamental 不会运行", "fundamental")
            _req(P, ident, "source_type", f"{base}.identity.source_type", "选择来源类型", "fundamental")
            _req(P, per, "currency", f"{base}.currency", "选择币种；系统不会默认任何币种", "fundamental")
            _req(P, per, "scale", f"{base}.scale", "选择金额量纲（元 / 千 / 百万 / 十亿）", "fundamental")
            _datetime_ok(P, per, "available_at", f"{base}.available_at", "fundamental")
            if per.get("shares_outstanding") is not None:
                _req(P, per, "shares_scale", f"{base}.shares_scale", "填了流通股数，就要选择股数量纲；系统不会默认", "fundamental")
            if "source_document_id" in per:
                P.append(_p(f"{base}.source_document_id", "DUPLICATE_IDENTITY_FIELD", "这一期还有一个旧的 source_document_id 字段",
                            "删掉它：Q8 只用“身份”里的来源编号，避免两处不一致", "fundamental"))
            _source_id_ok(P, ident, f"{base}.identity.source_id", "fundamental")
    v = m.get("valuation")
    if isinstance(v, dict):
        if v.get("market") is None:      # Q9: no market part at all (e.g. no price data obtained): one clear problem, not six identity / unit complaints
            P.append(_p("valuation.market", "MARKET_DATA_NOT_AVAILABLE", "没有市价与股本数据：Valuation 需要市价、价格日期和股数才能运行",
                        "真实公司：这个 as_of 没有价格快照（没有 Tiingo key、取价失败，或没有为这个 as_of 取过价格），重新点“获取数据”；"
                        "合成或自建案例：在表单里填写“市价与股本”", "valuation"))
        for part in (("market", "financials") if v.get("market") is not None else ("financials",)):
            obj = v.get(part) if isinstance(v.get(part), dict) else {}
            ident = obj.get("identity") if isinstance(obj.get("identity"), dict) else {}
            _req(P, ident, "issuer_id", f"valuation.{part}.identity.issuer_id", "填写这组数据属于哪家公司；缺失时 Valuation 不会运行", "valuation")
            _req(P, ident, "source_type", f"valuation.{part}.identity.source_type", "选择来源类型", "valuation")
            _source_id_ok(P, ident, f"valuation.{part}.identity.source_id", "valuation")
        mk = v.get("market") if isinstance(v.get("market"), dict) else None
        if mk is not None:
            _req(P, mk, "price_currency", "valuation.market.price_currency", "选择价格币种；系统不会默认任何币种", "valuation")
            _req(P, mk, "price_date", "valuation.market.price_date", "填写价格日期（YYYY-MM-DD）", "valuation")
            _req(P, mk, "shares_scale", "valuation.market.shares_scale", "选择股数量纲", "valuation")
        fi = v.get("financials") if isinstance(v.get("financials"), dict) else {}
        _req(P, fi, "currency", "valuation.financials.currency", "选择币种；系统不会默认任何币种", "valuation")
        _req(P, fi, "scale", "valuation.financials.scale", "选择金额量纲", "valuation")
        _datetime_ok(P, fi, "available_at", "valuation.financials.available_at", "valuation")
        _req(P, v, "currency", "valuation.currency", "选择估值币种", "valuation")
    i = m.get("information")
    if isinstance(i, dict):
        for n, d in enumerate(_lst(i.get("documents"))):
            base = f"information.documents[{n}]"
            if not isinstance(d, dict):
                continue
            ident = d.get("identity") if isinstance(d.get("identity"), dict) else {}
            _req(P, ident, "issuer_id", f"{base}.identity.issuer_id", "填写这份文件属于哪家公司；系统不会从正文里猜", "information")
            _req(P, ident, "source_type", f"{base}.identity.source_type", "选择来源类型", "information")
            _source_id_ok(P, ident, f"{base}.identity.source_id", "information")
            _datetime_ok(P, d, "availability_timestamp", f"{base}.availability_timestamp", "information")
            if "issuer_id" in d:
                P.append(_p(f"{base}.issuer_id", "DUPLICATE_IDENTITY_FIELD", "文件上还有一个旧的 issuer_id 字段", "删掉它：Q8 只用“身份”里的公司标识，避免两处不一致", "information"))


# ------------------------------------------------------------------------------------------------------------- identity resolution
def _resolve(ident, subject: dict, reg: dict, legacy: bool, where: str, kind: str, item: dict, attrs: dict, ctx: dict,
             extra_conflicts: list | None = None) -> dict:
    """the identity state of one data item (see the module docstring). kind: the registry kind this item must be; item: the item itself (for its
    content fingerprint); attrs: its own values of the attributes the kind registers; ctx: content index, source-id use counts"""
    if legacy and not isinstance(ident, dict):
        return {"where": where, "state": "LEGACY_UNVERIFIED", "state_zh": STATE_ZH["LEGACY_UNVERIFIED"], "issuer_id": None, "source_id": None, "basis": "LEGACY_FORMAT",
                "notes": ["Q7 旧格式没有这个字段，系统没有补写"] + list(extra_conflicts or [])}
    ident = ident if isinstance(ident, dict) else {}
    sid = ident.get("source_id")
    out = {"where": where, "issuer_id": ident.get("issuer_id"), "source_id": sid, "source_type": ident.get("source_type"), "notes": []}
    conflicts = list(extra_conflicts or [])
    csha = content_sha(item, kind) if isinstance(item, dict) else None
    for other_id, other in ctx["by_sha"].get(csha, []):       # another issuer's registered content, whatever the item declares
        if other["issuer_id"] != subject.get("issuer_id"):
            conflicts.append(f"内容与登记来源 {other_id}（属于 {other['issuer_id']}）完全相同：这是另一家公司的数据")
    if not ident.get("issuer_id") or not ident.get("source_type"):
        out.update(state="CONFLICT" if conflicts else "MISSING", state_zh=STATE_ZH["CONFLICT" if conflicts else "MISSING"], basis=None,
                   notes=["缺少公司标识或来源类型"] + conflicts)
        return out
    if ident.get("source_type") not in SOURCE_TYPES:
        conflicts.append(f"来源类型 {ident.get('source_type')} 不在 {SOURCE_TYPES} 内")
    if ident["issuer_id"] != subject.get("issuer_id"):
        conflicts.append(f"声明属于 {ident['issuer_id']}，分析对象是 {subject.get('issuer_id')}")
    if sid is not None and not isinstance(sid, str):
        conflicts.append("来源编号不是文字编号，无法核对")
        sid = None
    dup = ctx["uses"].get(sid, []) if sid is not None else []
    if len(set(dup)) > 1:
        conflicts.append(f"来源编号 {sid} 在本案例里被 {len(dup)} 项内容不同的数据使用（一个来源只能对应一份内容）")
    src = reg.get(sid) if sid else None
    unchecked, modified = [], False
    if src:
        if src.get("kind") != kind:
            conflicts.append(f"来源编号 {sid} 登记的是 {src.get('kind')}，不是这类数据（{kind}）")
        if src["issuer_id"] != ident["issuer_id"]:
            conflicts.append(f"来源登记表记录 {sid} 属于 {src['issuer_id']}，与声明的 {ident['issuer_id']} 不一致")
        if src["issuer_id"] != subject.get("issuer_id"):
            conflicts.append(f"来源登记表记录 {sid} 属于 {src['issuer_id']}，不是分析对象 {subject.get('issuer_id')}")
        if src.get("source_type") and src["source_type"] != ident.get("source_type"):
            conflicts.append(f"来源类型与登记不一致：输入 {ident.get('source_type')}，登记 {src['source_type']}")
        for k in KIND_ATTRS.get(src.get("kind"), ()):
            val = attrs.get(k)
            if val is None:
                unchecked.append(k)
            elif k in src and src[k] != val:
                conflicts.append(f"{k} 与来源登记不一致：输入 {val}，登记 {src[k]}")
        reg_c = ctx["content"].get(sid)
        if not conflicts and not unchecked and (reg_c is None or reg_c.get("kind") != kind or reg_c["sha256"] != csha):
            modified = True
    if conflicts:
        out.update(state="CONFLICT", state_zh=STATE_ZH["CONFLICT"], basis="SOURCE_REGISTRY" if src else "USER_DECLARED", notes=conflicts)
        return out
    elif src and unchecked:
        out.update(state="MATCH_USER_DECLARED", state_zh=STATE_ZH["MATCH_USER_DECLARED"], basis="USER_DECLARED",
                   notes=[f"来源 {sid} 已登记，但缺少 {'、'.join(unchecked)}，无法与登记完整核对"])
    elif src and modified:
        real = src.get("registry_kind") == "REAL_SNAPSHOT"
        out.update(state="MODIFIED_FROM_REGISTRY", state_zh=(REAL_STATE_ZH if real else STATE_ZH)["MODIFIED_FROM_REGISTRY"],
                   basis="REAL_SNAPSHOT_MODIFIED" if real else "SOURCE_REGISTRY_ID_ONLY",
                   notes=[f"来源编号 {sid}（{src.get('kind')}）已登记，公司和属性一致，但内容指纹与登记内容不同：按用户修改处理"], **four_way(src, "MODIFIED_FROM_REGISTRY"))
    elif src:
        real = src.get("registry_kind") == "REAL_SNAPSHOT"
        out.update(state="MATCH_SOURCE_REGISTRY", state_zh=(REAL_STATE_ZH if real else STATE_ZH)["MATCH_SOURCE_REGISTRY"], basis="REAL_SNAPSHOT" if real else "SOURCE_REGISTRY",
                   notes=[f"登记来源 {sid}（{src.get('kind')}）：公司、属性和内容指纹都一致"], **four_way(src, "MATCH_SOURCE_REGISTRY"))
        if real:
            out["source_url"], out["snapshot"], out["snapshot_sha256"] = src.get("url"), src.get("snapshot"), src.get("snapshot_sha256")
            out["source_dates"] = {k: src[k] for k in ("price_date", "shares_as_of_date", "fiscal_year", "available_at", "availability_timestamp", "fetched_at")
                                   if src.get(k) is not None}
    else:
        out.update(state="MATCH_USER_DECLARED", state_zh=STATE_ZH["MATCH_USER_DECLARED"], basis="USER_DECLARED",
                   notes=["来源编号没有登记" if sid else "没有给来源编号"])
    if len(dup) > 1:
        out["notes"].append(f"同一来源在本案例里出现 {len(dup)} 次，内容相同（重复，不是另一份数据）")
    return out


def _time_state(available, as_of_dt) -> str:
    a = _dt(available) if isinstance(available, str) else None
    if a is None:
        return "UNREADABLE_OR_MISSING"
    return "AFTER_AS_OF_EXCLUDED" if as_of_dt and a > as_of_dt else "AVAILABLE_BY_AS_OF"


def resolve_identity(m: dict) -> dict:
    """per-expert identity report, the experts it blocks, and the reasons (field paths)"""
    reg_all = source_registry()
    reg, secs = reg_all["sources"], reg_all["securities"]
    content = source_content()
    by_sha = {}
    for k, v in content.items():
        if k in reg:
            by_sha.setdefault(v["sha256"], []).append((k, reg[k]))
    legacy = is_legacy(m)
    subject = m.get("subject") if isinstance(m.get("subject"), dict) else {}
    as_of_dt = _dt(m.get("as_of")) if isinstance(m.get("as_of"), str) else None
    f = m.get("fundamental") if isinstance(m.get("fundamental"), dict) else None
    v = m.get("valuation") if isinstance(m.get("valuation"), dict) else None
    i = m.get("information") if isinstance(m.get("information"), dict) else None
    uses = {}                                    # source id -> the distinct contents that name it
    every = [(per, "ANNUAL_STATEMENTS") for per in _lst((f or {}).get("periods"))] + [((v or {}).get("market"), "MARKET_QUOTE"), ((v or {}).get("financials"), "VALUATION_FINANCIALS")] + \
        [(d, "DOCUMENT") for d in _lst((i or {}).get("documents"))]
    for it, kind in every:
        sid = it["identity"].get("source_id") if isinstance(it, dict) and isinstance(it.get("identity"), dict) else None
        if isinstance(sid, str):
            uses.setdefault(sid, []).append(content_sha(it, kind))
    ctx = {"content": content, "by_sha": by_sha, "uses": uses}
    subj_sec = subject.get("security")
    subj_sec_owner = (secs.get(subj_sec) or {}).get("issuer_id") if isinstance(subj_sec, str) else None
    subj_sec_conf = [f"证券登记显示分析对象的证券 {subj_sec} 属于 {subj_sec_owner}，不是 {subject.get('issuer_id')}"] \
        if subj_sec_owner and subj_sec_owner != subject.get("issuer_id") else []
    items = {e: [] for e in ("technical", "macro", "fundamental", "valuation", "information")}
    # ---- price data (Technical / Macro): structured registries only
    pid = m.get("price_dataset")
    if pid is not None:
        pr = C.registry()["price_datasets"].get(pid) if isinstance(pid, str) else None
        decl = C._declarations()["datasets"].get(pid) if isinstance(pid, str) else None
        if pr is None:
            it = {"where": "price_dataset", "state": "CONFLICT", "state_zh": STATE_ZH["CONFLICT"], "notes": [f"价格数据集 {pid} 没有登记"], "basis": None}
        else:
            owner = (secs.get(pr["security"]) or {}).get("issuer_id")
            real_pr = (decl or {}).get("availability") == "UNKNOWN"
            notes = ([f"数据集证券 {pr['security']}；证券登记属于 {owner}（{(secs.get(pr['security']) or {}).get('basis', '登记表')}）",
                      f"币种 {decl['currency']}：{decl.get('currency_basis')}", "日线的可得时间未知（来源没有说明；只比较日期，不使用任何时间约定）"] +
                     [f"{k}：{v}" for k, v in ((decl or {}).get("series_sources") or {}).items()] if real_pr else
                     [f"数据集证券 {pr['security']}；证券登记属于 {owner}", f"币种 {decl['currency'] if decl else '未声明'}（Q7 约定）", f"日线在当天 {decl['daily_bar_available_utc'] if decl else '?'}Z 可得（Q7 约定）"])
            if legacy:
                notes.append("旧格式回放：价格数据集仍按证券登记核对（价格数据本身没有逐项身份字段）")
            bad = list(subj_sec_conf)
            if pr["security"] != subj_sec:
                bad.append(f"数据集证券 {pr['security']} 不是分析对象的证券 {subj_sec}")
            if owner != subject.get("issuer_id"):
                bad.append(f"证券登记显示 {pr['security']} 属于 {owner}，不是分析对象 {subject.get('issuer_id')}")
            it = {"where": "price_dataset", "issuer_id": owner, "source_id": pid, "source_type": "PUBLIC_SOURCE" if real_pr else "SYNTHETIC", "basis": "SECURITY_REGISTRY",
                  "state": "CONFLICT" if bad else "MATCH_SOURCE_REGISTRY", "notes": bad + notes,
                  "currency_basis": "SYSTEM_INFERRED" if real_pr else "Q7_CONVENTION", "time_basis": "UNKNOWN_DATE_ONLY" if real_pr else "Q7_CONVENTION"}
            it["state_zh"] = ("与本次取得的价格快照登记一致（证券→发行人取自 SEC 的映射；币种为系统推断，可得时间未知）" if real_pr and not bad else STATE_ZH[it["state"]])
            if real_pr and not bad:          # a conflicting dataset shows its conflict, not another dataset's source statements
                it.update(source_says=list(decl.get("source_says") or []), system_checked=list(decl.get("system_checked") or []), user_declared=[],
                          not_verified=list(decl.get("not_verified") or []))
        items["technical"].append(it)
        items["macro"].append(copy.deepcopy(it))
    # ---- Fundamental
    period_end = {}
    if f is not None:
        for n, per in enumerate(_lst(f.get("periods"))):
            if not isinstance(per, dict):
                continue
            period_end.setdefault(per.get("fiscal_year"), per.get("period_end"))
            r = _resolve(per.get("identity"), subject, reg, legacy, f"fundamental.periods[{n}]", "ANNUAL_STATEMENTS", per,
                         {"fiscal_year": per.get("fiscal_year"), "currency": per.get("currency"), "scale": per.get("scale"), "available_at": per.get("available_at")}, ctx)
            r["label"] = f"FY{per.get('fiscal_year')}"
            r["time_state"] = _time_state(per.get("available_at"), as_of_dt)
            r["currency"], r["scale"] = per.get("currency"), per.get("scale")
            items["fundamental"].append(r)
    # ---- Valuation
    if v is not None and v.get("market") is None:
        items["valuation"].append({"where": "valuation.market", "label": "市价与股本", "state": "NOT_PROVIDED", "state_zh": "没有这部分数据", "basis": None,
                                   "notes": ["案例里没有市价与股本（真实公司：价格数据未取得）"]})
    if v is not None:
        mk = v.get("market") if isinstance(v.get("market"), dict) else {}
        mi = mk.get("identity") if isinstance(mk.get("identity"), dict) else None
        sec_conf = list(subj_sec_conf)
        msec = mi.get("security") if mi else None
        if msec and msec != subj_sec:
            sec_conf.append(f"市价对应证券 {msec}，分析对象证券是 {subj_sec}")
        msec_owner = (secs.get(msec) or {}).get("issuer_id") if isinstance(msec, str) else None
        if msec_owner and msec_owner != subject.get("issuer_id"):
            sec_conf.append(f"证券登记显示市价证券 {msec} 属于 {msec_owner}，不是分析对象 {subject.get('issuer_id')}")
        if v.get("market") is not None:
            r = _resolve(mi, subject, reg, legacy, "valuation.market", "MARKET_QUOTE", mk,
                         {"security": msec, "currency": mk.get("price_currency"), "price_date": mk.get("price_date")}, ctx, sec_conf)
            r["label"], r["currency"] = "市价与股本", mk.get("price_currency")
            items["valuation"].append(r)
        fi = v.get("financials") if isinstance(v.get("financials"), dict) else {}
        fy_conf, fy_note = [], []
        pe_ = period_end.get(fi.get("fiscal_year"))
        av = _dt(fi.get("available_at")) if isinstance(fi.get("available_at"), str) else None
        if isinstance(pe_, str) and av is not None:
            if av.date().isoformat() < pe_:
                fy_conf.append(f"估值用财务 FY{fi.get('fiscal_year')} 的可得时间 {fi.get('available_at')} 早于同一财年财报的期末 {pe_}：时间自相矛盾")
        elif fi.get("fiscal_year") is not None:
            fy_note.append(f"没有同一财年（FY{fi.get('fiscal_year')}）的财报期间，估值用财务数据的期末日期无法核对")
        r = _resolve(fi.get("identity") if isinstance(fi.get("identity"), dict) else None, subject, reg, legacy, "valuation.financials", "VALUATION_FINANCIALS", fi,
                     {"fiscal_year": fi.get("fiscal_year"), "currency": fi.get("currency"), "scale": fi.get("scale"), "available_at": fi.get("available_at")}, ctx, fy_conf)
        r["notes"] += fy_note
        r["label"], r["time_state"], r["currency"], r["scale"] = f"估值用财务 FY{fi.get('fiscal_year')}", _time_state(fi.get("available_at"), as_of_dt), fi.get("currency"), fi.get("scale")
        items["valuation"].append(r)
        items["valuation"].append({"where": "valuation.assumptions", "label": "估值假设", "state": "CASE_DECLARED", "state_zh": "案例声明的假设（适用于分析对象，未经验证）",
                                   "issuer_id": subject.get("issuer_id"), "notes": ["假设属于这个案例的分析对象；比率是小数（0.09 = 9%），倍数是“倍”"]})
    # ---- Information
    if i is not None:
        for n, d in enumerate(_lst(i.get("documents"))):
            if not isinstance(d, dict):
                continue
            ident = d.get("identity") if isinstance(d.get("identity"), dict) else None
            hdr = [x for x in C._text_identity(d)["ids"]]
            declared = (ident or {}).get("issuer_id") if ident else (d.get("issuer_id") if legacy else None)
            hconf = [f"正文页眉的发行人标识 {x} 与声明的 {declared} 不一致（结构化标识，只用来发现冲突，不用来认定身份）" for x in hdr if declared and x != declared]
            hconf += [f"正文页眉的发行人标识 {x} 不是分析对象 {subject.get('issuer_id')}" for x in hdr if x != subject.get("issuer_id") and x != declared]
            if ident and ident.get("source_id") is not None and ident.get("source_id") != d.get("document_id"):
                hconf.append(f"文件编号 {d.get('document_id')} 与来源编号 {ident.get('source_id')} 不同")
            if legacy and ident is None:
                r = _resolve(None, subject, reg, True, f"information.documents[{n}]", "DOCUMENT", d, {}, ctx, hconf)
                r["notes"].append(f"旧格式里的文件级 issuer_id = {d.get('issuer_id')}（未核实）")
                if d.get("issuer_id") not in (None, subject.get("issuer_id")) or hconf:
                    r.update(state="CONFLICT", state_zh=STATE_ZH["CONFLICT"],
                             notes=r["notes"] + ([f"旧格式文件声明属于 {d.get('issuer_id')}，不是分析对象"] if d.get("issuer_id") not in (None, subject.get("issuer_id")) else []))
            else:
                r = _resolve(ident, subject, reg, legacy, f"information.documents[{n}]", "DOCUMENT", d,
                             {"availability_timestamp": d.get("availability_timestamp"), "document_timestamp": d.get("document_timestamp")}, ctx, hconf)
            r["label"], r["time_state"] = str(d.get("document_id")), _time_state(d.get("availability_timestamp"), as_of_dt)
            items["information"].append(r)
    real_backed = 0
    for its in items.values():           # Q9: a real source's time is the source's own statement (SEC acceptanceDateTime, zone unverified): never shown as verified,
        for it in its:                   # also when the content was edited (the time is still the source's)
            src_ = reg.get(it.get("source_id")) if isinstance(it.get("source_id"), str) else None
            if (src_ or {}).get("registry_kind") == "REAL_SNAPSHOT" or it.get("time_basis") == "UNKNOWN_DATE_ONLY":
                real_backed += 1
            if it.get("basis") in ("REAL_SNAPSHOT", "REAL_SNAPSHOT_MODIFIED") and it.get("time_state") == "AVAILABLE_BY_AS_OF":
                it["time_state"] = "AVAILABLE_BY_AS_OF_SOURCE_TIME_UNVERIFIED"
    blocks = {}
    for e, its in items.items():
        reasons = []
        for it in its:
            if it["state"] == "CONFLICT":
                reasons.append({"code": "IDENTITY_CONFLICT", "path": it["where"], "detail": "；".join(it["notes"])})
            elif it["state"] == "MISSING":
                reasons.append({"code": "IDENTITY_MISSING", "path": it["where"], "detail": "；".join(it["notes"])})
        if reasons:
            blocks[e] = reasons
    counts = {}
    for its in items.values():
        for it in its:
            counts[it["state"]] = counts.get(it["state"], 0) + 1
    return {"version": VERSION, "legacy": legacy, "items": items, "blocks": blocks, "state_counts": counts, "real_backed_items": real_backed,
            "registry_note": REAL_REGISTRY_NOTE if real_backed else reg_all.get("note"),
            "rule": "身份只来自结构化字段（逐项公司标识、来源编号、来源登记表与内容指纹、证券登记表）；不从正文的公司名称猜测；最高只到"
                    + ("“与本次取得的来源快照一致”" if real_backed else "“与合成登记一致”") + "，不是外部验证"}


# ------------------------------------------------------------------------------------------------------------- conversion to te-input (the experts' unchanged contract)
def _strip_identity(o):
    o = copy.deepcopy(o)
    if isinstance(o, dict):
        o.pop("identity", None)
    return o


def to_q7_case(m: dict) -> dict:
    """the Q7 run format: research_input in te-input-1.1.0 (identity fields removed; a period's source_document_id and a document's issuer_id come
    from its identity), plus applicability"""
    legacy = is_legacy(m)
    subj = m.get("subject") if isinstance(m.get("subject"), dict) else {}
    pk = (m.get("provenance") or {}).get("kind") if isinstance(m.get("provenance"), dict) else None
    ri = {"contract_version": "te-input-1.1.0", "fixture_id": m.get("case_id"), "data_source": REAL_KIND if pk == REAL_KIND else "SYNTHETIC",
          "provenance": copy.deepcopy(m.get("provenance") or {"kind": "SYNTHETIC", "generator": "Q8 workbench"}), "as_of": m.get("as_of"),
          "issuer": {k: subj.get(k) for k in ("issuer_id", "name", "security", "industry_class")}, "price_dataset": m.get("price_dataset")}
    if m.get("label"):
        ri["title"] = str(m["label"])[:200]
    for s in SECTIONS:
        sec = m.get(s)
        if sec is None:
            continue
        sec = copy.deepcopy(sec)
        if s == "fundamental" and isinstance(sec, dict) and isinstance(sec.get("periods"), list):
            out = []
            for per in sec["periods"]:
                if isinstance(per, dict):
                    ident = per.get("identity") if isinstance(per.get("identity"), dict) else {}
                    per = _strip_identity(per)
                    if not legacy:                     # the expert cites the identity's source id, never a second field that could disagree
                        per.pop("source_document_id", None)
                        if isinstance(ident.get("source_id"), str):
                            per["source_document_id"] = ident["source_id"][:80]
                out.append(per)
            sec["periods"] = out
        if s == "valuation" and isinstance(sec, dict):
            for part in ("market", "financials"):
                if isinstance(sec.get(part), dict):
                    sec[part] = _strip_identity(sec[part])
        if s == "information" and isinstance(sec, dict) and isinstance(sec.get("documents"), list):
            out = []
            for d in sec["documents"]:
                if isinstance(d, dict):
                    ident = d.get("identity") if isinstance(d.get("identity"), dict) else {}
                    d = _strip_identity(d)
                    if not legacy:
                        d.pop("issuer_id", None)
                        d["issuer_id"] = ident.get("issuer_id")
                out.append(d)
            sec["documents"] = out
        ri[s] = sec
    q7 = {"q7_case_version": "q7-case-1.0.0", "case_id": m.get("case_id"), "research_input": ri}
    if m.get("label"):
        q7["label"] = str(m["label"])[:200]
    if m.get("purpose"):
        q7["purpose"] = str(m["purpose"])[:1000]
    if m.get("applicability"):
        q7["applicability"] = copy.deepcopy(m["applicability"])
    return q7


# ------------------------------------------------------------------------------------------------------------- the experts' own schema checks, translated
CODE_ZH = {
    "REQUIRED_FIELD_MISSING": ("缺少「{label}」", "在表单里填写它；系统不会补 0 或猜测"),
    "NULL_NOT_ALLOWED": ("「{label}」不能为空", "填写一个值"),
    "TYPE_NUMBER_EXPECTED": ("「{label}」需要是数字，现在是：{value}", "只填数字（可以有负号和小数点），不要带单位或逗号"),
    "TYPE_INTEGER_EXPECTED": ("「{label}」需要是整数，现在是：{value}", "填写整数，例如 2025"),
    "TYPE_STRING_EXPECTED": ("「{label}」需要是文字", "填写文字"),
    "TYPE_OBJECT_EXPECTED": ("「{label}」的结构不对", "在表单里重新填写这一部分"),
    "TYPE_ARRAY_EXPECTED": ("「{label}」应是一个列表", "在表单里用“添加”按钮增加条目"),
    "VALUE_NOT_ALLOWED": ("「{label}」的取值不在允许范围内：{value}", "从下拉框里选择"),
    "NUMBER_BELOW_MIN": ("「{label}」小于允许的最小值：{value}", "检查单位和数量级（例如百分数应写成小数）"),
    "NUMBER_ABOVE_MAX": ("「{label}」大于允许的最大值：{value}", "检查单位和数量级（例如百分数应写成小数）"),
    "DATE_INVALID": ("「{label}」不是 YYYY-MM-DD 格式的真实日期：{value}", "例如 2026-10-19"),
    "DATETIME_INVALID_OR_WITHOUT_TIMEZONE": ("「{label}」不是带时区的时间：{value}", "例如 2026-10-19T21:00:00Z"),
    "UNKNOWN_FIELD": ("不认识的字段「{label}」", "删掉它（契约不接受多余字段）"),
    "STRING_TOO_LONG": ("「{label}」太长", "缩短内容"),
    "STRING_TOO_SHORT": ("「{label}」不能为空", "填写内容"),
    "ARRAY_TOO_SHORT": ("「{label}」条目太少", "至少添加一条"),
    "ARRAY_TOO_LONG": ("「{label}」条目太多", "删减条目"),
    "NUMBER_NOT_REPRESENTABLE": ("「{label}」数字太大，无法精确表示：{value}", "检查数量级和量纲（例如用“百万”作量纲后填较小的数）"),
    "TYPE_BOOLEAN_EXPECTED": ("「{label}」需要是 true / false：{value}", "在 JSON 里写 true 或 false"),
    "NUMBER_NOT_FINITE": ("「{label}」不是有限的数字：{value}", "填写普通数字"),
}


def _q8_path(te_path: str) -> str:
    p = te_path[2:] if te_path.startswith("$.") else te_path
    p = re.sub(r"^(information\.documents\[\d+\])\.issuer_id$", r"\1.identity.issuer_id", p)
    p = re.sub(r"^(fundamental\.periods\[\d+\])\.source_document_id$", r"\1.identity.source_id", p)
    return p


def expert_schema_problems(q7case: dict, model: dict) -> list:
    """each experimental expert's own input check, run in its own subprocess (adapters/expert_runner.py, mode 'validate'), translated to Chinese
    with the field path of the Q8 model"""
    ri = q7case["research_input"]
    out = []
    for e in SECTIONS:
        if ri.get(e) is None:
            continue
        p = subprocess.run([sys.executable, "-I", "-B", "-X", f"pycache_prefix={Q8 / '.no_pycache_do_not_create'}", str(Q8 / "adapters/expert_runner.py")],
                           input=json.dumps({"expert_id": e, "section": ri[e], "common": {}, "mode": "validate"}, ensure_ascii=False, allow_nan=False),
                           capture_output=True, text=True, timeout=60, cwd=str(Q8))
        try:
            res = json.loads(p.stdout)
        except ValueError:
            out.append(_p(e, "VALIDATION_UNAVAILABLE", f"{e} 的输入检查没有返回结果", "重新运行；若持续出现请报告", e))
            continue
        for x in res.get("problems") or []:
            q8p = _q8_path(x.get("path", ""))
            val = _get(model, q8p)
            msg, fix = CODE_ZH.get(x.get("code"), ("「{label}」不合输入契约（" + str(x.get("code")) + "）", "按说明修改"))
            out.append(_p(q8p, x.get("code"), msg.format(label=label_of(q8p), value=json.dumps(val, ensure_ascii=False)[:60] if val is not None else "（空）"),
                          fix, e))
    return out


def _get(o, path: str):
    cur = o
    for k, i in re.findall(r"([^.\[\]]+)|\[(\d+)\]", path):
        if k:
            if not isinstance(cur, dict) or k not in cur:
                return None
            cur = cur[k]
        else:
            if not isinstance(cur, list) or int(i) >= len(cur):
                return None
            cur = cur[int(i)]
    return cur


def prepare(model: dict, with_expert_checks: bool = True) -> dict:
    """everything the run and the form need: structural problems (field level), identity report, the Q7 run case, expert-level blocks"""
    P = check_structure(model)
    fatal = [p for p in P if p["expert"] is None and p.get("severity") != "WARNING"]
    if fatal:
        return {"ok": False, "problems": P, "identity": None, "q7case": None, "blocks": {}}
    q7 = to_q7_case(model)
    ident = resolve_identity(model)
    pk = (model.get("provenance") or {}).get("kind") if isinstance(model.get("provenance"), dict) else None
    if pk == REAL_KIND and not ident["real_backed_items"]:      # the label "real public data" follows the registry, never the editable field alone
        P.append(_p("provenance.kind", "PROVENANCE_NOT_BACKED", f"来源类别写的是 {REAL_KIND}（真实公开数据），但案例里没有任何一项来自本次取得的真实来源快照",
                    "把 provenance.kind 改回 SYNTHETIC，或从“真实公司”重新获取数据"))
        return {"ok": False, "problems": P, "identity": ident, "q7case": None, "blocks": {}}
    if pk != REAL_KIND and ident["real_backed_items"]:
        P.append(_p("provenance.kind", "PROVENANCE_KIND_MISMATCH", f"案例里有 {ident['real_backed_items']} 项来自真实来源快照，但来源类别写的是 {pk}",
                    f"把 provenance.kind 改回 {REAL_KIND}：真实数据的时间规则和使用范围说明只在这个类别下生效"))
        return {"ok": False, "problems": P, "identity": ident, "q7case": None, "blocks": {}}
    if with_expert_checks:
        P += expert_schema_problems(q7, model)
    seen, uniq = set(), []                        # the Q8 check and the expert's own check may name the same field: keep the first (Q8's, more specific)
    for p in P:
        k = (p["path"], p["code"])
        if k not in seen:
            seen.add(k)
            uniq.append(p)
    P = uniq
    blocks = copy.deepcopy(ident["blocks"])
    for p in P:                                   # a new-format required identity / unit / time field that is missing refuses that expert
        if p["code"] == "MARKET_DATA_NOT_AVAILABLE":
            blocks.setdefault(p["expert"], []).append({"code": "MARKET_DATA_NOT_AVAILABLE", "path": p["path"], "detail": f"{p['message']}：{p['fix']}"})
            continue
        if p["expert"] and p["code"] in ("REQUIRED_FIELD_MISSING", "DATETIME_INVALID_OR_WITHOUT_TIMEZONE", "DUPLICATE_IDENTITY_FIELD", "SOURCE_ID_INVALID") and \
                p["path"].split(".")[0] in SECTIONS:
            if any(seg in p["path"] for seg in ("identity", "currency", "scale", "available_at", "availability_timestamp", "price_date", "shares_scale", "issuer_id",
                                                "source_document_id")):
                blocks.setdefault(p["expert"], []).append({"code": "REQUIRED_IDENTITY_UNIT_OR_TIME_MISSING", "path": p["path"], "detail": f"{p['message']}：{p['fix']}"})
    return {"ok": True, "problems": P, "identity": ident, "q7case": q7, "blocks": blocks}
