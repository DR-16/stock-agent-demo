"""Q8 successor of the Q7 orchestrator (q8-orchestrator 2.0.0; Q7: q7-orchestrator 1.2.0): one case, one fresh context, five real executions,
one run record, one synthesis. New in Q8: run_q8() takes the Q8 input model (orchestrator/q8_input.py): its field-level problems, its per-item
identity report and the experts it blocks (identity conflict / missing identity, unit or time) are applied before anything else; the record carries
the Q8 model, so the export shows exactly the input that was run.

  run_q8(model, fault_injection=None, input_origin="PROGRAMMATIC") -> run record (Q8_RUN_RECORD_V1)
  run_case(case, ...)  the Q7 path on a Q7-format case (kept for the Q7 regressions)

Order: (1) the context; (2) statuses that need no code to run - NOT_APPLICABLE (declared, or no listed security), REJECTED by the context
(applicability that contradicts the input, a section-level contract problem, a price dataset that is missing / of another security / after
as_of); (3) for the experts still to run, the code identity check; (4) the runs; (5) the synthesis.

Dependencies: technical, macro <- the price dataset (one shared subprocess: the unchanged production chain runs both models; a crash of that
process fails both, an exception inside one model is caught by the production orchestrator and fails only that one); fundamental / valuation /
information <- their own section (one subprocess each); synthesis <- every expert record.

Code identity, checked twice: before an expert is invoked, the files it will run are hashed and compared with the frozen identity
(records/reuse_copies.json for F / V / I; Gate 0's production hashes for every stock_agent / py_chain module the production chain loads); a mismatch,
or a file or identity record that cannot be read, means NOT_EXECUTED. After the run, the set of module files the child reports must equal (F / V / I)
or be contained in (T / M) the set checked before, with equal hashes; otherwise the output is discarded (FAILED). Children run with -I -B and a
pycache prefix that does not exist, so no cached bytecode can stand in for the hashed source. The price dataset is read once, hashed, and its exact
text is sent to the child; the production contract's own hash of that text must equal the registered one.

Nothing is cached: every call runs the experts again. Nothing is kept between runs; module-level tables are deep-copied into each record.
"""
from __future__ import annotations

import copy
import hashlib
import json
import subprocess
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

Q7 = Path(__file__).resolve().parents[1]
REPO = Q7.parents[2]
sys.path.insert(0, str(Q7))
from adapters import registry as R  # noqa: E402
from orchestrator import context as C  # noqa: E402
from orchestrator import contracts as K  # noqa: E402

PY = str(REPO / ".venv/bin/python")
ORCHESTRATOR_VERSION = "q8-orchestrator 2.0.0+q12.2"   # Q12.2: Q12 registrations (records/q12_successors_c*.json) are read after Q11's, by candidate number. Q12.1: run ids Q12R-. Q11: Q11 identity records (q11_copies, q11_successors_c*, q11_gate0), run ids Q11R-; was +q10.1   # Q10: Q10 identity records, run ids Q10R-; was +q9.1     # Q9 review: data kind / labels from the registry backing; registry hashes recorded
TIMEOUT_S = 120
NO_PYCACHE = Q7 / ".no_pycache_do_not_create"
FAULT_KINDS = {"production": ("exception", "process_crash"), "expert": ("exception", "non_finite_output", "wrong_issuer_output", "process_crash")}
INPUT_ORIGINS = ("REGISTERED_CASE", "SAVED_USER_CASE", "REAL_DATA_CASE", "EDITED_IN_WORKBENCH", "PROGRAMMATIC")   # REAL_DATA_CASE (Q9): built from snapshots   # SAVED_USER_CASE (Q8): a case the user saved; no registration   # PROGRAMMATIC: a case document handed to run_case by code (tests, scripts)
Q9_REL = Q7.relative_to(REPO).as_posix() + "/"
Q9_BRIDGE = Q9_REL + "adapters/q9_chain/"
PRODUCTION_FILES = ["stock_agent/engine.py", "stock_agent/indicators.py", "stock_agent/models/base.py", "stock_agent/models/technical.py", "stock_agent/models/macro.py",
                    "stock_agent/models/challenge.py", "stock_agent/models/meta.py", "stock_agent/regime/detector.py", "stock_agent/risk/engine.py",
                    "stock_agent/risk/checks.py", "stock_agent/calibration/calibrators.py",
                    Q9_BRIDGE + "py_chain.py", Q9_BRIDGE + "contract/normalize.py"]   # Q9: the successor bridge, pinned by records/bridge_identity.json


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")


def _frozen() -> dict:
    """Q11: the frozen identities, read fresh: the expert implementation copies (records/q11_copies.json, initial fingerprints) overlaid by the
    registered successor files of the latest candidate (records/q11_successors_c<NN>.json, written by q11_register.py), the production files
    (q11_gate0.json of this workspace) and the copied Q9 bridge (records/q11_copies.json)"""
    cp = json.loads((Q7 / "records/q11_copies.json").read_text(encoding="utf-8"))          # Q11: the Q11 copy record, Q11 Gate 0 and the Q11 registrations
    g0 = json.loads((Q7 / "q11_gate0.json").read_text(encoding="utf-8"))
    copies = {r["dest"]: r["copy_sha256"] for r in cp["copies"] if r["dest"].startswith("adapters/impl/")}
    batches = sorted((Q7 / "records").glob("q1[12]_successors_c*.json"), key=lambda p: int(p.stem.rsplit("_c", 1)[1]))   # Q12: a Q12 batch (c09 ...) follows Q11's
    if batches:
        copies.update(json.loads(batches[-1].read_text(encoding="utf-8"))["files_sha256"])
    prod = dict(g0["production"]["files_sha256"])
    prod.update({Q9_REL + r["dest"]: r["copy_sha256"] for r in cp["copies"] if r["dest"].startswith("adapters/q9_chain/")})
    if not all(isinstance(k, str) and isinstance(v, str) for k, v in list(copies.items()) + list(prod.items())):
        raise TypeError("identity records of the wrong shape")
    return {"copies": copies, "production": prod}


def _identity(eid: str, frozen: dict) -> dict:
    spec = R.EXPERTS[eid]
    try:
        if NO_PYCACHE.exists():
            return {"files_sha256": {}, "equal_to_frozen": False, "differs": [NO_PYCACHE.name],
                    "unreadable": f"{NO_PYCACHE.name} exists: the bytecode prefix the children use must not exist (planted bytecode could stand in for the source)"}
        if spec["runner"] == "expert":
            root = Q7 / spec["impl_root"]
            stray = sorted(p.relative_to(Q7).as_posix() for p in root.rglob("*") if p.is_file() and p.suffix != ".py")
            if stray:      # a .pyc / .so / anything but source in a directory on the child's sys.path could shadow a module
                return {"files_sha256": {}, "equal_to_frozen": False, "differs": stray}
            files = sorted(p for p in root.rglob("*.py"))
            now_ = {p.relative_to(Q7).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
            want = {k: v for k, v in frozen["copies"].items() if k.startswith(spec["impl_root"] + "/")}
        else:
            bridge = Q7 / "adapters/q9_chain"
            stray = sorted(p.relative_to(Q7).as_posix() for p in bridge.rglob("*") if p.is_file() and p.suffix != ".py")
            extra = sorted(p.relative_to(REPO).as_posix() for p in bridge.rglob("*.py") if p.relative_to(REPO).as_posix() not in PRODUCTION_FILES)
            if stray or extra:  # Q9 review: the bridge directory is checked like the expert roots (nothing but its two pinned source files)
                return {"files_sha256": {}, "equal_to_frozen": False, "differs": stray + extra}
            now_ = {n: hashlib.sha256((REPO / n).read_bytes()).hexdigest() for n in PRODUCTION_FILES}
            want = {n: frozen["production"].get(n) for n in PRODUCTION_FILES}
    except Exception as e:          # unreadable files or identity records of the wrong shape: never a run on unchecked code
        return {"files_sha256": {}, "equal_to_frozen": False, "unreadable": f"{type(e).__name__}: {str(e)[:200]}", "differs": []}
    return {"files_sha256": now_, "equal_to_frozen": bool(want) and now_ == want, "differs": sorted(k for k in set(now_) | set(want) if now_.get(k) != want.get(k))}


def _call(script: str, req: dict) -> tuple:
    t = time.monotonic()
    try:
        p = subprocess.run([PY, "-I", "-B", "-X", f"pycache_prefix={NO_PYCACHE}", str(Q7 / "adapters" / script)],
                           input=json.dumps(req, ensure_ascii=False, allow_nan=False), capture_output=True, text=True, timeout=TIMEOUT_S, cwd=str(Q7))
    except subprocess.TimeoutExpired:
        return None, {"exit_code": None, "timeout": True, "wall_s": round(time.monotonic() - t, 3), "stderr_tail": ""}
    proc = {"exit_code": p.returncode, "timeout": False, "wall_s": round(time.monotonic() - t, 3), "stderr_tail": p.stderr[-600:]}
    try:
        return (json.loads(p.stdout, parse_constant=lambda c: (_ for _ in ()).throw(ValueError(f"non-finite literal {c}"))) if p.stdout.strip() else None), proc
    except ValueError as e:
        proc["stdout_not_strict_json"] = str(e)[:200]
        return None, proc


def _reason(code: str, meaning: str, source: str, path: str = "$", detail: str = "") -> dict:
    return {"code": code, "meaning": meaning, "path": path, "detail": str(detail), "source": source}     # Q8: never cut


def _base(eid: str, run_id: str, ctx: dict) -> dict:
    spec = R.EXPERTS[eid]
    trust = copy.deepcopy(R.TRUST[eid])
    return {"expert_id": eid, "display_name": spec["display"], "tier": spec["tier"], "tier_label": R.TIER_LABEL[spec["tier"]], "run_id": f"{run_id}:{eid}",
            "implementation_version": None, "implementation_identity": None, "input_fingerprint": (ctx.get("expert_input_fingerprints") or {}).get(eid),
            "depends_on": list(spec["depends_on"]), "invoked": False, "process": None, "execution_status": None, "status_reasons": [], "output_contract_status": "NO_OUTPUT",
            "output_contract_problems": [], "output_fingerprint": None, "execution_error": None, "output": None, "fault_injection": None,
            "trust": {**trust, "validation_label": R.VALIDATION_LABEL[trust["validation_status"]]}}


def _prestatus(recs: dict, ctx: dict) -> None:
    """statuses decided by the case and its context alone, before any code identity check or run"""
    app, conflicts, secp = ctx.get("applicability") or {}, ctx.get("applicability_conflicts") or {}, ctx.get("section_problems") or {}
    for eid, reasons in (ctx.get("q8_blocks") or {}).items():          # Q8 data identity first: a conflict or a missing identity / unit / time refuses that expert
        if eid in recs and recs[eid]["execution_status"] is None:
            zh = {"IDENTITY_CONFLICT": "数据身份冲突：这部分数据不属于分析对象（或声明与来源登记不一致），已阻断，不与其他公司的数据混用",
                  "IDENTITY_MISSING": "数据身份缺失：新格式案例必须写明每项数据属于哪家公司",
                  "MARKET_DATA_NOT_AVAILABLE": "没有市价与股本数据：Valuation 需要市价、价格日期和股数才能运行",
                  "REQUIRED_IDENTITY_UNIT_OR_TIME_MISSING": "缺少身份、币种 / 量纲或可得时间：系统不猜测、不补值"}
            recs[eid].update(execution_status="REJECTED", status_reasons=[_reason(x["code"], zh.get(x["code"], x["code"]), "q8_identity", x["path"], x["detail"]) for x in reasons])
    for eid in ("fundamental", "valuation", "information"):
        r = recs[eid]
        if r["execution_status"] is not None:
            continue
        if eid in conflicts:
            c = conflicts[eid]
            r.update(execution_status="REJECTED", status_reasons=[_reason(c["code"], "案例同时声明不适用又提供了输入，自相矛盾；不猜测，不运行", "q7_context", c["path"], c["detail"])])
        elif eid in secp:
            r.update(execution_status="REJECTED", status_reasons=[_reason(p.get("code"), "这个专家的输入部分不合输入契约 te-input-1.1.0（只影响这个专家）", "q7_context", p.get("path", "$"),
                                                                          p.get("detail", "")) for p in secp[eid]])
        elif ctx["inputs"][eid]["section"] is None and eid in app:
            r.update(execution_status="NOT_APPLICABLE", status_reasons=[_reason("DECLARED_NOT_APPLICABLE", app[eid]["reason"], "case", f"$.applicability.{eid}")])
        elif eid == "valuation":
            late = [t for t in ctx.get("time_audit") or [] if t.get("where") == "valuation.market.price_date" and t.get("after_as_of")]
            if late:
                r.update(execution_status="REJECTED", status_reasons=[_reason("VALUATION_PRICE_AFTER_AS_OF", "估值市价按 Q7 约定在 as_of 之后才可得：不运行（与价格类专家同样对待）",
                                                                              "q7_context", "$.research_input.valuation.market.price_date",
                                                                              f"{late[0].get('occurred')} 可得于 {late[0].get('available')}，as_of {ctx.get('as_of')}")])
    pin = ctx["price_input"]
    for eid in ("technical", "macro"):
        r = recs[eid]
        if r["execution_status"] is not None:
            continue
        if eid in conflicts:
            c = conflicts[eid]
            r.update(execution_status="REJECTED", status_reasons=[_reason(c["code"], "案例同时声明不适用又提供了价格输入，自相矛盾；不猜测，不运行", "q7_context", c["path"], c["detail"])])
        elif pin["state"] == "NOT_APPLICABLE" and pin["code"] == "DECLARED_NOT_APPLICABLE":
            r.update(execution_status="NOT_APPLICABLE", status_reasons=[_reason("DECLARED_NOT_APPLICABLE", app[eid]["reason"], "case", f"$.applicability.{eid}")])
        elif pin["state"] == "NOT_APPLICABLE":
            r.update(execution_status="NOT_APPLICABLE", status_reasons=[_reason(pin["code"], pin["reason"], "q7_context", pin["path"])])
        elif pin["state"] == "MISSING" and eid in app:
            r.update(execution_status="NOT_APPLICABLE", status_reasons=[_reason("DECLARED_NOT_APPLICABLE", app[eid]["reason"], "case", f"$.applicability.{eid}")])
        elif pin["state"] != "OK":
            r.update(execution_status="REJECTED", status_reasons=[_reason(pin["code"], pin["reason"], "q7_context", pin["path"])])


def _child_mismatch(child: dict | None, parent: dict, prefix: str, exact: bool) -> list:
    """files the child reports with a hash other than the one checked before, files it reports that were never checked, and (exact=True) files
    checked before that the child does not report"""
    child = child or {}
    keyed = {(f"{prefix}/{k}" if prefix else k): h for k, h in child.items()}
    bad = sorted(k for k, h in keyed.items() if parent.get(k) != h)
    if exact:
        bad += sorted(k for k in parent if k not in keyed)
    return bad


def _run_experimental(eid: str, rec: dict, ctx: dict, fault) -> None:
    spec = R.EXPERTS[eid]
    sec = ctx["inputs"][eid]["section"]
    rec["fault_injection"] = copy.deepcopy(fault)
    req = {"expert_id": eid, "section": sec, "common": ctx["inputs"][eid]["common"], "fault_injection": fault}
    rec["input_scope"] = {"passed": {"section": f"research_input.{eid}" if sec is not None else None, "section_sha256": C.sha256_of(sec) if sec is not None else None,
                                     "common_keys": sorted(req["common"])},
                          "not_passed": [f"research_input.{x}" for x in ("fundamental", "valuation", "information") if x != eid] + ["price_dataset", "applicability"]}
    res, proc = _call("expert_runner.py", req)
    rec.update(invoked=True, process=proc)
    if res is None:
        why = "timeout" if proc["timeout"] else f"process exit {proc['exit_code']} with no strict JSON result"
        rec.update(execution_status="FAILED", execution_error={"kind": "PROCESS_FAILURE", "detail": why, "stderr_tail": proc["stderr_tail"]},
                   status_reasons=[_reason("PROCESS_FAILURE", "专家子进程没有返回结果（崩溃、超时或输出不是严格 JSON）", "q7_orchestrator", "$", why)])
        return
    rec["implementation_version"] = res.get("implementation_version")
    changed = _child_mismatch(res.get("module_files_sha256"), rec["implementation_identity"]["files_sha256"], spec["impl_root"], exact=True)
    if changed:
        rec.update(execution_status="FAILED", execution_error={"kind": "IMPLEMENTATION_CHANGED_DURING_RUN", "detail": ", ".join(changed)[:300]},
                   status_reasons=[_reason("IMPLEMENTATION_CHANGED_DURING_RUN", "子进程报告的实现文件与运行前核对的不一致（哈希不同、多出或缺少）：输出作废", "q7_orchestrator", "$",
                                           ", ".join(changed))])
        return
    if not res.get("ok"):
        kind = res.get("error_kind")
        st = "NOT_EXECUTED" if kind == "MODULE_UNAVAILABLE" else "FAILED"
        if kind == "OUTPUT_NOT_FINITE":
            rec["output_contract_status"] = "NON_FINITE"
        rec.update(execution_status=st, execution_error={"kind": kind, "detail": res.get("error"), "traceback_tail": res.get("traceback_tail")},
                   status_reasons=[_reason(kind or "UNKNOWN_ERROR", {"EXPERT_EXCEPTION": "专家抛出异常，没有输出", "OUTPUT_NOT_FINITE": "输出含 NaN / Infinity，整份输出被拒收",
                                                              "MODULE_UNAVAILABLE": "实现无法导入（专家代码没有运行）", "OUTPUT_NOT_JSON": "输出不能序列化为 JSON"}.get(kind, str(kind)),
                                           "q7_orchestrator", "$", str(res.get("error")))])
        return
    out = res["output"]
    rec["output_fingerprint"] = C.sha256_of(out)
    probs = K.check_experimental(out, spec, ctx)
    if probs:
        rec.update(execution_status="FAILED", output_contract_status="VIOLATED", output_contract_problems=probs,
                   status_reasons=[_reason("OUTPUT_CONTRACT_VIOLATED", "输出不符合输出契约，已隔离，不显示、不进入综合", "q7_contract", "$",
                                           "; ".join(f"{p['code']} {p['path']}" for p in probs))])
        return
    g = K.guards(eid, out, ctx)
    if g:
        rec.update(execution_status="FAILED", output_contract_status="BLOCKED_BY_GUARD", output_contract_problems=g,
                   status_reasons=[_reason("BLOCKED_BY_GUARD", "输出使用了 as_of 之后、无法核实可得时间或其他发行人的证据，已阻断", "q7_guard", "$",
                                           "; ".join(f"{p['code']} {p['detail']}" for p in g))])
        return
    st, why = K.experimental_status(out)
    rec.update(execution_status=st, status_reasons=why, output_contract_status="CONFORMS", output=out)


def _run_production(rec_t: dict, rec_m: dict, ctx: dict, fault) -> None:
    pin = ctx["price_input"]
    todo = {e: r for e, r in (("technical", rec_t), ("macro", rec_m)) if r["execution_status"] is None}
    if not todo:
        return
    raw = (Q7 / pin["file"]).read_bytes()
    if hashlib.sha256(raw).hexdigest() != pin["sha256"]:
        for r in todo.values():
            r.update(execution_status="NOT_EXECUTED", status_reasons=[_reason("PRICE_DATASET_CHANGED", "价格数据文件在上下文核对之后变了：不运行", "q7_orchestrator", "$.price_dataset")])
        return
    res, proc = _call("production_runner.py", {"price_dataset_text": raw.decode("utf-8"), "fault_injection": fault})
    for eid, r in todo.items():
        r["input_scope"] = {"passed": {"price_dataset_id": pin["dataset_id"], "file": pin["file"], "sha256": pin["sha256"], "sent": "exact text on stdin"},
                            "not_passed": ["research_input.fundamental", "research_input.valuation", "research_input.information", "applicability"]}
        r.update(invoked=True, process={**proc, "shared_process_with": sorted(set(todo) - {eid})},
                 fault_injection=copy.deepcopy(fault) if fault and (fault.get("expert") == eid or fault.get("kind") == "process_crash") else None)
    if res is None:
        why = "timeout" if proc["timeout"] else f"process exit {proc['exit_code']}"
        for r in todo.values():
            r.update(execution_status="FAILED", execution_error={"kind": "PROCESS_FAILURE", "detail": why, "stderr_tail": proc["stderr_tail"]},
                     status_reasons=[_reason("PROCESS_FAILURE", "生产链子进程没有返回结果（崩溃、超时或输出不是严格 JSON）；两个生产专家共用这个进程", "q7_orchestrator", "$", why)])
        return
    checked = next(iter(todo.values()))["implementation_identity"]["files_sha256"]
    loaded = res.get("loaded_modules_sha256") or {}
    changed = _child_mismatch(loaded, checked, "", exact=False)
    if changed or not loaded:
        for r in todo.values():
            r.update(execution_status="FAILED", execution_error={"kind": "UNVERIFIED_CODE_LOADED", "detail": ", ".join(changed)[:300] or "no module list"},
                     status_reasons=[_reason("UNVERIFIED_CODE_LOADED", "生产链子进程加载了运行前没有核对、或哈希不一致的模块：输出作废", "q7_orchestrator", "$", ", ".join(changed) or "no module list")])
        return
    for r in todo.values():
        r["loaded_modules_verified"] = sorted(loaded)
    if not res.get("ok"):
        kind = res.get("error_kind")
        st = "NOT_EXECUTED" if kind == "MODULE_UNAVAILABLE" else "FAILED"
        for r in todo.values():
            r.update(execution_status=st, execution_error={"kind": kind, "detail": res.get("error"), "stderr_tail": proc["stderr_tail"]},
                     status_reasons=[_reason(kind or "UNKNOWN_ERROR", "生产链没有返回结果", "q7_orchestrator", "$", str(res.get("error")))])
        return
    contract = res.get("contract") or {}
    for eid, r in todo.items():
        r["implementation_version"] = (res.get("implementation_versions") or {}).get(eid)
        r["production_contract"] = {k: contract.get(k) for k in ("status", "dataset_id", "security", "as_of_date", "input_sha256", "codes")}
        r["dropped_report_keys"] = res.get("dropped_report_keys")
        r["input_contract_notes"] = [_reason(c.get("code"), c.get("meaning", ""), "production_price_contract", c.get("path", "")) for c in contract.get("codes") or [] if isinstance(c, dict)]
        if contract.get("input_sha256") != pin["sha256"]:
            r.update(execution_status="FAILED", status_reasons=[_reason("PRICE_INPUT_IDENTITY_MISMATCH", "生产价格契约读到的数据与上下文核对的数据不是同一份", "q7_contract",
                                                                        "$.contract.input_sha256", f"{contract.get('input_sha256')} vs {pin['sha256']}")])
            continue
        if contract.get("status") == "REJECTED":
            r.update(execution_status="REJECTED", status_reasons=[_reason("PRICE_CONTRACT_REJECTED", "生产价格数据契约拒绝了这份数据集", "expert", "$.price_dataset",
                                                                          json.dumps(contract.get("codes"), ensure_ascii=False))])
            continue
        if not res.get("report_present"):
            r.update(execution_status="FAILED", status_reasons=[_reason("REPORT_MISSING", "价格契约接受了数据，但生产链没有给出报告", "q7_orchestrator", "$.report")])
            continue
        x = (res.get("experts") or {}).get(R.EXPERTS[eid]["model_name"])
        if x is None:
            r.update(execution_status="FAILED", status_reasons=[_reason("EXPERT_OUTPUT_MISSING", "生产报告里没有这个专家的输出", "q7_contract", "$.model_outputs")])
            continue
        if "output" not in x:
            r.update(execution_status="FAILED", output_contract_status="NON_FINITE", execution_error={"kind": x.get("error_kind"), "detail": x.get("error")},
                     status_reasons=[_reason(x.get("error_kind", "OUTPUT_NOT_FINITE_OR_NOT_JSON"), "这个模型的输出含非有限值或不能序列化，只作废这个模型", "q7_orchestrator", "$", x.get("error", ""))])
            continue
        out, withheld = x["output"], x["withheld_predictive_fields"]
        r["output_fingerprint"] = C.sha256_of({"output": out, "withheld_sha256": withheld["sha256"]})
        r["withheld_predictive_fields"] = withheld
        r["withheld_evidence_weights"] = x.get("withheld_evidence_weights")          # Q9 review: weights and trading-worded comments withheld in the child
        r["withheld_advice_like_comments"] = x.get("withheld_advice_like_comments")
        probs = K.check_production(out, R.EXPERTS[eid], ctx, withheld)
        if probs:
            r.update(execution_status="FAILED", output_contract_status="VIOLATED", output_contract_problems=probs,
                     status_reasons=[_reason("OUTPUT_CONTRACT_VIOLATED", "输出不符合输出契约，已隔离", "q7_contract", "$", "; ".join(f"{p['code']} {p['path']}" for p in probs))])
            continue
        st, why = K.production_status(out, res.get("report_warnings") or [])
        if st == "FAILED":         # the production orchestrator replaced the model's output by an empty substitute: not an output
            r.update(execution_status=st, status_reasons=why, output_contract_status="SUBSTITUTE_NOT_OUTPUT", output=None)
        else:
            r.update(execution_status=st, status_reasons=why, output_contract_status="CONFORMS", output=out)


def _check_fault(fault) -> None:
    if fault is None:
        return
    if not isinstance(fault, dict) or set(fault) != {"expert", "kind"} or not isinstance(fault.get("expert"), str) or not isinstance(fault.get("kind"), str):
        raise ValueError(f"fault injection is {{'expert': <id>, 'kind': <kind>}}, not {fault!r}"[:200])
    spec = R.EXPERTS.get(fault["expert"])
    if spec is None or fault["kind"] not in FAULT_KINDS[spec["runner"]]:
        raise ValueError(f"unknown fault injection {fault!r}"[:200])


def run_case(case: dict, fault_injection: dict | None = None, input_origin: str = "PROGRAMMATIC", q8: dict | None = None) -> dict:
    from synthesis import synthesize as S          # imported here so that a defect in synthesis can never stop the experts
    _check_fault(fault_injection)
    if input_origin not in INPUT_ORIGINS:
        raise ValueError(f"input_origin is one of {INPUT_ORIGINS}")
    fault = copy.deepcopy(fault_injection)
    run_id = ("Q12R-" if q8 else "Q7R-") + datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + "-" + uuid.uuid4().hex[:8]
    started = now()
    case = C.check_case(json.loads(json.dumps(case, allow_nan=False)))   # a private deep copy: the caller's document is never touched
    reg_sha = C.registered_case_sha(case["case_id"])
    if q8 is None and input_origin == "REGISTERED_CASE" and reg_sha != C.sha256_of(case):
        raise ValueError("input_origin REGISTERED_CASE, but the case is not the registered case file")
    try:
        ctx = C.build(case)
    except Exception as e:             # a defect of the context layer: every expert FAILED (an orchestrator failure, not an input refusal), nothing is guessed
        ctx = {"context_version": C.CONTEXT_VERSION, "case_id": case["case_id"], "case_sha256": C.sha256_of(case), "usable": False, "applicability": {},
               "input_fingerprint": C.sha256_of({"case": case}), "context_error": f"{type(e).__name__}: {str(e)[:300]}", "top_level_problems": []}
    if q8 is not None:
        ctx["q8_blocks"] = copy.deepcopy(q8["blocks"])
        if not q8.get("legacy") and isinstance(ctx.get("data_gaps"), list):   # Q8 checks each item's identity itself (identity report); Q7's blanket gap no longer applies
            ctx["data_gaps"] = [g for g in ctx["data_gaps"] if g.get("code") != "SECTION_ISSUER_UNVERIFIED"]
    recs = {e: _base(e, run_id, ctx) for e in R.ORDER}
    if ctx.get("context_error"):
        for r in recs.values():
            r.update(execution_status="FAILED", execution_error={"kind": "CONTEXT_BUILD_ERROR", "detail": ctx["context_error"]},
                     status_reasons=[_reason("CONTEXT_BUILD_ERROR", "Q7 上下文层出错（编排器缺陷，不是输入被拒）：没有专家被调用", "q7_orchestrator", "$", ctx["context_error"])])
    elif not ctx["usable"]:
        for r in recs.values():
            r.update(execution_status="REJECTED", status_reasons=[_reason(p.get("code"), "研究输入的公共字段（发行人、as_of、来源、数据来源等）不合输入契约，无法建立统一上下文：没有专家能拿到输入",
                                                                          "q7_context", p.get("path", "$"), p.get("detail", "")) for p in ctx["top_level_problems"]])
    else:
        _prestatus(recs, ctx)
        pending = [e for e in R.ORDER if recs[e]["execution_status"] is None]
        try:
            frozen = _frozen()
            idfail = None
            if not isinstance(frozen.get("copies"), dict) or not isinstance(frozen.get("production"), dict):
                raise TypeError("identity records of the wrong shape")
        except Exception as e:          # missing, unparseable or malformed identity records: nothing runs on unchecked code
            frozen, idfail = None, f"{type(e).__name__}: {str(e)[:200]}"
        for e in pending:
            recs[e]["implementation_identity"] = _identity(e, frozen) if frozen else {"files_sha256": {}, "equal_to_frozen": False, "unreadable": idfail, "differs": []}
        blocked = [e for e in pending if not recs[e]["implementation_identity"]["equal_to_frozen"]]
        for e in blocked:
            ii = recs[e]["implementation_identity"]
            code = "IMPLEMENTATION_IDENTITY_UNREADABLE" if ii.get("unreadable") else "IMPLEMENTATION_IDENTITY_MISMATCH"
            recs[e].update(execution_status="NOT_EXECUTED", status_reasons=[_reason(code, "实现文件或冻结身份记录无法读取，或实现与冻结身份不一致，拒绝运行", "q7_orchestrator", "$",
                                                                                  ii.get("unreadable") or ", ".join(ii["differs"]))])
        prod_pending = [e for e in ("technical", "macro") if e in pending]
        if prod_pending and any(e in blocked for e in prod_pending):
            for x in prod_pending:
                if recs[x]["execution_status"] is None:
                    recs[x].update(execution_status="NOT_EXECUTED", status_reasons=[_reason("SHARED_PROCESS_BLOCKED", "两个生产专家共用一个生产链进程，另一个的实现身份不符，所以都不运行", "q7_orchestrator")])
        elif prod_pending:
            pf = fault if fault and R.EXPERTS[fault["expert"]]["runner"] == "production" else None
            try:
                _run_production(recs["technical"], recs["macro"], ctx, pf)
            except Exception as e:                               # an orchestrator defect is a failure of these two, never of the run
                for x in prod_pending:
                    if recs[x]["execution_status"] is None:
                        recs[x].update(execution_status="FAILED", execution_error={"kind": "ORCHESTRATOR_EXCEPTION", "detail": f"{type(e).__name__}: {e}"[:300]},
                                       status_reasons=[_reason("ORCHESTRATOR_EXCEPTION", "编排器在调用生产链时出错", "q7_orchestrator", "$", f"{type(e).__name__}: {e}")])
        for e in ("fundamental", "valuation", "information"):
            if e not in pending or e in blocked:
                continue
            ef = fault if fault and fault.get("expert") == e else None
            try:
                _run_experimental(e, recs[e], ctx, ef)
            except Exception as ex:
                recs[e].update(execution_status="FAILED", execution_error={"kind": "ORCHESTRATOR_EXCEPTION", "detail": f"{type(ex).__name__}: {ex}"[:300]},
                               status_reasons=[_reason("ORCHESTRATOR_EXCEPTION", "编排器处理这个专家时出错", "q7_orchestrator", "$", f"{type(ex).__name__}: {ex}")])
    for r in recs.values():
        assert r["execution_status"] in K.STATUSES, (r["expert_id"], r["execution_status"])
        if r["execution_status"] in ("FAILED", "REJECTED", "ABSTAINED", "NOT_EXECUTED", "NOT_APPLICABLE") and not r["status_reasons"]:
            r["status_reasons"] = [_reason("NO_REASON_RECORDED", "没有记录到具体原因（这本身是一个缺陷）", "q7_orchestrator")]
    differs = None if reg_sha is None else ctx["case_sha256"] != reg_sha
    if q8 is not None:
        input_origin, differs = q8["origin"], q8["differs"]
    rec = {"schema": "Q8_RUN_RECORD_V1" if q8 else "Q7_RUN_RECORD_V1", "run_id": run_id, "orchestrator_version": ORCHESTRATOR_VERSION, "started_at_utc": started,
           "case_id": case["case_id"], "case_label": (q8["model"].get("label") if q8 else case.get("label")), "case_sha256": ctx["case_sha256"],
           "input_fingerprint": q8["model_sha256"] if q8 else ctx["input_fingerprint"],
           "input_origin": input_origin, "input_differs_from_registered_case": differs,
           "fault_injection": fault, "context": {k: v for k, v in ctx.items() if k != "inputs"}, "experts": recs,
           "dependencies": {e: list(R.EXPERTS[e]["depends_on"]) for e in R.ORDER} | {"synthesis": list(R.ORDER)},
           "cache": "none: every run executes the experts again; no result is reused", **_data_labels(q8, input_origin)}
    if q8 is not None:
        rec["q8"] = copy.deepcopy({k: v for k, v in q8.items() if k != "blocks"}) | {"blocks": copy.deepcopy(q8["blocks"])}
    try:
        rec["synthesis"] = S.synthesize(rec)
    except Exception as e:
        rec["synthesis"] = {"status": "FAILED", "error": f"{type(e).__name__}: {str(e)[:300]}"}
    rec["finished_at_utc"] = now()
    bad = K.non_finite_paths(rec) + K.unsafe_int_paths(rec)
    if bad:
        raise ValueError(f"run record not finite / not JSON-safe at {bad[:5]}")
    return rec


DATA_KINDS = {"REAL_PUBLIC_DATA_INTERNAL_TEST": ("PUBLIC_SOURCE_INTERNAL_TEST", ["真实公开数据（内部试验）", "仅限个人内部使用（Tiingo 免费层）", "工程原型", "未经金融验证", "不是投资建议", "非生产"]),
              "REAL_PUBLIC_DATA_USER_MODIFIED": ("PUBLIC_SOURCE_INTERNAL_TEST", ["以真实公开数据为基础，经用户修改或另存（逐项身份见数据身份）", "仅限个人内部使用（Tiingo 免费层）",
                                                                                "工程原型", "未经金融验证", "不是投资建议", "非生产"]),
              "SYNTHETIC": ("SYNTHETIC", ["合成数据", "工程原型", "未经金融验证", "不是投资建议", "非生产"])}


def data_kind(q8: dict | None, input_origin: str) -> str:
    """what the run's data is, from the registry backing of its items (never from the editable provenance field alone - q8_input refuses a case
    whose provenance disagrees with its items) and from where the input came from: the case built from the snapshots, or anything else"""
    if not q8 or not ((q8.get("identity") or {}).get("real_backed_items")):
        return "SYNTHETIC"
    return "REAL_PUBLIC_DATA_INTERNAL_TEST" if input_origin == "REAL_DATA_CASE" and q8.get("differs") is False else "REAL_PUBLIC_DATA_USER_MODIFIED"


def _data_labels(q8: dict | None, input_origin: str) -> dict:
    k = data_kind(q8, (q8 or {}).get("origin") or input_origin)
    return {"data_kind": k, "data_source": DATA_KINDS[k][0], "labels": list(DATA_KINDS[k][1])}


def run_q8(model: dict, fault_injection: dict | None = None, input_origin: str = "PROGRAMMATIC") -> dict:
    """run the five experts on a Q8 input model (or a Q7 case replayed as LEGACY). Problems that leave no usable common block raise
    q8_input.InputError (field level, Chinese) and nothing runs; problems confined to one expert refuse that expert only"""
    from orchestrator import q8_input as Q
    if input_origin not in INPUT_ORIGINS:
        raise ValueError(f"input_origin is one of {INPUT_ORIGINS}")
    _check_fault(fault_injection)
    model = json.loads(json.dumps(model, allow_nan=False))
    prep = Q.prepare(model)
    if not prep["ok"]:
        raise Q.InputError(prep["problems"])
    reg = Q.registered_model(model.get("case_id"))
    msha = Q.model_sha(model)
    if input_origin == "REGISTERED_CASE" and not (reg and reg[1] in ("Q8", "LEGACY_Q7") and reg[0] == msha):
        raise ValueError("input_origin REGISTERED_CASE, but the input is not a registered case")
    if input_origin == "SAVED_USER_CASE" and not (reg and reg[1] == "USER" and reg[0] == msha):
        raise ValueError("input_origin SAVED_USER_CASE, but the input is not a saved user case")
    if input_origin == "REAL_DATA_CASE" and not (reg and reg[1] == "REAL" and reg[0] == msha):
        raise ValueError("input_origin REAL_DATA_CASE, but the input is not the case built from the snapshots")
    q8 = {"input_version": Q.VERSION, "case_format": model.get("case_format"), "legacy": Q.is_legacy(model), "model": model, "model_sha256": msha,
          "origin": input_origin, "compared_with": reg[1] if reg else None, "differs": None if reg is None else reg[0] != msha,
          "identity": prep["identity"], "blocks": prep["blocks"], "problems": prep["problems"],
          "registries_sha256": {k: (hashlib.sha256(f.read_bytes()).hexdigest() if f.exists() else None)       # the registries this run's identity was computed against
                                for k, f in (("real_source_registry", Q.REAL_REGISTRY), ("real_case_index", Q.REAL_INDEX), ("real_price_index", C.REAL_INDEX))}}
    return run_case(prep["q7case"], fault_injection, "PROGRAMMATIC", q8=q8)
