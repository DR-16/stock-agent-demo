"""Q7 - what an expert's output must be before anything downstream may use it, and how a run ends up in one of the six statuses.

Output contract (checked on every output; a violation quarantines the output: the status becomes FAILED and only its fingerprint is kept):
  experimental (te-output-1.1.0)  envelope keys, expert name, output / input contract versions, as_of = case as_of, provenance fixture_id and
                                  issuer_id = the case's, meta_eligibility NOT_ELIGIBLE, predictive_validation NOT_ESTABLISHED, predictive validity
                                  not claimed, every result code registered (code + meaning), no forbidden key anywhere, finite JSON
  production (ModelOutput)        model name and version, asset = the issuer's security, as_of date = the case's UTC date, data_quality finite in
                                  [0, 1], evidence items {metric, value, interpretation, weight, comment}, the five predictive / scoring fields
                                  (signal_score, expected_return, probability_positive, risk_score, confidence) withheld and absent
Post-run guards (the case's time and issuer audit): Information may not use (in any findings field other than its audit fields) a document that is
foreign or available after as_of, nor evidence without an aware availability time; Fundamental may not use evidence available after as_of or
without an available_at, nor a period available after as_of; Valuation may not use a price or financials available after as_of. A breach blocks
the output (FAILED, BLOCKED_BY_GUARD) - it is never shown as a result.

Statuses: COMPLETED (ran, output conforms, produced a result) / ABSTAINED (ran, declined or could not give a result, with reasons) /
REJECTED (input refused by the case context or by the expert) / NOT_APPLICABLE (declared or derivable, with the reason) / FAILED (exception,
crash, timeout, non-finite or non-contract output, guard breach) / NOT_EXECUTED (the expert's code did not run: implementation identity
mismatch or unreadable, module not importable, a shared process blocked). Every FAILED / REJECTED / ABSTAINED status carries at least one reason.
"""
from __future__ import annotations

import math
from datetime import datetime

STATUSES = ("COMPLETED", "ABSTAINED", "REJECTED", "NOT_APPLICABLE", "FAILED", "NOT_EXECUTED")
ENVELOPE = ("expert_name", "prototype_version", "experimental", "execution_status", "analysis_type", "research_status", "data_source", "data_status", "as_of",
            "input_provenance", "input_contract_version", "output_contract_version", "evidence", "counter_evidence", "findings", "confidence_basis", "warnings",
            "missing_dependencies", "abstentions", "calculation_or_extraction_trace", "questions", "predictive_validation", "research_validation_status",
            "meta_eligibility", "production_state_unchanged", "result_codes")
FORBIDDEN_KEYS = {"probability", "probability_positive", "expected_return", "target_price", "price_target", "rating", "recommendation", "buy_sell", "signal_score",
                  "meta_score", "trade_signal", "position_size", "risk_score", "raw_probability_positive", "calibrated_probability_positive"}
PRODUCTION_WITHHELD = ["confidence", "expected_return", "probability_positive", "risk_score", "signal_score"]
INFO_AUDIT_FIELDS = {"documents_processed", "rejection_audit", "metadata_layer", "metadata_ambiguity", "temporal_validation", "information_quality", "notes",
                     "limitations", "research_summary"}    # these list excluded documents on purpose; every other findings field may not name one
EXP_STATUS = {"COMPLETED", "COMPLETED_NO_RESULT", "REJECTED_INPUT", "NOT_RUN", "FAILED"}


def _dt(s):
    """aware datetimes only: a naive or malformed timestamp is unreadable (None), never compared"""
    try:
        d = datetime.fromisoformat(str(s).replace("Z", "+00:00"))
    except ValueError:
        return None
    return d if d.tzinfo is not None else None


def unsafe_int_paths(o, path="$") -> list:
    """integers a JavaScript reader cannot represent exactly (|n| > 2^53): refused in a run record, never rounded"""
    out = []
    if isinstance(o, int) and not isinstance(o, bool) and abs(o) > 2 ** 53:
        out.append(path)
    elif isinstance(o, dict):
        for k, v in o.items():
            out += unsafe_int_paths(v, f"{path}.{k}")
    elif isinstance(o, list):
        for n, v in enumerate(o):
            out += unsafe_int_paths(v, f"{path}[{n}]")
    return out


def non_finite_paths(o, path="$") -> list:
    out = []
    if isinstance(o, float) and not math.isfinite(o):
        out.append(path)
    elif isinstance(o, dict):
        for k, v in o.items():
            out += non_finite_paths(v, f"{path}.{k}")
    elif isinstance(o, list):
        for n, v in enumerate(o):
            out += non_finite_paths(v, f"{path}[{n}]")
    return out


def forbidden_key_paths(o, path="$") -> list:
    out = []
    if isinstance(o, dict):
        for k, v in o.items():
            if str(k).lower() in FORBIDDEN_KEYS:
                out.append(f"{path}.{k}")
            out += forbidden_key_paths(v, f"{path}.{k}")
    elif isinstance(o, list):
        for n, v in enumerate(o):
            out += forbidden_key_paths(v, f"{path}[{n}]")
    return out


def check_experimental(out, spec: dict, ctx: dict) -> list:
    p = []
    if not isinstance(out, dict):
        return [{"code": "OUTPUT_NOT_OBJECT", "path": "$"}]
    miss = [k for k in ENVELOPE if k not in out]
    if miss:
        p.append({"code": "ENVELOPE_FIELD_MISSING", "path": "$", "detail": ", ".join(miss)})
    if out.get("expert_name") != spec["envelope_name"]:
        p.append({"code": "EXPERT_NAME_MISMATCH", "path": "$.expert_name", "detail": str(out.get("expert_name"))})
    if out.get("output_contract_version") != "te-output-1.1.0" or out.get("input_contract_version") != "te-input-1.1.0":
        p.append({"code": "CONTRACT_VERSION_MISMATCH", "path": "$.output_contract_version", "detail": f"{out.get('output_contract_version')} / {out.get('input_contract_version')}"})
    if not str(out.get("prototype_version", "")).startswith(spec["expected_version_prefix"]):
        p.append({"code": "IMPLEMENTATION_VERSION_MISMATCH", "path": "$.prototype_version", "detail": str(out.get("prototype_version"))[:120]})
    if out.get("as_of") != ctx["as_of"]:
        p.append({"code": "AS_OF_MISMATCH", "path": "$.as_of", "detail": f"{out.get('as_of')} vs case {ctx['as_of']}"})
    prov = out.get("input_provenance") or {}
    if prov.get("issuer_id") != ctx["issuer"]["issuer_id"]:
        p.append({"code": "ISSUER_MISMATCH", "path": "$.input_provenance.issuer_id", "detail": f"{prov.get('issuer_id')} vs case {ctx['issuer']['issuer_id']}"})
    if prov.get("fixture_id") != ctx["fixture_id"]:
        p.append({"code": "CASE_IDENTITY_MISMATCH", "path": "$.input_provenance.fixture_id", "detail": f"{prov.get('fixture_id')} vs case {ctx['fixture_id']}"})
    if out.get("meta_eligibility") != "NOT_ELIGIBLE" or out.get("predictive_validation") != "NOT_ESTABLISHED" or \
            (out.get("questions") or {}).get("predictive_validity_demonstrated") is not False:
        p.append({"code": "VALIDATION_CLAIM_NOT_ALLOWED", "path": "$.meta_eligibility", "detail": "an experimental output may not claim eligibility or predictive validity"})
    if out.get("execution_status") not in EXP_STATUS:
        p.append({"code": "EXECUTION_STATUS_UNKNOWN", "path": "$.execution_status", "detail": str(out.get("execution_status"))})
    for n, c in enumerate(out.get("result_codes") or []):
        if not isinstance(c, dict) or not c.get("code") or not c.get("meaning"):
            p.append({"code": "RESULT_CODE_UNREGISTERED", "path": f"$.result_codes[{n}]"})
    for fp in forbidden_key_paths(out):
        p.append({"code": "FORBIDDEN_FIELD", "path": fp, "detail": "a score / probability / target / rating field is not part of this contract"})
    for np_ in non_finite_paths(out):
        p.append({"code": "NON_FINITE_VALUE", "path": np_})
    return p


def check_production(out, spec: dict, ctx: dict, withheld: dict) -> list:
    p = []
    if not isinstance(out, dict):
        return [{"code": "OUTPUT_NOT_OBJECT", "path": "$"}]
    if out.get("model_name") != spec["model_name"]:
        p.append({"code": "EXPERT_NAME_MISMATCH", "path": "$.model_name", "detail": str(out.get("model_name"))})
    if out.get("model_version") != spec["expected_version"]:
        p.append({"code": "IMPLEMENTATION_VERSION_MISMATCH", "path": "$.model_version", "detail": str(out.get("model_version"))})
    if out.get("asset") != ctx["issuer"].get("security"):
        p.append({"code": "ISSUER_MISMATCH", "path": "$.asset", "detail": f"{out.get('asset')} vs security {ctx['issuer'].get('security')}"})
    if str(out.get("as_of", ""))[:10] != ctx["as_of_utc_date"]:
        p.append({"code": "AS_OF_MISMATCH", "path": "$.as_of", "detail": f"{out.get('as_of')} vs case UTC date {ctx['as_of_utc_date']}"})
    for k in ("data_quality",):
        x = out.get(k)
        if not isinstance(x, (int, float)) or isinstance(x, bool) or not math.isfinite(x) or not 0 <= x <= 1:
            p.append({"code": "VALUE_OUT_OF_CONTRACT", "path": f"$.{k}", "detail": str(x)})
    for side in ("evidence", "counter_evidence"):
        for n, e in enumerate(out.get(side) or []):
            if not isinstance(e, dict) or not {"metric", "value", "interpretation", "weight", "comment"} <= set(e):
                p.append({"code": "EVIDENCE_ITEM_MALFORMED", "path": f"$.{side}[{n}]"})
    if sorted(withheld.get("names", [])) != PRODUCTION_WITHHELD:
        p.append({"code": "PREDICTIVE_FIELDS_NOT_WITHHELD", "path": "$", "detail": str(withheld.get("names"))})
    for k in PRODUCTION_WITHHELD:
        if k in out:
            p.append({"code": "FORBIDDEN_FIELD", "path": f"$.{k}", "detail": "a withheld production field reached the output"})
    for fp in forbidden_key_paths(out):
        p.append({"code": "FORBIDDEN_FIELD", "path": fp})
    for np_ in non_finite_paths(out):
        p.append({"code": "NON_FINITE_VALUE", "path": np_})
    return p


def _doc_refs(o, path="$") -> list:
    """(path, document id) for every structured reference to a document: a document_id key, a documents list, a record_id 'DOC#...'"""
    out = []
    if isinstance(o, dict):
        for k, v in o.items():
            if k == "document_id" and isinstance(v, str):
                out.append((f"{path}.{k}", v))
            elif k == "documents" and isinstance(v, list):
                out += [(f"{path}.{k}[{n}]", x) for n, x in enumerate(v) if isinstance(x, str)]
            elif k == "record_id" and isinstance(v, str) and "#" in v:
                out.append((f"{path}.{k}", v.split("#", 1)[0]))
            out += _doc_refs(v, f"{path}.{k}")
    elif isinstance(o, list):
        for n, v in enumerate(o):
            out += _doc_refs(v, f"{path}[{n}]")
    return out


def _string_leaves(o, path="$") -> list:
    out = []
    if isinstance(o, str):
        out.append((path, o))
    elif isinstance(o, dict):
        for k, v in o.items():
            out += _string_leaves(v, f"{path}.{k}")
    elif isinstance(o, list):
        for n, v in enumerate(o):
            out += _string_leaves(v, f"{path}[{n}]")
    return out


def _avail(day, ctx) -> datetime | None:
    """the instant a daily price dated `day` counts as available, by the same declaration the context used (fixtures/q7_price_declarations.json)"""
    t = ctx.get("valuation_price_available_utc") or "21:00:00"
    return _dt(f"{day}T{t}+00:00") if isinstance(day, str) and len(day) == 10 else None


def guards(eid: str, out: dict, ctx: dict) -> list:
    """time / issuer breaches in a conforming experimental output (defence in depth: the experts are expected to exclude these themselves)"""
    if not isinstance(out, dict):
        return []
    as_of = _dt(ctx["as_of"])
    issuer = ctx["issuer"]["issuer_id"]
    b = []
    if eid == "information":
        f = out.get("findings") or {}
        recs = [("evidence", n, r) for n, r in enumerate(out.get("evidence") or [])] + [("findings.supporting_evidence", n, r) for n, r in enumerate(f.get("supporting_evidence") or [])]
        for where, n, r in recs:
            if not isinstance(r, dict):
                continue
            av = _dt(r.get("availability_timestamp")) if r.get("availability_timestamp") else None
            if av is None:
                b.append({"code": "AVAILABILITY_UNVERIFIABLE", "path": f"{where}[{n}]", "detail": f"{r.get('document_id')}: availability {r.get('availability_timestamp')!r} is not an aware timestamp"})
            elif as_of and av > as_of:
                b.append({"code": "FUTURE_EVIDENCE_USED", "path": f"{where}[{n}]", "detail": f"{r.get('document_id')} available {r.get('availability_timestamp')} > as_of"})
            if r.get("issuer_id") not in (None, issuer):
                b.append({"code": "FOREIGN_ISSUER_EVIDENCE_USED", "path": f"{where}[{n}]", "detail": f"{r.get('document_id')} issuer {r.get('issuer_id')}"})
        foreign = {x["document_id"] for x in ctx.get("issuer_audit", []) if x.get("state") == "FOREIGN" and isinstance(x.get("document_id"), str)}
        future = {t["where"].split("[", 1)[1][:-1] for t in ctx.get("time_audit", []) if str(t.get("where", "")).startswith("information.documents") and t.get("after_as_of")}
        blocked = foreign | future
        for n, a in enumerate(f.get("abstentions") or []):          # an exclusion / abstention record names the document on purpose; anything else may not
            if isinstance(a, dict) and isinstance(a.get("document_id"), str) and a["document_id"] in blocked and a.get("status") not in ("EXCLUDED", "ABSTAINED"):
                b.append({"code": "BLOCKED_DOCUMENT_NOT_EXCLUDED", "path": f"findings.abstentions[{n}]", "detail": str(a.get("document_id"))})
        for n, c in enumerate(f.get("claims_verification") or []):  # a claim that cites a blocked document may only be answered "not evaluated / excluded"
            if not isinstance(c, dict):
                continue
            refused = c.get("citation") == "CITATION_NOT_EVALUATED" and c.get("source_status") == "SOURCE_EXCLUDED" and not c.get("related_records")
            if isinstance(c.get("document_id"), str) and c["document_id"] in blocked and not refused:
                b.append({"code": "BLOCKED_DOCUMENT_USED_FOR_CLAIM", "path": f"findings.claims_verification[{n}]", "detail": str(c.get("document_id"))})
            for path, d in _doc_refs(c.get("related_records"), f"findings.claims_verification[{n}].related_records"):
                if d in blocked:
                    b.append({"code": "BLOCKED_DOCUMENT_USED_FOR_CLAIM", "path": path, "detail": str(d)})
        scan = [("evidence", out.get("evidence"))] + [(f"findings.{k}", v) for k, v in f.items() if k not in INFO_AUDIT_FIELDS | {"abstentions", "claims_verification"}]
        for base, val in scan:      # ANY text value naming a blocked document (a document_id, a record id 'DOC#...', an 'amendment', a 'supersedes', ...) is a use
            for path, sv in _string_leaves(val, base):
                d = sv.split("#", 1)[0]
                if d in foreign:
                    b.append({"code": "FOREIGN_ISSUER_DOCUMENT_USED", "path": path, "detail": d})
                if d in future:
                    b.append({"code": "FUTURE_DOCUMENT_USED", "path": path, "detail": d})
    if eid == "fundamental":
        for n, r in enumerate(out.get("evidence") or []):
            if not isinstance(r, dict):
                continue
            av = _dt(r.get("available_at")) if r.get("available_at") else None
            if av is None:
                b.append({"code": "AVAILABILITY_UNVERIFIABLE", "path": f"evidence[{n}]", "detail": f"{r.get('source_document_id')}: available_at {r.get('available_at')!r}"})
            elif as_of and av > as_of:
                b.append({"code": "FUTURE_EVIDENCE_USED", "path": f"evidence[{n}]", "detail": f"{r.get('source_document_id')} available {r.get('available_at')} > as_of"})
        future_fy = {t["where"][len("fundamental.periods[FY"):-1] for t in ctx.get("time_audit", []) if t["where"].startswith("fundamental.periods") and t.get("after_as_of")}
        used = {str(y) for y in ((out.get("data_status") or {}).get("usable_periods") or [])}
        for y in sorted(future_fy & used):
            b.append({"code": "FUTURE_PERIOD_USED", "path": "data_status.usable_periods", "detail": f"FY{y} is available after as_of but was used"})
    if eid == "valuation" and out.get("execution_status") in ("COMPLETED", "COMPLETED_NO_RESULT"):
        vals = [t.get("values") for t in (out.get("findings") or {}).get("calculation_trace") or [] if isinstance(t, dict) and isinstance(t.get("values"), dict)]
        pdates = [v["price_date"] for v in vals if v.get("price_date")]
        fats = [v["financials_available_at"] for v in vals if v.get("financials_available_at")]
        if not pdates or not fats:
            b.append({"code": "AVAILABILITY_UNVERIFIABLE", "path": "findings.calculation_trace", "detail": "price_date / financials_available_at not found in the output"})
        for d in pdates:
            pav = _avail(d, ctx)
            if pav is None or (as_of and pav > as_of):
                b.append({"code": "FUTURE_PRICE_USED", "path": "findings.calculation_trace[*].values.price_date", "detail": f"price of {d} counts as available at {pav} > as_of"})
        for d in fats:
            fav = _dt(d)
            if fav is None or (as_of and fav > as_of):
                b.append({"code": "FUTURE_EVIDENCE_USED", "path": "findings.calculation_trace[*].values.financials_available_at", "detail": f"financials available {d} > as_of"})
    return b


def experimental_status(out: dict) -> tuple:
    """(status, reasons) of a conforming te-output envelope"""
    es = out.get("execution_status")
    codes = [{"code": c.get("code"), "meaning": c.get("meaning"), "path": c.get("path"), "source": "expert"} for c in out.get("result_codes") or []]
    abst = [{"code": a.get("code"), "meaning": a.get("meaning"), "path": a.get("path"), "source": "expert"} for a in out.get("abstentions") or [] if isinstance(a, dict)]
    if es == "COMPLETED":
        ds = out.get("data_status") or {}
        if out.get("expert_name") == "Information" and ds.get("analysed") == 0:
            return "ABSTAINED", codes + [{"code": "NO_USABLE_DOCUMENTS", "meaning": "没有任何文件被分析（全部被排除或没有文件），所以没有结果", "path": "$.data_status.analysed", "source": "q7_contract"}]
        return "COMPLETED", []
    if es == "COMPLETED_NO_RESULT":
        return "ABSTAINED", codes + abst + [{"code": "NO_RESULT", "meaning": "专家运行了，但没有任何方法给出结果", "path": "$.execution_status", "source": "expert"}]
    if es == "REJECTED_INPUT":
        return "REJECTED", codes or [{"code": "NO_REASON_GIVEN_BY_EXPERT", "meaning": "专家拒绝了输入但没有给出原因代码", "path": "$.result_codes", "source": "q7_contract"}]
    if es == "NOT_RUN":
        if any(c["code"] == "SECTION_ABSENT" for c in codes):
            return "REJECTED", codes + [{"code": "SECTION_ABSENT_UNDECLARED", "meaning": "必需的输入部分缺失，且案例没有声明它不适用", "path": "$", "source": "q7_context"}]
        return "ABSTAINED", codes + abst + [{"code": "NO_SUPPORTED_REQUEST", "meaning": out.get("confidence_basis", ""), "path": "$", "source": "expert"}]
    return "FAILED", codes or [{"code": "NO_REASON_GIVEN_BY_EXPERT", "meaning": "专家报告失败但没有给出原因代码", "path": "$.result_codes", "source": "q7_contract"}]


def production_status(out: dict, report_warnings: list) -> tuple:
    md = out.get("metadata") or {}
    reason = md.get("reason_no_signal")
    if reason is None:
        return "COMPLETED", []
    if str(reason).startswith("exception:"):
        w = [x for x in report_warnings if str(x).startswith(f"model {out.get('model_name')} ")]
        return "FAILED", [{"code": "EXPERT_EXCEPTION", "meaning": "生产模型在生产编排器内抛出异常；编排器用空输出代替（不是结果）", "path": "$.metadata.reason_no_signal",
                           "detail": f"{reason}; {w[0] if w else ''}"[:300], "source": "expert"}]
    return "ABSTAINED", [{"code": "NO_SIGNAL", "meaning": "生产模型放弃判断", "path": "$.metadata.reason_no_signal", "detail": str(reason)[:300], "source": "expert"}]
