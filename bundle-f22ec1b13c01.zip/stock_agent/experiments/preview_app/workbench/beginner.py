"""Q11 beginner's report (q11-beginner 1.0.0): what a beginner sees first, built from the run's own expert outputs - in plain Chinese, in four
separate parts, each key point with the evidence it rests on:

  facts        公司事实：公告里的管理层变动（谁、什么职务、何时生效、在 as_of 是否已生效）、财报里的数字（哪一年、来自哪份数据）
  readings     指标解读：技术面、宏观、估值倍数 —— 说明这是规则读法 / 描述值，不是买卖建议
  gaps         数据缺口：哪些数据缺了、因此哪些没有算（不按零处理）
  limits       系统限制：离线快照、未经金融验证、抽取是待核实线索、年报不是 TTM、时点未核实 ……（真实限制不隐藏）
  experts      五个专家各自有没有结果，没有的原因
  advanced     内部代码、规则编号、记录编号（只在“高级详情”里）

No internal code, rule id or record id appears in the four main parts (a test checks this); they stay in `advanced`. Nothing here is computed
anew: every number and every event is read from the run record, with its source.
"""
from __future__ import annotations

import re

VERSION = "q13-beginner 1.4.1"   # 1.4.1 (Q13 independent review N1-N16, records/q13_reviews/review_beginner_data_layer.md): the reference-range sentence per method; a computed DCF is said (not shown as prices); superseded records do not point to a version that is itself contradicted; ROIC with a meaningless tax rate is said as such; a filing excluded for contradictory times is listed under needs-check; tentative wording is not put in the person's mouth; Form 4 codes in words with their direction and the 10b5-1 footnote as evidence; valuation evidence names the price date, the fiscal year and the sources; relative strength in points; a P/B of limited relevance says so; needs-check changes carry their dates. 1.4.0 (Q13 consistency audit, records/q13_consistency/audit_raw.json): an expert whose input was rejected says which field or which other company's data stopped it (it used to say '运行没有正常完成'), one gap per reason; Form 4 rows are leads, not facts, with the filer's role and the 10b5-1 flag; technical / macro readings carry the date of their last data row, and a price series that ends early or a valuation price of another day is a gap; a declared reference range is not called absent; a negative base FCF is not called a missing assumption; 'not meaningful' and 'no qualified source' are not called missing data; fundamental facts name their source (counter evidence and inputs_by_year too); deterioration flags come from the expert's indicators and risk flags, not from text matching; superseded / contradicted 8-K records say so; the macro model's environment hint is shown; a synthetic case has no snapshot time. 1.3.0 (Q12): 8-K events are leads (out["leads"]), not facts; (Q11 R6): missing / not available / not meaningful / no interest expense / no prior year said apart; a capacity is not quoted as a title. 1.2.0 (Q12): Form 4 rows and other non-management events no longer crash the report (KeyError on a synthetic case). 1.1.2   # 1.1.0 (mid-round review): technical / macro evidence names the price dataset; the price date is the case's own; an
                                 # expert with no valid finding is not '有结果'; repeated gaps once; evidence numbers formatted
FIELD_ZH = {"revenue": "收入", "net_income": "净利润", "stockholders_equity": "股东权益", "operating_income": "营业利润", "depreciation_amort": "折旧摊销",
            "operating_cash_flow": "经营现金流", "capex": "资本开支", "long_term_debt": "长期债务", "short_term_debt": "短期债务", "cash_and_equivalents": "现金及等价物",
            "total_assets": "总资产", "total_liabilities": "总负债", "current_assets": "流动资产", "current_liabilities": "流动负债", "interest_expense": "利息费用",
            "cost_of_revenue": "营业成本", "gross_profit": "毛利", "shares_outstanding": "股数", "price": "股价", "pretax_income": "税前利润",
            "income_tax_expense": "所得税", "shares": "股数", "market_cap": "市值", "enterprise_value": "企业价值", "free_cash_flow": "自由现金流",
            "total_debt": "债务合计", "cash": "现金", "ebitda": "EBITDA（营业利润 + 折旧摊销）", "price_date": "价格日期", "fiscal_year": "财年"}
METHOD_ZH = {"TRAILING_PE": "市盈率", "PRICE_TO_BOOK": "市净率", "EV_EBITDA": "企业价值 / EBITDA", "EV_SALES": "企业价值 / 收入", "FCF_YIELD": "自由现金流收益率",
             "FORWARD_PE": "前瞻市盈率", "PEG": "PEG", "DCF_FCF": "现金流折现估值"}
TECH_ZH = {"momentum_12m_1m": "过去 12 个月涨幅（不含最近 1 个月）", "relative_strength_6m": "近 6 个月相对大盘（SPY）的表现", "sma50_sma200_ratio": "50 日均线与 200 日均线之比",
           "momentum_1m": "近 1 个月涨幅", "momentum_3m": "近 3 个月涨幅", "momentum_6m": "近 6 个月涨幅", "volatility_63d_ann": "近 3 个月年化波动率",
           "max_drawdown_2y": "两年内最大回撤", "rsi_14": "14 日 RSI", "tnx_change_6m": "10 年期国债利率（美国财政部数据，替代 ^TNX）6 个月变化",
           "tnx_level": "10 年期国债利率", "irx_level": "13 周国库券利率", "yield_curve_slope": "长短端利差", "vix_level": "VIX 波动率指数",
           "credit_risk_proxy_change_3m": "信用风险代理 3 个月变化", "usd_proxy_change_3m": "美元代理 3 个月变化"}
PCT = ("momentum_12m_1m", "relative_strength_6m", "momentum_1m", "momentum_3m", "momentum_6m", "volatility_63d_ann", "max_drawdown_2y",
       "credit_risk_proxy_change_3m", "usd_proxy_change_3m")
CLASS_ZH = {"EXPANDING": "增长", "CONTRACTING": "下降", "FLAT": "基本持平", "INSUFFICIENT_DATA": "数据不足，无法判断", "NOT_MEANINGFUL": "数值异常，无法计算",
            "IMPROVING": "改善", "STABLE": "稳定", "DETERIORATING": "下滑", "INCREASING": "上升", "DECREASING": "下降"}
STATUS_ZH = {"IN_EFFECT": "截至报告日已生效", "NOT_YET_EFFECTIVE": "截至报告日尚未生效", "ENDED": "截至报告日已经结束", "PENDING_INTENTION": "只是意向，尚未确定",
             "UNKNOWN": "公告没有写明生效日期，截至报告日是否生效无法判断"}
ACTION_ZH = {"APPOINTMENT": "被任命为", "DEPARTURE": "卸任", "CONTINUATION": "继续担任"}
EXPERT_ZH = {"technical": "技术面（价格走势）", "macro": "宏观（市场环境）", "fundamental": "基本面（财报）", "valuation": "估值（倍数）", "information": "公告（管理层变动、内部人交易）"}
EXPERT_SHORT = {"technical": "技术面", "macro": "宏观", "fundamental": "基本面", "valuation": "估值", "information": "公告"}
F4_CODE_ZH = {"G": "赠与", "M": "行使期权或转换", "F": "以股份缴税", "A": "获授股份", "D": "股份交回公司", "J": "其他交易", "C": "转换", "X": "行权", "W": "继承或遗赠"}
F4_ROLE_ZH = {"DIRECTOR": "董事", "OFFICER": "高管", "TEN_PERCENT_OWNER": "持股 10% 以上的股东", "OTHER": "其他身份"}
REGIME_ZH = {"macro_supportive": "偏支持", "macro_neutral": "中性", "macro_stress": "偏紧张"}
IND_ZH = {"revenue_down": ("收入比上一年下降", "revenue_growth"), "operating_margin_down": ("营业利润率比上一年下降", "operating_margin"),
          "net_margin_down": ("净利率比上一年下降", "net_margin"), "leverage_up": ("债务与权益之比比上一年上升", "debt_to_equity"),
          "current_ratio_down": ("流动比率比上一年下降", "current_ratio"), "cash_conversion_down": ("经营现金流与净利润之比比上一年下降", "cash_conversion")}
RISK_ZH = {"LOSS_MAKING": "净利润为负（亏损）", "NEGATIVE_OPERATING_CASH_FLOW": "经营现金流为负", "NEGATIVE_FREE_CASH_FLOW": "自由现金流为负",
           "OPERATING_LOSS_INTEREST_UNCOVERED": "营业利润为负，不够支付利息费用", "CURRENT_LIABILITIES_EXCEED_CURRENT_ASSETS": "流动负债超过流动资产"}   # the other risk flags repeat an indicator
CODE_RX = re.compile(r"\b(?:[A-Z][A-Z0-9]*_[A-Z0-9_]+|[a-z]+_[a-z0-9_]+|Q\d+R\d+-\d+|R-[A-Z]\d|V2-[A-Z]+-[A-Z]+|[0-9]{10}-[0-9]{2}-[0-9]{6}(?:#\S+)?)\b")


def _num(v):
    """an evidence number as a person reads it (no 17-digit floats); text and None as they are"""
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return v
    if v != v or v in (float("inf"), float("-inf")):
        return "不是有限数"
    return f"{v:,.0f}" if abs(v) >= 1000 else f"{v:.4g}"


def _pct(x) -> str:
    return f"{x * 100:+.1f}%" if isinstance(x, (int, float)) else "—"


def _role_zh(role: str | None) -> str:
    if not role:
        return "（公告没有写明职务）"
    if role == "Director":
        return "董事"
    m = re.fullmatch(r"(Member|Chair) of the (.+ Committee)", role)
    if m:
        return f"董事会 {m.group(2)} {'主席' if m.group(1) == 'Chair' else '成员'}"
    if re.search(r"\bcapacity\b", role, re.I):                        # 1.3.0 (Q11 R6): 'in a non-executive capacity' is a way of serving, not a title
        return f"以“{role}”的身份（这是任职方式，不是具体职务）"
    return f"“{role}”"


METRIC_ZH = {"liabilities_to_assets": "负债/资产", "current_ratio": "流动比率", "debt_to_equity": "债务/权益", "interest_coverage": "利息保障倍数",
             "gross_margin": "毛利率", "operating_margin": "营业利润率", "net_margin": "净利率", "roe": "净资产收益率", "roic": "投入资本回报率",
             "cash_conversion": "经营现金流/净利润", "fcf_margin": "自由现金流率", "revenue_growth": "收入增长", "total_debt": "债务合计（长期 + 短期）",
             "net_debt": "净债务", "effective_tax_rate": "实际税率", "free_cash_flow": "自由现金流", "asset_turnover": "资产周转率"}
NOT_MEANINGFUL_ZH = {"DENOMINATOR_ZERO": "作为分母的数字是零", "DENOMINATOR_NEGATIVE": "作为分母的数字是负数", "NEGATIVE_EQUITY": "股东权益为负数",
                     "VALUE_NOT_REPRESENTABLE": "算出的数值不是有限数", "PRETAX_LOSS": "税前是亏损"}
CHECK_ZH = {"ACCOUNTING_IDENTITY_MISMATCH": "会计恒等式核对", "LEVERAGE_INCREASING": "杠杆是否上升", "REVENUE_CONTRACTING": "收入是否下降",
            "OPERATING_MARGIN_DETERIORATING": "营业利润率是否下滑", "EARNINGS_CASH_DIVERGENCE": "利润与经营现金流是否背离",
            "CURRENT_LIABILITIES_EXCEED_CURRENT_ASSETS": "流动负债是否超过流动资产"}


def _missing_zh(m: dict, F: dict | None = None) -> str:
    """1.3.0 (Q12, Q11 R6): a missing field, a missing input, a value the source does not give, no interest expense and a ratio that is not
    meaningful although its inputs are present are different things; each is said as what it is (the report used to call all of them missing data)"""
    st = m.get("status")
    if m.get("field"):
        return f"财报缺少“{FIELD_ZH.get(m['field'], '一项数据')}”（FY{m.get('fiscal_year')}），用到它的指标没有算（不按零处理）。"
    nm_ = METRIC_ZH.get(m.get("metric"), "一项比率")
    if st == "NOT_MEANINGFUL":
        det = str(((((F or {}).get("metrics_by_year") or {}).get(str(m.get("fiscal_year"))) or {}).get(m.get("metric")) or {}).get("code", {}).get("detail") or "")
        if "effective tax rate is not meaningful" in det:          # 1.4.1 (review N7, audit #12): the input is not missing and no denominator is negative
            return f"“{nm_}”没有算：它要用的实际税率没有意义（税前是亏损或为零），所以这个比率没有意义（不是缺数据，也不按零处理）。"
        why = NOT_MEANINGFUL_ZH.get(m.get("reason"), "数值上没有意义")
        return f"“{nm_}”没有算：所需数据齐全，但{why}，这个比率没有意义（不是缺数据，也不按零处理）。"
    if st == "NO_INTEREST_EXPENSE":
        return f"“{nm_}”不适用：财报没有利息费用（不是缺数据）。"
    if st == "NOT_AVAILABLE":
        return f"“{nm_}”没有算：来源没有提供所需的数据（不按零处理）。"
    return f"财报缺少计算“{nm_}”所需的数据，这一项没有算（不按零处理）。"


def _indeterminate_zh(it: dict) -> str:
    name = CHECK_ZH.get(it.get("check"), "一项检查")
    need = " ".join(str(x) for x in it.get("inputs_needed") or [])
    if it.get("why"):                                                  # inputs present, a ratio in it not meaningful (RISK_CHECK_NOT_MEANINGFUL)
        return f"风险检查“{name}”无法判断：所需数据齐全，但其中的比率没有意义（例如分母为零或为负）；无法判断不等于没有风险。"
    if "prior fiscal year" in need:                                    # fundamental +q11.4 (R1): no comparison year in the input
        return f"风险检查“{name}”无法判断：缺少上一财年的数据，无法做同比比较；无法判断不等于没有风险。"
    return f"风险检查“{name}”因缺少输入无法判断；无法判断不等于没有风险。"


def _status_zh(e: dict, d: dict) -> str:
    """1.3.0 (Q12): 'no effective date' only when the record has none (a dated record whose status is unknown used to be called undated)"""
    st = e.get("current_status")
    if e.get("evidence_status") == "SUPERSEDED":                      # 1.4.0 (Q13 audit #8): the real reason, not a date conflict
        return "已被后来的修订公告取代；修订后的说法见同一人的其他条目，也需要核实"
    if e.get("evidence_status") == "CONTRADICTED":
        return "与另一份公告矛盾，截至报告日是否生效无法判断"
    if st in STATUS_ZH and st != "UNKNOWN":
        return STATUS_ZH[st]
    if d.get("effective_date") or (d.get("linked_date") or {}).get("value"):
        return "截至报告日是否生效无法判断：日期或读法不唯一，系统不判断哪一个对"
    return STATUS_ZH["UNKNOWN"]


def _reason_zh_form4(reason) -> str:
    return {"shares must be a positive number": "股数不是正数"}.get(str(reason), f"记录不完整（{reason}）")


def _date_zh(det: dict) -> str:
    b = det.get("date_basis")
    ev = det.get("date_evidence") or {}
    if det.get("effective_date"):
        where = {"DEFINED_TERM": f"（公告在{_sec_zh(ev.get('section'))}把“{ev.get('defined_term')}”定义为这一天）",
                 "OTHER_SECTION": f"（生效日期写在{_sec_zh(ev.get('section'))}）"}.get(b, "")
        return f"{det['effective_date']} 生效{where}"
    if det.get("linked_date"):
        return f"与前一项变动同日生效（{det['linked_date']['value']}，公告原文是“the same date”）"
    if det.get("event_date"):
        return f"公告写明决定日期 {det['event_date']}，但没有写明生效日期"
    return "公告没有写明生效日期"


def _sec_zh(s: str | None) -> str:
    if not s:
        return "公告中"
    if s.startswith("Explanatory"):
        return "开头的说明段"
    return s.replace("Item ", "第 ") + " 项"


def _shares_date(rec: dict) -> str | None:
    for it in ((rec.get("q8") or {}).get("identity") or {}).get("items", {}).get("valuation") or []:
        for s_ in it.get("source_says") or []:
            m = re.search(r"股数 [0-9]+：.*?截至 ([0-9]{4}-[0-9]{2}-[0-9]{2})", s_)
            if m:
                return m.group(1)
    return None


def build(rec: dict, ticker: str, company: str, as_of: str, snap: dict) -> dict:
    E = rec["experts"]
    out = {"version": VERSION, "company": company, "ticker": ticker, "as_of": as_of, "facts": [], "leads": [], "readings": [], "gaps": [], "limits": [], "experts": [],
           "needs_check": [], "advanced": {"codes": [], "record_ids": [], "rule_ids": []}}
    seen_dd = set()
    dates = [(k_zh, snap.get(k)) for k, k_zh in (("sec_filings", "SEC 申报列表"), ("sec_xbrl", "SEC 财报数据"), ("prices", "日线价格"), ("vix", "VIX"),
                                                 ("treasury", "国债利率")) if snap.get(k)]
    synthetic = str(rec.get("data_kind") or "").upper() == "SYNTHETIC"
    if dates:
        out["data_notice"] = "本次使用已有数据（离线快照），不是刚刚获取的最新数据。" + "快照取得时间：" + "；".join(f"{a} {b[:16].replace('T', ' ')} UTC" for a, b in dates)
    elif synthetic:                                                  # 1.4.0 (Q13 audit #16): a synthetic case has no snapshot to date
        out["data_notice"] = "合成测试数据：为测试编写，没有联网取数，也没有快照时间。"
    else:
        out["data_notice"] = "本次使用已有数据（离线快照），不是刚刚获取的最新数据；快照取得时间没有记录。"
    # ---- Information: management changes
    I = E["information"]
    if I["execution_status"] == "COMPLETED":
        F = (I.get("output") or {}).get("findings") or {}
        det = {r["record_id"]: r for r in F.get("all_extraction_records") or []}
        docs = {d["document_id"]: d for d in F.get("documents_processed") or []}
        shown = 0
        for e in F.get("events_detected") or []:
            r = det.get(e["record_id"]) or {}
            d = r.get("details") or {}
            ev = {"kind": "公告原文", "document": e["document_id"], "form": r.get("form_type"), "available": (r.get("availability_timestamp") or "")[:10],
                  "section": (r.get("evidence_location") or {}).get("section"), "quote": e.get("exact_evidence_span"),
                  "date_quote": (d.get("date_evidence") or {}).get("text")}
            out["advanced"]["record_ids"].append(e["record_id"])
            out["advanced"]["rule_ids"].append(((r.get("extraction_method") or {}).get("rule_id")))
            cat = str(e.get("event_category") or "")
            if cat.startswith("INSIDER_TRANSACTION"):          # Q12: Form 4 rows (synthetic cases have them; real Form 4 is not supported)
                ev = {**ev, "kind": "Form 4 原文", "section": None}
                if not d.get("transaction_type"):
                    out["needs_check"].append({"text": f"一行内部人交易记录没有使用：{_reason_zh_form4(d.get('reason'))}", "status": "无法判断", "evidence": ev})
                    continue
                who = "、".join((o.get("name") or "") + f"（{_f4_role(o.get('role'))}）" for o in d.get("owners") or []) or "（没有写明交易人）"
                dir_ = {"A": "股份转入", "D": "股份转出"}.get(d.get("acquired_disposed"), "方向未写明")
                kind_ = {"PURCHASE": "买入", "SALE": "卖出"}.get(d["transaction_type"]) or \
                    f"{F4_CODE_ZH.get(str(d.get('raw_code')), '其他类型交易')}（申报代码 {d.get('raw_code')}，{dir_}）"      # 1.4.1 (review N10)
                fn_ = (d.get("ten_b5_1") or {}).get("footnote_text")
                if fn_:
                    ev = {**ev, "footnote": fn_}
                px = f"，每股 {_num(d['price'])}" if d.get("price") is not None else "，没有写明价格"
                tb = {"TRUE": "申报标明是 10b5-1 预先计划交易", "FALSE": "申报标明不是 10b5-1 预先计划交易"}.get(str((d.get("ten_b5_1") or {}).get("value")),
                                                                                                    "申报没有写明是否 10b5-1 预先计划交易")
                # 1.4.0 (Q13 audit #2, #11): a row the experimental expert extracted is a lead, like an 8-K event; the filer's role and the 10b5-1 flag are kept
                out["leads"].append({"kind": "内部人交易（Form 4）", "text": f"{who}在 {d.get('transaction_date')} {kind_} {_num(d.get('shares'))} 股{px}；{tb}（Form 4 申报原文，按申报原样列出，未核实）。",
                                     "status": None, "evidence": ev})
                continue
            if d.get("action") not in ACTION_ZH and d.get("action") != "DEPARTURE":     # Q12: any other event kind is listed with its original claim
                out["needs_check"].append({"text": f"其他类型的公告事件（系统没有中文说明，下面是原文摘要）：{e.get('claim')}", "status": "无法判断", "evidence": ev})
                continue
            if d.get("modality") == "TENTATIVE" or e.get("ambiguity_status") != "UNAMBIGUOUS" or e.get("evidence_status") in ("CONTRADICTED", "SUPERSEDED"):
                why = ("措辞是可能或意向（例如“may”“打算”），不是确定的决定" if d.get("modality") == "TENTATIVE" else
                       "公告没有写明是哪个职务" if not d.get("role") else
                       "委员会名单怎么拆分，原文不能确定" if "committees" in str(e.get("claim")) else
                       "另一份公告与它不一致" if e.get("evidence_status") == "CONTRADICTED" else
                       "已被后来的修订公告取代（修订后的说法也要核实）" if e.get("evidence_status") == "SUPERSEDED" else
                       f"几份公告给出的生效日期不一致（{'、'.join(d['date_disagreement'])}），系统不判断哪一个对" if d.get("date_disagreement") else "原文的读法不唯一")
                dkey = ("DD", str(d.get("person")), str(d.get("role")), tuple(d.get("date_disagreement") or ())) if d.get("date_disagreement") else None
                if dkey and dkey in seen_dd:                  # 1.3.0: one line for one disagreement (each filing's record carries it)
                    continue
                if dkey:
                    seen_dd.add(dkey)
                verb = ({"DEPARTURE": "可能离任", "APPOINTMENT": "可能被任命为", "CONTINUATION": "可能继续担任"} if d.get("modality") == "TENTATIVE" else
                        {"DEPARTURE": "卸任", "APPOINTMENT": "被任命为", "CONTINUATION": "继续担任"}).get(d.get("action"), "")
                rz = _role_zh(d.get("role")) if d.get("role") else ("（公告没有写明职务）" if d.get("modality") != "TENTATIVE" else "")
                dz = f"（{_date_zh(d)}）" if d.get("modality") != "TENTATIVE" else ""          # 1.4.1 (review N16): the date the filing gives
                out["needs_check"].append({"text": f"{d.get('person')} {verb}{rz}{dz}——需要核实：{why}",
                                           "status": _status_zh(e, d), "evidence": ev})
                continue
            shown += 1
            act = d.get("action")
            txt = (f"{d.get('person')} {ACTION_ZH[act]}{_role_zh(d.get('role'))}" if act != "DEPARTURE" else f"{d.get('person')} 卸任{_role_zh(d.get('role'))}")
            if act == "CONTINUATION" and (d.get("end_date") or {}).get("value"):
                txt += f"，任期到 {d['end_date']['value']}"
            stz = STATUS_ZH.get(e.get("current_status"), STATUS_ZH["UNKNOWN"]) if e.get("current_status") != "UNKNOWN" else "截至报告日是否生效无法判断"
            out["leads"].append({"kind": "公告线索", "text": f"{txt}；{_date_zh(d)}。{stz}。",      # 1.3.0 (Q12): a lead extracted by rules, not a verified fact
                                 "status": e.get("current_status"), "evidence": ev})
        if not shown and not any(x.get("kind") == "公告线索" for x in out["leads"]) and not out["needs_check"]:
            n8k_ = sum(1 for d_ in docs.values() if str(d_.get("form_type") or "").upper().startswith("8-K"))     # (independent review #12) 8-Ks only
            out["leads"].append({"kind": "公告线索", "text": f"在本次读取的 {n8k_} 份 8-K 公告里，没有找到能确定的管理层变动。这不等于没有发生：本系统只读管理层变动条目。",
                                 "status": None, "evidence": {"kind": "读取范围", "documents": sorted(docs)}})
    for g_ in (rec.get("context") or {}).get("data_gaps") or []:          # 1.4.1 (review N8, audit #18): an excluded filing is said, not silently dropped
        if g_.get("code") == "TIME_ORDER_INCONSISTENT":
            dm_ = re.search(r"documents\[([^\]]+)\]", str(g_.get("path") or ""))
            out["needs_check"].append({"text": f"公告 {dm_.group(1) if dm_ else '（编号未知）'} 的时间字段自相矛盾（发布时间晚于声明的可得时间），系统没有使用它；它说了什么需要人工核对。",
                                       "status": "没有使用", "evidence": {"kind": "公告原文", "document": dm_.group(1) if dm_ else None}})
    # ---- Fundamental
    Fu = E["fundamental"]
    if Fu["execution_status"] == "COMPLETED":
        F = (Fu.get("output") or {}).get("findings") or {}
        mb = F.get("metrics_by_year") or {}
        fy = max(mb, key=lambda k: int(k)) if mb else None
        iby = F.get("inputs_by_year") or {}
        allev = ((Fu.get("output") or {}).get("evidence") or []) + ((Fu.get("output") or {}).get("counter_evidence") or [])   # 1.4.0 (Q13 audit #6)
        src = next((x.get("source_document_id") for x in allev if x.get("source_document_id")), None) or (iby.get(str(fy)) or {}).get("_source")
        av = next((x.get("available_at") for x in allev if x.get("available_at")), None) or (iby.get(str(fy)) or {}).get("_available_at")
        evb = {"kind": "财报数据", "source": src or "来源未记录", "fiscal_year": fy, "available": (av or "")[:10] or "可得时间未记录"}
        prev = iby.get(str(int(fy) - 1)) if fy else None
        g = F.get("financial_growth") or {}
        if g.get("classification"):
            v = g.get("latest_growth")
            out["facts"].append({"kind": "财报", "text": f"FY{fy} 收入较上一年 {_pct(v) if v is not None else ''}（{CLASS_ZH.get(g['classification'], '无法判断')}）。".replace("  ", " "),
                                 "evidence": {**evb, "inputs": f"收入（FY{int(fy) - 1} 和 FY{fy}）",
                                              "documents": [x for x in ((prev or {}).get("_source"), src) if x]}})
        prof = F.get("financial_profitability") or {}
        parts = []
        for k, zh in (("gross_margin", "毛利率"), ("operating_margin", "营业利润率"), ("net_margin", "净利率")):
            t = prof.get(k) or {}
            if t.get("latest") is not None:
                parts.append(f"{zh} {t['latest'] * 100:.1f}%（{CLASS_ZH.get(t.get('classification'), '无法判断')}" + (f"，{t['change'] * 100:+.2f} 个百分点" if t.get("change") is not None else "") + "）")
            elif t.get("classification"):
                parts.append(f"{zh}：{CLASS_ZH.get(t['classification'], '无法判断')}")
        if parts:
            out["facts"].append({"kind": "财报", "text": f"FY{fy} " + "；".join(parts) + "。“稳定”指变化在 ±0.5 个百分点以内。", "evidence": {**evb, "inputs": "利润表"}})
        bsh = F.get("balance_sheet_health") or {}
        de = (bsh.get("debt_to_equity") or {})
        if de.get("status") == "COMPUTED":
            out["facts"].append({"kind": "财报", "text": f"FY{fy} 债务合计 {de['inputs']['total_debt']:,.0f} 美元，约为股东权益的 {de['value']:.2f} 倍（长期债务 + 短期债务）。",
                                 "evidence": {**evb, "inputs": "长期债务、短期债务、股东权益"}})
        cr = (bsh.get("current_ratio") or {})
        if cr.get("status") == "COMPUTED":
            out["facts"].append({"kind": "财报", "text": f"FY{fy} 流动资产是流动负债的 {cr['value']:.2f} 倍。", "evidence": {**evb, "inputs": "流动资产、流动负债"}})
        # 1.4.0 (Q13 audit #14): from the expert's own indicators and risk flags (the old text matching missed every flag of a loss-making case)
        ce = {c.get("metric"): str(c.get("fact") or "") for c in (Fu.get("output") or {}).get("counter_evidence") or [] if c.get("metric")}
        watch = [zh + ("（变化在稳定区间以内）" if "within the stable band" in ce.get(met, "") else "")
                 for k, (zh, met) in IND_ZH.items() if (F.get("deterioration_indicators") or {}).get(k) == "TRUE"]
        watch += [RISK_ZH[r_["flag"]] for r_ in F.get("financial_risks") or [] if r_.get("flag") in RISK_ZH]
        if watch:
            out["facts"].append({"kind": "财报", "text": f"FY{fy} 需要留意（基本面专家的规则检查，不是结论）：" + "；".join(dict.fromkeys(watch)) + "。",
                                 "evidence": {**evb, "inputs": "利润表、资产负债表、现金流量表（两年）"}})
        for m in F.get("missing_information") or []:                    # 1.3.0 (Q12, Q11 R6): missing / not available / not meaningful are said apart
            out["gaps"].append({"text": _missing_zh(m, F)})
        for it in F.get("indeterminate_risk_checks") or []:
            out["gaps"].append({"text": _indeterminate_zh(it)})
            out["advanced"]["codes"].append(it.get("check"))
    # ---- Valuation
    V = E["valuation"]
    if V["execution_status"] == "COMPLETED":
        F = (V.get("output") or {}).get("findings") or {}
        sd = _shares_date(rec)
        pdate = (((rec.get("q8") or {}).get("model") or {}).get("valuation") or {}).get("market", {}).get("price_date") or (rec.get("context") or {}).get("as_of", as_of)[:10]
        try:
            from datetime import date as _d
            lag = (_d.fromisoformat(pdate[:10]) - _d.fromisoformat(sd)).days if sd else None
        except ValueError:
            lag = None
        sd_txt = (f"股数截至 {sd}" + (f"，比价格日早 {lag} 天" if lag is not None and lag > 0 else "")) if sd else "股数日期未知"
        if lag is not None and lag > 90:
            out["gaps"].append({"text": f"股数是 {sd} 的数字，比价格日早 {lag} 天；这期间回购或增发会让所有按市值计算的倍数偏离（没有更新的股数）。"})
        for w_ in ((V.get("output") or {}).get("warnings") or []):          # 1.1.2 (2nd review N8): old figures / an old price are said in words
            if w_.get("code") == "FINANCIALS_STALE":
                out["gaps"].append({"text": "估值用的年报数字比价格日早一年以上，倍数是拿现在的价格和较旧的年度数字比，参考意义有限。"})
            elif w_.get("code") == "PRICE_NOT_CURRENT":
                out["gaps"].append({"text": "估值用的价格不是报告截止日附近的价格，倍数不代表截止日的情况。"})
        fin = next((m.get("inputs") for m in F.get("methods") or [] if m.get("status") == "COMPUTED"), None)
        vm_ = (((rec.get("q8") or {}).get("model") or {}).get("valuation") or {})
        vsrc = (((vm_.get("market") or {}).get("identity") or {}).get("source_id"), ((vm_.get("financials") or {}).get("identity") or {}).get("source_id"),
                str((vm_.get("financials") or {}).get("available_at") or "")[:10] or None)
        vas = ((((rec.get("q8") or {}).get("model") or {}).get("valuation") or {}).get("assumptions") or {})
        ref_tail = ("案例声明了参考倍数区间（用户假设，未经验证），这里不展示由它推出的价格；不判断贵或便宜。" if vas.get("reference_multiples") else
                    "这是描述值，没有参考区间，不判断贵或便宜。")              # 1.4.0 (Q13 audit #3): a declared range is not called absent
        for m in F.get("methods") or []:
            name = METHOD_ZH.get(m.get("method"), "一种估值方法")
            if m.get("status") == "COMPUTED" and m.get("observed_multiple") is not None:
                val = f"{m['observed_multiple'] * 100:.1f}%" if m["method"] == "FCF_YIELD" else f"{m['observed_multiple']:.1f} 倍"
                rr_ = (m.get("assumptions") or {}).get("declared_reference_multiple_range")
                tail_ = ("案例声明了这个倍数的参考区间（用户假设，未经验证），这里不展示由它推出的价格；不判断贵或便宜。" if isinstance(rr_, dict) else
                         "这是描述值，没有参考区间，不判断贵或便宜。")          # 1.4.1 (review N1): per method, not per case
                lim_ = any(m["method"] in str(c_.get("fact") or "") and "limited relevance" in str(c_.get("fact") or "")
                           for c_ in (V.get("output") or {}).get("counter_evidence") or [])
                if lim_:                                                 # 1.4.1 (review N15)
                    tail_ += "估值专家提示：这个倍数对这个行业参考意义有限（例如资产大多是无形的、不在资产负债表上）。"
                fyv = re.search(r"FY\d{4}", str((m.get("assumptions") or {}).get("period") or ""))
                out["readings"].append({"kind": "估值倍数", "text": f"{name} {val}（价格日期 {pdate[:10]}；财务数据用最近一个财年的年报，不是最近四个季度；"
                                        f"{sd_txt}）。{tail_}",
                                        "evidence": {"kind": "估值输入", "inputs": {FIELD_ZH.get(k, f"输入 {k}"): _num(v) for k, v in (m.get("inputs") or {}).items()},
                                                     "price_date": pdate[:10], "fiscal_year": f"{fyv.group(0)} 年报" if fyv else None,     # 1.4.1 (review N11)
                                                     "document": "、".join(x for x in (f"{vsrc[0]}（价格）" if vsrc[0] else None, f"{vsrc[1]}（财务）" if vsrc[1] else None) if x) or None,
                                                     "available": vsrc[2]}})
            elif m.get("method") == "DCF_FCF" and m.get("status") == "COMPUTED":      # 1.4.1 (review N2): said, not shown as prices
                cz = [c.get("code") for c in m.get("codes") or []]
                warn_ = "；".join(x for x in ("结果对假设非常敏感" if "HIGH_ASSUMPTION_SENSITIVITY" in cz else None,
                                               "大部分价值来自终值" if "TERMINAL_VALUE_DOMINANT" in cz else None) if x)
                out["readings"].append({"kind": "估值情景（不展示价格）", "text": "现金流折现估值按案例声明的几组假设算出了情景，这里不展示由它推出的每股价格"
                                        + (f"；估值专家提示：{warn_}" if warn_ else "") + "。这些是用户假设下的计算，未经验证，不是目标价。",
                                        "evidence": {"kind": "估值输入", "inputs": {"情景数": len((m.get("assumptions") or {}).get("scenarios") or {}),
                                                                                     "预测年数": (m.get("assumptions") or {}).get("horizon_years")}}})
            if m.get("status") != "COMPUTED":
                miss = [FIELD_ZH.get(x, x) for x in m.get("missing_fields") or [] if x in FIELD_ZH]
                codes = [c.get("code") for c in m.get("codes") or []]
                out["advanced"]["codes"] += codes
                tail = "（缺的数据不按零处理）"                                  # 1.4.0 (Q13 audit #13): the suffix says what kind of gap it is
                if "FORWARD_METHOD_UNAVAILABLE" in codes:
                    why, tail = "需要分析师预测数据，本系统没有合格来源", "（不按零处理）"
                elif "NEGATIVE_BASE_FCF" in codes:                              # 1.4.0 (Q13 audit #5): declared assumptions, a negative start
                    why, tail = "起点自由现金流为负，按增长推算的现金流折现没有意义（假设已经声明，不是缺数据）", ""
                elif "NEGATIVE_EARNINGS" in codes:
                    why, tail = "最近一个财年是亏损，市盈率没有意义", "（不是缺数据，也不按零处理）"      # 1.1.2 (2nd review N8)
                elif "NEGATIVE_ENTERPRISE_VALUE" in codes:
                    why, tail = "企业价值（市值 + 债务 − 现金）为零或负数，这个倍数没有意义", "（不是缺数据，也不按零处理）"
                elif "NEGATIVE_BOOK_VALUE" in codes:
                    why, tail = "股东权益为负数，市净率没有意义", "（不是缺数据，也不按零处理）"
                elif "NEGATIVE_EBITDA" in codes:
                    why, tail = "EBITDA 为负数，这个倍数没有意义", "（不是缺数据，也不按零处理）"
                elif "DENOMINATOR_ZERO" in codes:
                    why, tail = "作为分母的数字是零，这个倍数没有意义", "（不是缺数据，也不按零处理）"
                elif "NEGATIVE_VALUE_INVALID" in codes:
                    why, tail = "有一项输入是负数（不应为负），没有使用", "（这项输入无效，不按零处理）"
                elif m.get("applicability") == "NOT_APPLICABLE":           # 1.4.1 (review N13): before the DCF assumption check
                    why, tail = "对这个行业不适用", "（不是缺数据）"
                elif m.get("method") == "DCF_FCF" and not vas.get("dcf"):
                    why = "没有声明现金流假设，系统不自行假设"
                elif miss:
                    why = "缺少" + "、".join(miss)
                else:
                    why = "所需数据不全或不适用"
                out["gaps"].append({"text": f"{name}没有计算：{why}{tail}。"})
        del fin
    # ---- Technical / Macro (production models, unchanged; their own rule readings)
    pin = (rec.get("context") or {}).get("price_input") or {}
    last = pin.get("series_last_row") or {}
    sec_ = pin.get("security")
    macro_last = min((last[k] for k in ("^TNX", "^IRX", "^VIX", "HYG", "LQD", "UUP") if last.get(k)), default=None)
    for g_ in (rec.get("context") or {}).get("data_gaps") or []:            # 1.4.0 (Q13 audit #4, #26): the date a reading really describes
        if g_.get("code") == "PRICE_SERIES_ENDS_BEFORE_AS_OF" and last.get(sec_):
            try:
                from datetime import date as _d
                n_ = (_d.fromisoformat(str(pin.get("as_of_date") or as_of)[:10]) - _d.fromisoformat(last[sec_])).days
            except ValueError:
                n_ = None
            out["gaps"].append({"text": f"价格走势只算到 {last[sec_]}" + (f"，比报告截止日早 {n_} 天" if n_ else "") + "；技术面的读数说的是那一天的情况，不是截止日。"})
        elif g_.get("code") == "PRICE_DATE_DIFFERS" and last.get(sec_):
            out["gaps"].append({"text": f"估值用的价格日期和价格序列的最后一天（{last[sec_]}）不是同一天：技术面和估值看的不是同一天的价格。"})
    for eid in ("technical", "macro"):
        X = E[eid]
        if X["execution_status"] != "COMPLETED":
            continue
        o = X.get("output") or {}
        row_date = (last.get(sec_) if eid == "technical" else macro_last) or (o.get("as_of") or (rec.get("context") or {}).get("as_of") or as_of or "")[:10]
        if eid == "macro":                                                   # 1.4.0 (Q13 audit #17): the model's own environment hint
            hint = ((o.get("metadata") or {}).get("regime_hint"))
            if hint in REGIME_ZH:
                quiet = "这次没有触发偏正面或偏负面的单项规则。" if not ((o.get("evidence") or []) + (o.get("counter_evidence") or [])) else ""
                out["readings"].append({"kind": "宏观（市场层面，不针对这家公司）",
                                        "text": f"生产宏观模型给出的市场环境提示：{REGIME_ZH[hint]}。{quiet}这是规则读法，未经验证，不是买卖信号。",
                                        "evidence": {"kind": "宏观序列", "metric": "市场环境提示", "metric_value": REGIME_ZH[hint], "as_of": row_date}})
        for ev_ in (o.get("evidence") or []) + (o.get("counter_evidence") or []):
            k, v = ev_.get("metric"), ev_.get("value")
            name = TECH_ZH.get(k, "一项指标")
            vtxt = (f"{v * 100:+.1f} 个百分点（与 SPY 的涨幅之差）" if k == "relative_strength_6m" and isinstance(v, (int, float)) else      # 1.4.1 (review N14)
                    _pct(v) if k in PCT else (f"{v:+.2f} 个百分点" if k == "tnx_change_6m" else f"{v:.2f}" if isinstance(v, (int, float)) else "—"))
            lean = {"positive": "偏强" if eid == "technical" else "对市场环境偏正面", "negative": "偏弱" if eid == "technical" else "对市场环境偏负面"}.get(ev_.get("interpretation"), "中性")
            out["readings"].append({"kind": "技术面" if eid == "technical" else "宏观（市场层面，不针对这家公司）",
                                    "text": f"{name} {vtxt}；生产模型的规则读法：{lean}。这是对指标的规则读法，未经验证，不是买卖信号。",
                                    "evidence": {"kind": "价格序列" if eid == "technical" else "宏观序列",
                                                 "dataset": (((rec.get("q8") or {}).get("model") or {}).get("price_dataset") or (rec.get("q8") or {}).get("price_dataset")
                                                             or (rec.get("context") or {}).get("price_dataset")),
                                                 "metric": name, "metric_value": (_pct(v) if k in PCT else _num(v)), "as_of": row_date}})
            out["advanced"]["codes"].append(k)
    # ---- experts table
    from synthesis import synthesize as SY
    BX = (rec.get("synthesis") or {}).get("B_experts") or {}
    for eid in ("technical", "macro", "fundamental", "valuation", "information"):
        X = E[eid]
        ok = X["execution_status"] == "COMPLETED"
        valid = ok and bool((BX.get(eid) or {}).get("used_in_synthesis")) and SY.valid_finding(eid, BX.get(eid) or {})
        rej = [] if ok or X["execution_status"] != "REJECTED" else _rejected_zh(rec, X.get("status_reasons") or [])
        reason = None if ok else ("；".join(rej) if rej else "；".join(dict.fromkeys(_reason_zh(x) for x in X.get("status_reasons") or []))[:300] or "原因未记录")
        out["experts"].append({"expert": eid, "name": EXPERT_ZH[eid], "ok": ok, "valid_content": bool(valid),
                               "text": ("运行完成，有有效发现" if valid else "运行完成，但没有有效发现（这不等于没有风险）") if ok else
                               (f"输入被拒绝，没有运行：{reason}。" if rej else f"没有结果：{reason}。") + "这个维度在本次报告中缺失，不按零或中性处理，也不等于没有风险。"})
        for line in rej:                                                     # 1.4.0 (Q13 audit #0, #1)
            out["gaps"].append({"text": f"{EXPERT_SHORT[eid]}没有运行：{line}。"})
        out["advanced"]["codes"] += [x.get("code") for x in X.get("status_reasons") or []]
    # ---- limits (always shown)
    out["limits"] = [
        "内部试验：没有经过金融有效性验证，不是投资建议，不提供买卖信号。",
        "离线：合成测试数据，没有联网获取任何数据。" if synthetic else "离线：用的是上面写明日期的已有快照，没有联网获取最新数据。" if dates else
        "离线：用的是已有快照，快照取得时间没有记录；没有联网获取最新数据。",
        "公告事件由规则从原文抽取，是待核实的线索，系统不判断真伪：8-K 只读管理层变动（第 5.02 项，以及第 7.01 / 8.01 项和说明段中能对上的日期与人员），不读其他事件类型；"
        "Form 4 交易行按申报原样列出，不判断含义（真实数据模式目前不读 Form 4）。",
        "没有找到事件不等于没有事件；没有触发规则不等于没有风险。",
        "估值倍数用最近一个财年的年报数字，不是最近四个季度（TTM）；股数日期写在每条倍数旁边。",
        "技术面、宏观的“偏强 / 偏负面”是生产模型的规则读法，未经验证；宏观描述市场环境，不针对这家公司。",
        "每项数据当时是否已经公开（历史时点）没有逐项核实。",
    ]
    for g in ((rec.get("synthesis") or {}).get("K_key_gaps") or []):
        out["advanced"]["codes"] += [it.split("（")[0] for it in g.get("items") or []]
    out["advanced"]["codes"] = sorted({c for c in out["advanced"]["codes"] if c})
    seen_ = set()                                    # 1.1.0: the same gap once
    out["gaps"] = [g for g in out["gaps"] if not (g["text"] in seen_ or seen_.add(g["text"]))]
    return out


def _reason_zh(x: dict) -> str:
    c = x.get("code") or ""
    return {"INJECTED_FAULT": "测试注入的故障", "PROCESS_CRASH": "专家进程异常退出", "TIMEOUT": "运行超时", "INPUT_REJECTED": "输入没有通过检查",
            "IDENTITY_MISMATCH": "代码身份核对没有通过", "OUTPUT_CONTRACT_VIOLATION": "输出不符合约定格式", "DEPENDENCY_MISSING": "缺少需要的输入数据"}.get(c) or \
        (x.get("meaning_zh") or x.get("meaning") or "运行没有正常完成")      # 1.4.0: the record's field is 'meaning' (the old key never matched)


def _f4_role(role) -> str:
    """a Form 4 filer's relationship as filed: 'DIRECTOR' -> 董事, 'OFFICER:Chief Operating Officer' -> 高管（Chief Operating Officer）"""
    r_ = str(role or "")
    if not r_:
        return "申报没有写明身份"
    head, _, title = r_.partition(":")
    zh = F4_ROLE_ZH.get(head.strip().upper(), head.strip())
    return f"{zh}：{title.strip()}" if title.strip() else zh


def _where_zh(rec: dict, path) -> str:
    """'fundamental.periods[2]...' -> 'FY2024 财报'; 'information.documents[6]' / '[LANT-8K-0011]' -> '公告 LANT-8K-0003'; valuation parts by name"""
    p = str(path or "")
    model = (rec.get("q8") or {}).get("model") or {}
    m = re.match(r"fundamental\.periods\[(\d+)\]", p)
    if m:
        per = ((model.get("fundamental") or {}).get("periods") or [])
        i = int(m.group(1))
        return f"FY{per[i].get('fiscal_year')} 财报" if i < len(per) and per[i].get("fiscal_year") else "一期财报"
    m = re.match(r"information\.documents\[([^\]]+)\]", p)
    if m:
        k = m.group(1)
        docs = (model.get("information") or {}).get("documents") or []
        did = docs[int(k)].get("document_id") if k.isdigit() and int(k) < len(docs) else (None if k.isdigit() else k)
        return f"公告 {did}" if did else "一份公告"
    if p.startswith("valuation.financials"):
        return "估值用的财务数据"
    if p.startswith("valuation.market"):
        return "估值用的市价"
    return "输入"


def _rejected_zh(rec: dict, reasons: list) -> list:
    """1.4.0 (Q13 audit #0, #1): a rejected input says what stopped it - the missing field, or that the data belongs to another company - per
    part of the input, each reason once (the gate's own detail text, cut before its form instructions)"""
    lines, seen = [], {}
    for x in reasons:
        code, det, where = x.get("code") or "", str(x.get("detail") or ""), _where_zh(rec, x.get("path"))
        sp = " " if where[-1:].isascii() and where[-1:].isalnum() else ""
        if code == "IDENTITY_CONFLICT":
            cl = det.split("；")
            why = re.sub(r"（结构化标识[^）]*）", "", next((c for c in cl if "另一家公司" in c), cl[0]))
            line = f"{where}{sp}属于另一家公司，已阻断，不与分析对象的数据混用（{why}）"
        elif code == "REQUIRED_IDENTITY_UNIT_OR_TIME_MISSING":
            line = f"{where}{sp}{det.split('：')[0] if det else '缺少必需的身份、币种或时间字段'}，系统不猜测、不补值"
        elif code == "IDENTITY_MISSING":
            line = f"{where}{sp}没有写明属于哪家公司，系统不猜测"
        else:
            line = _reason_zh(x)
        seen.setdefault(where, []).append((code, line))
    for where, items in seen.items():
        specific = [ln for c, ln in items if c != "IDENTITY_MISSING"]
        for ln in (specific or [ln for _, ln in items]):
            if ln not in lines:
                lines.append(ln)
    return lines


def code_tokens(b: dict) -> list:
    """internal codes that leaked into the four main parts or the experts table (the evidence blocks and `advanced` are exempt)"""
    texts = [x["text"] for k in ("facts", "leads", "readings", "gaps", "needs_check") for x in b.get(k) or []] + list(b.get("limits") or []) + [x["text"] for x in b.get("experts") or []]
    return sorted({m for t in texts for m in CODE_RX.findall(t)})
