"""Q7 - the five experts: which implementation runs, its identity, and what is (and is not) established about it.

execution_status says only whether a run happened and how it ended. The trust fields below are separate and never derived from a run:
production_identity (canonical production_versions), validation_status (what the project records establish), evidence_basis and limitations.
Where the records give no validation grade, the value is NOT_ESTABLISHED (shown as 未确立) - never a guess, never a colour that suggests one.
"""
from __future__ import annotations

ORDER = ("technical", "macro", "fundamental", "valuation", "information")

EXPERTS = {
    "technical": {"display": "Technical", "tier": "PRODUCTION_ACTIVE", "runner": "production", "model_name": "technical",
                  "canonical_key": "technical_expert", "canonical_state": "ACTIVE", "expected_version": "0.1.0", "depends_on": ["price_dataset"]},
    "macro": {"display": "Macro", "tier": "PRODUCTION_ACTIVE", "runner": "production", "model_name": "macro",
              "canonical_key": "macro_expert", "canonical_state": "ACTIVE", "expected_version": "1.0.0-yfinance-proxy", "depends_on": ["price_dataset"]},
    "fundamental": {"display": "Fundamental", "tier": "EXPERIMENTAL_ISOLATED", "runner": "expert", "impl_root": "adapters/impl/fundamental_q11", "envelope_name": "Fundamental",
                    "canonical_key": "fundamental_expert", "canonical_state": "DORMANT", "expected_version_prefix": "q5-fundamental-d 0.2.2-experimental+q11.4",
                    "depends_on": ["research_input.fundamental"]},
    "valuation": {"display": "Valuation", "tier": "EXPERIMENTAL_ISOLATED", "runner": "expert", "impl_root": "adapters/impl/valuation_q11", "envelope_name": "Valuation",
                  "canonical_key": "valuation_expert", "canonical_state": "DORMANT", "expected_version_prefix": "q4-valuation-d 0.2.1-experimental+q11.2",
                  "depends_on": ["research_input.valuation"]},
    "information": {"display": "Information", "tier": "EXPERIMENTAL_ISOLATED", "runner": "expert", "impl_root": "adapters/impl/information_q11", "envelope_name": "Information",
                    "canonical_key": "information_expert", "canonical_state": "DORMANT_NOT_ASSESSED", "expected_version_prefix": "q13-information 0.4.10",
                    "depends_on": ["research_input.information"]},
}

COMMON_PRODUCTION = ["生产在用不等于经过金融验证：项目记录为 FINANCIAL_VALIDATION_NOT_PERFORMED",
                     "专家权重为 uniform-untrained，校准器为 ACTIVE_UNFITTED",
                     "生产输出中的预测性/评分字段（signal_score、expected_return、probability_positive、risk_score，以及与之配套的 confidence）不显示、不进入综合、不导出，只保留指纹",
                     "生产链内部仍按原样计算 Meta / Bull-Bear / Risk，工作台不读取、不显示这些结果"]
COMMON_EXPERIMENTAL = ["隔离实验版本：生产中该专家仍为 DORMANT，本次运行不等于激活",
                       "meta_eligibility = NOT_ELIGIBLE：不进入 Meta、Bull/Bear、Risk",
                       "在合成数据和（Q9）少量真实公开数据上做过功能检查；Level 2 研究验证未授权、未进行；真实数据上的功能运行不是金融验证",
                       "预测有效性：NOT_ESTABLISHED"]

TRUST = {
    "technical": {
        "production_identity": "生产 ACTIVE（PROJECT_CHECKPOINT.production_versions.technical_expert），代码未改动；被调用时通过 Q9 桥接（MV py_chain.py 的后继副本，只改了来源门：见 records/bridge_identity.json）原样调用（是否真的被调用、是否通过身份检查见本次的执行状态）",
        "validation_status": "NOT_ESTABLISHED",
        "validation_note": "项目记录没有给出 Technical 的金融验证等级；不能因为它是生产版本就视为已验证",
        "evidence_basis": "本次输入的价格序列（合成案例为合成序列；真实案例为 Tiingo 复权日线，见数据身份）上的价格/动量/波动指标；证据项里的 positive/negative 是生产模型自己的解读",
        "limitations": COMMON_PRODUCTION + ["只看价格行为，不看公司基本面或公告"],
        "known_open_issues": []},
    "macro": {
        "production_identity": "生产 ACTIVE（PROJECT_CHECKPOINT.production_versions.macro_expert），代码未改动；被调用时通过 Q9 桥接（MV py_chain.py 的后继副本，只改了来源门：见 records/bridge_identity.json）原样调用（是否真的被调用、是否通过身份检查见本次的执行状态）",
        "validation_status": "NOT_ESTABLISHED",
        "validation_note": "项目记录没有给出 Macro 的金融验证等级；不能因为它是生产版本就视为已验证",
        "evidence_basis": "本次输入的宏观代理序列（^TNX、^IRX、HYG、LQD、UUP、^VIX；真实案例里 ^TNX / ^IRX 是美国国债利率替代、不是 Cboe 指数，见数据身份）；与具体公司无关",
        "limitations": COMMON_PRODUCTION + ["描述市场环境，不是对这家公司的判断"],
        "known_open_issues": []},
    "fundamental": {
        "production_identity": "生产 Fundamental 为 DORMANT；生产 0.1.0 为 FROZEN_FAILED_REFERENCE_CANDIDATE（不变）。这里运行的是隔离实验版本 q5-fundamental-d 0.2.2-experimental+q11.4（Q12：输入里没有上一财年时，同比风险检查写明缺的是上一财年，不再说“无意义”；Q11：收入增长率非有限值或前一年收入为零 / 负数时记为“无意义”并写明原因，收入下降对任何符号直接比较，风险检查不适用时写明原因，ROIC 写出实际缺少的输入；Q5 冻结版本；Q9 改了输入契约的来源门和数据描述；Q10 让证据归类跟随利润率分类、把为真的内部恶化指标写进反证、利润率趋势检查有限值；指标、阈值和分类规则未改）",
        "validation_status": "NOT_ESTABLISHED",
        "validation_note": "Q5：M-02 为 PARTIALLY_FIXED；Q10 修了利润率趋势路径（Q5R5-01），Q11 修了收入增长路径；随机变形检查通过不等于金融验证",
        "evidence_basis": "本次输入的年度财报（合成，或真实 SEC XBRL 数值，每期带 available_at，见数据身份）；描述性计算，不做预测",
        "limitations": COMMON_EXPERIMENTAL + ["只描述已公布财期，不推断未来"],
        "known_open_issues": ["Q5R5-01（Q10）：利润率趋势的“变化值”现在检查有限值（两个有限利润率相减溢出时判为 NOT_MEANINGFUL）；只是有限复现后的定向修复，其余 M-02 类路径没有逐条审计"]},
    "valuation": {
        "production_identity": "生产 Valuation 为 DORMANT。这里运行的是隔离实验版本 q4-valuation-d 0.2.1-experimental+q11.2（Q11：给了但无效的输入写成“无效”而不是“不可得”，分母为零、企业价值不为正、财年晚于发布日期时拒绝，财报过旧和价格不是当前价时给出警告，写明数据期间口径；Q5 冻结版本；Q9 改了输入契约的来源门和数据描述；Q10 让不可用原因写出实际缺失的字段；估值规则未改）",
        "validation_status": "NOT_ESTABLISHED",
        "validation_note": "情景估值完全取决于案例里声明的假设；预测有效性未确立；FOV2 = NOT_ELIGIBLE_FOR_META_EXPERIMENT（不变）",
        "evidence_basis": "本次输入的价格、股本、财务数据（合成或真实，见数据身份）和案例声明的情景假设（真实案例默认不声明假设）",
        "limitations": COMMON_EXPERIMENTAL + ["情景估值区间不是目标价，也不是买卖依据"],
        "known_open_issues": []},
    "information": {
        "production_identity": "生产 Information 为 DORMANT_NOT_ASSESSED（1.0.0-rule-based）。这里运行的是隔离实验版本 q13-information 0.4.10（Q13 C12。Q13 两轮开发（每项单独对 C10 测量）加入：同位语里带法律形式的公司名不再挡住主语；“other than / except”后面的人是被排除者；“a retired judge”是形容词；后一份公告说现任无期限留任时，较早的、尚未生效的继任任命标为矛盾；附条件变动的条件原文写进说明；姓名前的头衔不算姓名；“填补董事会空缺”是董事任命；媒体、分析师、报道里说的事和别家公司宣布的自家任命不算本公司事件。这些是开发集上的改善（错误 135→132、漏抽 203→199），不是盲测结果。Q13 新盲测只给 C11 和 C10 各跑了一次：错误 35→34（只有 1 个案例不同）。独立审查随后用常见写法找到 C11 的 4 个新回退（“Co-”头衔、非董事席位的空缺、公司自己的表述被当成第三方说法、一致的交接被标成矛盾），C12 修复了这些回退；C12 没有经过盲测，它在 Q13 集上的数字是已看过的集合上的数字。以下为 Q12 C10：辞职被撤回、撤销、拒绝或只是提出时不算离任；媒体报道里说的事不算事件；“不会生效”的变动不显示；有明确离任时不再另加推断的离任；单独使用的昵称就是全名那个人；业务单元名称不当人名。Q12：Q11 开发根的修复按 15 项逐项检验后纳入 13 项，2 项因增加漏抽未纳入；年会句子里的高管任命不再静默丢弃；后一句或所附事件给出的日期写进说明，不再同时说“没有日期”；两份公告给出不同生效日期时两条都标为需要核实；Q11 0.4.0–0.4.6：as_of 当前状态与歧义分开、定义日期 / 其他章节日期 / “同日”/ 后一句日期关联、已任职头衔、退休意向、过渡任职结束、条件与意向措辞、别家公司职务、登记名称；三轮独立审查后的修复——第三轮审查的 131 段新措辞已用于开发，不再是盲测；以下为 Q10 说明：Q9 版本加上 Q10 针对真实 8-K 措辞的通用规则：称谓、倒装、弯引号、缩写、委员会、跨句职务、模板句、意向、历史年份、继任；在 15 份已看过的真实 8-K 上是开发集改善，不是盲测）",
        "validation_status": "NOT_ESTABLISHED",
        "validation_note": "Q5 四项结论全为 PARTIAL，45 条 MAJOR 未解；Q6 阶段 A = PARTIAL，阶段 B（人物—职务配对、作用范围错误断言的修复）未开始",
        "evidence_basis": "本次输入的公告文本（合成，或真实 SEC 8-K 由系统从 HTML 转成文字，带 document / availability 时间）；为合成文本调出的规则抽取，带原文证据片段",
        "limitations": COMMON_EXPERIMENTAL + ["主张真伪一律为 TRUTH_NOT_DETERMINED", "抽取出的事件是待核实线索，不是事实", "真实 8-K 的措辞超出合成规则的覆盖范围：漏抽、未解析的提及和错配都可能出现；不支持真实 Form 4"],
        "known_open_issues": ["Q12 冻结评价集（60 段新写法，两名独立写手 + 一名盲标注，先冻结后运行；评分器与 Q11 相同）首次运行：C08 错误 34 / 显示 141，C09 错误 34 / 141（完整 69→73、漏抽 17→16）——Q11 开发根的修复在新写法上没有降低错误断言",
                              "C10 的规则是看过该评价集之后写的：在该集上错误 34→25（属于回归，不是盲测）；在开发集上错误 112→110、漏抽 188 不变；下一次盲测要用新的冻结集",
                              "Q13：开发集错误 135→132、漏抽 203→199、完整 237→243（开发集，不是盲测）；新盲测（只 C10、C11 各一次）错误 35→34、漏抽 24→23；C12 = C11 加上独立审查后的回退修复，未经盲测（records/q13_reviews/review_information_c11.md）",
                              "仍有：标注者认为不确定的事件被显示成确定（Q12 集约 16 条，没有可靠的规则区分）；附条件的变动显示为“可能”（开发集之间口径不一致，未改）；子公司职务的写法不统一；昵称写在宾语位置时任命漏抽；委员会名称识别不全",
                              "Q6 R-1..R-7：评估工具本身的口径问题未解决（Q7 不使用这些工具主张正确性）"]},
}

VALIDATION_LABEL = {"NOT_ESTABLISHED": "未确立"}
TIER_LABEL = {"PRODUCTION_ACTIVE": "生产 ACTIVE（原样调用）", "EXPERIMENTAL_ISOLATED": "隔离实验（生产中 DORMANT，未激活）"}
