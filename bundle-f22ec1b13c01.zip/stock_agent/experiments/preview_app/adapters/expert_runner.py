"""Q9 successor (q9-expert-runner 1.2.0: the Q9 implementation roots; Q8: q8-expert-runner 1.1.0, Q7 1.0.0 + a "validate" mode) - runs ONE experimental expert (Fundamental / Valuation / Information)
in its own disposable subprocess, on its own frozen implementation
root (adapters/impl/<root>, byte copies of the Q5 freeze). Each root has its own shared/ package (their output.py files differ), so experts never
share a module. Sockets are refused by an audit hook. The expert's code is not changed: it is imported from the copy and its analyze() called.

    python -I -B adapters/expert_runner.py < request (JSON on stdin)
    request = {"expert_id": "fundamental" | "valuation" | "information", "section": {...} | null, "common": {...},
               "fault_injection": null | {"kind": "exception" | "non_finite_output" | "wrong_issuer_output" | "process_crash"},
               "mode": "run" (default) | "validate"}
    validate: only the expert's own input check (its SPEC through its own schema.check) - nothing is analysed; used for field-level messages

stdout: one strict JSON object {"ok", "implementation_version", "module_files_sha256", "output" | "error"}. Fault injection exists for the
isolation tests only; when present it is echoed in the result so that a run with an injected fault can never be mistaken for a normal run.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import sys
import traceback
from pathlib import Path

sys.dont_write_bytecode = True


def _no_network(event, args):
    if event.startswith("socket."):
        raise RuntimeError("Q7 expert runner: network refused")


sys.addaudithook(_no_network)
HERE = Path(__file__).resolve().parent
ROOTS = {"fundamental": ("impl/fundamental_q11", "fundamental.fundamental_lab"), "valuation": ("impl/valuation_q11", "valuation.valuation_lab"),   # Q11 successors
         "information": ("impl/information_q11", "information.information_lab")}                                                                    # (records/expert_q9_identity.json)


def _emit(obj: dict) -> None:
    sys.stdout.write(json.dumps(obj, ensure_ascii=False, allow_nan=False))
    sys.stdout.flush()


def main() -> int:
    req = json.loads(sys.stdin.read())   # the request comes on stdin: no temporary file
    eid = req["expert_id"]
    if eid not in ROOTS:
        _emit({"ok": False, "error_kind": "UNKNOWN_EXPERT", "error": eid})
        return 2
    root, modname = ROOTS[eid]
    sys.path.insert(0, str(HERE / root))
    files = sorted(p for p in (HERE / root).rglob("*.py") if "__pycache__" not in p.parts)
    shas = {p.relative_to(HERE / root).as_posix(): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
    fault = req.get("fault_injection")
    try:
        mod = __import__(modname, fromlist=["analyze"])
    except Exception as e:  # a module that cannot be imported is unavailable, not a result
        _emit({"ok": False, "error_kind": "MODULE_UNAVAILABLE", "error": f"{type(e).__name__}: {str(e)[:300]}", "module_files_sha256": shas, "fault_injection": fault})
        return 0
    version = getattr(mod, "VERSION", None)
    base = {"implementation_version": version, "module_files_sha256": shas, "module": modname, "fault_injection": fault}
    if req.get("mode") == "validate":
        from shared import schema
        try:
            probs = schema.check(req["section"], mod.SPEC, f"$.{eid}") if req.get("section") is not None else []
        except Exception as e:
            _emit({"ok": False, "error_kind": "VALIDATION_EXCEPTION", "error": f"{type(e).__name__}: {str(e)[:200]}", **base})
            return 0
        _emit({"ok": True, "mode": "validate", "problems": [{"code": p.get("code"), "path": p.get("path"), "detail": str(p.get("detail", ""))[:200]} for p in probs], **base})
        return 0
    try:
        if fault and fault.get("kind") == "process_crash":
            os._exit(17)
        if fault and fault.get("kind") == "exception":
            raise RuntimeError("Q7 injected fault (isolation test): the expert raised before producing an output")
        out = mod.analyze(req["section"], req["common"])
        if fault and fault.get("kind") == "non_finite_output":
            out.setdefault("findings", {})["q7_injected_value"] = math.nan
        if fault and fault.get("kind") == "wrong_issuer_output":
            out.setdefault("input_provenance", {})["issuer_id"] = "SYN-SOMEONE-ELSE"
    except Exception as e:
        _emit({"ok": False, "error_kind": "EXPERT_EXCEPTION", "error": f"{type(e).__name__}: {str(e)[:300]}",
               "traceback_tail": traceback.format_exc()[-800:], **base})
        return 0
    try:
        text = json.dumps({"ok": True, "output": out, **base}, ensure_ascii=False, allow_nan=False)
    except ValueError as e:  # NaN / Infinity in the output: the output is refused, never repaired
        _emit({"ok": False, "error_kind": "OUTPUT_NOT_FINITE", "error": str(e)[:200], **base})
        return 0
    except TypeError as e:
        _emit({"ok": False, "error_kind": "OUTPUT_NOT_JSON", "error": str(e)[:200], **base})
        return 0
    sys.stdout.write(text)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
