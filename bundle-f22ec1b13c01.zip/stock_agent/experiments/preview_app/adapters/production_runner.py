"""Q9 successor (q9-production-runner 1.1.0; Q7 / Q8: byte-identical original) - the Q9 bridge path below; after the Q9 review also: the evidence
items' weights are withheld like the scoring fields (they are the inputs of the hidden signal score), an evidence comment with trading wording
(e.g. "机会", "买入") is withheld (its SHA-256 kept), and the bridge files are reported among the loaded modules; otherwise as Q7:
Q7 - runs the two ACTIVE production experts (Technical, Macro) in a disposable subprocess through WEB MVP 002's py_chain.py, which loads the
UNCHANGED stock_agent chain (models = [technical, macro], enable_sec False, sockets refused) on one synthetic PRICE_DATASET_CONTRACT_V1 document.
py_chain.py is loaded by path and its run() called on the exact text the parent hashed (sent on stdin, never re-read from disk); neither it nor
stock_agent is changed.

What Q7 takes from the chain's report: the two experts' own outputs (model_outputs), the contract status and the report warnings. What it drops,
by name, before anything leaves this process: the regime snapshot, Bull/Bear challenge outputs, the Meta output, raw / calibrated probabilities,
the risk decision and the direct feature dumps (the production chain still computes them inside py_chain - Q7 never reads them), plus the
predictive / scoring fields of each expert output (signal_score, expected_return, probability_positive, risk_score, confidence): those are kept only
as a SHA-256 fingerprint and the field names. Each model is serialised on its own: a non-finite or non-JSON value fails that model only.
The files of every stock_agent / py_chain module this process actually loaded are hashed and reported, for the parent to compare.

    python -I -B adapters/production_runner.py < request (JSON on stdin)
    request = {"price_dataset_text": "...", "fault_injection": null | {"expert": "technical" | "macro", "kind": "exception" | "process_crash"}}
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import re
import sys
import traceback
from pathlib import Path

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
REPO = HERE.parents[3]
PY_CHAIN = HERE / "q9_chain/py_chain.py"      # Q9: the successor bridge (records/bridge_identity.json): MV's py_chain with the listed edits only
WITHHELD = ("confidence", "expected_return", "probability_positive", "risk_score", "signal_score")
KEEP_REPORT = ("model_outputs", "warnings")
ADVICE = re.compile(r"(?i)机会|买入|买进|卖出|抛售|加仓|减仓|建仓|抄底|止损|止盈|做多|做空|看多|看空|推荐|建议|\bbuy\b|\bsell\b|opportunit")
ADVICE_WITHHELD = "（生产模型的原文注释含交易性措辞，不显示；指标、数值和规则读法照常显示）"


def _strict_default(o):
    """numpy scalars become Python numbers (a non-finite one is then refused by allow_nan=False); anything else is refused, never stringified"""
    np = sys.modules.get("numpy")
    if np is not None:
        for t, f in (("floating", float), ("integer", int), ("bool_", bool)):
            if isinstance(o, getattr(np, t)):
                return f(o)
    raise TypeError(f"not JSON: {type(o).__name__}")


def _dump(o) -> str:
    return json.dumps(o, ensure_ascii=False, allow_nan=False, default=_strict_default)


def _emit(obj: dict) -> None:
    sys.stdout.write(_dump(obj))
    sys.stdout.flush()


def _fp(o) -> str:
    return hashlib.sha256(json.dumps(o, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=repr).encode("utf-8")).hexdigest()


def _loaded() -> dict:
    out = {}
    for m in list(sys.modules.values()):
        f = getattr(m, "__file__", None)
        if not f:
            continue
        p = Path(f).resolve()
        if p.is_relative_to(REPO / "stock_agent") and p.suffix == ".py" and (not p.is_relative_to(HERE.parent) or p.is_relative_to(HERE / "q9_chain")):
            out[p.relative_to(REPO).as_posix()] = hashlib.sha256(p.read_bytes()).hexdigest()   # Q7's own runner is not production code; the Q9 bridge is reported
    return out


def main() -> int:
    req = json.loads(sys.stdin.read())   # the request comes on stdin: no temporary file
    fault = req.get("fault_injection")
    base = {"interface": "Q9 bridge adapters/q9_chain/py_chain.py run() (MV py_chain + listed edits; unchanged stock_agent Orchestrator; models technical + macro; sockets refused)", "fault_injection": fault}
    try:
        spec = importlib.util.spec_from_file_location("q7_py_chain", PY_CHAIN)
        pc = importlib.util.module_from_spec(spec)
        sys.modules["q7_py_chain"] = pc     # its dataclasses look the module up by name
        spec.loader.exec_module(pc)        # installs py_chain's own socket-refusing audit hook
    except Exception as e:
        _emit({"ok": False, "error_kind": "MODULE_UNAVAILABLE", "error": f"{type(e).__name__}: {str(e)[:300]}", "loaded_modules_sha256": _loaded(), **base})
        return 0
    versions = {"technical": getattr(pc.TECH.TechnicalModel, "version", None), "macro": getattr(pc.MACRO.MacroModel, "version", None)}
    if fault:
        if fault.get("kind") == "process_crash":
            os._exit(17)
        if fault.get("kind") == "exception":
            target = {"technical": pc.TECH.TechnicalModel, "macro": pc.MACRO.MacroModel}[fault["expert"]]

            def _boom(self, ctx):
                raise RuntimeError("Q7 injected fault (isolation test)")
            target.analyze = _boom             # this disposable process only; the file is not touched
    try:
        res = pc.run(req["price_dataset_text"])
    except Exception as e:
        _emit({"ok": False, "error_kind": "CHAIN_EXCEPTION", "error": f"{type(e).__name__}: {str(e)[:300]}", "traceback_tail": traceback.format_exc()[-800:],
               "implementation_versions": versions, "loaded_modules_sha256": _loaded(), **base})
        return 0
    rep = res.get("report") or {}
    dropped = sorted(k for k in rep if k not in KEEP_REPORT) + (["direct"] if res.get("direct") is not None else [])
    experts = {}
    for mo in rep.get("model_outputs", []) or []:
        name = str(mo.get("model_name"))
        withheld = {k: mo.get(k) for k in WITHHELD if k in mo}
        out = {k: v for k, v in mo.items() if k not in WITHHELD}
        weights, comments = [], []
        for side in ("evidence", "counter_evidence"):
            items = []
            for e in out.get(side) or []:
                if isinstance(e, dict):
                    e = dict(e)
                    weights.append(e.get("weight"))
                    e["weight"] = None
                    if isinstance(e.get("comment"), str) and ADVICE.search(e["comment"]):
                        comments.append(e["comment"])
                        e["comment"] = ADVICE_WITHHELD
                items.append(e)
            if side in out:
                out[side] = items
        entry = {"output": out,
                 "withheld_predictive_fields": {"names": sorted(withheld), "sha256": _fp(withheld),
                                                "why": "predictive / scoring fields of the production expert: not financially validated; not shown, not synthesised, not exported"},
                 "withheld_evidence_weights": {"count": len(weights), "sha256": _fp(weights),
                                               "why": "the evidence items' weights are the inputs of the withheld signal score: withheld too (weight null)"},
                 "withheld_advice_like_comments": {"count": len(comments), "sha256": _fp(comments), "why": "evidence comments with trading wording are not shown"}}
        try:
            _dump(withheld)                      # a withheld field that is not finite JSON means the model's result is not finite: refused, not hidden
            experts[name] = json.loads(_dump(entry))
        except (ValueError, TypeError) as e:     # this model's output is refused; the other model is unaffected
            experts[name] = {"error_kind": "OUTPUT_NOT_FINITE_OR_NOT_JSON", "error": str(e)[:200]}
    try:
        contract = json.loads(_dump(res.get("contract")))
        warnings = json.loads(_dump(rep.get("warnings", [])))
    except (ValueError, TypeError) as e:
        _emit({"ok": False, "error_kind": "OUTPUT_NOT_FINITE_OR_NOT_JSON", "error": str(e)[:200], "loaded_modules_sha256": _loaded(), **base})
        return 0
    _emit({"ok": True, "contract": contract, "report_present": bool(res.get("report")), "experts": experts, "report_warnings": warnings,
           "dropped_report_keys": dropped, "implementation_versions": versions, "loaded_modules_sha256": _loaded(),
           "modules": {"engine": pc.ENGINE.__file__, "technical": pc.TECH.__file__, "macro": pc.MACRO.__file__}, **base})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
