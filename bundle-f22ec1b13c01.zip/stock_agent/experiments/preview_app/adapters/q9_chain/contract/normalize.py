"""FA-WEB input contract 1.0.0 - the Python normalizer (the reference path). Mirrors web/src/engine/contract.js step by step; both follow
contract/input_contract_v1.json. Standard library only. normalize(text) -> the contract result (a JSON-able dict)."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import math
import re

CONTRACT_VERSION = "1.0.0"
MACRO = ["^VIX", "^TNX", "^IRX", "HYG", "LQD", "UUP"]
RESERVED = ["SPY"] + MACRO
YIELD = {"^TNX", "^IRX"}
COLUMNS = {"Open", "High", "Low", "Close", "Volume"}
DOC_REQUIRED = ["contract_version", "dataset_id", "security", "as_of_date", "provenance", "series"]
DOC_OPTIONAL = {"title": 200, "description": 4000}
RE_ID = re.compile(r"[A-Za-z0-9_.-]{1,80}")
RE_SEC = re.compile(r"[A-Z][A-Z0-9.-]{0,14}")
RE_VER = re.compile(r"1\.[0-9]+\.[0-9]+")
RE_DATE = re.compile(r"([0-9]{4})-([0-9]{2})-([0-9]{2})")
RE_TS = re.compile(r"([0-9]{4})-([0-9]{2})-([0-9]{2})(?:[T ]([0-9]{2}):([0-9]{2})(?::([0-9]{2})(?:\.[0-9]{1,9})?)?(Z|[+-][0-9]{2}:[0-9]{2})?)?")
EXPERTS_RUN = ["technical", "macro", "regime", "bull_bear", "meta", "calibration", "risk"]
DORMANT = ["fundamental", "valuation", "information"]


class _Reject(Exception):
    pass


def _code(code, cls, series=None, **detail):
    return {"code": code, "class": cls, "series": series, "detail": detail}


def _real_date(y, m, d) -> dt.date | None:
    if not 1900 <= y <= 2100:
        return None
    try:
        return dt.date(y, m, d)
    except ValueError:
        return None


def _date_ok(s) -> dt.date | None:
    m = RE_DATE.fullmatch(s) if isinstance(s, str) else None
    return _real_date(int(m.group(1)), int(m.group(2)), int(m.group(3))) if m else None


def _no_constant(name):
    raise ValueError(name)


def _num(v):
    """None for null; a float for a JSON number; raises TypeError for any other type, OverflowError for a value beyond binary64"""
    if v is None:
        return None
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        raise TypeError
    return float(v)


def _weekday_count(after: dt.date, upto: dt.date) -> int:
    n, d = 0, after + dt.timedelta(days=1)
    while d <= upto:
        n += d.weekday() < 5
        d += dt.timedelta(days=1)
    return n


def normalize(text: str) -> dict:
    sha = hashlib.sha256(text.encode("utf-8")).hexdigest()
    res = {"contract_version": CONTRACT_VERSION, "document_contract_version": None, "dataset_id": None, "security": None, "as_of_date": None, "status": None,
           "provenance_status": "UNVERIFIED", "provenance": None, "input_sha256": sha, "codes": [], "series_quality": {}, "withheld": [], "normalized_series": {},
           "expert_availability": {e: "SKIPPED_INPUT_REJECTED" for e in EXPERTS_RUN + DORMANT}}
    codes = res["codes"]

    def fatal(c):
        codes.append(c)
        res["status"] = "REJECTED"
        return res
    # P - parse
    try:
        doc = json.loads(text, parse_constant=_no_constant)
    except (ValueError, RecursionError):
        return fatal(_code("JSON_INVALID", "REJECTED"))
    if not isinstance(doc, dict):
        return fatal(_code("DOCUMENT_INVALID", "REJECTED", field="document"))
    # D - document
    cv = doc.get("contract_version")
    if not isinstance(cv, str):
        return fatal(_code("DOCUMENT_INVALID", "REJECTED", field="contract_version"))
    res["document_contract_version"] = cv
    if not RE_VER.fullmatch(cv):
        return fatal(_code("CONTRACT_VERSION_UNSUPPORTED", "REJECTED"))
    if not (isinstance(doc.get("dataset_id"), str) and RE_ID.fullmatch(doc["dataset_id"])):
        return fatal(_code("DOCUMENT_INVALID", "REJECTED", field="dataset_id"))
    res["dataset_id"] = doc["dataset_id"]
    sec = doc.get("security")
    if not (isinstance(sec, str) and RE_SEC.fullmatch(sec)) or sec in RESERVED:
        return fatal(_code("DOCUMENT_INVALID", "REJECTED", field="security"))
    res["security"] = sec
    as_of = _date_ok(doc.get("as_of_date"))
    if as_of is None:
        return fatal(_code("DOCUMENT_INVALID", "REJECTED", field="as_of_date"))
    res["as_of_date"] = doc["as_of_date"]
    if not isinstance(doc.get("provenance"), dict):
        return fatal(_code("DOCUMENT_INVALID", "REJECTED", field="provenance"))
    if not isinstance(doc.get("series"), dict):
        return fatal(_code("DOCUMENT_INVALID", "REJECTED", field="series"))
    for k, lim in DOC_OPTIONAL.items():
        if k in doc and not (isinstance(doc[k], str) and len(doc[k]) <= lim):
            return fatal(_code("DOCUMENT_INVALID", "REJECTED", field=k))
    extra = sorted(k for k in doc if k not in DOC_REQUIRED and k not in DOC_OPTIONAL)
    if extra:
        return fatal(_code("DOCUMENT_KEY_UNSUPPORTED", "REJECTED", keys=",".join(extra)))
    # V - provenance
    prov = doc["provenance"]
    bad = sorted(k for k, v in prov.items() if not isinstance(v, str))
    if bad:
        return fatal(_code("PROVENANCE_UNVERIFIED", "REJECTED", field=bad[0]))
    res["provenance"] = {k: prov[k] for k in sorted(prov)}
    kind = prov.get("source_kind")
    if kind in ("USER_IMPORT", "LICENSED_PROVIDER"):
        return fatal(_code("SOURCE_KIND_NOT_YET_AVAILABLE", "REJECTED", source_kind=kind))
    if kind == "PUBLIC_SOURCE_INTERNAL_TEST":       # Q9: real public data for an internal functional test, every series traced to a Q9 source record
        if not prov.get("generator") or not prov.get("q9_source_record"):
            return fatal(_code("PROVENANCE_UNVERIFIED", "REJECTED", field="generator" if not prov.get("generator") else "q9_source_record"))
        res["provenance_status"] = "DECLARED_REAL_Q9_INTERNAL_TEST"
    else:
        if kind != "SYNTHETIC" or not prov.get("generator"):
            return fatal(_code("PROVENANCE_UNVERIFIED", "REJECTED", field="source_kind" if kind != "SYNTHETIC" else "generator"))
        res["provenance_status"] = "DECLARED_SYNTHETIC"
    # K - series keys
    series = doc["series"]
    allowed = [sec] + RESERVED
    unsupported = sorted(k for k in series if k not in allowed)
    if unsupported:
        return fatal(_code("SERIES_KEY_UNSUPPORTED", "REJECTED", keys=",".join(unsupported)))
    if sec not in series:
        return fatal(_code("SECURITY_SERIES_MISSING", "REJECTED"))
    order = [k for k in allowed if k in series]
    # S - per series
    out, quality_codes, rows_in, rejected = {}, {}, {}, False
    for key in order:
        sc = []
        quality_codes[key] = sc
        try:
            out_key = _series(key, series[key], key == sec, key in YIELD, as_of, sc)
        except _Reject:
            rejected = True
            out_key = None
        codes.extend(sc)
        rows_in[key] = len(series[key]["rows"]) if isinstance(series[key], dict) and isinstance(series[key].get("rows"), list) else 0
        if out_key is not None:
            out[key] = out_key
    if rejected or any(c["class"] == "REJECTED" for c in codes):
        res["status"] = "REJECTED"
        return res
    withheld = [k for k in order if k not in out]
    # Q - dataset quality
    if "SPY" not in out:
        codes.append(_code("BENCHMARK_MISSING", "DEGRADED", "SPY"))
    for k in MACRO:
        if k not in out:
            codes.append(_code("MACRO_SERIES_MISSING", "DEGRADED", k))
    n_sec = len(out[sec]["rows"])
    n_spy = len(out["SPY"]["rows"]) if "SPY" in out else 0
    if n_sec < 60:
        codes.append(_code("TECHNICAL_INSUFFICIENT_HISTORY", "DEGRADED", None, for_series=sec, closes=n_sec))
    if "SPY" in out and n_spy < 200:
        codes.append(_code("REGIME_INSUFFICIENT_BENCHMARK", "DEGRADED", None, rows=n_spy))
    short = [(sec, "momentum_12m_1m", 253), (sec, "sma50_sma200_ratio", 200), (sec, "volatility_63d_ann", 64), ("SPY", "relative_strength_6m", 127),
             ("^TNX", "tnx_change_6m", 130), ("HYG", "credit_risk_proxy_change_3m", 65), ("LQD", "credit_risk_proxy_change_3m", 65), ("UUP", "usd_proxy_change_3m", 65)]
    for k, metric, need in short:
        if k in out and len(out[k]["rows"]) < need:
            codes.append(_code("HISTORY_SHORT", "INFO", k, metric=metric, rows=len(out[k]["rows"]), needed=need))
    expected = as_of if as_of.weekday() < 5 else as_of - dt.timedelta(days=as_of.weekday() - 4)
    behind = {}
    for k in order:
        if k in out:
            last = dt.date.fromisoformat(out[k]["rows"][-1][0])
            behind[k] = _weekday_count(last, expected) if last < expected else 0
            if behind[k] > 0:
                c = _code("LATEST_SESSION_MISSING", "DEGRADED", k, sessions_behind=behind[k], last_session=out[k]["rows"][-1][0])
                codes.append(c)
                quality_codes[k].append(c)
    codes.append(_code("CALENDAR_UNVERIFIED", "INFO"))
    codes.append(_code("PIT_UNVERIFIED", "INFO"))
    # quality, status, availability
    sq = {}
    for k in [sec] + RESERVED:
        if k not in series:
            sq[k] = {"rows_in": 0, "rows_out": 0, "first_session": None, "last_session": None, "sessions_behind": None, "quality": "MISSING", "codes": []}
            continue
        names = [c["code"] for c in quality_codes[k]]
        classes = {c["class"] for c in quality_codes[k]}
        if k in withheld:
            q = "WITHHELD"
        elif behind[k] >= 3:
            q = "STALE"
        elif behind[k] >= 1:
            q = "LAGGING"
        elif "DEGRADED" in classes:
            q = "DEGRADED"
        elif "NORMALIZED" in classes:
            q = "NORMALIZED"
        else:
            q = "COMPLETE"
        rows = out[k]["rows"] if k in out else []
        sq[k] = {"rows_in": rows_in[k], "rows_out": len(rows), "first_session": rows[0][0] if rows else None, "last_session": rows[-1][0] if rows else None,
                 "sessions_behind": behind.get(k), "quality": q, "codes": names}
    classes = {c["class"] for c in codes}
    res["status"] = "DEGRADED" if "DEGRADED" in classes else "NORMALIZED" if "NORMALIZED" in classes else "VALID"
    res["series_quality"] = sq
    res["withheld"] = withheld
    res["normalized_series"] = out
    av = {e: "AVAILABLE" for e in EXPERTS_RUN}
    av["technical"] = "AVAILABLE" if n_sec >= 60 else "INSUFFICIENT_INPUT"
    av["macro"] = "AVAILABLE" if any(k in out for k in MACRO) else "INSUFFICIENT_INPUT"
    av["regime"] = "AVAILABLE" if "SPY" in out and n_spy >= 200 else "INSUFFICIENT_INPUT"
    for e in DORMANT:
        av[e] = "NOT_YET_AVAILABLE"
    res["expert_availability"] = av
    return res


def _series(key: str, s, is_security: bool, is_yield: bool, as_of: dt.date, sc: list):
    """steps S1-S9 for one series; appends its codes to sc; returns {columns, rows} or None (withheld); raises _Reject after a REJECTED code"""
    def reject(code, **detail):
        sc.append(_code(code, "REJECTED", key, **detail))
        raise _Reject
    # S1
    if not isinstance(s, dict) or sorted(s) != ["columns", "rows"] or not isinstance(s["columns"], list) or not isinstance(s["rows"], list):
        reject("SERIES_SHAPE_INVALID")
    cols = s["columns"]
    if not all(isinstance(c, str) for c in cols):
        reject("SERIES_SHAPE_INVALID")
    for c in cols:
        if c not in COLUMNS:
            reject("COLUMN_UNSUPPORTED", column=c)
    if len(set(cols)) != len(cols):
        reject("COLUMNS_DUPLICATE")
    if "Close" not in cols:
        reject("CLOSE_COLUMN_MISSING")
    k = len(cols)
    ci = cols.index("Close")
    vi = cols.index("Volume") if "Volume" in cols else None
    # S2
    probs = {}                                                    # code -> [first index, count, column]

    def note(code, i, col=None):
        if code not in probs:
            probs[code] = [i, 0, col]
        probs[code][1] += 1
    rows = []
    for i, r in enumerate(s["rows"]):
        if not isinstance(r, list) or len(r) != k + 1:
            note("ROW_SHAPE_INVALID", i)
            continue
        if not isinstance(r[0], str):
            note("DATE_INVALID", i)
            continue
        vals = []
        for j in range(k):
            try:
                v = _num(r[j + 1])
            except TypeError:
                note("VALUE_NOT_NUMERIC", i, cols[j])
                v = None
            except OverflowError:
                note("VALUE_NOT_FINITE", i, cols[j])
                v = None
            else:
                if v is not None and not math.isfinite(v):
                    note("VALUE_NOT_FINITE", i, cols[j])
                elif v is not None and j == vi and v < 0:
                    note("VOLUME_NEGATIVE", i, cols[j])
            vals.append(v)
        rows.append([r[0]] + vals)
    for code in ("ROW_SHAPE_INVALID", "DATE_INVALID", "VALUE_NOT_NUMERIC", "VALUE_NOT_FINITE", "VOLUME_NEGATIVE"):
        if code in probs:
            first, count, col = probs[code]
            d = {"first_index": first, "count": count}
            if col is not None:
                d["column"] = col
            sc.append(_code(code, "REJECTED", key, **d))
    if probs:
        raise _Reject
    # S3
    bad, weekend, timed, offsets, labelled = [], [], 0, set(), []
    for i, r in enumerate(rows):
        m = RE_TS.fullmatch(r[0])
        dd = None
        if m:
            dd = _real_date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
            if dd is not None and m.group(4) is not None:
                if int(m.group(4)) > 23 or int(m.group(5)) > 59 or (m.group(6) is not None and int(m.group(6)) > 59):
                    dd = None
            if dd is not None and m.group(7) not in (None, "Z") and (int(m.group(7)[1:3]) > 23 or int(m.group(7)[4:6]) > 59):
                dd = None
        if dd is None:
            bad.append(i)
            continue
        label = dd.isoformat()
        if dd.weekday() >= 5:
            weekend.append(label)
        if m.group(4) is not None:
            timed += 1
        if m.group(7) is not None:
            offsets.add(m.group(7))
        labelled.append([label] + r[1:])
    if bad:
        sc.append(_code("DATE_INVALID", "REJECTED", key, first_index=bad[0], count=len(bad)))
    if weekend:
        sc.append(_code("SESSION_ON_WEEKEND", "REJECTED", key, first_label=weekend[0], count=len(weekend)))
    if bad or weekend:
        raise _Reject
    if timed:
        sc.append(_code("DATE_TIME_COMPONENT_REMOVED", "NORMALIZED", key, count=timed))
    if offsets:
        n_off = sum(1 for r in rows if RE_TS.fullmatch(r[0]).group(7) is not None)
        sc.append(_code("TIMEZONE_OFFSET_IGNORED_LOCAL_DATE_KEPT", "NORMALIZED", key, count=n_off, offsets=",".join(sorted(offsets))))
    # S4
    if any(labelled[i][0] > labelled[i + 1][0] for i in range(len(labelled) - 1)):
        idx = sorted(range(len(labelled)), key=lambda i: labelled[i][0])
        moved = sum(1 for pos, i in enumerate(idx) if pos != i)
        labelled = [labelled[i] for i in idx]
        sc.append(_code("ROWS_REORDERED", "NORMALIZED", key, moved=moved))
    # S5
    kept, same, conflict = [], 0, []
    for r in labelled:
        if kept and kept[-1][0] == r[0]:
            if kept[-1][1:] == r[1:]:
                same += 1
            else:
                conflict.append(r[0])
            continue
        kept.append(r)
    if conflict:
        sc.append(_code("DUPLICATE_SESSION_CONFLICT", "REJECTED", key, first_label=conflict[0], count=len(conflict)))
        raise _Reject
    if same:
        sc.append(_code("DUPLICATE_SESSION_IDENTICAL_REMOVED", "NORMALIZED", key, count=same))
    # S6
    ao = as_of.isoformat()
    after = sum(1 for r in kept if r[0] > ao)
    if after:
        kept = [r for r in kept if r[0] <= ao]
        sc.append(_code("ROWS_AFTER_AS_OF_EXCLUDED", "NORMALIZED", key, count=after))
    # S7
    closes = [r[ci + 1] for r in kept]
    if not is_yield:
        nonpos = [kept[i][0] for i, c in enumerate(closes) if c is not None and c <= 0]
        if nonpos:
            sc.append(_code("CLOSE_NOT_POSITIVE", "REJECTED", key, first_label=nonpos[0], count=len(nonpos)))
            raise _Reject
    last_valid = max((i for i, c in enumerate(closes) if c is not None), default=-1)
    interior = [kept[i][0] for i in range(last_valid) if closes[i] is None]
    if interior:
        sc.append(_code("CLOSE_MISSING_INTERIOR", "REJECTED", key, first_label=interior[0], count=len(interior)))
        raise _Reject
    trailing = len(kept) - (last_valid + 1)
    if trailing:
        kept = kept[:last_valid + 1]
        sc.append(_code("TRAILING_CLOSE_MISSING_EXCLUDED", "DEGRADED", key, count=trailing))
    # S8
    if not kept:
        if is_security:
            sc.append(_code("SECURITY_SERIES_EMPTY", "REJECTED", key))
            raise _Reject
        sc.append(_code("SERIES_EMPTY_WITHHELD", "DEGRADED", key))
        return None
    # S9
    out_cols = list(cols)
    if is_security:
        if vi is None:
            sc.append(_code("VOLUME_COLUMN_ABSENT", "DEGRADED", key))
        else:
            last20 = kept[-20:]
            missing20 = sum(1 for r in last20 if r[vi + 1] is None)
            gaps = sum(1 for r in kept if r[vi + 1] is None)
            if missing20:
                sc.append(_code("VOLUME_INCOMPLETE_LAST_20", "DEGRADED", key, nulls_in_last_20=missing20))
                out_cols = [c for c in cols if c != "Volume"]
                kept = [r[:vi + 1] + r[vi + 2:] for r in kept]
            elif gaps:
                sc.append(_code("VOLUME_GAPS_OUTSIDE_LAST_20", "INFO", key, count=gaps))
    elif vi is not None:
        gaps = sum(1 for r in kept if r[vi + 1] is None)
        if gaps:
            sc.append(_code("VOLUME_GAPS_UNUSED", "INFO", key, count=gaps))
    return {"columns": out_cols, "rows": kept}


if __name__ == "__main__":
    import sys
    sys.stdout.write(json.dumps(normalize(open(sys.argv[1], encoding="utf-8").read()), ensure_ascii=False))
