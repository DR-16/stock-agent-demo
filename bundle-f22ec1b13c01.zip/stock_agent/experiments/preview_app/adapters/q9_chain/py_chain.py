"""WEB MVP 002 - PY_REF: the UNCHANGED stock_agent Orchestrator chain on the contract's normalized input.

stock_agent/engine.py, models/{base,technical,macro,challenge,meta}.py, regime/detector.py, risk/{engine,checks}.py and calibration/calibrators.py are
loaded by path into a private package (sa_ref). Three things are stubbed, nothing of a model: stock_agent/data.py (DataSource, CompanyProfile,
Financials - it imports requests / yfinance), stock_agent/data_sources (SECClient - never constructed: enable_sec is False) and the package
__init__ files (they import every model; the explicit model list replaces default_model_set, which raises if called). A Python audit hook refuses
every socket. The Orchestrator is built as the workbench child builds it (models = [technical, macro], enable_sec False, enable_macro True,
peer_limit 0) and engine.now_utc is fixed to as_of_date 00:00 UTC; the stub data source serves the contract's normalized frames.

    python -I -B py_chain.py <dataset.json> [<dataset.json> ...]   -> one JSON object on stdout: {dataset_id: {contract, report, direct}}
"""
from __future__ import annotations

import importlib
import json
import sys
import types
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path


def _no_network(event, args):
    if event.startswith("socket."):
        raise RuntimeError("PY_REF: network refused")


sys.addaudithook(_no_network)
HERE = Path(__file__).resolve().parent
REPO = HERE.parents[4]          # Q9: this copy sits in <Q9>/adapters/q9_chain/ (MV's sat at stock_agent/experiments/<MV>/)
sys.path.insert(0, str(HERE / "contract"))
import normalize as N  # noqa: E402
import pandas as pd  # noqa: E402


def _pkg(name: str, path: Path | None = None) -> types.ModuleType:
    m = types.ModuleType(name)
    if path is not None:
        m.__path__ = [str(path)]
    sys.modules[name] = m
    return m


SA = _pkg("sa_ref", REPO / "stock_agent")
MODELS = _pkg("sa_ref.models", REPO / "stock_agent" / "models")
REGIME = _pkg("sa_ref.regime", REPO / "stock_agent" / "regime")
RISK = _pkg("sa_ref.risk", REPO / "stock_agent" / "risk")
CAL = _pkg("sa_ref.calibration", REPO / "stock_agent" / "calibration")
DATA = _pkg("sa_ref.data")
DS = _pkg("sa_ref.data_sources")


@dataclass
class CompanyProfile:          # stub of stock_agent.data.CompanyProfile (the fields engine.py reads)
    ticker: str = ""
    name: str = ""
    sector: str | None = None
    industry: str | None = None
    market_cap: float | None = None
    country: str | None = None
    website: str | None = None


@dataclass
class Financials:              # stub (no model of this chain reads it)
    raw: dict = field(default_factory=dict)


class DataSource:              # stub base; never fetches
    pass


class SECClient:               # stub; never constructed (enable_sec False)
    def __init__(self, *a, **k):
        raise RuntimeError("SEC client is not available in PY_REF")


DATA.DataSource, DATA.CompanyProfile, DATA.Financials = DataSource, CompanyProfile, Financials
DS.SECClient = SECClient
BASE = importlib.import_module("sa_ref.models.base")
TECH = importlib.import_module("sa_ref.models.technical")
MACRO = importlib.import_module("sa_ref.models.macro")
CH = importlib.import_module("sa_ref.models.challenge")
META = importlib.import_module("sa_ref.models.meta")


def _no_default_set(*a, **k):
    raise RuntimeError("default_model_set is not used: the model list is explicit")


MODELS.default_model_set, MODELS.ExpertModel = _no_default_set, BASE.ExpertModel
MODELS.ChallengeAgent, MODELS.RuleBasedBullAgent, MODELS.RuleBasedBearAgent, MODELS.MetaModel = CH.ChallengeAgent, CH.RuleBasedBullAgent, CH.RuleBasedBearAgent, META.MetaModel
DET = importlib.import_module("sa_ref.regime.detector")
REGIME.RegimeDetector, REGIME.RegimeSnapshot, REGIME.SimpleTrendVolatilityRegime = DET.RegimeDetector, DET.RegimeSnapshot, DET.SimpleTrendVolatilityRegime
RENG = importlib.import_module("sa_ref.risk.engine")
RISK.RiskEngine, RISK.RiskAdjustedDecision = RENG.RiskEngine, RENG.RiskAdjustedDecision
CALS = importlib.import_module("sa_ref.calibration.calibrators")
CAL.Calibrator, CAL.IdentityCalibrator = CALS.Calibrator, CALS.IdentityCalibrator
ENGINE = importlib.import_module("sa_ref.engine")


def frame(s: dict | None) -> pd.DataFrame:
    if not s or not s["rows"]:
        return pd.DataFrame()
    return pd.DataFrame([r[1:] for r in s["rows"]], columns=s["columns"], index=pd.DatetimeIndex([r[0] for r in s["rows"]]), dtype="float64")


class ContractSource(DataSource):
    """serves the contract's normalized frames; a series the contract did not accept is an empty frame (as a provider with no data)"""
    def __init__(self, normalized: dict, security: str):
        self.frames = {k: frame(v) for k, v in normalized.items()}
        self.security = security

    def get_profile(self, ticker):
        return CompanyProfile(ticker=ticker, name=ticker)     # Q9: no "Synthetic" label on real data (no model of this chain reads the name)

    def get_financials(self, ticker):
        return Financials()

    def get_price_history(self, ticker, period="2y"):
        return self.frames.get(ticker, pd.DataFrame())

    def get_peers(self, ticker, limit=12):
        return []


def run(text: str) -> dict:
    c = N.normalize(text)
    contract = {k: v for k, v in c.items() if k != "normalized_series"}
    if c["status"] == "REJECTED":
        return {"contract": contract, "report": None, "direct": None}
    as_of = datetime.fromisoformat(c["as_of_date"]).replace(tzinfo=timezone.utc)
    ENGINE.now_utc = lambda: as_of
    src = ContractSource(c["normalized_series"], c["security"])
    H = 63
    orch = ENGINE.Orchestrator(data_source=src, models=[TECH.TechnicalModel(), MACRO.MacroModel()], bull_agent=CH.RuleBasedBullAgent(horizon_days=H),
                               bear_agent=CH.RuleBasedBearAgent(horizon_days=H), meta_model=META.MetaModel(horizon_days=H), regime_detector=DET.SimpleTrendVolatilityRegime(),
                               calibrator=CALS.IdentityCalibrator(), risk_engine=RENG.RiskEngine(), enable_sec=False, enable_macro=True, peer_limit=0)
    rep = orch.analyze(c["security"], horizon_days=H).to_dict()
    for k in ("profile", "peer_tickers"):
        rep.pop(k, None)
    px, bench = src.get_price_history(c["security"]), src.get_price_history("SPY")
    vix = src.get_price_history("^VIX")
    prices = {}
    for mt in MACRO.MACRO_TICKERS:                                   # the dict Orchestrator.analyze builds
        if mt == "^VIX" and not vix.empty:
            prices[mt] = vix
            continue
        df = src.get_price_history(mt)
        if df is not None and not df.empty:
            prices[mt] = df
    direct = {"technical_metrics_full": TECH._compute_technical_metrics(px, bench) if not px.empty and "Close" in px.columns else None,
              "macro_features_full": MACRO._compute_macro_features(prices, as_of=as_of) if prices else None}
    return {"contract": contract, "report": rep, "direct": direct}


def main() -> None:
    out = {}
    for p in sys.argv[1:]:
        text = Path(p).read_text(encoding="utf-8")
        out[Path(p).stem] = run(text)
    out["_modules"] = {"engine": ENGINE.__file__, "technical": TECH.__file__, "macro": MACRO.__file__, "challenge": CH.__file__, "meta": META.__file__,
                       "regime": DET.__file__, "risk_engine": RENG.__file__, "calibrators": CALS.__file__, "pandas": pd.__version__}
    sys.stdout.write(json.dumps(out, default=str, ensure_ascii=False))


if __name__ == "__main__":
    main()
