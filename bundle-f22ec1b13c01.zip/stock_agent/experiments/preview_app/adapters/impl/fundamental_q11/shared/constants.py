"""The declared constants of the three prototypes, mirrored from te_acceptance_rules.json (pre-registered before this code; a test checks that the
two agree). Every one of them is a design constant for DESCRIPTION, not a validated threshold and not derived from any outcome."""
from __future__ import annotations

GROWTH_FLAT_BAND = 0.01
MARGIN_STABLE_BAND = 0.005
LEVERAGE_STABLE_BAND = 0.05
IDENTITY_TOLERANCE = 0.005
ANNUAL_PERIOD_DAYS = (350, 380)
COMPLETENESS_NEEDS_MORE_DATA_BELOW = 0.60
FUNDAMENTAL_REQUIRED_LATEST = ("revenue", "operating_income", "net_income", "operating_cash_flow", "capex", "total_assets", "stockholders_equity",
                               "current_assets", "current_liabilities", "cash_and_equivalents")

DCF_BOUNDS = {"discount_rate": (0.04, 0.20), "terminal_growth": (-0.02, 0.04), "terminal_spread_min": 0.02, "stage_growth": (-0.30, 0.40), "horizon_years": (3, 10)}
SENSITIVITY_GRID = {"discount_rate_offsets": (-0.02, -0.01, 0.0, 0.01, 0.02), "terminal_growth_offsets": (-0.01, -0.005, 0.0, 0.005, 0.01)}
HIGH_SENSITIVITY_RELATIVE_SPREAD = 0.50
TERMINAL_VALUE_DOMINANT_SHARE = 0.75
UNITS_PLAUSIBILITY = {"market_cap_to_revenue": (0.01, 1000.0), "market_cap_to_book": (0.01, 1000.0)}
TEN_B5_1_APPLICABLE_FROM = "2023-04-01"

INDUSTRY_CLASSES = ("INDUSTRIAL", "CONSUMER", "TECHNOLOGY_SOFTWARE", "HEALTHCARE", "ENERGY", "UTILITY", "REIT", "BANK", "INSURANCE", "OTHER")
INDUSTRY_APPLICABILITY = {
    "EV_EBITDA": {"NOT_APPLICABLE": ("BANK", "INSURANCE"), "why": "interest and debt are operating items for banks and insurers; EBITDA is not meaningful"},
    "EV_SALES": {"NOT_APPLICABLE": ("BANK", "INSURANCE"), "why": "as for EV/EBITDA"},
    "FCF_YIELD": {"NOT_APPLICABLE": ("BANK", "INSURANCE"), "why": "free cash flow (OCF - capex) is not meaningful for deposit-funded balance sheets"},
    "DCF_FCF": {"NOT_APPLICABLE": ("BANK", "INSURANCE"), "why": "as for FCF yield"},
    "PE": {"LIMITED_RELEVANCE": ("REIT",), "why": "depreciation of real estate distorts earnings"},
    "PB": {"LIMITED_RELEVANCE": ("TECHNOLOGY_SOFTWARE",), "why": "most of the capital is intangible and off the balance sheet"},
    "GROSS_MARGIN": {"NOT_APPLICABLE": ("BANK", "INSURANCE"), "why": "no cost of revenue line"},
    "INTEREST_COVERAGE": {"NOT_APPLICABLE": ("BANK", "INSURANCE"), "why": "interest is an operating cost of a bank, not a financing burden"},
    "CURRENT_RATIO": {"NOT_APPLICABLE": ("BANK", "INSURANCE"), "why": "the balance sheet is not classified into current and non-current"},
    "FREE_CASH_FLOW": {"NOT_APPLICABLE": ("BANK", "INSURANCE"), "why": "operating cash flow of a deposit-funded balance sheet is not a free-cash-flow measure"},
}


def applicability(method: str, industry: str) -> tuple[str, str]:
    """(APPLICABLE | LIMITED_RELEVANCE | NOT_APPLICABLE, why)"""
    rule = INDUSTRY_APPLICABILITY.get(method)
    if not rule:
        return "APPLICABLE", ""
    if industry in rule.get("NOT_APPLICABLE", ()):
        return "NOT_APPLICABLE", rule["why"]
    if industry in rule.get("LIMITED_RELEVANCE", ()):
        return "LIMITED_RELEVANCE", rule["why"]
    return "APPLICABLE", ""


CURRENCIES = ("USD", "EUR", "GBP", "JPY", "CNY", "CAD", "CHF", "AUD", "HKD")
SCALES = {"UNITS": 1.0, "THOUSANDS": 1e3, "MILLIONS": 1e6, "BILLIONS": 1e9}
MAX_ABS_AMOUNT = 1e13          # in the declared scale; larger inputs are refused by the schema

REQUESTS = {
    "fundamental": {"supported": ("DESCRIPTIVE_FINANCIAL_CONDITION",), "unsupported": ("RETURN_PREDICTION", "EARNINGS_FORECAST", "CREDIT_RATING")},
    "valuation": {"supported": ("SCENARIO_VALUATION",), "unsupported": ("PRICE_TARGET", "BUY_SELL_RECOMMENDATION", "FORWARD_PE", "PEG", "FAIR_VALUE_POINT_ESTIMATE")},
    "information": {"supported": ("EVIDENCE_EXTRACTION", "CLAIM_VERIFICATION"), "unsupported": ("SENTIMENT", "MARKET_DIRECTION", "GUIDANCE_ANALYSIS")},
}
