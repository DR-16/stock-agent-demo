"""A small strict schema checker. (CORRECTNESS 002: derived from 001 shared/schema.py; R-05 - a number check never raises, and an integer beyond
2**53 is NUMBER_NOT_REPRESENTABLE before any float conversion.) A spec is plain data; check(value, spec) returns a list of problems [{code, path, detail}] and never raises on
input data. Every object spec lists its keys: a key that is not listed is UNKNOWN_FIELD (also "__proto__", "constructor" and the like: there is no
prototype chain here, and the key list is the only authority). A number is a finite int or float and never a bool. A datetime carries a time zone.

Spec forms:
  {"type": "object", "keys": {name: spec}, "required": [names]}
  {"type": "array", "items": spec, "min": n, "max": n}
  {"type": "string", "min": n, "max": n, "enum": [...]}      (enum optional)
  {"type": "number", "min": x, "max": x}                      (bounds optional; inclusive)
  {"type": "integer", "min": n, "max": n}
  {"type": "boolean"}
  {"type": "date"}                                            YYYY-MM-DD, a real calendar date
  {"type": "datetime"}                                        ISO-8601 with Z or an explicit offset
  any spec may add "nullable": True
"""
from __future__ import annotations

import math
import re
from datetime import date, datetime

RE_DATE = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}")
RE_DT = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}T[0-9]{2}:[0-9]{2}:[0-9]{2}(\.[0-9]{1,6})?(Z|[+-][0-9]{2}:[0-9]{2})")


def parse_date(s) -> date | None:
    if not isinstance(s, str) or not RE_DATE.fullmatch(s):
        return None
    try:
        return date.fromisoformat(s)
    except ValueError:
        return None


def parse_datetime(s) -> datetime | None:
    """an aware datetime, or None (a naive or malformed timestamp is never guessed into a time zone)"""
    if not isinstance(s, str) or not RE_DT.fullmatch(s):
        return None
    try:
        d = datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None
    return d if d.tzinfo is not None else None


SAFE_INT = 2 ** 53


def number_problem(v) -> str | None:
    """None for a usable number, else the code; never raises (an int is checked by magnitude, never converted)"""
    if isinstance(v, bool) or not isinstance(v, (int, float)):
        return "TYPE_NUMBER_EXPECTED"
    if isinstance(v, int):
        return "NUMBER_NOT_REPRESENTABLE" if abs(v) > SAFE_INT else None
    return None if math.isfinite(v) else "TYPE_NUMBER_EXPECTED"


def is_number(v) -> bool:
    return number_problem(v) is None


def check(value, spec: dict, path: str = "$") -> list:
    out: list = []
    _check(value, spec, path, out)
    return out


def _p(out, code, path, detail=""):
    out.append({"code": code, "path": path, "detail": str(detail)[:200]})


def _check(v, spec, path, out):
    if v is None:
        if not spec.get("nullable"):
            _p(out, "NULL_NOT_ALLOWED", path)
        return
    t = spec["type"]
    if t == "object":
        if not isinstance(v, dict):
            return _p(out, "TYPE_OBJECT_EXPECTED", path, type(v).__name__)
        keys = spec.get("keys", {})
        for k in v:
            if not isinstance(k, str) or k not in keys:
                _p(out, "UNKNOWN_FIELD", f"{path}.{k}", "not in the contract")
        for k in spec.get("required", []):
            if k not in v:
                _p(out, "REQUIRED_FIELD_MISSING", f"{path}.{k}")
        for k, sub in keys.items():
            if k in v:
                _check(v[k], sub, f"{path}.{k}", out)
    elif t == "array":
        if not isinstance(v, list):
            return _p(out, "TYPE_ARRAY_EXPECTED", path, type(v).__name__)
        if len(v) < spec.get("min", 0):
            _p(out, "ARRAY_TOO_SHORT", path, f"{len(v)} < {spec.get('min')}")
        if "max" in spec and len(v) > spec["max"]:
            _p(out, "ARRAY_TOO_LONG", path, f"{len(v)} > {spec['max']}")
        for i, item in enumerate(v):
            _check(item, spec["items"], f"{path}[{i}]", out)
    elif t == "string":
        if not isinstance(v, str):
            return _p(out, "TYPE_STRING_EXPECTED", path, type(v).__name__)
        if len(v) < spec.get("min", 0):
            _p(out, "STRING_TOO_SHORT", path)
        if "max" in spec and len(v) > spec["max"]:
            _p(out, "STRING_TOO_LONG", path, f"{len(v)} > {spec['max']}")
        if "enum" in spec and v not in spec["enum"]:
            _p(out, "VALUE_NOT_ALLOWED", path, v[:60])
    elif t == "number":
        np_ = number_problem(v)
        if np_:
            return _p(out, np_, path, repr(v)[:40] if np_ != "NUMBER_NOT_REPRESENTABLE" else f"an integer of {len(str(abs(v)))} digits")
        if "min" in spec and v < spec["min"]:
            _p(out, "NUMBER_BELOW_MIN", path, f"{v} < {spec['min']}")
        if "max" in spec and v > spec["max"]:
            _p(out, "NUMBER_ABOVE_MAX", path, f"{v} > {spec['max']}")
    elif t == "integer":
        if not isinstance(v, int) or isinstance(v, bool):
            return _p(out, "TYPE_INTEGER_EXPECTED", path, repr(v)[:40])
        if abs(v) > SAFE_INT:
            return _p(out, "NUMBER_NOT_REPRESENTABLE", path, f"an integer of {len(str(abs(v)))} digits")
        if "min" in spec and v < spec["min"]:
            _p(out, "NUMBER_BELOW_MIN", path)
        if "max" in spec and v > spec["max"]:
            _p(out, "NUMBER_ABOVE_MAX", path)
    elif t == "boolean":
        if not isinstance(v, bool):
            _p(out, "TYPE_BOOLEAN_EXPECTED", path)
    elif t == "date":
        if parse_date(v) is None:
            _p(out, "DATE_INVALID", path, repr(v)[:40])
    elif t == "datetime":
        if parse_datetime(v) is None:
            _p(out, "DATETIME_INVALID_OR_WITHOUT_TIMEZONE", path, repr(v)[:40])
    else:                                                   # a defect of a spec, not of the input
        raise ValueError(f"unknown spec type {t}")
