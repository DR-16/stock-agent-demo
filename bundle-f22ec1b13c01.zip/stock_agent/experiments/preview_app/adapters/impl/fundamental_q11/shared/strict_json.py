"""Strict JSON for the three-expert prototypes: a text either parses into plain data under every rule below, or it is refused with a result code.

Refused (never repaired): a byte-order mark, invalid UTF-8 (the loader decodes strictly), duplicate keys at any level, the NaN / Infinity / -Infinity
literals, a number that overflows to infinity (1e999), an integer longer than the interpreter's digit limit, nesting deeper than MAX_DEPTH, a text
longer than MAX_CHARS. Nothing here evaluates or executes any part of the input.
"""
from __future__ import annotations

import json
import math

MAX_CHARS = 2_000_000
MAX_DEPTH = 16


class StrictJSONError(ValueError):
    def __init__(self, code: str, detail: str = ""):
        super().__init__(f"{code}: {detail}")
        self.code, self.detail = code, detail


def _pairs(pairs):
    out = {}
    for k, v in pairs:
        if k in out:
            raise StrictJSONError("JSON_DUPLICATE_KEY", k[:80])
        out[k] = v
    return out


def _constant(name):
    raise StrictJSONError("JSON_NON_FINITE_LITERAL", name)


def _float(s: str) -> float:
    v = float(s)
    if not math.isfinite(v):
        raise StrictJSONError("JSON_NUMBER_OVERFLOW", s[:40])
    return v


def _depth(o, limit: int) -> int:
    stack, deepest = [(o, 1)], 1
    while stack:
        cur, d = stack.pop()
        deepest = max(deepest, d)
        if d > limit:
            raise StrictJSONError("JSON_TOO_DEEP", f"depth > {limit}")
        if isinstance(cur, dict):
            stack.extend((v, d + 1) for v in cur.values())
        elif isinstance(cur, list):
            stack.extend((v, d + 1) for v in cur)
    return deepest


def loads(text) -> object:
    """parse one JSON text strictly; raises StrictJSONError with a result code"""
    if not isinstance(text, str):
        raise StrictJSONError("JSON_NOT_TEXT", type(text).__name__)
    if text.startswith("﻿"):
        raise StrictJSONError("JSON_BOM", "a byte-order mark is refused")
    if len(text) > MAX_CHARS:
        raise StrictJSONError("JSON_TOO_LARGE", f"{len(text)} > {MAX_CHARS} characters")
    try:
        obj = json.loads(text, object_pairs_hook=_pairs, parse_constant=_constant, parse_float=_float)
    except StrictJSONError:
        raise
    except (ValueError, RecursionError) as e:            # syntax errors, an over-long integer literal, nesting beyond the parser
        raise StrictJSONError("JSON_INVALID", str(e)[:160]) from None
    _depth(obj, MAX_DEPTH)
    return obj
