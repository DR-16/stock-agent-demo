"""The only file reader of the prototypes: approved synthetic fixtures, by registry id. fixtures/index.json maps an id to a relative path and its
SHA-256. A path that leaves the fixture directory, passes through a link, is not a .json file, or whose bytes do not match the registry is refused.
Nothing else on disk is opened."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

from . import strict_json

FIXTURES = Path(__file__).resolve().parents[1] / "fixtures"
INDEX = FIXTURES / "index.json"


class FixtureError(Exception):
    def __init__(self, code: str, detail: str = ""):
        super().__init__(f"{code}: {detail}")
        self.code, self.detail = code, detail


def registry() -> dict:
    return json.loads(INDEX.read_text(encoding="utf-8"))


def _safe_path(rel: str) -> Path:
    if not isinstance(rel, str) or rel.startswith("/") or "\\" in rel or ".." in rel.split("/") or not rel.endswith(".json"):
        raise FixtureError("FIXTURE_PATH_REFUSED", str(rel)[:120])
    p = FIXTURES
    for part in rel.split("/"):
        p = p / part
        if os.path.islink(p):
            raise FixtureError("FIXTURE_PATH_REFUSED", f"link: {rel}")
    if not p.resolve().is_relative_to(FIXTURES.resolve()) or not p.is_file():
        raise FixtureError("FIXTURE_PATH_REFUSED", rel)
    return p


def read_text(fixture_id: str) -> tuple[str, dict]:
    """the text of one registered fixture and its registry entry"""
    reg = registry()["fixtures"]
    if fixture_id not in reg:
        raise FixtureError("FIXTURE_UNKNOWN", str(fixture_id)[:80])
    ent = reg[fixture_id]
    p = _safe_path(ent["file"])
    b = p.read_bytes()
    if hashlib.sha256(b).hexdigest() != ent["sha256"]:
        raise FixtureError("FIXTURE_HASH_MISMATCH", fixture_id)
    try:
        return b.decode("utf-8", errors="strict"), ent
    except UnicodeDecodeError:
        raise FixtureError("FIXTURE_NOT_UTF8", fixture_id) from None


def load(fixture_id: str) -> tuple[object, dict]:
    text, ent = read_text(fixture_id)
    return strict_json.loads(text), ent


def path_of(fixture_id: str) -> Path:
    """the verified path of a registered fixture (used to hand a price dataset to the read-only Technical/Macro reference process)"""
    read_text(fixture_id)
    return _safe_path(registry()["fixtures"][fixture_id]["file"])
