"""(CORRECTNESS 002: derived from 001 shared/contract.py; input contract te-input-1.1.0.)
The top level of the input contract te-input-1.1.0: one research fixture. The three expert sections are opaque here; each expert checks its own
section with its own strict spec, so a defect in one section never blocks another expert, and no expert ever receives another expert's section.

    fixture_problems(doc)  -> list of problems for the top level (empty when it is acceptable)
    split(doc)             -> {"common": {...}, "fundamental": section|None, "valuation": ..., "information": ..., "price_dataset": id|None}
"""
from __future__ import annotations

import copy

from . import schema
from .constants import INDUSTRY_CLASSES

SECTIONS = ("fundamental", "valuation", "information")

FIXTURE_SPEC = {"type": "object", "required": ["contract_version", "fixture_id", "data_source", "provenance", "as_of", "issuer"], "keys": {
    "contract_version": {"type": "string", "enum": ["te-input-1.0.0", "te-input-1.1.0"]},   # 002: both read with the 1.1.0 checks; the data shape is unchanged
    "fixture_id": {"type": "string", "min": 1, "max": 80},
    "title": {"type": "string", "max": 200},
    "description": {"type": "string", "max": 4000},
    "data_source": {"type": "string", "min": 1, "max": 40},
    "provenance": {"type": "object", "required": ["kind", "generator"], "keys": {
        "kind": {"type": "string", "enum": ["SYNTHETIC", "PUBLIC_SOURCE_INTERNAL_TEST"]}, "generator": {"type": "string", "min": 1, "max": 200}, "note": {"type": "string", "max": 1000}}},
    "as_of": {"type": "datetime"},
    "issuer": {"type": "object", "required": ["issuer_id", "name", "industry_class"], "keys": {
        "issuer_id": {"type": "string", "min": 1, "max": 40}, "name": {"type": "string", "min": 1, "max": 160},
        "security": {"type": "string", "min": 1, "max": 16, "nullable": True}, "industry_class": {"type": "string", "enum": list(INDUSTRY_CLASSES)}}},
    "price_dataset": {"type": "string", "min": 1, "max": 80, "nullable": True},
    "fundamental": {"type": "object", "keys": {}},           # placeholders: the section bodies are checked by their experts
    "valuation": {"type": "object", "keys": {}},
    "information": {"type": "object", "keys": {}},
}}


def fixture_problems(doc) -> list:
    if not isinstance(doc, dict):
        return [{"code": "TYPE_OBJECT_EXPECTED", "path": "$", "detail": type(doc).__name__}]
    top = {k: v for k, v in doc.items() if k not in SECTIONS}
    probs = schema.check(top, FIXTURE_SPEC)
    for s in SECTIONS:
        if s in doc and not isinstance(doc[s], dict):
            probs.append({"code": "TYPE_OBJECT_EXPECTED", "path": f"$.{s}", "detail": type(doc[s]).__name__})
    if isinstance(doc.get("data_source"), str) and doc["data_source"] not in ("SYNTHETIC", "PUBLIC_SOURCE_INTERNAL_TEST"):
        probs.append({"code": "DATA_SOURCE_NOT_SYNTHETIC", "path": "$.data_source", "detail": doc["data_source"][:40]})
    return probs


def split(doc: dict) -> dict:
    """deep copies, so that no expert can reach another expert's section or mutate the caller's document"""
    common = {"fixture_id": doc["fixture_id"], "as_of": doc["as_of"], "issuer": copy.deepcopy(doc["issuer"]), "provenance": copy.deepcopy(doc["provenance"]),
              "data_source": doc["data_source"]}
    out = {"common": common, "price_dataset": doc.get("price_dataset")}
    for s in SECTIONS:
        out[s] = copy.deepcopy(doc[s]) if s in doc else None
    return out
