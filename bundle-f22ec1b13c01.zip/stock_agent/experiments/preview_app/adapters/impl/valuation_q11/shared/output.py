"""(CORRECTNESS 002: derived from 001 shared/output.py; output contract te-output-1.1.0, input contract te-input-1.1.0; R-07 removes CLAIM_VERIFIED.)
The common experimental output contract (Track D) and the registry of result codes. Every code an expert emits is registered here with a
plain-language meaning; an unregistered code is a defect (the tests check it).

The contract keeps five questions apart: did the calculation succeed, are the data adequate, is the evidence sufficient, is a financial
interpretation supported, and is predictive validity demonstrated. The last one is always False in this stage; no field carries a probability or a
score, and meta_eligibility is always NOT_ELIGIBLE.
"""
from __future__ import annotations

import hashlib
import json

OUTPUT_CONTRACT_VERSION = "te-output-1.1.0"
INPUT_CONTRACT_VERSION = "te-input-1.1.0"

CODES = {
    # ---- strict input (shared)
    "JSON_NOT_TEXT": "the input is not text",
    "JSON_BOM": "a byte-order mark is refused",
    "JSON_TOO_LARGE": "the input is larger than the contract allows",
    "JSON_INVALID": "the input is not valid JSON",
    "JSON_DUPLICATE_KEY": "a key appears twice in one object; neither value is used",
    "JSON_NON_FINITE_LITERAL": "NaN or Infinity is not a number in this contract",
    "JSON_NUMBER_OVERFLOW": "a number overflows to infinity",
    "JSON_TOO_DEEP": "the input is nested deeper than the contract allows",
    "UNKNOWN_FIELD": "a field that the contract does not define (it is refused, not ignored)",
    "REQUIRED_FIELD_MISSING": "a required field is missing",
    "NULL_NOT_ALLOWED": "null is not allowed for this field",
    "TYPE_OBJECT_EXPECTED": "an object was expected",
    "TYPE_ARRAY_EXPECTED": "a list was expected",
    "TYPE_STRING_EXPECTED": "a text value was expected",
    "TYPE_NUMBER_EXPECTED": "a finite number was expected (true/false, text and NaN are not numbers)",
    "TYPE_INTEGER_EXPECTED": "a whole number was expected",
    "TYPE_BOOLEAN_EXPECTED": "true or false was expected",
    "ARRAY_TOO_SHORT": "the list has fewer entries than required",
    "ARRAY_TOO_LONG": "the list has more entries than allowed",
    "STRING_TOO_SHORT": "the text is shorter than required",
    "STRING_TOO_LONG": "the text is longer than allowed",
    "VALUE_NOT_ALLOWED": "the value is not one of the allowed values",
    "NUMBER_BELOW_MIN": "the number is below the allowed range",
    "NUMBER_ABOVE_MAX": "the number is above the allowed range",
    "DATE_INVALID": "not a real calendar date in YYYY-MM-DD form",
    "DATETIME_INVALID_OR_WITHOUT_TIMEZONE": "a timestamp must be ISO-8601 with a time zone; none is guessed",
    "DATA_SOURCE_NOT_SYNTHETIC": "only synthetic inputs (and, in Q9, PUBLIC_SOURCE_INTERNAL_TEST inputs) are accepted in this stage",
    "SECTION_ABSENT": "the fixture has no input for this expert",
    "INTERNAL_ERROR": "an unexpected error inside the expert; no result is given",
    # ---- fixtures and loading
    "FIXTURE_UNKNOWN": "the fixture is not in the registry of approved synthetic fixtures",
    "FIXTURE_PATH_REFUSED": "the registry entry points outside the fixture directory, through a link, or to a non-JSON file",
    "FIXTURE_HASH_MISMATCH": "the fixture file does not match the hash recorded in the registry",
    "FIXTURE_NOT_UTF8": "the fixture file is not valid UTF-8",
    "PRICE_DATASET_SECURITY_MISMATCH": "the price dataset is for a different security than the fixture's issuer",
    "PRICE_DATASET_AS_OF_MISMATCH": "the price dataset's as-of date is not the fixture's as-of date",
    "NO_PRICE_DATASET": "the fixture names no price dataset, so Technical and Macro are not run",
    # ---- time
    "FUTURE_PERIOD_EXCLUDED": "a statement period that became available after as_of is excluded",
    "PERIOD_END_AFTER_AS_OF": "a statement period that ends after as_of is excluded",
    "AVAILABILITY_TIMESTAMP_MISSING": "no availability time: the item cannot be shown to be known at as_of and is excluded",
    "AVAILABILITY_BEFORE_PERIOD_END": "the stated availability time is before the period it reports on ended; the item is excluded",
    # ---- fundamental
    "CURRENCY_MISMATCH": "values in different currencies; nothing is converted, the comparison is refused",
    "SCALE_NORMALIZED": "a declared scale (thousands, millions, billions) was converted to units; the values are unchanged",
    "DUPLICATE_PERIOD_IDENTICAL": "an identical duplicate period was removed (recorded)",
    "DUPLICATE_PERIOD_CONFLICT": "two different statements for the same fiscal year; the input is refused",
    "PERIODS_REORDERED": "periods were put in fiscal-year order (recorded)",
    "NO_USABLE_PERIOD": "no statement period is usable at as_of",
    "NEGATIVE_VALUE_INVALID": "a value that cannot be negative is negative; that value is not used",
    "GROSS_PROFIT_IDENTITY_MISMATCH": "gross profit differs from revenue minus cost of revenue by more than the tolerance",
    "BALANCE_SHEET_IDENTITY_MISMATCH": "total assets differ from liabilities plus equity by more than the tolerance",
    "NET_INCOME_ABOVE_REVENUE": "net income above revenue is unusual and is flagged for review",
    "NON_CONSECUTIVE_YEARS": "fiscal years are not consecutive; growth across the gap is not computed",
    "DENOMINATOR_ZERO": "the denominator is zero; the ratio is unavailable",
    "DENOMINATOR_NEGATIVE": "the denominator is negative; the ratio is not meaningful and is unavailable",
    "INPUT_UNAVAILABLE": "a required input is not supplied; the metric is unavailable",
    "NEGATIVE_EQUITY": "equity is negative; equity-based ratios are unavailable",
    # ---- valuation
    "FORECAST_INPUT_NOT_ACCEPTED": "analyst forecasts are not accepted: no qualified source exists; forward P/E and PEG stay unavailable",
    "FORWARD_METHOD_UNAVAILABLE": "the method needs forecast data that this prototype does not have",
    "PRICE_AFTER_AS_OF": "the market price is dated after as_of",
    "FINANCIALS_AFTER_AS_OF": "the financial data became available after as_of",
    "SHARE_COUNT_MISSING": "no share count: per-share values cannot be computed",
    "DEBT_OR_CASH_MISSING": "debt or cash is missing: enterprise value and equity bridges cannot be computed",
    "NEGATIVE_EARNINGS": "earnings are zero or negative: P/E is not meaningful",
    "NEGATIVE_ENTERPRISE_VALUE": "enterprise value (market cap + debt - cash) is zero or negative: EV multiples are not meaningful (Q11)",
    "FINANCIALS_STALE": "the latest annual figures end more than about 16 months before the price date: the multiples compare a current price with old figures (Q11)",
    "PRICE_NOT_CURRENT": "the price is more than 10 days older than the as-of date: the multiples are not as of that date (Q11)",
    "FISCAL_YEAR_AFTER_AVAILABILITY": "the financials say they are for a fiscal year that had not begun when they were published: the period is inconsistent (Q11)",
    "NEGATIVE_BOOK_VALUE": "book value is zero or negative: P/B is not meaningful",
    "NEGATIVE_EBITDA": "EBITDA is zero or negative: EV/EBITDA is not meaningful",
    "NEGATIVE_BASE_FCF": "the starting free cash flow is zero or negative: a growth-based DCF is not meaningful",
    "INDUSTRY_NOT_APPLICABLE": "the method is not applicable to this industry class",
    "DISCOUNT_RATE_OUT_OF_BOUNDS": "the discount rate is outside the declared valid range",
    "TERMINAL_GROWTH_OUT_OF_BOUNDS": "the terminal growth is outside the declared valid range or too close to the discount rate",
    "GROWTH_OUT_OF_BOUNDS": "a stage growth rate is outside the declared valid range",
    "SCENARIO_ORDER_INCONSISTENT": "bear, base and bull assumptions are not ordered as their names say",
    "HIGH_ASSUMPTION_SENSITIVITY": "small assumption changes move the modelled value a lot",
    "TERMINAL_VALUE_DOMINANT": "most of the modelled value comes from the terminal value",
    "SCENARIO_REFUSED": "one DCF scenario is outside the declared bounds and is not valued; the other scenarios are (Track D)",
    "SENSITIVITY_NOT_AVAILABLE": "the sensitivity grid is built around the base scenario, which could not be valued (Track D)",
    "UNITS_IMPLAUSIBLE": "market value and fundamentals differ by an implausible factor: the units are probably inconsistent",
    "REFERENCE_MULTIPLE_RANGE_ABSENT": "no declared reference multiple range: only the observed multiple is shown, no implied value",
    "NO_APPLICABLE_METHOD": "no valuation method is applicable to the supplied data",
    # ---- information
    "DOCUMENT_ISSUER_MISMATCH": "the document is about another issuer and is not analysed",
    "DOCUMENT_CATEGORY_UNSUPPORTED": "the document category is not supported by this prototype",
    "DOCUMENT_EMPTY": "the document has no text",
    "DOCUMENT_AFTER_AS_OF": "the document became available after as_of and is excluded",
    "DOCUMENT_TIMESTAMP_AFTER_AVAILABILITY": "the document date is after its availability time; the timestamps are inconsistent",
    "DOCUMENT_DUPLICATE_IDENTICAL": "an identical duplicate document was removed (recorded)",
    "DOCUMENT_ID_CONFLICT": "two different documents share one id; both are excluded",
    "AMENDMENT_TARGET_UNKNOWN": "an amendment does not name the document it amends; supersession is not resolved",
    "AMENDMENT_TARGET_NOT_FOUND": "the amended document is not among the available documents",
    "SUPERSEDED_BY_AMENDMENT": "the document's events are superseded by an available amendment",
    "NO_SUPPORTED_EVENT": "the document contains no supported event",
    "EVENT_AMBIGUOUS": "an event is indicated but cannot be identified reliably: AMBIGUOUS",
    "EVENT_NOT_VERIFIABLE": "a statement cannot be verified from the document: NOT_VERIFIABLE",
    "EVENT_NEGATED": "the sentence negates the event; no event is extracted",
    "ITEM_NOT_INTERPRETED": "an 8-K item that this prototype records as present but does not interpret (broad item)",
    "CONTRADICTORY_EVIDENCE": "available documents state incompatible facts",
    "CITATION_FOUND": "the exact quoted text was found in an admissible source document (this says nothing about whether the claim is true)",
    "CITATION_NOT_FOUND": "the exact quoted text is not in the cited admissible document",
    "CITATION_NOT_EVALUATED": "the cited document is not admissible (excluded, not supplied or unavailable at as_of), so the citation was not looked up",
    "SOURCE_CURRENT": "the cited source is admissible and the quoted text is not part of a superseded or contradicted extraction",
    "SOURCE_SUPERSEDED": "the quoted text belongs to an extraction that a later amendment supersedes",
    "SOURCE_CONTRADICTED": "the quoted text belongs to an extraction that another available document contradicts",
    "SOURCE_EXCLUDED": "the cited document was excluded or rejected (issuer, category, time, duplicate, emptiness) and cannot support a claim",
    "SOURCE_NOT_SUPPLIED": "the cited document is not among the supplied documents",
    "CLAIM_SUPPORT_UNDETERMINED": "the citation exists, but whether the cited text supports the free-text claim is not determined by this prototype",
    "CLAIM_SUPPORT_NOT_ASSESSED": "there is no admissible citation, so claim support is not assessed",
    "TRUTH_NOT_DETERMINED": "the factual truth of a claim is never determined by this prototype",
    "GUIDANCE_ANALYSIS_UNAVAILABLE": "management guidance is not analysed: the task definition has unresolved blocking questions",
    "FORM4_ROW_INVALID": "a Form 4 transaction row is incomplete or invalid and is not used",
    "UNSUPPORTED_RESEARCH_REQUEST": "the requested kind of research is not supported by this prototype and is refused",
    "PERIOD_NOT_ANNUAL": "the statement period is not an annual period (350-380 days); it is excluded",
    "PRICE_BEFORE_FINANCIALS_AVAILABLE": "the price is dated before the financials became public; the multiple mixes two moments",
    "UNITS_PLAUSIBILITY_NOT_CHECKED": "no positive revenue or book value (or no market cap): unit plausibility could not be checked",
    "HORIZON_OUT_OF_BOUNDS": "the DCF horizon is outside the declared valid range",
    "NEGATIVE_FREE_CASH_FLOW": "free cash flow is zero or negative: the yield is shown as such and P/FCF is not meaningful",
    "AVAILABILITY_UNKNOWN_SEMANTICS": "a date-only or offset-less time: the instant is unknown, so the document is not used (no midnight, zone or filing date is assumed)",
    "AVAILABILITY_INVALID": "the availability time cannot be read",
    "DOCUMENT_DUPLICATE_CONTENT": "a document with another id but the same text and availability time; the first is kept (recorded)",
    "AMENDMENT_ORDER_INVALID": "the amended document is not available before its amendment; supersession is not resolved",
    "ROUTINE_ELECTION_EXCLUDED": "an annual-meeting election or re-election is not treated as a management change",
    "SECTION_SUPPRESSED": "wording inside a forward-looking, risk-factor or safe-harbor section is not interpreted",
    "NUMBER_NOT_REPRESENTABLE": "an integer too large to be represented safely (magnitude above 2**53); it is refused, never converted or clamped",
    "OBLIGATIONS_EXCEED_MODELED_EV": "net obligations (debt - cash) exceed the modelled enterprise value: equity value is negative and no per-share value is meaningful",
    "OBLIGATIONS_EQUAL_MODELED_EV": "net obligations equal the modelled enterprise value: equity value is zero and no per-share value is meaningful",
    "SENSITIVITY_RANGE_NOT_SHOWN": "the sensitivity grid contains cells without a meaningful per-share value, so no per-share range is shown",
    "SCENARIO_RANGE_NOT_SHOWN": "not every DCF scenario has a meaningful per-share value, so no scenario range is shown",
    "EQUITY_SIGN_CHANGES_ACROSS_GRID": "equity value changes sign across the sensitivity grid",
    "DUPLICATE_MATCH_MERGED": "two rules matched the same event in one sentence; one event is kept",
    "SEGMENTATION_AMBIGUOUS": "two different event matches overlap in one sentence and cannot be separated reliably; no event is extracted from them",
    "EFFECTIVE_DATE_INVALID": "the stated effective date is not a real calendar date; the event is AMBIGUOUS and no date is substituted",
    "EFFECTIVE_DATE_UNREADABLE": "the effective date is written in a form this prototype does not read; the event is AMBIGUOUS and no date is guessed",
    "DOCUMENT_PROCESSING_ERROR": "an unexpected error while processing this one document; it is excluded and every other document is still processed",
    "VALUE_NOT_REPRESENTABLE": "a ratio or multiple is not a representable finite number (an input is too small or too large); no value is given",
    "IMPLIED_EQUITY_NOT_POSITIVE": "the equity value implied by a declared multiple is not positive; no per-share value is given for that end of the range",
    "IDENTITY_NOT_CHECKED": "an accounting identity could not be checked because an input is missing; consistency is not asserted",
    "INDETERMINATE_RISK_CHECK": "a risk check could not be evaluated because an input is missing; its absence from the risk flags is not reassurance",
}


def sha256_of(o) -> str:
    b = json.dumps(o, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8") if not isinstance(o, (bytes, str)) else (o.encode("utf-8") if isinstance(o, str) else o)
    return hashlib.sha256(b).hexdigest()


def code(c: str, path: str = "", detail: str = "") -> dict:
    if c not in CODES:
        raise KeyError(f"unregistered result code {c}")
    return {"code": c, "meaning": CODES[c], "path": path, "detail": str(detail)[:240]}


def envelope(expert: str, version: str, analysis_type: str, research_status: str, as_of: str, provenance: dict) -> dict:
    return {
        "expert_name": expert,
        "prototype_version": version,
        "experimental": True,
        "execution_status": "NOT_RUN",
        "analysis_type": analysis_type,
        "research_status": research_status,
        "data_source": ((provenance or {}).get("fixture_provenance") or {}).get("kind") or "SYNTHETIC",   # Q9: what the input was, not a constant
        "data_status": {},
        "as_of": as_of,
        "input_provenance": provenance,
        "input_contract_version": INPUT_CONTRACT_VERSION,
        "output_contract_version": OUTPUT_CONTRACT_VERSION,
        "evidence": [],
        "counter_evidence": [],
        "findings": {},
        "confidence_basis": "",
        "warnings": [],
        "missing_dependencies": [],
        "abstentions": [],
        "calculation_or_extraction_trace": [],
        "questions": {"calculation_succeeded": False, "data_adequate": "NOT_ASSESSED", "evidence_sufficient": "NOT_ASSESSED",
                      "financial_interpretation_supported": "NOT_ASSESSED", "predictive_validity_demonstrated": False},
        "predictive_validation": "NOT_ESTABLISHED",
        "research_validation_status": "NOT_VALIDATED: Level 1 FUNCTIONAL_SYNTHETIC_PROTOTYPE target only; Level 2 RESEARCH_VALIDATION_ELIGIBLE not met",
        "meta_eligibility": "NOT_ELIGIBLE",
        "production_state_unchanged": True,
        "result_codes": [],
    }


def reject(env: dict, problems: list) -> dict:
    env["execution_status"] = "REJECTED_INPUT"
    env["result_codes"] = [code(p["code"], p.get("path", ""), p.get("detail", "")) for p in problems]
    env["questions"]["calculation_succeeded"] = False
    env["questions"]["data_adequate"] = "INADEQUATE"
    env["confidence_basis"] = "no result: the input was refused (see result_codes); nothing was calculated"
    return env
