"""TE Valuation laboratory, CORRECTNESS 002 (derived from 001 valuation/valuation_lab.py, sha24 c6065a5f4cabe7502192939a). Experimental prototype;
synthetic inputs only; DORMANT in production and not connected to anything.

002 corrections: R-01 - the DCF reports enterprise value, equity value and per-share value separately, with an explicit state for a zero or negative
equity value (never a negative "price"), and every sensitivity metric is dimensionless with the same unit above and below the line; a sensitivity
warning can no longer be hidden by a mismatched denominator. R-14 - the EV wording below names its deviation.
Post-review fixes (after this stage's review): the EV/EBITDA implied range goes through the same equity bridge (no negative per-share value; review R-01
and main-flow M-01); every division is checked for a finite result (review R-12: tiny inputs never raise or produce inf).

An assumption-explicit valuation laboratory. Each method declares its prerequisites and its industry applicability and is shown on its own; methods
are never averaged and no single "fair price" is produced. Market multiples report the OBSERVED multiple; an implied value range exists only when
the user declares a reference multiple range. The DCF is a scenario calculation under declared assumptions (bear / base / bull) with a sensitivity
grid. Forward P/E and PEG need analyst forecasts, for which no qualified source exists: they are always unavailable, and a forecast input is refused.

Definitions: EBITDA = operating income + depreciation and amortisation (ERC1), FCF = operating cash flow - capex (capex a positive outflow), P/FCF
only for positive FCF (Valuation 0.1.0). EV = market cap + long-term debt + short-term debt - cash: a DEVIATION from ERC1, which used long-term
debt only (0.1.0 itself takes EV as given).
Where 0.1.0 returned a silent None (negative earnings, negative FCF), this prototype returns an explicit status. A modelled value is not evidence of
future market returns, and nothing here is a buy or sell instruction.
"""
from __future__ import annotations

import math
from decimal import Decimal
from datetime import date

from shared import output as O
from shared import schema
from shared.constants import (DCF_BOUNDS, HIGH_SENSITIVITY_RELATIVE_SPREAD, MAX_ABS_AMOUNT, REQUESTS, SCALES, SENSITIVITY_GRID, TERMINAL_VALUE_DOMINANT_SHARE,
                              UNITS_PLAUSIBILITY, CURRENCIES, applicability)

VERSION = "q4-valuation-d 0.2.1-experimental+q11.2 (Q11.2 (second review N6): a negative capex / depreciation is named as invalid in the method's code; Q11.1 (mid-round review VA-1..3): a negative input is named as invalid, not as missing; a zero denominator is DENOMINATOR_ZERO, not 'negative'; a zero or negative enterprise value gives no EV multiple; a fiscal year that had not begun when published is refused; old annual figures and an old price are flagged and the period is written as the fiscal year's annual figures; Q10: an unavailable method names the input fields that are actually missing; Q9 contract and wording kept; valuation rules unchanged)"
ZERO_EQUITY_REL = 1e-9          # |equity| <= 1e-9 x |EV| is a numerical zero (a state, not a floor)
AMT = {"type": "number", "min": -MAX_ABS_AMOUNT, "max": MAX_ABS_AMOUNT, "nullable": True}
RANGE = {"type": "object", "required": ["low", "high"], "keys": {"low": {"type": "number", "min": 0.0001, "max": 1e4}, "high": {"type": "number", "min": 0.0001, "max": 1e4},
                                                                "rationale": {"type": "string", "max": 500}}}
SCEN = {"type": "object", "required": ["stage_growth", "terminal_growth", "discount_rate"], "keys": {
    "stage_growth": {"type": "number", "min": -10, "max": 10}, "terminal_growth": {"type": "number", "min": -10, "max": 10},
    "discount_rate": {"type": "number", "min": -10, "max": 10}, "rationale": {"type": "string", "max": 500}}}
SPEC = {"type": "object", "required": ["currency", "market", "financials"], "keys": {
    "currency": {"type": "string", "enum": list(CURRENCIES)},
    "requests": {"type": "array", "max": 10, "items": {"type": "string", "enum": list(REQUESTS["valuation"]["supported"] + REQUESTS["valuation"]["unsupported"])}},
    "market": {"type": "object", "required": ["price", "price_currency", "price_date", "shares_outstanding", "shares_scale"], "keys": {
        "price": {"type": "number", "min": 0.000001, "max": 1e7}, "price_currency": {"type": "string", "enum": list(CURRENCIES)}, "price_date": {"type": "date"},
        "shares_outstanding": {"type": "number", "min": 0.000001, "max": 1e13, "nullable": True}, "shares_scale": {"type": "string", "enum": list(SCALES)}}},
    "financials": {"type": "object", "required": ["fiscal_year", "available_at", "currency", "scale"], "keys": {
        "fiscal_year": {"type": "integer", "min": 1900, "max": 2100}, "available_at": {"type": "datetime", "nullable": True},
        "currency": {"type": "string", "enum": list(CURRENCIES)}, "scale": {"type": "string", "enum": list(SCALES)},
        "revenue": AMT, "net_income": AMT, "stockholders_equity": AMT, "operating_income": AMT, "depreciation_amort": AMT, "operating_cash_flow": AMT,
        "capex": AMT, "long_term_debt": AMT, "short_term_debt": AMT, "cash_and_equivalents": AMT}},
    "assumptions": {"type": "object", "keys": {
        "reference_multiples": {"type": "object", "keys": {"pe": RANGE, "pb": RANGE, "ev_ebitda": RANGE}},
        "dcf": {"type": "object", "required": ["horizon_years", "scenarios"], "keys": {
            "horizon_years": {"type": "integer", "min": 1, "max": 50},
            "scenarios": {"type": "object", "required": ["bear", "base", "bull"], "keys": {"bear": SCEN, "base": SCEN, "bull": SCEN}}}}}},
}}


def _c(codes: list, c: str, path: str = "", detail: str = ""):
    codes.append(O.code(c, path, detail))


def _method(name: str, industry: str, app_key: str | None, prerequisites: list) -> dict:
    app, why = applicability(app_key, industry) if app_key else ("APPLICABLE", "")
    return {"method": name, "status": "UNAVAILABLE", "applicability": app, "applicability_rule": why or "no industry restriction declared for this method",
            "prerequisites": prerequisites, "inputs": {}, "observed_multiple": None, "implied_value_per_share": None, "codes": [], "trace": []}


def _discount(fcf0: float, g: float, gt: float, r: float, n: int) -> dict:
    flows, pv, f = [], 0.0, fcf0
    for t in range(1, n + 1):
        f = f * (1.0 + g)
        d = (1.0 + r) ** t
        pv += f / d
        flows.append({"year": t, "fcf": f, "discount_factor": d, "present_value": f / d})
    tv = f * (1.0 + gt) / (r - gt)
    pv_tv = tv / (1.0 + r) ** n
    ev = pv + pv_tv
    return {"enterprise_value": ev, "pv_explicit": pv, "terminal_value": tv, "pv_terminal": pv_tv, "terminal_share": pv_tv / ev if ev else None, "flows": flows}


def _fin(x):
    """a finite number, else None (post-review R-12: tiny or huge inputs never become inf, nan or a ZeroDivisionError)"""
    return x if isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) else None


def _div(a, b):
    return _fin(a / b) if b else None


def equity_bridge(ev: float, debt, cash, shares) -> dict:
    """enterprise value -> equity value -> per-share value, each with its own state; a non-positive equity value never becomes a per-share number"""
    if debt is None or cash is None:
        return {"net_obligations": None, "equity_value": None, "equity_state": "UNAVAILABLE", "value_per_share": {"state": "UNAVAILABLE_NO_DEBT_OR_CASH", "value": None}}
    eq = ev - debt + cash
    st = "ZERO" if abs(eq) <= ZERO_EQUITY_REL * abs(ev) else "POSITIVE" if eq > 0 else "NEGATIVE"
    if st == "ZERO":
        vps = {"state": "NOT_MEANINGFUL_ZERO_EQUITY", "value": None}
    elif st == "NEGATIVE":
        vps = {"state": "NOT_MEANINGFUL_NEGATIVE_EQUITY", "value": None}
    elif shares is None:
        vps = {"state": "UNAVAILABLE_NO_SHARES", "value": None}
    else:
        vps = {"state": "MEANINGFUL", "value": eq / shares}
    return {"net_obligations": debt - cash, "equity_value": eq, "equity_state": st, "value_per_share": vps}


def _D(x) -> Decimal:
    return Decimal(str(x))


def _scenario_problems(s: dict) -> list:
    """Track D: every bound of the declared DCF contract is compared in exact decimal arithmetic of the declared numbers (bounds inclusive), so a value
    written exactly on a bound is inside it whatever its binary representation"""
    out = []
    r, gt, g = s["discount_rate"], s["terminal_growth"], s["stage_growth"]
    lo, hi = DCF_BOUNDS["discount_rate"]
    if not _D(lo) <= _D(r) <= _D(hi):
        out.append(("DISCOUNT_RATE_OUT_OF_BOUNDS", f"{r} not in [{lo}, {hi}]"))
    lo, hi = DCF_BOUNDS["terminal_growth"]
    if not _D(lo) <= _D(gt) <= _D(hi):
        out.append(("TERMINAL_GROWTH_OUT_OF_BOUNDS", f"{gt} not in [{lo}, {hi}]"))
    elif _D(gt) > _D(r) - _D(DCF_BOUNDS["terminal_spread_min"]):
        out.append(("TERMINAL_GROWTH_OUT_OF_BOUNDS", f"terminal growth {gt} is closer than {DCF_BOUNDS['terminal_spread_min']} to the discount rate {r}"))
    lo, hi = DCF_BOUNDS["stage_growth"]
    if not _D(lo) <= _D(g) <= _D(hi):
        out.append(("GROWTH_OUT_OF_BOUNDS", f"{g} not in [{lo}, {hi}]"))
    return out


def analyze(section: dict | None, common: dict) -> dict:
    prov = {"fixture_id": common["fixture_id"], "section": "valuation", "section_sha256": O.sha256_of(section) if section is not None else None,
            "fixture_provenance": common["provenance"], "issuer_id": common["issuer"]["issuer_id"]}
    env = O.envelope("Valuation", VERSION, "SCENARIO_VALUATION", "SCENARIO_VALUATION_ONLY", common["as_of"], prov)
    if section is None:
        env["result_codes"] = [O.code("SECTION_ABSENT", "$.valuation")]
        env["confidence_basis"] = "not run: the fixture has no valuation input"
        return env
    if isinstance(section, dict) and "analyst_forecasts" in section:
        return O.reject(env, [{"code": "FORECAST_INPUT_NOT_ACCEPTED", "path": "$.valuation.analyst_forecasts",
                               "detail": "no qualified source of analyst forecasts is established; forecasts are not accepted as input"}])
    probs = schema.check(section, SPEC, "$.valuation")
    if probs:
        return O.reject(env, probs)
    codes, warnings, trace = [], [], []
    industry = common["issuer"]["industry_class"]
    as_of = schema.parse_datetime(common["as_of"])
    reqs = section.get("requests") or ["SCENARIO_VALUATION"]
    for q in reqs:
        if q in REQUESTS["valuation"]["unsupported"]:
            env["abstentions"].append({"request": q, **O.code("UNSUPPORTED_RESEARCH_REQUEST", "$.valuation.requests", q)})
    if "SCENARIO_VALUATION" not in reqs:
        env["execution_status"] = "NOT_RUN"
        env["confidence_basis"] = "not run: no supported valuation request"
        return env
    mkt, fin, asm = section["market"], section["financials"], section.get("assumptions") or {}
    cur = section["currency"]
    if not (mkt["price_currency"] == cur == fin["currency"]):
        return O.reject(env, [{"code": "CURRENCY_MISMATCH", "path": "$.valuation", "detail": f"section {cur}, price {mkt['price_currency']}, financials {fin['currency']}"}])
    if date.fromisoformat(mkt["price_date"]) > as_of.date():
        return O.reject(env, [{"code": "PRICE_AFTER_AS_OF", "path": "$.valuation.market.price_date", "detail": f"{mkt['price_date']} > {common['as_of']}"}])
    if fin["available_at"] is None:
        return O.reject(env, [{"code": "AVAILABILITY_TIMESTAMP_MISSING", "path": "$.valuation.financials.available_at", "detail": "the financials cannot be shown to be known at as_of"}])
    fin_at = schema.parse_datetime(fin["available_at"])
    if fin_at > as_of:
        return O.reject(env, [{"code": "FINANCIALS_AFTER_AS_OF", "path": "$.valuation.financials.available_at", "detail": f"{fin['available_at']} > {common['as_of']}"}])
    if date.fromisoformat(mkt["price_date"]) < fin_at.date():
        warnings.append(O.code("PRICE_BEFORE_FINANCIALS_AVAILABLE", "$.valuation.market.price_date", "the price predates the public availability of the financials"))
    if isinstance(fin.get("fiscal_year"), int) and date(fin["fiscal_year"], 1, 1) > fin_at.date():          # Q11.1 (review VA-3)
        return O.reject(env, [{"code": "FISCAL_YEAR_AFTER_AVAILABILITY", "path": "$.valuation.financials.fiscal_year",
                               "detail": f"FY{fin['fiscal_year']} figures published {fin['available_at'][:10]}, before that fiscal year began"}])
    pdate_ = date.fromisoformat(mkt["price_date"])
    stale = isinstance(fin.get("fiscal_year"), int) and (pdate_ - date(fin["fiscal_year"], 12, 31)).days > 486
    if stale:
        warnings.append(O.code("FINANCIALS_STALE", "$.valuation.financials.fiscal_year", f"FY{fin['fiscal_year']} annual figures with a price of {mkt['price_date']}"))
    if (as_of.date() - pdate_).days > 10:
        warnings.append(O.code("PRICE_NOT_CURRENT", "$.valuation.market.price_date", f"price of {mkt['price_date']}, {(as_of.date() - pdate_).days} days before as_of"))

    # ---- units: everything in currency units and in single shares
    k, ks = SCALES[fin["scale"]], SCALES[mkt["shares_scale"]]
    v = {n: (fin.get(n) * k if fin.get(n) is not None else None) for n in ("revenue", "net_income", "stockholders_equity", "operating_income", "depreciation_amort",
                                                                         "operating_cash_flow", "capex", "long_term_debt", "short_term_debt", "cash_and_equivalents")}
    if fin["scale"] != "UNITS" or mkt["shares_scale"] != "UNITS":
        trace.append({"step": "units", "detail": f"amounts x {k:g} ({fin['scale']}), shares x {ks:g} ({mkt['shares_scale']})", "code": "SCALE_NORMALIZED"})
    invalid = set()                               # Q11.1 (review VA-1): an input that was given but is invalid is never called 'missing'
    for n in ("capex", "long_term_debt", "short_term_debt", "cash_and_equivalents", "revenue", "depreciation_amort"):
        if v[n] is not None and v[n] < 0:
            _c(codes, "NEGATIVE_VALUE_INVALID", f"$.valuation.financials.{n}", f"{n} < 0 is not used")
            v[n] = None
            invalid.add(n)
    price = mkt["price"]
    shares = mkt["shares_outstanding"] * ks if mkt["shares_outstanding"] is not None else None
    mcap = price * shares if shares is not None else None
    debt = v["long_term_debt"] + v["short_term_debt"] if v["long_term_debt"] is not None and v["short_term_debt"] is not None else None
    cash = v["cash_and_equivalents"]
    ebitda = v["operating_income"] + v["depreciation_amort"] if v["operating_income"] is not None and v["depreciation_amort"] is not None else None
    fcf = v["operating_cash_flow"] - v["capex"] if v["operating_cash_flow"] is not None and v["capex"] is not None else None
    ev = mcap + debt - cash if mcap is not None and debt is not None and cash is not None else None
    inputs = {"price": price, "price_date": mkt["price_date"], "shares": shares, "market_cap": mcap, "total_debt": debt, "cash": cash, "enterprise_value": ev,
              "ebitda": ebitda, "free_cash_flow": fcf, **{n: v[n] for n in ("revenue", "net_income", "stockholders_equity")}, "currency": cur, "fiscal_year": fin["fiscal_year"],
              "financials_available_at": fin["available_at"]}
    trace.append({"step": "derived inputs", "formulas": {"market_cap": "price * shares", "total_debt": "long_term_debt + short_term_debt", "enterprise_value": "market_cap + total_debt - cash",
                                                         "ebitda": "operating_income + depreciation_amort", "free_cash_flow": "operating_cash_flow - capex"}, "values": inputs})
    if shares is None:
        _c(codes, "SHARE_COUNT_MISSING", "$.valuation.market.shares_outstanding")
    missing_parts = [n for n in ("long_term_debt", "short_term_debt", "cash_and_equivalents") if v[n] is None and n not in invalid]
    invalid_parts = [n for n in ("long_term_debt", "short_term_debt", "cash_and_equivalents") if n in invalid]
    if debt is None or cash is None:
        _c(codes, "NEGATIVE_VALUE_INVALID" if invalid_parts and not missing_parts else "DEBT_OR_CASH_MISSING", "$.valuation.financials",
           ("missing: " + ", ".join(missing_parts) if missing_parts else "") + ("; " if missing_parts and invalid_parts else "") +
           ("invalid (negative, not used): " + ", ".join(invalid_parts) if invalid_parts else "") +
           " (long_term_debt, short_term_debt and cash_and_equivalents are all needed; none is assumed to be zero)")
    # ---- unit plausibility
    plaus = None
    if mcap is not None:
        if v["revenue"] is not None and v["revenue"] > 0:
            plaus = ("market_cap_to_revenue", mcap / v["revenue"])
        elif v["stockholders_equity"] is not None and v["stockholders_equity"] > 0:
            plaus = ("market_cap_to_book", mcap / v["stockholders_equity"])
    if plaus:
        lo, hi = UNITS_PLAUSIBILITY[plaus[0]]
        trace.append({"step": "unit plausibility", "ratio": plaus[0], "value": plaus[1], "bounds": [lo, hi]})
        if not lo <= plaus[1] <= hi:
            return O.reject(env, [{"code": "UNITS_IMPLAUSIBLE", "path": "$.valuation", "detail": f"{plaus[0]} = {plaus[1]:.6g} outside [{lo}, {hi}]"}])
    else:
        warnings.append(O.code("UNITS_PLAUSIBILITY_NOT_CHECKED", "$.valuation", "no positive revenue or book value, or no market cap"))

    refm = asm.get("reference_multiples") or {}
    methods = []
    # ---- trailing P/E
    m = _method("TRAILING_PE", industry, "PE", ["price", "shares_outstanding", "net_income > 0"])
    m["inputs"] = {"price": price, "net_income": v["net_income"], "shares": shares}
    eps = _div(v["net_income"], shares) if shares is not None and v["net_income"] is not None and v["net_income"] > 0 else None
    if shares is None or v["net_income"] is None:
        m["codes"].append(O.code("SHARE_COUNT_MISSING" if shares is None else "INPUT_UNAVAILABLE", "", "net income and a share count are needed"))
    elif v["net_income"] <= 0:
        m["status"] = "NOT_MEANINGFUL"
        m["codes"].append(O.code("NEGATIVE_EARNINGS" if v["net_income"] < 0 else "DENOMINATOR_ZERO", "", f"net income {v['net_income']:g}"))   # Q11.1
    elif not eps or _div(price, eps) is None:
        m["status"] = "NOT_MEANINGFUL"
        m["codes"].append(O.code("VALUE_NOT_REPRESENTABLE", "", "EPS or P/E is not a representable finite number"))
    else:
        m.update(status="COMPUTED", observed_multiple=price / eps)
        m["trace"] = [f"EPS = net_income / shares = {v['net_income']:g} / {shares:g} = {eps:.10g}", f"P/E = price / EPS = {price:g} / {eps:.10g} = {price / eps:.10g}"]
        if "pe" in refm:
            m["implied_value_per_share"] = {"low": eps * refm["pe"]["low"], "high": eps * refm["pe"]["high"], "basis": f"EPS x declared P/E range [{refm['pe']['low']}, {refm['pe']['high']}]",
                                            "assumption_rationale": refm["pe"].get("rationale", "")}
        else:
            m["codes"].append(O.code("REFERENCE_MULTIPLE_RANGE_ABSENT", "", "pe"))
    methods.append(m)
    # ---- price to book
    m = _method("PRICE_TO_BOOK", industry, "PB", ["price", "shares_outstanding", "stockholders_equity > 0"])
    m["inputs"] = {"price": price, "stockholders_equity": v["stockholders_equity"], "shares": shares}
    bvps = _div(v["stockholders_equity"], shares) if shares is not None and v["stockholders_equity"] is not None and v["stockholders_equity"] > 0 else None
    if shares is None or v["stockholders_equity"] is None:
        m["codes"].append(O.code("SHARE_COUNT_MISSING" if shares is None else "INPUT_UNAVAILABLE", "", "book value and a share count are needed"))
    elif v["stockholders_equity"] <= 0:
        m["status"] = "NOT_MEANINGFUL"
        m["codes"].append(O.code("NEGATIVE_BOOK_VALUE" if v["stockholders_equity"] < 0 else "DENOMINATOR_ZERO", "", f"equity {v['stockholders_equity']:g}"))   # Q11.1
    elif not bvps or _div(price, bvps) is None:
        m["status"] = "NOT_MEANINGFUL"
        m["codes"].append(O.code("VALUE_NOT_REPRESENTABLE", "", "BVPS or P/B is not a representable finite number"))
    else:
        m.update(status="COMPUTED", observed_multiple=price / bvps)
        m["trace"] = [f"BVPS = equity / shares = {bvps:.10g}", f"P/B = {price:g} / {bvps:.10g} = {price / bvps:.10g}"]
        if "pb" in refm:
            m["implied_value_per_share"] = {"low": bvps * refm["pb"]["low"], "high": bvps * refm["pb"]["high"], "basis": f"BVPS x declared P/B range [{refm['pb']['low']}, {refm['pb']['high']}]",
                                            "assumption_rationale": refm["pb"].get("rationale", "")}
        else:
            m["codes"].append(O.code("REFERENCE_MULTIPLE_RANGE_ABSENT", "", "pb"))
    methods.append(m)
    # ---- EV / EBITDA and EV / Sales
    for name, key, denom_name in (("EV_EBITDA", "EV_EBITDA", "ebitda"), ("EV_SALES", "EV_SALES", "revenue")):
        m = _method(name, industry, key, ["market cap (price x shares)", "total debt", "cash", f"{denom_name} > 0"])
        denom = ebitda if denom_name == "ebitda" else v["revenue"]
        m["inputs"] = {"enterprise_value": ev, denom_name: denom}
        if m["applicability"] == "NOT_APPLICABLE":
            m["status"] = "NOT_APPLICABLE"
            m["codes"].append(O.code("INDUSTRY_NOT_APPLICABLE", "", f"{industry}: {m['applicability_rule']}"))
        elif ev is None:
            m["codes"].append(O.code("SHARE_COUNT_MISSING" if shares is None else "NEGATIVE_VALUE_INVALID" if invalid_parts and not missing_parts else "DEBT_OR_CASH_MISSING", "",
                                     "enterprise value cannot be computed" + (f"; missing: {', '.join(missing_parts)}" if shares is not None and missing_parts else "")
                                     + (f"; invalid (negative, not used): {', '.join(invalid_parts)}" if shares is not None and invalid_parts else "")))
        elif ev <= 0:                                 # Q11.1 (review VA-2): a zero or negative enterprise value gives no EV multiple
            m["status"] = "NOT_MEANINGFUL"
            m["codes"].append(O.code("NEGATIVE_ENTERPRISE_VALUE", "", f"EV = {mcap:g} + {debt:g} - {cash:g} = {ev:g}"))
        elif denom is None:
            bad_ = [n_ for n_ in ((denom_name,) if denom_name == "revenue" else ("operating_income", "depreciation_amort")) if n_ in invalid]
            m["codes"].append(O.code("NEGATIVE_VALUE_INVALID" if bad_ else "INPUT_UNAVAILABLE", "", f"{', '.join(bad_)} < 0 is not used ({denom_name} needs it)" if bad_ else denom_name))   # Q11.2 (2nd review N6)
        elif denom <= 0:
            m["status"] = "NOT_MEANINGFUL"
            m["codes"].append(O.code("DENOMINATOR_ZERO" if denom == 0 else "NEGATIVE_EBITDA" if denom_name == "ebitda" else "DENOMINATOR_NEGATIVE", "", f"{denom_name} {denom:g}"))
        elif _div(ev, denom) is None:
            m["status"] = "NOT_MEANINGFUL"
            m["codes"].append(O.code("VALUE_NOT_REPRESENTABLE", "", f"{name} is not a representable finite number"))
        else:
            m.update(status="COMPUTED", observed_multiple=ev / denom)
            m["trace"] = [f"EV = {mcap:g} + {debt:g} - {cash:g} = {ev:g}", f"{name} = {ev:g} / {denom:g} = {ev / denom:.10g}"]
            if name == "EV_EBITDA":
                if "ev_ebitda" in refm:
                    # post-review R-01 / M-01: the implied equity goes through the same equity bridge as the DCF: no negative 'price'
                    iv = {"basis": f"(EBITDA x declared EV/EBITDA range [{refm['ev_ebitda']['low']}, {refm['ev_ebitda']['high']}] - debt + cash) / shares",
                          "assumption_rationale": refm["ev_ebitda"].get("rationale", ""), "implied_enterprise_value": {}, "implied_equity": {}, "states": {}}
                    for x in ("low", "high"):
                        iev = refm["ev_ebitda"][x] * ebitda
                        br = equity_bridge(iev, debt, cash, shares)
                        iv["implied_enterprise_value"][x], iv["implied_equity"][x] = iev, br["equity_value"]
                        iv["states"][x] = br["value_per_share"]["state"]
                        iv[x] = br["value_per_share"]["value"]
                    if any(st != "MEANINGFUL" for st in iv["states"].values()):
                        m["codes"].append(O.code("IMPLIED_EQUITY_NOT_POSITIVE", "", ", ".join(f"{x}: implied equity {iv['implied_equity'][x]:,.0f} ({iv['states'][x]})" for x in ("low", "high"))))
                    m["implied_value_per_share"] = iv
                else:
                    m["codes"].append(O.code("REFERENCE_MULTIPLE_RANGE_ABSENT", "", "ev_ebitda"))
        methods.append(m)
    # ---- FCF yield (and P/FCF for positive FCF)
    m = _method("FCF_YIELD", industry, "FCF_YIELD", ["market cap", "free cash flow (operating cash flow - capex)"])
    m["inputs"] = {"free_cash_flow": fcf, "market_cap": mcap}
    fy = _div(fcf, mcap) if mcap is not None and fcf is not None else None
    if m["applicability"] == "NOT_APPLICABLE":
        m["status"] = "NOT_APPLICABLE"
        m["codes"].append(O.code("INDUSTRY_NOT_APPLICABLE", "", f"{industry}: {m['applicability_rule']}"))
    elif mcap is None or fcf is None:
        bad_ = [n_ for n_ in ("operating_cash_flow", "capex") if n_ in invalid]
        m["codes"].append(O.code("SHARE_COUNT_MISSING" if mcap is None else "NEGATIVE_VALUE_INVALID" if bad_ else "INPUT_UNAVAILABLE", "",
                                 f"{', '.join(bad_)} < 0 is not used (free cash flow needs it)" if (mcap is not None and bad_) else "market cap and free cash flow are needed"))   # Q11.2 (2nd review N6)
    elif fy is None:
        m["status"] = "NOT_MEANINGFUL"
        m["codes"].append(O.code("VALUE_NOT_REPRESENTABLE", "", "FCF yield is not a representable finite number"))
    else:
        m.update(status="COMPUTED", observed_multiple=fy)
        pf = _div(mcap, fcf) if fcf > 0 else None
        m["p_fcf"] = pf if pf is not None else "NOT_MEANINGFUL (free cash flow <= 0 or not representable)"
        m["trace"] = [f"FCF yield = {fcf:g} / {mcap:g} = {fy:.10g}"]
        if fcf <= 0:
            m["codes"].append(O.code("NEGATIVE_FREE_CASH_FLOW", "", "the yield is negative or zero; P/FCF is not meaningful"))
    methods.append(m)
    # ---- forward methods: never available
    for name in ("FORWARD_PE", "PEG"):
        m = _method(name, industry, None, ["analyst forecast of earnings" + (" growth" if name == "PEG" else "")])
        m["codes"].append(O.code("FORWARD_METHOD_UNAVAILABLE", "", "ERC1: needs an analyst forecast; no qualified source is established (PROVIDER_DECISION_PENDING)"))
        methods.append(m)
    # ---- DCF
    dcf = {"method": "DCF_FCF", "status": "UNAVAILABLE", "codes": []}
    app, why = applicability("DCF_FCF", industry)
    dcf.update(applicability=app, applicability_rule=why or "no industry restriction declared for this method",
               prerequisites=["free cash flow > 0 (base year)", "declared bear / base / bull assumptions within bounds", "total debt and cash for the equity bridge", "shares for per-share values"],
               bounds=DCF_BOUNDS, formula="EV = sum_{t=1..N} FCF0 (1+g)^t / (1+r)^t + [FCF_N (1+gT) / (r - gT)] / (1+r)^N; equity = EV - debt + cash; per share = equity / shares")
    spec = asm.get("dcf")
    if app == "NOT_APPLICABLE":
        dcf["status"] = "NOT_APPLICABLE"
        dcf["codes"].append(O.code("INDUSTRY_NOT_APPLICABLE", "", f"{industry}: {why}"))
    elif spec is None:
        dcf["codes"].append(O.code("INPUT_UNAVAILABLE", "$.valuation.assumptions.dcf", "no DCF assumptions declared"))
    elif fcf is None:
        dcf["codes"].append(O.code("NEGATIVE_VALUE_INVALID" if "capex" in invalid else "INPUT_UNAVAILABLE", "", "capex < 0 is not used (free cash flow needs it)" if "capex" in invalid else "free cash flow"))
    elif fcf <= 0:
        dcf["status"] = "NOT_MEANINGFUL"
        dcf["codes"].append(O.code("NEGATIVE_BASE_FCF", "", f"FCF {fcf:g}"))
    else:
        lo, hi = DCF_BOUNDS["horizon_years"]
        sc = spec["scenarios"]
        if not lo <= spec["horizon_years"] <= hi:         # Track D: the horizon is shared by every scenario - the whole method is refused
            dcf["status"] = "REFUSED"
            dcf["refusal_scope"] = "METHOD"
            dcf["codes"].append(O.code("HORIZON_OUT_OF_BOUNDS", "$.valuation.assumptions.dcf.horizon_years", f"horizon {spec['horizon_years']} not in [{lo}, {hi}]"))
        else:
            n = spec["horizon_years"]
            out, refused = {}, []
            for sname in ("bear", "base", "bull"):
                s_ = sc[sname]
                probs = _scenario_problems(s_)
                if probs:                                  # Track D: a scenario outside the bounds is refused on its own; the others are still valued
                    refused.append(sname)
                    out[sname] = {"assumptions": dict(s_), "horizon_years": n, "state": "REFUSED", "reasons": [c for c, _ in probs]}
                    for c, d in probs:
                        dcf["codes"].append(O.code(c, f"$.valuation.assumptions.dcf.scenarios.{sname}", d))
                    dcf["codes"].append(O.code("SCENARIO_REFUSED", f"scenario {sname}", "outside the declared DCF bounds: this scenario is not valued; the others are"))
                    continue
                res = _discount(fcf, s_["stage_growth"], s_["terminal_growth"], s_["discount_rate"], n)
                br = equity_bridge(res["enterprise_value"], debt, cash, shares)
                out[sname] = {"assumptions": dict(s_), "horizon_years": n, "base_fcf": fcf, "state": "COMPUTED", **res, **br}
                if br["equity_state"] in ("NEGATIVE", "ZERO"):
                    c = "OBLIGATIONS_EXCEED_MODELED_EV" if br["equity_state"] == "NEGATIVE" else "OBLIGATIONS_EQUAL_MODELED_EV"
                    out[sname]["obligations"] = {"net_obligations": br["net_obligations"], "modelled_enterprise_value": res["enterprise_value"], "shortfall": -br["equity_value"],
                                                 "explanation": f"net obligations (debt - cash = {br['net_obligations']:,.0f}) {'exceed' if c.endswith('EXCEED_MODELED_EV') else 'equal'} the modelled "
                                                                f"enterprise value ({res['enterprise_value']:,.0f}); equity value {br['equity_value']:,.0f} {cur}: no per-share value is meaningful"}
                    dcf["codes"].append(O.code(c, f"scenario {sname}", out[sname]["obligations"]["explanation"]))
            status_by = {k: out[k]["state"] for k in ("bear", "base", "bull")}
            if len(refused) == 3:
                dcf.update(status="REFUSED", refusal_scope="METHOD (every scenario refused)", scenario_status=status_by)
            else:
                order_ok = (sc["bear"]["stage_growth"] <= sc["base"]["stage_growth"] <= sc["bull"]["stage_growth"] and
                            sc["bear"]["terminal_growth"] <= sc["base"]["terminal_growth"] <= sc["bull"]["terminal_growth"] and
                            sc["bear"]["discount_rate"] >= sc["base"]["discount_rate"] >= sc["bull"]["discount_rate"])
                if not order_ok:
                    dcf["codes"].append(O.code("SCENARIO_ORDER_INCONSISTENT", "$.valuation.assumptions.dcf.scenarios"))
                if "base" in refused:                      # the grid is built around the base scenario: nothing to vary
                    sens = {"around": "base scenario", "state": "NOT_AVAILABLE_BASE_SCENARIO_REFUSED", "grid": [], "metrics": {}, "per_share_range": None,
                            "threshold": HIGH_SENSITIVITY_RELATIVE_SPREAD, "triggers": []}
                    dcf["codes"].append(O.code("SENSITIVITY_NOT_AVAILABLE", "", "the base scenario was refused; the sensitivity grid is built around it"))
                else:
                    # ---- sensitivity around the base scenario: every cell carries EV, equity and per share, each in its own unit
                    b = sc["base"]
                    grid = []
                    for dr in SENSITIVITY_GRID["discount_rate_offsets"]:
                        row = []
                        for dg in SENSITIVITY_GRID["terminal_growth_offsets"]:
                            s2 = {"stage_growth": b["stage_growth"], "terminal_growth": round(b["terminal_growth"] + dg, 10), "discount_rate": round(b["discount_rate"] + dr, 10)}
                            if _scenario_problems(s2):
                                row.append({"discount_rate": s2["discount_rate"], "terminal_growth": s2["terminal_growth"], "state": "OUT_OF_BOUNDS"})
                                continue
                            ev2 = _discount(fcf, s2["stage_growth"], s2["terminal_growth"], s2["discount_rate"], n)["enterprise_value"]
                            row.append({"discount_rate": s2["discount_rate"], "terminal_growth": s2["terminal_growth"], "state": "COMPUTED", "enterprise_value": ev2,
                                        **equity_bridge(ev2, debt, cash, shares)})
                        grid.append(row)
                    cells = [c for row in grid for c in row if c["state"] == "COMPUTED"]
                    base = out["base"]
                    evs = [c["enterprise_value"] for c in cells]
                    metrics = {"ev_relative_spread": {"value": _div(max(evs) - min(evs), base["enterprise_value"]), "unit": "enterprise value / enterprise value",
                                                      "formula": "(max EV - min EV) / base EV over the computed cells"}}
                    if base["equity_state"] == "POSITIVE":
                        eqs = [c["equity_value"] for c in cells]
                        metrics["equity_relative_spread"] = {"value": _div(max(eqs) - min(eqs), base["equity_value"]), "unit": "equity value / equity value",
                                                             "formula": "(max equity - min equity) / base equity over the computed cells"}
                    else:
                        metrics["equity_relative_spread"] = {"value": None, "state": "NOT_MEANINGFUL_BASE_EQUITY_NOT_POSITIVE" if base["equity_state"] != "UNAVAILABLE" else "UNAVAILABLE_NO_DEBT_OR_CASH"}
                    if base["equity_state"] == "UNAVAILABLE":
                        sign_changes = None
                    else:
                        sign_changes = sum(1 for c in cells if (c["equity_state"] == "POSITIVE") != (base["equity_state"] == "POSITIVE"))
                    metrics["equity_sign_change_cells"] = {"value": sign_changes, "unit": "count of computed cells"}
                    not_meaningful = [c for c in cells if c["value_per_share"]["state"] != "MEANINGFUL"]
                    if base["value_per_share"]["state"] == "MEANINGFUL" and not not_meaningful:
                        pss = [c["value_per_share"]["value"] for c in cells]
                        metrics["per_share_relative_spread"] = {"value": _div(max(pss) - min(pss), base["value_per_share"]["value"]), "unit": "per share / per share",
                                                                "formula": "(max - min) / base per-share value; every computed cell meaningful"}
                        ps_range = {"min": min(pss), "max": max(pss)}
                    else:
                        metrics["per_share_relative_spread"] = {"value": None, "state": "NOT_MEANINGFUL", "reason":
                                                                f"base per-share state {base['value_per_share']['state']}; {len(not_meaningful)} of {len(cells)} computed cells without a meaningful per-share value"}
                        ps_range = None
                    T_ = HIGH_SENSITIVITY_RELATIVE_SPREAD
                    triggers = [k for k in ("ev_relative_spread", "equity_relative_spread") if metrics[k]["value"] is not None and metrics[k]["value"] > T_]
                    if sign_changes:
                        triggers.append("equity_sign_change_cells")
                        dcf["codes"].append(O.code("EQUITY_SIGN_CHANGES_ACROSS_GRID", "", f"{sign_changes} of {len(cells)} computed cells differ in equity sign from the base"))
                    if triggers:
                        dcf["codes"].append(O.code("HIGH_ASSUMPTION_SENSITIVITY", "", "; ".join(f"{k} = {metrics[k]['value']:.4g}" for k in triggers) + f" (threshold {T_} for the spreads; any sign change)"))
                    if ps_range is None:
                        dcf["codes"].append(O.code("SENSITIVITY_RANGE_NOT_SHOWN", "", metrics["per_share_relative_spread"]["reason"]))
                    sens = {"around": "base scenario", "grid": grid, "metrics": metrics, "per_share_range": ps_range, "threshold": T_, "triggers": triggers,
                            "rule": "HIGH_ASSUMPTION_SENSITIVITY when ev_relative_spread > threshold, or equity_relative_spread > threshold, or any equity sign change across the grid"}
                tv = {}                                    # Track D: terminal-value dominance per computed scenario
                for k in ("bear", "base", "bull"):
                    if k in refused:
                        tv[k] = {"terminal_share": None, "dominant": None, "state": "SCENARIO_REFUSED"}
                    else:
                        sh_ = out[k]["terminal_share"]
                        tv[k] = {"terminal_share": sh_, "dominant": sh_ is not None and sh_ > TERMINAL_VALUE_DOMINANT_SHARE}
                dominant = [k for k in tv if tv[k]["dominant"]]
                if dominant:
                    dcf["codes"].append(O.code("TERMINAL_VALUE_DOMINANT", "", "; ".join(f"{k}: terminal value is {tv[k]['terminal_share']:.3f} of the enterprise value" for k in dominant)
                                               + f" (threshold {TERMINAL_VALUE_DOMINANT_SHARE})"))
                if refused:
                    disagreement = {"value": None, "state": "NOT_AVAILABLE_SCENARIO_REFUSED", "refused": refused}
                else:
                    disagreement = {"value": _div(out["bull"]["enterprise_value"] - out["bear"]["enterprise_value"], abs(out["base"]["enterprise_value"])),
                                    "unit": "enterprise value / enterprise value"}
                dcf.update(status="COMPUTED", refusal_scope="SCENARIO" if refused else None, scenario_status=status_by, scenarios=out, sensitivity=sens,
                           terminal_value_by_scenario={"threshold": TERMINAL_VALUE_DOMINANT_SHARE, "scenarios": tv, "dominant_in": dominant},
                           scenario_disagreement=disagreement,
                           values_per_share={k: (out[k]["value_per_share"] if k not in refused else {"state": "SCENARIO_REFUSED", "value": None}) for k in ("bear", "base", "bull")})
    methods.append(dcf)

    # ---- Track D: per-method diagnostics, inapplicability disclosure and stability warnings (interpretation only: no value changes)
    src = {"price": mkt.get("price"), "shares_outstanding": mkt.get("shares_outstanding"), **{n: fin.get(n) for n in (
        "net_income", "stockholders_equity", "operating_income", "depreciation_amort", "revenue", "operating_cash_flow", "capex", "long_term_debt",
        "short_term_debt", "cash_and_equivalents")}}
    EV_IN = ["price", "shares_outstanding", "long_term_debt", "short_term_debt", "cash_and_equivalents"]
    REQUIRED = {"TRAILING_PE": ["price", "shares_outstanding", "net_income"], "PRICE_TO_BOOK": ["price", "shares_outstanding", "stockholders_equity"],
                "EV_EBITDA": EV_IN + ["operating_income", "depreciation_amort"], "EV_SALES": EV_IN + ["revenue"],
                "FCF_YIELD": ["price", "shares_outstanding", "operating_cash_flow", "capex"],
                "FORWARD_PE": ["analyst forecast of earnings (no qualified source)"], "PEG": ["analyst forecast of earnings growth (no qualified source)"],
                "DCF_FCF": ["operating_cash_flow", "capex", "assumptions.dcf (horizon, bear / base / bull)", "long_term_debt", "short_term_debt", "cash_and_equivalents",
                            "shares_outstanding"]}
    LIMITS = {"TRAILING_PE": ["one trailing fiscal year of earnings; non-recurring items are not removed"],
              "PRICE_TO_BOOK": ["book value is historical cost and may differ from economic value"],
              "EV_EBITDA": ["enterprise value combines a price at as_of with debt and cash at the fiscal year end"],
              "EV_SALES": ["enterprise value combines a price at as_of with debt and cash at the fiscal year end; sales ignore profitability"],
              "FCF_YIELD": ["free cash flow is operating cash flow minus capex for one year"],
              "FORWARD_PE": ["no qualified analyst-forecast source (ERC1; PROVIDER_DECISION_PENDING)"], "PEG": ["no qualified analyst-forecast source (ERC1; PROVIDER_DECISION_PENDING)"],
              "DCF_FCF": ["the value depends on user-declared assumptions; the terminal value can dominate", "operating cash flow minus capex proxies unlevered free cash flow"]}
    for x in methods:
        name = x["method"]
        req = REQUIRED.get(name, [])
        x["required_fields"] = req
        x["invalid_fields"] = [f for f in req if f in invalid]                  # Q11.1 (review VA-1): given but invalid (negative), not missing
        x["missing_fields"] = ([f for f in req if f in src and src[f] is None] + ([f for f in req if f.startswith("analyst")]) +
                               (["assumptions.dcf"] if name == "DCF_FCF" and asm.get("dcf") is None else []))
        if name == "DCF_FCF":
            x.setdefault("assumptions", asm.get("dcf") or "none declared")
        else:
            key = {"TRAILING_PE": "pe", "PRICE_TO_BOOK": "pb", "EV_EBITDA": "ev_ebitda", "EV_SALES": "ev_sales"}.get(name)
            x.setdefault("assumptions", {"declared_reference_multiple_range": (refm.get(key) if key else None) or "none declared",
                                         "period": f"FY{fin.get('fiscal_year')} annual figures (the latest annual report; not a sum of recent quarters)"
                                                   + ("; more than a year older than the price" if stale else ""),
                                         "price": f"close of {mkt['price_date']} (on or before as_of)"})
        x["limitations"] = LIMITS.get(name, [])
        if not x.get("trace") and not (name == "DCF_FCF" and x.get("formula") and x.get("scenarios")):
            x["trace"] = [f"not calculated ({x['status']}): " + ("; ".join(c["code"] for c in x["codes"]) or "no reason recorded")]
        if x["status"] == "NOT_APPLICABLE":
            x["inapplicability"] = {"state": "NOT_APPLICABLE", "rule": x.get("applicability_rule"),
                                    "consequence": "no value is computed for this method; its absence is not evidence about the company either way"}
        if not x.get("sensitivity") and not ((x.get("implied_value_per_share") or {}).get("low") is not None):
            x["sensitivity"] = {"state": "NOT_ASSESSED", "reason": ("the method is " + x["status"]) if x["status"] != "COMPUTED"
                                else "no declared reference range: no implied value range to vary"}
    stab_codes = {"HIGH_ASSUMPTION_SENSITIVITY": "the value moves by more than the declared threshold across the sensitivity grid",
                  "EQUITY_SIGN_CHANGES_ACROSS_GRID": "the equity value changes sign inside the grid",
                  "TERMINAL_VALUE_DOMINANT": "most of the value comes from the terminal value",
                  "SCENARIO_REFUSED": "a scenario is outside the declared bounds and is not valued",
                  "SENSITIVITY_NOT_AVAILABLE": "the base scenario could not be valued, so its sensitivity is unknown",
                  "SCENARIO_ORDER_INCONSISTENT": "the bear / base / bull assumptions are not ordered",
                  "OBLIGATIONS_EXCEED_MODELED_EV": "net obligations exceed the modelled enterprise value"}
    warn = [{"code": c["code"], "explanation": stab_codes[c["code"]], "detail": c.get("detail", "")} for c in dcf.get("codes") or [] if c["code"] in stab_codes]
    unstable = any(w["code"] in ("HIGH_ASSUMPTION_SENSITIVITY", "EQUITY_SIGN_CHANGES_ACROSS_GRID", "TERMINAL_VALUE_DOMINANT", "SENSITIVITY_NOT_AVAILABLE") for w in warn)
    dcf["stability"] = {"state": ("UNSTABLE" if unstable else "NO_INSTABILITY_SIGNAL") if dcf["status"] == "COMPUTED" else "NOT_ASSESSED", "warnings": warn,
                        "note": "a stability signal concerns the declared assumptions, not the company; NO_INSTABILITY_SIGNAL is not a claim that the value is right"}

    # ---- assemble
    computed = [x for x in methods if x["status"] == "COMPUTED"]
    unavailable = [{"method": x["method"], "status": x["status"], "reasons": [c["code"] for c in x["codes"]]} for x in methods if x["status"] != "COMPUTED"]
    ranges = []
    for x in computed:
        iv = x.get("implied_value_per_share")
        if iv and isinstance(iv.get("low"), (int, float)) and isinstance(iv.get("high"), (int, float)):
            ranges.append({"method": x["method"], "low": iv["low"], "high": iv["high"], "unit": f"{cur} per share", "basis": iv["basis"], "not_a_fair_price": True})
    if dcf["status"] == "COMPUTED":
        vps = dcf["values_per_share"]
        if all(vps[k]["state"] == "MEANINGFUL" for k in vps):
            vals = [vps[k]["value"] for k in vps]
            ranges.append({"method": "DCF_FCF scenarios", "low": min(vals), "high": max(vals), "unit": f"{cur} per share",
                           "basis": "bear..bull scenario values under the declared assumptions", "not_a_fair_price": True})
        else:
            dcf["codes"].append(O.code("SCENARIO_RANGE_NOT_SHOWN", "", ", ".join(f"{k} {vps[k]['state']}" for k in vps)))
        pr = dcf["sensitivity"]["per_share_range"]
        if pr:
            ranges.append({"method": "DCF_FCF sensitivity (base)", "low": pr["min"], "high": pr["max"], "unit": f"{cur} per share",
                           "basis": "base scenario with discount rate and terminal growth varied over the declared grid", "not_a_fair_price": True})
    limitations = [
        "inputs as given in the case (see data_source); a modelled value is not evidence of future realised market returns and is not a buy or sell instruction",
        "methods are shown separately and never averaged; no single fair price is produced",
        "DCF uses operating cash flow minus capex as a proxy for unlevered free cash flow; interest effects are not adjusted",
        "forward P/E and PEG are unavailable: no qualified analyst-forecast source (ERC1; PROVIDER_DECISION_PENDING)",
        "reference multiple ranges and DCF assumptions are user-declared, not market consensus",
    ]
    all_codes = codes + [c for x in methods for c in x["codes"]]
    flags = {c["code"] for c in all_codes}
    env["warnings"] = warnings
    env["missing_dependencies"] = sorted({c["code"] for c in all_codes if c["code"] in ("SHARE_COUNT_MISSING", "DEBT_OR_CASH_MISSING", "INPUT_UNAVAILABLE", "FORWARD_METHOD_UNAVAILABLE")})
    env["evidence"] = [{"fact": f"{x['method']} observed = {x['observed_multiple']:.6g}", "method": x["method"], "inputs": x["inputs"]} for x in computed if x["method"] != "DCF_FCF"] + \
                      ([{"fact": "DCF_FCF under declared assumptions: " + "; ".join(
                          f"{k}: REFUSED ({', '.join(dcf['scenarios'][k]['reasons'])})" if dcf['scenarios'][k].get('state') == 'REFUSED' else
                          f"{k}: EV {dcf['scenarios'][k]['enterprise_value']:,.0f}, equity " +
                          (f"{dcf['scenarios'][k]['equity_value']:,.0f} ({dcf['scenarios'][k]['equity_state']})" if dcf['scenarios'][k]['equity_value'] is not None else "unavailable") +
                          ", per share " + (format(dcf['scenarios'][k]['value_per_share']['value'], '.6g') if dcf['scenarios'][k]['value_per_share']['value'] is not None
                                            else dcf['scenarios'][k]['value_per_share']['state']) for k in ("bear", "base", "bull")),
                         "method": "DCF_FCF", "inputs": {"base_fcf": fcf, "total_debt": debt, "cash": cash, "shares": shares}}] if dcf["status"] == "COMPUTED" else [])
    env["counter_evidence"] = [{"fact": c["meaning"], "code": c["code"], "detail": c["detail"]} for c in all_codes
                               if c["code"] in ("HIGH_ASSUMPTION_SENSITIVITY", "TERMINAL_VALUE_DOMINANT", "NEGATIVE_EARNINGS", "NEGATIVE_BASE_FCF", "NEGATIVE_BOOK_VALUE", "NEGATIVE_EBITDA",
                                                "SCENARIO_ORDER_INCONSISTENT", "OBLIGATIONS_EXCEED_MODELED_EV", "OBLIGATIONS_EQUAL_MODELED_EV", "EQUITY_SIGN_CHANGES_ACROSS_GRID")] + \
                              [{"fact": f"{x['method']} has limited relevance for {industry}: {x['applicability_rule']}", "code": "LIMITED_RELEVANCE"} for x in methods if x["applicability"] == "LIMITED_RELEVANCE"]
    env["findings"] = {
        "applicable_methods": [x["method"] for x in computed],
        "unavailable_methods": unavailable,
        "methods": methods,
        "valuation_scenarios": dcf.get("scenarios"),
        "assumptions": {"reference_multiples": refm or None, "dcf": spec, "bounds": DCF_BOUNDS, "sensitivity_grid": SENSITIVITY_GRID,
                        "source": "declared in the case input by the user (none declared means none used); no analyst consensus, no forecast input"},
        "sensitivity": dcf.get("sensitivity"),
        "estimated_value_ranges": ranges,
        "calculation_trace": trace,
        "uncertainty": {"formula_result": "per method, see methods[].observed_multiple / implied_value_per_share and DCF scenarios",
                        "input_data_reliability": "input of the kind stated in data_source; financials available at as_of; price dated on or before as_of; unit plausibility " + ("checked" if plaus else "not checked"),
                        "assumption_sensitivity": dcf["sensitivity"]["metrics"] if dcf["status"] == "COMPUTED" else None,
                        "model_applicability": {x["method"]: x["applicability"] for x in methods},
                        "scenario_disagreement": dcf.get("scenario_disagreement"),
                        "missing_information": env["missing_dependencies"]},
        "limitations": limitations,
        "evidence": env["evidence"],
        "inapplicable_methods": [{"method": x["method"], **x["inapplicability"]} for x in methods if x.get("inapplicability")],
        "stability_warnings": dcf["stability"],
    }
    env["calculation_or_extraction_trace"] = trace + [{"method": x["method"], "trace": x.get("trace", [])} for x in methods]
    env["result_codes"] = all_codes + warnings
    env["execution_status"] = "COMPLETED" if computed else "COMPLETED_NO_RESULT"
    if not computed:
        env["result_codes"].append(O.code("NO_APPLICABLE_METHOD", "$.valuation"))
    core = [price, shares, v["net_income"], v["stockholders_equity"], ebitda, fcf, debt, cash]
    env["data_status"] = {"inputs_present": sum(x is not None for x in core), "inputs_expected": len(core), "currency": cur, "units": f"{fin['scale']} amounts, {mkt['shares_scale']} shares"}
    env["questions"] = {"calculation_succeeded": bool(computed),
                        "data_adequate": "ADEQUATE" if all(x is not None for x in core) else "PARTIAL" if computed else "INADEQUATE",
                        "evidence_sufficient": "SUFFICIENT_FOR_SCENARIO_ARITHMETIC" if computed else "INSUFFICIENT",
                        "financial_interpretation_supported": "SCENARIO_ONLY: modelled values under declared assumptions; no market-value claim",
                        "predictive_validity_demonstrated": False}
    env["confidence_basis"] = ("no probability: " + f"{len(computed)} of {len(methods)} methods computed; " +
                               ("high assumption sensitivity; " if "HIGH_ASSUMPTION_SENSITIVITY" in flags else "") +
                               ("terminal value dominant; " if "TERMINAL_VALUE_DOMINANT" in flags else "") + "assumptions user-declared")
    return env
