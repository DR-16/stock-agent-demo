"""Q8 successor of the Q7 synthesis layer (q8-synthesis 2.1.0 after the Q8 review; Q7: q7-synthesis 1.2.0): evidence synthesis only, from the run record of ONE run.

What changed in Q8 (work package 3):
  * four separate categories instead of one 'agreements / conflicts' pair:
      C1 INPUT_NUMBERS_CONSISTENT          the same number as two experts used it (X1), the same price on the same day (X2)
      C2 EXPERT_OBSERVATIONS_CONSISTENT    two experts' own observations agree (X5: Fundamental's loss status vs Valuation's trailing P/E)
      D1 CROSS_EXPERT_CONTRADICTION        two experts' inputs or observations disagree (X1 / X2 / X5)
      D2 DIFFERENT_DIMENSION_OR_HORIZON    different dimension or date (X3, X2 on different dates) - not a contradiction
      S  SAME_EXPERT_SOURCE_CONFLICT       documents cited by ONE expert disagree (X4, Information) - never called a cross-expert contradiction
  * Fundamental's risk_checks are shown as check RESULTS; the thresholds are the case's declared assumptions (from the Q8 input model)
  * nothing is cut at a fixed number of characters: every text is kept whole (the page and the HTML fold long content)
  * a headline (the important findings, conflicts and limitations - only those present, never padded), the key gaps by name, a valuation view
    (assumptions, sensitivity, ranges, unavailable methods) and an identity view (per item: registry / user-declared / missing / conflict / legacy)
  * every observation names its expert run, output field and evidence; document spans carry the document id so the page can show the source text
Rules kept from Q7: only COMPLETED experts give observations / agreements / conflicts; others appear with their reasons, never as zero or neutral;
numbers are printed with 12 significant digits; no score, probability, target price, rating, position or expert weight is produced.
"""
from __future__ import annotations

import copy
from datetime import date
import math

SYNTHESIS_VERSION = "q10-synthesis 2.4.1"     # Q10: the Fundamental deterioration indicators are shown (none stays internal); was q9-synthesis 2.3.0     # Q9: real-data label, "executed but no valid finding", compared / not-compared rules per category; 2.3.0 after the Q9 review
RULES = {"X1": "SAME_FACT_CROSS_SECTION (Fundamental vs Valuation; same declared currency only)",
         "X2": "PRICE_INPUT_CONSISTENCY (Valuation price vs the price input of Technical; units first, then dates; currency from Q7's declaration)",
         "X3": "PRICE_VS_REPORTED_TREND (Technical vs Fundamental; different dimension / horizon)",
         "X4": "SOURCE_CONFLICTS_INSIDE_INFORMATION (documents cited by Information disagree; as reported, unverified)",
         "X5": "LOSS_STATUS (Fundamental's loss_making vs whether Valuation's trailing P/E is meaningful; same fiscal year only)"}
RULE_EXPERTS = {"X1": ("fundamental", "valuation"), "X2": ("valuation", "technical"), "X3": ("technical", "fundamental"), "X4": ("information",), "X5": ("fundamental", "valuation")}
CATEGORIES = {"INPUT_NUMBERS_CONSISTENT": "输入数字一致（两个专家用的是同一个数字；这只说明案例两部分输入一致，不是独立印证）",
              "EXPERT_OBSERVATIONS_CONSISTENT": "不同专家的观察一致（各自得出的判断相同；输入仍来自同一个案例）",
              "CROSS_EXPERT_CONTRADICTION": "不同专家之间的矛盾（同一事实在两个专家那里不同）",
              "DIFFERENT_DIMENSION_OR_HORIZON": "维度或时间尺度不同（方向不同，但不是矛盾）",
              "SAME_EXPERT_SOURCE_CONFLICT": "同一专家引用的文件互相冲突（不是跨专家矛盾）"}
KINDS = {"X1": ("INPUT_NUMBERS_CONSISTENT", "CROSS_EXPERT_CONTRADICTION"), "X2": ("INPUT_NUMBERS_CONSISTENT", "CROSS_EXPERT_CONTRADICTION", "DIFFERENT_DIMENSION_OR_HORIZON"),
         "X3": ("DIFFERENT_DIMENSION_OR_HORIZON",), "X4": ("SAME_EXPERT_SOURCE_CONFLICT",), "X5": ("EXPERT_OBSERVATIONS_CONSISTENT", "CROSS_EXPERT_CONTRADICTION")}
SECTION_OF = {"INPUT_NUMBERS_CONSISTENT": "C1_input_numbers_consistent", "EXPERT_OBSERVATIONS_CONSISTENT": "C2_observations_consistent",
              "CROSS_EXPERT_CONTRADICTION": "D1_cross_expert_contradictions", "DIFFERENT_DIMENSION_OR_HORIZON": "D2_different_dimension_or_horizon",
              "SAME_EXPERT_SOURCE_CONFLICT": "S_same_expert_source_conflicts"}
NOT_INCLUDED = ["综合评分或 Meta 评分", "买卖评分或信号", "概率", "目标价", "评级", "仓位或交易", "任何专家的权重", "输出和输入里都没有的数字"]
ZH_STATUS = {"COMPLETED": "已执行完成", "ABSTAINED": "已执行但弃权", "REJECTED": "输入被拒绝", "NOT_APPLICABLE": "不适用", "FAILED": "失败", "NOT_EXECUTED": "未执行"}
FIELD_IS_EVIDENCE = "OUTPUT_FIELD_IS_THE_EVIDENCE"
ID_SUFFIX = {"MATCH_USER_DECLARED": "（该文件身份：用户声明，未核实）", "LEGACY_UNVERIFIED": "（该文件身份：旧格式／身份未核实）",
             "MODIFIED_FROM_REGISTRY": "（该文件内容与登记来源不同：按用户修改处理，未核实）"}


def _f(x) -> str:
    if isinstance(x, bool) or x is None:
        return str(x)
    if isinstance(x, float):
        return f"{x:.12g}"
    return str(x)


def _pct(x) -> str:
    return f"{x * 100:.10g}%" if isinstance(x, (int, float)) and not isinstance(x, bool) else str(x)


class _Obs:
    def __init__(self, rec: dict, eid: str):
        self.eid, self.run_id, self.items = eid, rec["run_id"], []

    def add(self, field: str, parts: list, value, paths: list | None = None, kind: str = "EXPERT_EVIDENCE_ITEMS", prefix: str = "", suffix: str = "",
            doc: dict | None = None) -> str:
        """parts: [(key path in value, label, separator, value text)]; the statement is exactly prefix + '；'.join(part texts) + suffix"""
        oid = f"OBS-{self.eid}-{len(self.items) + 1:03d}"
        ps = [{"key": k, "label": lb, "sep": sp, "text": f"{lb}{sp}{vt}"} for k, lb, sp, vt in parts]
        statement = prefix + "；".join(p_["text"] for p_ in ps) + suffix
        ref = {"kind": kind, "paths": paths} if paths else {"kind": FIELD_IS_EVIDENCE, "paths": [field],
                                                           "note": "这个观察本身就是专家输出的描述性字段，没有单独的证据条目"}
        if doc:
            ref["document"] = doc
        self.items.append({"obs_id": oid, "expert_id": self.eid, "run_id": f"{self.run_id}:{self.eid}", "field": field, "statement": statement,
                           "prefix": prefix, "suffix": suffix, "value": value, "parts": ps, "evidence_ref": ref})
        return oid


def _technical_like(o: _Obs, out: dict, kind: str) -> dict:
    for side in ("evidence", "counter_evidence"):
        for n, e in enumerate(out.get(side) or []):
            v = {k: e.get(k) for k in ("metric", "value", "interpretation", "comment")}
            o.add(f"$.{side}[{n}]", [("metric", "指标", " ", str(v["metric"])), ("value", "数值", " ", _f(v["value"])), ("comment", "说明", "：", str(v["comment"])),
                                     ("interpretation", "生产模型自身解读", "：", str(v["interpretation"]))], v, [f"$.{side}[{n}]"], "PRODUCTION_EVIDENCE_ITEM",
                  suffix="（positive / negative 是生产模型对这个指标的规则读法，不是买卖信号）")
    md = out.get("metadata") or {}
    key = "metrics" if kind == "technical" else "features"
    if md.get(key):
        o.add(f"$.metadata.{key}", [(k, k, "=", _f(v)) for k, v in md[key].items()], dict(md[key]),
              prefix=("技术指标" if kind == "technical" else "宏观代理特征") + "（描述性数值）：")
    if kind == "macro" and md.get("regime_hint"):
        o.add("$.metadata.regime_hint", [("", "生产 Macro 给出的市场环境提示", "：", str(md["regime_hint"]))], md["regime_hint"], suffix="（市场层面，不针对这家公司）")
    if out.get("data_freshness_days") is not None:
        o.add("$.data_freshness_days", [("", "输入数据最旧一项距 as_of 的天数", " ", _f(out["data_freshness_days"]))], out["data_freshness_days"])
    return {"assumptions": [{"field": "$.horizon_days", "statement": f"生产模型的固定观察期 horizon_days = {out.get('horizon_days')}（只是模型参数，不是预测）"}]
            + ([{"field": "$.metadata.price_bars_used", "statement": f"使用价格条数 {md.get('price_bars_used')}"}] if md.get("price_bars_used") is not None else []),
            "scope": ("价格行为（技术面）" if kind == "technical" else "市场层面的宏观代理（与具体公司无关）") + "；positive / negative 是生产模型的规则读法，不是买卖信号"}


def _ev_paths(out: dict, metrics: tuple) -> list:
    return [f"$.{side}[{n}]" for side in ("evidence", "counter_evidence") for n, e in enumerate(out.get(side) or []) if isinstance(e, dict) and e.get("metric") in metrics]


def _fundamental(o: _Obs, out: dict, model: dict | None) -> dict:
    F = out["findings"]
    g = F["financial_growth"]
    v = {"classification": g["classification"], "latest_growth": g.get("latest_growth"), "rule": g.get("rule")}
    o.add("$.findings.financial_growth", [("classification", "收入增长分类", " ", str(v["classification"])), ("latest_growth", "最近一年增长", " ", _f(v["latest_growth"])),
                                          ("rule", "规则", "：", str(v["rule"]))], v, _ev_paths(out, ("revenue_growth",)))
    p = F["financial_profitability"]
    v = {k: {"classification": p[k]["classification"]} for k in ("gross_margin", "operating_margin", "net_margin")} | {"loss_making": p["loss_making"]}
    o.add("$.findings.financial_profitability", [("gross_margin.classification", "毛利率", " ", str(v["gross_margin"]["classification"])),
                                                 ("operating_margin.classification", "营业利润率", " ", str(v["operating_margin"]["classification"])),
                                                 ("net_margin.classification", "净利率", " ", str(v["net_margin"]["classification"])),
                                                 ("loss_making", "是否亏损 loss_making", " = ", str(v["loss_making"]))],
          v, _ev_paths(out, ("gross_margin", "operating_margin", "net_margin")))
    c = F["cash_flow_quality"]
    v = {k: c.get(k) for k in ("classification", "operating_cash_flow", "net_income", "free_cash_flow")}
    o.add("$.findings.cash_flow_quality", [("classification", "现金流质量分类", " ", str(v["classification"])), ("operating_cash_flow", "经营现金流", " ", _f(v["operating_cash_flow"])),
                                           ("net_income", "净利润", " ", _f(v["net_income"])), ("free_cash_flow", "自由现金流", " ", _f(v["free_cash_flow"]))],
          v, _ev_paths(out, ("cash_conversion", "accruals_ratio", "operating_cash_flow", "free_cash_flow")))
    b = F["balance_sheet_health"]
    v = {"leverage_trend": b.get("leverage_trend"), "liquidity_fact": b.get("liquidity_fact")}
    o.add("$.findings.balance_sheet_health", [("leverage_trend", "杠杆趋势", " ", str(v["leverage_trend"])), ("liquidity_fact", "流动性事实", " ", str(v["liquidity_fact"]))], v,
          _ev_paths(out, ("debt_to_equity", "current_ratio", "cash_ratio")))
    uua = b.get("under_user_assumptions") if isinstance(b.get("under_user_assumptions"), dict) else {}
    uua_gaps = []
    if uua:
        parts, lab = [], {"value": ("数值", " "), "assumption": ("案例声明的阈值", " "), "source": ("来源", " "), "why": ("没有评估的原因", "：")}
        for k, x in uua.items():
            if not isinstance(x, dict):
                continue
            for kk, vv in x.items():          # one part per value: the check result first, then its numbers / reason
                lb, sp = (f"{k} 检查结果", "：") if kk == "assessment" else lab.get(kk, (kk, " "))
                parts.append((f"{k}.{kk}", lb, sp, _f(vv) if isinstance(vv, (int, float)) and not isinstance(vv, bool) else str(vv)))
            if x.get("assessment") == "NOT_ASSESSED":
                uua_gaps.append({"code": "THRESHOLD_CHECK_NOT_ASSESSED", "field": f"$.findings.balance_sheet_health.under_user_assumptions.{k}", "detail": f"{k}：没有评估（{x.get('why')}）"})
        o.add("$.findings.balance_sheet_health.under_user_assumptions", parts, {k: dict(x) for k, x in uua.items() if isinstance(x, dict)},
              prefix="按案例声明阈值的检查结果（WITHIN_USER_ASSUMPTION = 在阈值内，OUTSIDE_USER_ASSUMPTION = 超出，NOT_ASSESSED = 没有评估）：")
    rc = F.get("risk_checks")
    if isinstance(rc, dict) and rc:
        legend = {"TRUE": "TRUE = 触发", "FALSE": "FALSE = 未触发", "UNKNOWN": "UNKNOWN = 缺输入、无法判断（不能当作没有风险）",
                  "INDETERMINATE": "INDETERMINATE = 缺输入、无法判断（不能当作没有风险）", "NOT_APPLICABLE": "NOT_APPLICABLE = 按行业规则不适用"}
        present = sorted({str(x) for x in rc.values()}, key=lambda z: list(legend).index(z) if z in legend else 99)
        o.add("$.findings.risk_checks", [(k, k, "=", str(x)) for k, x in rc.items()], dict(rc),
              prefix="风险检查结果（定义性检查，不使用案例声明的阈值；" + "，".join(legend.get(z, f"{z} = 专家给出的状态") for z in present) + "）：")
    det = F.get("deterioration_indicators")
    if isinstance(det, dict):                        # Q10: the internal deterioration indicators reach the report (GGG: current_ratio_down = TRUE was not shown)
        items = [(k, str(x)) for k, x in det.items() if k != "states"]
        o.add("$.findings.deterioration_indicators", [(k, k, "=", x) for k, x in items], {k: x for k, x in items},
              prefix="内部恶化指标（任何下降都算 TRUE，包括稳定带内的小幅下降；FALSE = 没有下降；UNKNOWN = 缺输入或缺上一年，无法判断，不能当作没有恶化）：")
    risks = F.get("financial_risks") or []
    if not risks:
        o.add("$.findings.financial_risks", [], [], prefix="财务风险标记：无（这不等于没有风险，只是声明的检查没有触发）")
    for n, r in enumerate(risks):
        v = {"flag": r.get("flag"), "evidence": r.get("evidence")}
        o.add(f"$.findings.financial_risks[{n}]", [("flag", "财务风险标记", " ", str(v["flag"])), ("evidence", "依据", "：", str(v["evidence"]))], v,
              [f"$.findings.financial_risks[{n}].evidence"], "EXPERT_STATED_BASIS")
    ev = [{"field": f"$.evidence[{n}]", "fact": e.get("fact"), "source_document_id": e.get("source_document_id"), "available_at": e.get("available_at")}
          for n, e in enumerate(out.get("evidence") or [])]
    gaps = [{"code": "INDETERMINATE_RISK_CHECK", "field": "$.findings.indeterminate_risk_checks", "detail": f"{x.get('check')}：无法判断（缺输入），不能当作没有风险"}
            for x in F.get("indeterminate_risk_checks") or []]
    gaps += [{"code": "MISSING_INFORMATION", "field": "$.findings.missing_information", "detail": str(x)} for x in F.get("missing_information") or []]
    gaps += uua_gaps
    thr = ((model or {}).get("fundamental") or {}).get("assumptions") if isinstance((model or {}).get("fundamental"), dict) else None
    nums = {k: x for k, x in (thr or {}).items() if isinstance(x, (int, float)) and not isinstance(x, bool)} if isinstance(thr, dict) else {}
    assumptions = ([{"field": "input: fundamental.assumptions", "statement": "资产负债阈值检查（$.findings.balance_sheet_health.under_user_assumptions）使用的阈值（案例声明，未经验证）：" +
                     "；".join(f"{k} = {_f(x)}" for k, x in nums.items())}] if nums else
                   [{"field": "input: fundamental.assumptions", "statement": "案例没有声明阈值：三项阈值检查都没有评估（NOT_ASSESSED）；专家没有内置的默认阈值"
                     if model is not None else "旧路径：输入里的阈值不在运行记录中"}])
    assumptions.append({"field": "$.findings.risk_checks", "statement": "风险检查（risk_checks）是专家的定义性检查（例如是否亏损、经营现金流是否为负），不使用案例声明的阈值"})
    return {"evidence": ev, "gaps": gaps, "scope": "已公布财期的描述性财务状况（不预测）", "assumptions": assumptions,
            "quality_extra": {"confidence_explanation": str(F.get("confidence_explanation"))}}


def _valuation(o: _Obs, out: dict, basis: str = "") -> dict:
    F = out["findings"]
    evi = {e.get("method"): n for n, e in enumerate(out.get("evidence") or []) if isinstance(e, dict)}
    methods = F.get("methods") or []
    am = list(F.get("applicable_methods") or [])
    o.add("$.findings.applicable_methods", [(str(n), "方法", " ", str(m)) for n, m in enumerate(am)], am, prefix="可计算的方法：" if am else "可计算的方法：无")
    for n, m in enumerate(methods):
        if m.get("status") == "COMPUTED" and m.get("observed_multiple") is not None:
            yld = "YIELD" in str(m.get("method"))
            o.add(f"$.findings.methods[{n}].observed_multiple", [("", f"{m['method']} 观察到的{'收益率' if yld else '倍数'}", " = ", _f(m["observed_multiple"]))], m["observed_multiple"],
                  [f"$.findings.methods[{n}].inputs"] + ([f"$.evidence[{evi[m['method']]}]"] if m["method"] in evi else []), "VALUATION_METHOD_INPUTS",
                  suffix=(f"（即 {_pct(m['observed_multiple'])}；由案例输入算出的描述值）" if yld else "（由案例输入算出的描述值）") + basis)
    for n, r in enumerate(F.get("estimated_value_ranges") or []):
        v = {k: r.get(k) for k in ("method", "low", "high", "unit", "basis")}
        base = str(r.get("method", "")).split(" ")[0]
        mi = next((k for k, m in enumerate(methods) if m.get("method") == base), None)
        o.add(f"$.findings.estimated_value_ranges[{n}]", [("method", "情景区间方法", " ", str(v["method"])), ("low", "下限", " ", _f(v["low"])), ("high", "上限", " ", _f(v["high"])),
                                                          ("unit", "单位", " ", str(v["unit"])), ("basis", "依据", "：", str(v["basis"]))], v,
              ([f"$.findings.methods[{mi}]"] if mi is not None else []) + ([f"$.evidence[{evi[base]}]"] if base in evi else []), "VALUATION_METHOD_INPUTS",
              suffix="；完全取决于声明的假设，不是目标价，也不是公允价格")
    st = F.get("stability_warnings") or {}
    if st.get("state"):
        o.add("$.findings.stability_warnings", [("state", "对假设的敏感性", "：", str(st["state"]))], {"state": st["state"]}, suffix="（这只针对声明的假设，不是对公司的判断）")
    ev = [{"field": f"$.evidence[{n}]", "fact": e.get("fact"), "method": e.get("method")} for n, e in enumerate(out.get("evidence") or [])]
    gaps = [{"code": "METHOD_UNAVAILABLE", "field": "$.findings.unavailable_methods", "detail": f"{u['method']}：{', '.join(u.get('reasons') or [])}"} for u in F.get("unavailable_methods") or []]
    gaps += [{"code": "METHOD_NOT_APPLICABLE", "field": "$.findings.inapplicable_methods", "detail": f"{u['method']}：{u.get('rule')}"} for u in F.get("inapplicable_methods") or []]
    for n, m in enumerate(methods):                    # every per-method code: why a range is missing, which scenario was refused, caveats
        for c in m.get("codes") or []:
            if isinstance(c, dict):
                gaps.append({"code": c.get("code"), "field": f"$.findings.methods[{n}].codes", "detail": f"{m.get('method')}：{c.get('meaning') or ''}"
                             + (f"（{c['path']}）" if c.get("path") else "") + (f"：{c['detail']}" if c.get("detail") not in (None, "") else "")})
    gaps += [{"code": w.get("code"), "field": "$.findings.stability_warnings", "detail": "：".join(x for x in (str(w.get("explanation") or ""), str(w.get("detail") or "")) if x)}
             for w in st.get("warnings") or []]
    if not F.get("estimated_value_ranges"):
        gaps.append({"code": "NO_VALUE_RANGE", "field": "$.findings.estimated_value_ranges", "detail": "没有任何情景估值区间（原因见各方法的代码）"})
    A = F.get("assumptions") or {}
    assumptions = [{"field": "$.findings.assumptions.reference_multiples", "statement": f"参考倍数区间（案例声明）：{A['reference_multiples']}" if A.get("reference_multiples")
                    else "案例没有声明参考倍数（因此没有倍数区间）"},
                   {"field": "$.findings.assumptions.dcf", "statement": f"DCF 情景假设（案例声明）：{A['dcf']}" if A.get("dcf") else "案例没有声明 DCF 情景假设"},
                   {"field": "$.findings.assumptions.bounds", "statement": f"假设的允许范围（专家内置，非案例声明）：{A.get('bounds')}"},
                   {"field": "$.findings.assumptions.sensitivity_grid", "statement": f"敏感性网格（专家内置，非案例声明；“不稳定”按它判断）：{A.get('sensitivity_grid')}"},
                   {"field": "$.findings.assumptions.source", "statement": str(A.get("source"))}]
    return {"evidence": ev, "gaps": gaps, "assumptions": assumptions, "scope": "基于声明假设的情景估值（不是目标价）",
            "expert_limitations": [str(x) for x in (F.get("limitations") or [])]}


def _information(o: _Obs, out: dict, doc_ident: dict, real: bool = False) -> dict:
    F = out["findings"]
    sup = {}
    for n, e in enumerate(F.get("supporting_evidence") or []):
        sup.setdefault(e.get("record_id"), []).append(f"$.findings.supporting_evidence[{n}]")
    for n, e in enumerate(F.get("events_detected") or []):
        v = {k: e.get(k) for k in ("record_id", "document_id", "event_category", "claim", "current_status", "ambiguity_status", "evidence_status")}   # Q11: current_status = status at as_of
        o.add(f"$.findings.events_detected[{n}]", [("claim", "抽取到的事件（实验性，待核实）", "：", str(v["claim"])), ("event_category", "类别", " ", str(v["event_category"])),
                                                   ("current_status", "当前状态", " ", str(v["current_status"])), ("ambiguity_status", "歧义", " ", str(v["ambiguity_status"])),
                                                   ("document_id", "文件", " ", str(v["document_id"])), ("record_id", "记录", " ", str(v["record_id"]))], v,
              [f"$.findings.events_detected[{n}].exact_evidence_span"] + sup.get(e.get("record_id"), []), "DOCUMENT_SPAN",
              suffix=ID_SUFFIX.get(doc_ident.get(e.get("document_id")), ""), doc={"document_id": e.get("document_id"), "span": e.get("exact_evidence_span")})
    for n, c in enumerate(F.get("claims_verification") or []):
        v = {k: c.get(k) for k in ("claim_id", "claim", "document_id", "citation", "source_status", "claim_support", "truth")}
        o.add(f"$.findings.claims_verification[{n}]", [("claim_id", "待核实主张", " ", str(v["claim_id"])), ("claim", "主张", "：", str(v["claim"])), ("document_id", "文件", " ", str(v["document_id"])),
                                                       ("citation", "引文", " ", str(v["citation"])), ("source_status", "来源状态", " ", str(v["source_status"])),
                                                       ("claim_support", "支持", " ", str(v["claim_support"])), ("truth", "真伪", " ", str(v["truth"]))], v,
              [f"$.findings.claims_verification[{n}].{k}" for k in ("evidence_location", "related_records") if c.get(k)] if c.get("citation") == "CITATION_FOUND" else [],
              "DOCUMENT_SPAN", suffix=ID_SUFFIX.get(doc_ident.get(c.get("document_id")), ""),
              doc={"document_id": c.get("document_id"), "span": c.get("quoted_span")} if c.get("citation") == "CITATION_FOUND" else None)
    ev = [{"field": f"$.findings.supporting_evidence[{n}]", "document_id": e.get("document_id"), "issuer_id": e.get("issuer_id"),
           "available": e.get("availability_timestamp"), "span": str(e.get("exact_evidence_span"))} for n, e in enumerate(F.get("supporting_evidence") or [])]
    gaps = [{"code": "DOCUMENT_EXCLUDED", "field": "$.findings.rejection_audit", "detail": f"{r.get('document_id')}：{'; '.join(str(x) for x in (r.get('reasons') or []))}"
             + ("（同编号文件的重复副本被排除，另一份照常分析）" if any("DUPLICATE" in str(x) for x in (r.get("reasons") or [])) else "")}
            for r in F.get("rejection_audit") or []]
    gaps += [{"code": "AMBIGUOUS_CLAIM", "field": "$.findings.ambiguous_claims", "detail": str(x)} for x in F.get("ambiguous_claims") or []]
    gaps += [{"code": "UNRESOLVED_MENTION", "field": f"$.findings.unresolved_mentions[{n}]",
              "detail": (f"文件 {x.get('document_id')}，位置 {x.get('span')}：「{x.get('text')}」；人名 {'、'.join(map(str, x.get('persons') or [])) or '无'}；"
                         f"角色词 {'、'.join(map(str, x.get('roles') or [])) or '无'}；{x.get('kind')}：{x.get('why')}") if isinstance(x, dict) else str(x)}
             for n, x in enumerate(F.get("unresolved_mentions") or [])]
    gaps.append({"code": "TRUTH_NOT_DETERMINED", "field": "$.findings.claims_verification[*].truth", "detail": "Information 不判断主张真伪；事件和主张都是待核实线索"})
    if not (F.get("events_detected") or F.get("claims_verification")):
        gaps.append({"code": "NOTHING_EXTRACTED", "field": "$.findings.events_detected", "detail": "Information 执行完成，但没有抽取到任何事件或待核实主张"})
    iq = F.get("information_quality") or {}
    return {"evidence": ev, "gaps": gaps, "scope": "真实 SEC 8-K 文本上的规则抽取与引文核对（规则是为合成公告调出的；不判断真伪）" if real else "合成公告的规则抽取与引文核对（不判断真伪）",
            "assumptions": [{"field": "$.findings.research_summary", "statement": "Information 自己的摘要：" + " / ".join(str(s) for s in (F.get("research_summary") or []))}],
            "expert_limitations": [str(x) for x in (F.get("limitations") or [])],
            "quality_extra": {"information_quality": {k: ({kk: vv for kk, vv in v.items() if kk != "document_hashes"} if isinstance(v, dict) else v) for k, v in iq.items()}}}


def _val_basis(rec: dict) -> str:
    """what an observed multiple is computed on (Q9 review): the price date, the fiscal year of the financials (annual figures, not trailing twelve
    months) and the date of the share count, as the run's own inputs say"""
    out = rec["experts"]["valuation"].get("output") or {}
    tr = next((t for t in (out.get("findings") or {}).get("calculation_trace") or [] if isinstance(t, dict) and t.get("step") == "derived inputs"), None)
    vals = (tr or {}).get("values") or {}
    pd_, fy = vals.get("price_date"), vals.get("fiscal_year")
    if not isinstance(pd_, str) or fy is None:
        return ""
    model = (rec.get("q8") or {}).get("model") or {}
    pe = next((p.get("period_end") for p in ((model.get("fundamental") or {}).get("periods") or []) if isinstance(p, dict) and p.get("fiscal_year") == fy), None)
    mk = next(iter(_ident_of(rec, "valuation", "valuation.market")), {})
    sd = (mk.get("source_dates") or {}).get("shares_as_of_date")
    txt = f"（价格：{pd_} 的收盘价；财务数据：FY{fy} 年报" + (f"（截至 {pe}）" if pe else "") + "，不是最近四个季度（TTM）"
    if isinstance(sd, str):
        gap = (date.fromisoformat(pd_) - date.fromisoformat(sd)).days
        txt += f"；股数截至 {sd}" + (f"，比价格日早 {gap} 天" if gap > 120 else "")
    return txt + "）"


def _gaps_common(r: dict) -> list:
    out = r.get("output") or {}
    def txt(a):
        return "：".join(x for x in ((f"请求 {a['request']}" if a.get("request") else ""), str(a.get("meaning") or ""),
                                    (f"{a['detail']}" if a.get("detail") not in (None, "", a.get("request")) else ""), (f"（{a['path']}）" if a.get("path") else "")) if x)
    g = [{"code": a.get("code"), "field": "$.abstentions", "detail": txt(a)} for a in out.get("abstentions") or [] if isinstance(a, dict)]
    g += [{"code": "MISSING_DEPENDENCY", "field": "$.missing_dependencies", "detail": str(m)} for m in out.get("missing_dependencies") or []]
    g += [{"code": w.get("code") if isinstance(w, dict) else "WARNING", "field": "$.warnings", "detail": (txt(w) if isinstance(w, dict) else str(w))} for w in out.get("warnings") or []]
    return g


def _quality(r: dict) -> dict:
    out = r.get("output")
    if out is None or r["output_contract_status"] != "CONFORMS":
        return {"available": False, "note": "没有可用的输出，无法说明证据质量"}
    if r["tier"] == "PRODUCTION_ACTIVE":
        pc = r.get("production_contract") or {}
        other = "MACRO" if r["expert_id"] == "technical" else "TECHNICAL"
        notes = sorted({str(x.get("code")) for x in r.get("input_contract_notes") or [] if other not in str(x.get("code"))})
        return {"available": True, "self_reported": True, "data_quality_share_of_features": out.get("data_quality"), "data_freshness_days": out.get("data_freshness_days"),
                "price_contract_status": pc.get("status"), "price_contract_notes": notes,
                "note": "生产模型自报：data_quality 是所需特征的可得比例，不是置信度或概率；价格契约的提示只列与本专家相关的"}
    q = out.get("questions") or {}
    return {"available": True, "self_reported": True, "data_adequate": q.get("data_adequate"), "evidence_sufficient": q.get("evidence_sufficient"),
            "financial_interpretation_supported": q.get("financial_interpretation_supported"), "data_status": out.get("data_status"),
            "confidence_basis": str(out.get("confidence_basis")), "note": "实验专家自报的数据与证据状况，不是验证结论"}


def _num(x):
    return x if isinstance(x, (int, float)) and not isinstance(x, bool) and math.isfinite(x) else None


def _doc_dates(ctx: dict, doc) -> dict:
    t = next((t for t in ctx.get("time_audit") or [] if t.get("where") == f"information.documents[{doc}]"), {})
    return {"document_timestamp": t.get("published"), "availability_timestamp": t.get("available")}


def _ident_of(rec: dict, expert: str, where_prefix: str) -> list:
    items = (((rec.get("q8") or {}).get("identity") or {}).get("items") or {}).get(expert) or []
    return [it for it in items if str(it.get("where", "")).startswith(where_prefix)]


def _ident_note(rec: dict, fy: str | None = None) -> str:
    """the identity of the two items X1 compares: the Fundamental period of that fiscal year and the Valuation financials (Q8 identity report)"""
    if rec.get("q8") is None:
        return "这两部分输入没有逐项身份字段（Q7 路径），数字属于哪家发行人未核实"
    per = [it for it in _ident_of(rec, "fundamental", "fundamental.periods") if fy is None or it.get("label") == f"FY{fy}"]
    fin = _ident_of(rec, "valuation", "valuation.financials")
    side = lambda its: "、".join(sorted({it["state_zh"] for it in its})) or "没有身份记录"  # noqa: E731
    return f"发行人身份：Fundamental FY{fy} 期间为“{side(per)}”，Valuation 估值用财务为“{side(fin)}”"


def _x1(rec, E, ctx, ref, out, notes, cur_gap):
    Fo, Vo = E["fundamental"]["output"], E["valuation"]["output"]
    F, V = Fo["findings"], Vo["findings"]
    fcur, vcur = (Fo.get("data_status") or {}).get("currency"), (Vo.get("data_status") or {}).get("currency")
    vin = (ctx.get("section_identity") or {}).get("valuation_financials_fiscal_year")
    fy = str(vin) if vin is not None else None
    why = ("案例里不同部分声明了不同币种" if cur_gap else f"币种不同或未声明（Fundamental {fcur}，Valuation {vcur}）" if not fcur or fcur != vcur else
           "Valuation 输入没有声明财年" if fy is None else None)
    if why:
        notes.append({"rule": "X1", "fact": "*", "state": "NOT_COMPARED", "why": why})
        return
    fin = (F.get("inputs_by_year") or {}).get(fy) or {}
    vm = {m.get("method"): (k, m) for k, m in enumerate(V.get("methods") or [])}
    for fk, meth, vk in (("net_income", "TRAILING_PE", "net_income"), ("stockholders_equity", "PRICE_TO_BOOK", "stockholders_equity"), ("revenue", "EV_SALES", "revenue")):
        k, m = vm.get(meth, (None, {}))
        a, b = _num(fin.get(fk)), _num((m.get("inputs") or {}).get(vk))
        if m and m.get("status") != "COMPUTED":
            notes.append({"rule": "X1", "fact": f"FY{fy} {fk}", "state": "NOT_COMPARED", "why": f"Valuation 的 {meth} 没有计算（{m.get('status')}），它收到的 {vk} 没有用在任何结果里"})
            continue
        if a is None or b is None:
            notes.append({"rule": "X1", "fact": f"FY{fy} {fk}", "state": "NOT_COMPARED", "why": "至少一方没有这个数值"})
            continue
        item = {"rule": "X1", "fact": f"FY{fy} {fk}", "values": {"fundamental": a, "valuation": b, "currency": fcur},
                "refs": [ref("fundamental", f"$.findings.inputs_by_year.{fy}.{fk}"), ref("valuation", f"$.findings.methods[{k}].inputs.{vk}")]}
        if math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-6):
            out.append({**item, "kind": "INPUT_NUMBERS_CONSISTENT",
                        "statement": f"Fundamental 与 Valuation 使用的 FY{fy} {fk} 相同（"
                                     + (f"{_f(a)} {fcur}" if a == b else f"{_f(a)} 与 {_f(b)} {fcur}，只差浮点误差") +
                                     f"）。这只说明案例两部分输入一致，不是两个独立来源的相互印证；{_ident_note(rec, fy)}"})
        else:
            out.append({**item, "kind": "CROSS_EXPERT_CONTRADICTION",
                        "statement": f"同一事实 FY{fy} {fk}（{fcur}）在两个专家的输入里不同：Fundamental {_f(a)}，Valuation {_f(b)}。是案例输入不一致，需要核对数据来源；本层不判断哪一个对"})


def _x2(rec, E, ctx, ref, out, notes, cur_gap):
    pin = ctx.get("price_input") or {}
    V = E["valuation"]["output"]["findings"]
    pk = next((k for k, m in enumerate(V.get("methods") or []) if _num((m.get("inputs") or {}).get("price")) is not None), None)
    dk = next((k for k, t in enumerate(V.get("calculation_trace") or []) if isinstance(t, dict) and isinstance(t.get("values"), dict) and t["values"].get("price_date")), None)
    vcur = (E["valuation"]["output"].get("data_status") or {}).get("currency")
    if pin.get("last_close") is None:
        notes.append({"rule": "X2", "fact": "market price", "state": "NOT_COMPARED", "why": "价格输入没有收盘价"})
        return
    if not vcur or vcur != pin.get("currency"):
        notes.append({"rule": "X2", "fact": "market price", "state": "NOT_COMPARED", "why": f"币种不一致或未知（Valuation {vcur}，价格数据集声明的币种 {pin.get('currency')}）"})
        return
    if pk is None or dk is None:
        notes.append({"rule": "X2", "fact": "market price", "state": "NOT_COMPARED", "why": "Valuation 输出里没有价格或价格日期"})
        return
    p, pdate = V["methods"][pk]["inputs"]["price"], V["calculation_trace"][dk]["values"]["price_date"]
    lc, ldate = pin["last_close"], pin.get("last_row_date")
    item = {"rule": "X2", "fact": "market price", "currency_verified": False, "currency_declared_by_q7": pin.get("currency"),
            "values": {"valuation_price": p, "valuation_price_date": pdate, "price_dataset_last_close": lc, "price_dataset_last_row_date": ldate},
            "refs": [ref("valuation", f"$.findings.methods[{pk}].inputs.price"), ref("valuation", f"$.findings.calculation_trace[{dk}].values.price_date"),
                     {"expert_id": "technical", "run_id": E["technical"]["run_id"], "field": "context.price_input.last_close"},
                     {"expert_id": "technical", "run_id": E["technical"]["run_id"], "field": "context.price_input.last_row_date"}]}
    cur_note = (f"价格数据文件本身不声明币种；{pin.get('currency')} 是系统推断（美国上市证券），未从数据中核实" if rec.get("data_kind", "SYNTHETIC") != "SYNTHETIC"
                else f"价格数据文件本身不声明币种，按 Q7 约定为 {pin.get('currency')}，币种未从数据中核实")
    ratio = p / lc if lc else None
    scale = ratio is not None and (80 <= ratio <= 125 or 0.008 <= ratio <= 0.0125)
    same_cent = round(p, 2) == round(lc, 2)
    identical = math.isclose(p, lc, rel_tol=1e-12, abs_tol=0.0)
    if scale:
        out.append({**item, "kind": "CROSS_EXPERT_CONTRADICTION", "unit_scale_suspect": True,
                    "statement": f"Valuation 使用的市价 {_f(p)}（{pdate}）与 Technical 所分析价格序列的收盘价 {_f(lc)}（{ldate}）相差约 100 倍，日期差异解释不了，"
                                 f"疑似单位错误（如美分 / 美元）；{cur_note}"})
    elif pdate != ldate:
        out.append({**item, "kind": "DIFFERENT_DIMENSION_OR_HORIZON", "unit_scale_suspect": False,
                    "statement": f"Valuation 使用 {pdate} 的市价 {_f(p)}，Technical 所分析价格序列的最后一行是 {ldate}（收盘 {_f(lc)}）。两者日期不同，"
                                 + ("数值相同，但不能当作同一个价格的印证；" if identical else "数值差异可能来自时间不同，不是事实矛盾；") + cur_note})
    elif same_cent:
        out.append({**item, "kind": "INPUT_NUMBERS_CONSISTENT",
                    "statement": f"Valuation 使用的市价 {_f(p)}（{pdate}）与 Technical 所分析价格序列同日的收盘价 {_f(lc)} 四舍五入到 0.01 后相同；{cur_note}"})
    else:
        out.append({**item, "kind": "CROSS_EXPERT_CONTRADICTION", "unit_scale_suspect": False,
                    "statement": f"同一日期 {pdate}：Valuation 使用的市价 {_f(p)} 与 Technical 所分析价格序列的收盘价 {_f(lc)} 不同。两个专家看到的不是同一个价格；{cur_note}"})


def _x3(rec, E, ctx, ref, out, notes, cur_gap):
    T, F = E["technical"]["output"], E["fundamental"]["output"]["findings"]
    items = [(f"$.{side}[{n}]", e) for side in ("evidence", "counter_evidence") for n, e in enumerate(T.get(side) or [])]
    gc = F["financial_growth"]["classification"]
    readable = [(p, e) for p, e in items if e.get("interpretation") in ("positive", "negative")]
    if gc not in ("EXPANDING", "CONTRACTING", "DECLINING", "FLAT") or not readable:
        notes.append({"rule": "X3", "fact": "price evidence vs reported growth", "state": "NOT_COMPARED",
                      "why": f"增长分类 {gc} 没有方向可比" if gc not in ("EXPANDING", "CONTRACTING", "DECLINING", "FLAT") else "Technical 没有可读出方向的价格证据"})
        return
    want = "negative" if gc == "EXPANDING" else "positive" if gc in ("CONTRACTING", "DECLINING") else None
    hit = [(p, e) for p, e in readable if want and e.get("interpretation") == want]
    if not hit:
        notes.append({"rule": "X3", "fact": "price evidence vs reported growth", "state": "NOT_APPLICABLE_NO_TENSION",
                      "why": f"比较过：增长分类 {gc}，Technical 的价格证据没有相反方向的解读"})
        return
    out.append({"rule": "X3", "kind": "DIFFERENT_DIMENSION_OR_HORIZON", "values": {"technical_metrics": [e["metric"] for _, e in hit], "technical_reading": want, "fundamental_growth": gc},
                "refs": [ref("technical", p) for p, _ in hit] + [ref("fundamental", "$.findings.financial_growth.classification")],
                "statement": f"Technical 的价格证据（{'、'.join(e['metric'] for _, e in hit)}，生产模型解读为 {want}）与 Fundamental 的已公布财报增长分类 {gc} 方向不同。"
                             f"二者维度和时间尺度不同（近 1–2 年价格行为 vs 已公布财年数据），不是事实矛盾；本层不据此给出任何方向判断"})


def _x4(rec, E, ctx, ref, out, notes, cur_gap):
    I = E["information"]["output"]["findings"]
    if not (I.get("events_detected") or I.get("claims_verification")):
        notes.append({"rule": "X4", "fact": "document statements", "state": "NOT_COMPARED", "why": "Information 没有抽取到任何事件或主张，没有可比较的文件说法"})
        return
    if not (I.get("conflicting_evidence") or I.get("date_disagreements") or I.get("within_document_inconsistencies")):
        notes.append({"rule": "X4", "fact": "document statements", "state": "NOT_APPLICABLE_NO_TENSION",
                      "why": "比较过：Information 抽取到的事件之间没有说法冲突、日期不一致或同一文件内前后不一致"})
        return
    for n, c in enumerate(I.get("conflicting_evidence") or []):
        docs = [d for d in (c.get("documents") or []) if isinstance(d, str)]
        dates = {d: _doc_dates(ctx, d) for d in docs}
        out.append({"rule": "X4", "kind": "SAME_EXPERT_SOURCE_CONFLICT", "expert_id": "information", "asserted_by": "information（实验专家，未核实）",
                    "values": {"person": c.get("person"), "role": c.get("role"), "documents": dates, "later_change_wording": c.get("later_change_wording")},
                    "refs": [ref("information", f"$.findings.conflicting_evidence[{n}]")],
                    "statement": f"Information 引用的文件之间说法冲突（未核实）：{c.get('person')} / {c.get('role')}：{c.get('reason')}。文件：" +
                                 "；".join(f"{d}（文件日期 {dates[d]['document_timestamp']}，可得 {dates[d]['availability_timestamp']}）" for d in docs)})
    for key, label in (("date_disagreements", "Information 引用的文件之间日期不一致"), ("within_document_inconsistencies", "Information 引用的同一文件内前后不一致")):
        for n, c in enumerate(I.get(key) or []):
            c = c if isinstance(c, dict) else {"detail": str(c)}
            docs = [d for d in (c.get("documents") or ([c.get("document_id")] if c.get("document_id") else [])) if isinstance(d, str)]
            dates = {d: _doc_dates(ctx, d) for d in docs}
            fields = "；".join(f"{k} {c.get(k)}" for k in ("person", "role", "action", "dates", "detail") if c.get(k) is not None)
            out.append({"rule": "X4", "kind": "SAME_EXPERT_SOURCE_CONFLICT", "expert_id": "information", "asserted_by": "information（实验专家，未核实）",
                        "values": {k: c.get(k) for k in ("person", "role", "action", "dates", "detail")} | {"documents": dates},
                        "refs": [ref("information", f"$.findings.{key}[{n}]")],
                        "statement": f"{label}（未核实）：{fields}。文件：" +
                                     ("；".join(f"{d}（文件日期 {dates[d]['document_timestamp']}，可得 {dates[d]['availability_timestamp']}）" for d in docs) or "未列出")})


def _x5(rec, E, ctx, ref, out, notes, cur_gap):
    Fo, V = E["fundamental"]["output"], E["valuation"]["output"]["findings"]
    lm = (Fo["findings"].get("financial_profitability") or {}).get("loss_making")
    fy_f = (Fo.get("data_status") or {}).get("latest_fiscal_year")
    fy_v = (ctx.get("section_identity") or {}).get("valuation_financials_fiscal_year")
    k, m = next(((k, m) for k, m in enumerate(V.get("methods") or []) if m.get("method") == "TRAILING_PE"), (None, None))
    if lm not in ("TRUE", "FALSE") or m is None or fy_f is None or fy_f != fy_v:
        notes.append({"rule": "X5", "fact": "loss status", "state": "NOT_COMPARED",
                      "why": f"缺少可比的观察（Fundamental loss_making = {lm}，财年 {fy_f}；Valuation 财年 {fy_v}；TRAILING_PE {'有' if m else '没有'}）"})
        return
    codes = [c.get("code") for c in m.get("codes") or [] if isinstance(c, dict)]
    if m.get("status") == "COMPUTED":
        v_loss = "FALSE"
    elif "NEGATIVE_EARNINGS" in codes:
        v_loss = "TRUE"
    else:
        notes.append({"rule": "X5", "fact": "loss status", "state": "NOT_COMPARED", "why": f"Valuation 的 TRAILING_PE 状态 {m.get('status')} 不能说明是否亏损"})
        return
    item = {"rule": "X5", "fact": f"FY{fy_f} loss status", "values": {"fundamental_loss_making": lm, "valuation_trailing_pe_status": m.get("status"), "valuation_codes": codes},
            "refs": [ref("fundamental", "$.findings.financial_profitability.loss_making"), ref("valuation", f"$.findings.methods[{k}].status")]}
    v_txt = "TRAILING_PE 可以计算（净利润为正）" if v_loss == "FALSE" else "TRAILING_PE 不可用，原因是 NEGATIVE_EARNINGS（净利润不为正）"
    if v_loss == lm:
        out.append({**item, "kind": "EXPERT_OBSERVATIONS_CONSISTENT",
                    "statement": f"Fundamental 判断 FY{fy_f} loss_making = {lm}；Valuation 的 {v_txt}：两个专家对是否亏损的观察一致。两者的输入都来自同一个案例（财报部分和估值部分），不是独立来源"})
    else:
        out.append({**item, "kind": "CROSS_EXPERT_CONTRADICTION",
                    "statement": f"Fundamental 判断 FY{fy_f} loss_making = {lm}，Valuation 却显示 {v_txt}：两个专家对是否亏损的观察相反，需要核对两部分输入"})


def _cross(rec: dict, done: dict) -> tuple:
    found, notes = [], []
    ctx = rec["context"]
    E = rec["experts"]
    ref = lambda eid, field: {"expert_id": eid, "run_id": E[eid]["run_id"], "field": field}  # noqa: E731
    cur_gap = any(g.get("code") == "CROSS_SECTION_CURRENCY_MISMATCH" for g in ctx.get("data_gaps") or [])
    for rule, fn in (("X1", _x1), ("X2", _x2), ("X3", _x3), ("X4", _x4), ("X5", _x5)):
        missing = [E[e]["display_name"] for e in RULE_EXPERTS[rule] if e not in done]
        if missing:
            notes.append({"rule": rule, "fact": "*", "state": "NOT_COMPARED", "why": f"参与这条规则的专家没有进入综合：{'、'.join(missing)}"})
            continue
        o_, n_ = [], []
        try:
            fn(rec, E, ctx, ref, o_, n_, cur_gap)
            found += o_
            notes += n_
        except Exception as e:           # one rule that cannot read an output shape is reported (and contributes nothing)
            notes.append({"rule": rule, "fact": "*", "state": "RULE_ERROR", "why": f"规则读取输出时出错（{type(e).__name__}），本规则没有结果"})
    sections = {sec: [] for sec in SECTION_OF.values()}
    pref = {"C1_input_numbers_consistent": "AGR", "C2_observations_consistent": "OBS", "D1_cross_expert_contradictions": "CON", "D2_different_dimension_or_horizon": "DIM",
            "S_same_expert_source_conflicts": "SRC"}
    for it in found:
        it["category"] = it["kind"]
        it["category_zh"] = CATEGORIES[it["kind"]]
        sections[SECTION_OF[it["kind"]]].append(it)
    for sec, items in sections.items():
        for k, it in enumerate(items):
            it["id"] = f"{pref[sec]}-{k + 1:02d}"
    for k, it in enumerate(notes):
        it["id"] = f"NC-{k + 1:02d}"
    return sections, notes


def _identity_view(rec: dict) -> dict:
    q8 = rec.get("q8")
    if not q8:
        return {"available": False, "note": "Q7 路径的运行没有 Q8 身份报告"}
    ident = q8.get("identity") or {}
    return {"available": True, "legacy": q8.get("legacy"), "items": ident.get("items"), "state_counts": ident.get("state_counts"), "blocks": q8.get("blocks"),
            "rule": ident.get("rule"), "registry_note": ident.get("registry_note"),
            "conventions": ("真实数据：价格的币种 USD 是系统推断，日线的可得时间未知（只比较日期）；SEC 的 acceptanceDateTime 时区未核实，距 as_of 不到 24 小时的申报不使用；"
                            "^TNX / ^IRX 是美国国债利率替代品" if rec.get("data_kind", "SYNTHETIC") != "SYNTHETIC" else
                            "合成价格数据的币种（USD）和日线可得时间（当天 21:00Z）是 Q7 的约定，不是真实市场事实；合成来源登记表也是合成的"),
            "legacy_banner": "旧格式回放：Q7 案例的财报、估值和公告没有逐项身份字段，身份都是“旧格式／身份未核实”（价格数据集仍按证券登记核对）" if q8.get("legacy") else None}


def _valuation_view(rec: dict) -> dict:
    r = rec["experts"]["valuation"]
    model = (rec.get("q8") or {}).get("model") or {}
    declared = (model.get("valuation") or {}).get("assumptions") if isinstance(model.get("valuation"), dict) else None
    if r["execution_status"] != "COMPLETED" or not r.get("output"):
        return {"ran": False, "status": r["execution_status"], "declared_assumptions": declared,
                "note": f"Valuation 没有给出结果（{ZH_STATUS[r['execution_status']]}）；下面只列出案例声明的假设，没有任何估值数字"}
    F = r["output"]["findings"]
    sens = F.get("sensitivity") or {}
    return {"ran": True, "declared_assumptions": declared, "expert_assumptions": F.get("assumptions"),
            "scenarios": {k: {"state": v.get("state"), "assumptions": v.get("assumptions")} for k, v in (F.get("valuation_scenarios") or {}).items()},
            "sensitivity": {"around": sens.get("around"), "metrics": sens.get("metrics"), "triggers": sens.get("triggers"), "grid": sens.get("grid")},
            "stability": F.get("stability_warnings"), "ranges": F.get("estimated_value_ranges"),
            "unavailable_methods": F.get("unavailable_methods"), "inapplicable_methods": F.get("inapplicable_methods"),
            "methods": [{"method": m.get("method"), "status": m.get("status"), "codes": m.get("codes") or []} for m in F.get("methods") or []],
            "basis": _val_basis(rec),
            "note": "情景区间完全取决于声明的假设，不是目标价，也不是公允价格；敏感性只说明假设变动时数字变化多大；观察到的倍数" + (_val_basis(rec) or "")}


def _key_gaps(U: list) -> list:
    groups = {}
    order = ["EXPERT_NOT_COMPLETED", "IDENTITY", "CONTEXT_GAP", "EXPERT_GAP", "NOT_COMPARED", "KNOWN_OPEN_ISSUE", "SYNTHESIS_SKIPPED"]
    for u in U:
        k = u["kind"]
        if k == "CONTEXT_GAP" and str(u.get("code", "")).startswith(("SECTION_ISSUER", "FOREIGN_ISSUER", "ISSUER_TEXT", "TEXT_NAME")):
            k = "IDENTITY"
        if k == "RULE_NO_FINDING":
            continue
        text = u.get("statement") or f"{u.get('code')}（{u.get('expert_id') or u.get('path') or ''}）：{u.get('detail') or ''}"
        groups.setdefault(k, []).append(text)
    zh = {"EXPERT_NOT_COMPLETED": "没有执行完成的专家", "IDENTITY": "身份相关提示", "CONTEXT_GAP": "输入数据缺口", "EXPERT_GAP": "专家自己报告的缺口 / 弃权 / 警告",
          "NOT_COMPARED": "没有比较的跨专家规则", "KNOWN_OPEN_ISSUE": "已知未修问题", "SYNTHESIS_SKIPPED": "执行完成但没有进入综合"}  # noqa: E501
    return [{"group": k, "group_zh": zh.get(k, k), "items": groups[k]} for k in order if k in groups]


def _headline(rec: dict, B: dict, sections: dict, U: list) -> list:
    """the important things of this run, in a fixed priority order; only what is present (never padded)"""
    H = []
    for eid, b in B.items():
        if b["execution_status"] != "COMPLETED":
            rs = b["status_reasons"] or [{}]
            H.append({"kind": "EXPERT_NOT_COMPLETED", "text": f"{b['display_name']} {b['execution_status_zh']}（{len(rs)} 条原因）：" +
                      "；".join(f"{r0.get('meaning', '')}（{r0.get('path', '')}）{('：' + r0['detail']) if r0.get('detail') else ''}" for r0 in rs), "refs": [f"B.{eid}"]})
        elif not b["used_in_synthesis"]:
            H.append({"kind": "SYNTHESIS_SKIPPED", "text": f"{b['display_name']} 执行完成，但综合层读不了它的输出，没有使用它的任何结果", "refs": [f"B.{eid}"]})
    for u in U:
        if u.get("kind") == "NOT_COMPARED" and u.get("rule_error"):
            H.append({"kind": "RULE_ERROR", "text": u["statement"], "refs": ["X"]})
    for sec, kind in (("D1_cross_expert_contradictions", "CROSS_EXPERT_CONTRADICTION"), ("S_same_expert_source_conflicts", "SAME_EXPERT_SOURCE_CONFLICT"),
                      ("D2_different_dimension_or_horizon", "DIFFERENT_DIMENSION_OR_HORIZON")):
        for it in sections[sec]:
            H.append({"kind": kind, "text": f"{CATEGORIES[kind].split('（')[0]}：{it['statement']}", "refs": [it["id"]]})
    q8 = rec.get("q8") or {}
    if q8.get("legacy"):
        H.append({"kind": "LIMITATION", "text": "旧格式回放：Q7 案例的财报、估值和公告没有逐项身份字段，身份都是“旧格式／身份未核实”（价格数据集仍按证券登记核对）", "refs": ["I"]})
    ud = [f"{e}:{it.get('label') or it['where']}" for e, its in (((q8.get("identity") or {}).get("items")) or {}).items() for it in its if it["state"] == "MATCH_USER_DECLARED"]
    if ud:
        H.append({"kind": "LIMITATION", "text": f"这些数据的身份只是用户声明，没有来源登记可核对：{'、'.join(ud)}", "refs": ["I"]})
    md = [f"{e}:{it.get('label') or it['where']}" for e, its in (((q8.get("identity") or {}).get("items")) or {}).items() for it in its if it["state"] == "MODIFIED_FROM_REGISTRY"]
    if md:
        H.append({"kind": "LIMITATION", "text": f"这些数据写了已登记的来源编号，但内容与登记不同，按用户修改处理（未核实）：{'、'.join(md)}", "refs": ["I"]})
    vb = B.get("valuation") or {}
    st = next((o["value"].get("state") for o in vb.get("observations", []) if o["field"] == "$.findings.stability_warnings"), None)
    if st == "UNSTABLE":
        H.append({"kind": "LIMITATION", "text": "Valuation 的结果对声明的假设很敏感（UNSTABLE）：小幅改动假设，数字变化很大", "refs": ["V"]})
    na = {g["detail"].split("：")[0]: g["detail"] for g in vb.get("gaps", []) if g["code"] == "METHOD_NOT_APPLICABLE"}
    un = {g["detail"].split("：")[0]: g["detail"] for g in vb.get("gaps", []) if g["code"] == "METHOD_UNAVAILABLE" and g["detail"].split("：")[0] not in na}
    if na:
        H.append({"kind": "LIMITATION", "text": "Valuation 有方法不适用（行业规则）：" + "；".join(na.values()), "refs": ["V"]})
    if un:
        H.append({"kind": "LIMITATION", "text": "Valuation 有方法缺数据没有算：" + "；".join(un.values()), "refs": ["V"]})
    if (B.get("information") or {}).get("used_in_synthesis") and (B.get("information") or {}).get("observations"):
        H.append({"kind": "LIMITATION", "text": "Information 抽取的事件和主张都是待核实线索，真伪一律未判定", "refs": ["B.information"]})
    for eid, b in B.items():          # Q9: an expert that ran but produced nothing usable is said so - never counted as an analysis done
        if b["execution_status"] == "COMPLETED" and b["used_in_synthesis"] and not valid_finding(eid, b):
            H.append({"kind": "EXPERT_NO_VALID_FINDING", "text": f"{b['display_name']} 执行完成，但没有有效发现：{no_finding_why(eid, b)}", "refs": [f"B.{eid}"]})
    return H


def valid_finding(eid: str, b: dict) -> bool:
    """an expert's output counts as a finding when it has at least one observation that states something about the input (Information: an event
    or a claim answer; the others: any observation)"""
    obs = b.get("observations") or []
    if eid == "information":
        return any(o["field"].startswith(("$.findings.events_detected", "$.findings.claims_verification")) for o in obs)
    return bool(obs)


def no_finding_why(eid: str, b: dict) -> str:
    if eid == "information":
        un = sum(1 for g in b.get("gaps") or [] if g.get("code") == "UNRESOLVED_MENTION")
        return f"没有抽取到任何事件或待核实主张；只有 {un} 条未解析的提及（句子里有人名和管理层用词，但规则无法确定事件）"
    return "没有可报告的观察"


def synthesize(rec: dict) -> dict:
    E, ctx = rec["experts"], rec["context"]
    q8 = rec.get("q8") or {}
    model = q8.get("model")
    real0 = (rec.get("data_kind") or "SYNTHETIC") != "SYNTHETIC"
    vbasis = _val_basis(rec) if E["valuation"].get("output") else ""
    B, done, skipped = {}, {}, []
    doc_ident = {}
    for it in ((q8.get("identity") or {}).get("items") or {}).get("information") or []:
        doc_ident[it.get("label")] = it.get("state")
    for eid, r in E.items():
        try:
            q = _quality(r)
        except Exception as e:
            q = {"available": False, "note": f"读取证据质量时出错（{type(e).__name__}）"}
        b = {"display_name": r["display_name"], "tier": r["tier"], "tier_label": r["tier_label"], "execution_status": r["execution_status"],
             "execution_status_zh": ZH_STATUS[r["execution_status"]], "status_reasons": copy.deepcopy(r["status_reasons"]), "output_contract_status": r["output_contract_status"],
             "validation_status": r["trust"]["validation_status"], "validation_label": r["trust"]["validation_label"], "validation_note": r["trust"]["validation_note"],
             "production_identity": r["trust"]["production_identity"], "evidence_basis": r["trust"]["evidence_basis"], "evidence_quality": q,
             "limitations": copy.deepcopy(r["trust"]["limitations"]), "expert_reported_limitations": [], "known_open_issues": copy.deepcopy(r["trust"]["known_open_issues"]),
             "identity": copy.deepcopy(((q8.get("identity") or {}).get("items") or {}).get(eid) or []),
             "observations": [], "evidence": [], "assumptions": [], "gaps": [], "scope": None, "used_in_synthesis": False}
        if r["output_contract_status"] == "CONFORMS" and r.get("output") is not None:
            try:
                b["gaps"] = _gaps_common(r)
            except Exception as e:
                b["gaps"] = [{"code": "GAPS_UNREADABLE", "field": "$", "detail": f"读取弃权 / 缺依赖 / 警告时出错（{type(e).__name__}）"}]
        if r["execution_status"] == "COMPLETED" and r["output_contract_status"] == "CONFORMS":
            o = _Obs(rec, eid)
            try:
                extra = {"technical": lambda: _technical_like(o, r["output"], "technical"), "macro": lambda: _technical_like(o, r["output"], "macro"),
                         "fundamental": lambda: _fundamental(o, r["output"], model), "valuation": lambda: _valuation(o, r["output"], vbasis),
                         "information": lambda: _information(o, r["output"], doc_ident, real0)}[eid]()
                weak = [it for it in ((q8.get("identity") or {}).get("items") or {}).get(eid) or [] if eid in ("fundamental", "valuation") and
                        it.get("state") in ("MATCH_USER_DECLARED", "MODIFIED_FROM_REGISTRY", "LEGACY_UNVERIFIED")]
                if weak:                                 # the observation rests on inputs whose identity is not registry-matched: said on each one
                    sfx = "（输入里 " + "、".join(f"{it.get('label') or it['where']} 的身份为“{it['state_zh']}”" for it in weak) + "，见数据身份）"
                    for ob in o.items:
                        ob["suffix"] += sfx
                        ob["statement"] += sfx
                b["observations"] = o.items
                b["evidence"] = extra.get("evidence", [])
                b["assumptions"] = extra.get("assumptions", [])
                b["gaps"] += extra.get("gaps", [])
                b["scope"] = extra.get("scope")
                b["expert_reported_limitations"] = extra.get("expert_limitations", [])
                b["evidence_quality"].update(extra.get("quality_extra", {}))
                b["used_in_synthesis"] = True
                done[eid] = True
            except Exception as e:      # an unexpected output shape: the expert is not used, and that is said, never hidden
                skipped.append({"expert_id": eid, "why": f"{type(e).__name__}: {e}"})
                b["observations"], b["used_in_synthesis"] = [], False
                b["gaps"].append({"code": "SYNTHESIS_EXTRACTION_SKIPPED", "field": "$", "detail": f"综合层无法读取这个输出的结构（{type(e).__name__}），本专家不进入综合"})
        B[eid] = b
    sections, notes = _cross(rec, done)
    U = []
    for eid, r in E.items():
        if r["execution_status"] != "COMPLETED":
            U.append({"kind": "EXPERT_NOT_COMPLETED", "expert_id": eid, "status": r["execution_status"],
                      "statement": f"{r['display_name']}：{ZH_STATUS[r['execution_status']]}（" + "；".join(f"{x.get('code')}: {x.get('meaning') or ''} {x.get('path') or ''} {x.get('detail') or ''}".strip()
                                                                                                           for x in r["status_reasons"]) + "）。这个维度在本次运行中缺失，不按零或中性处理"})
    for s_ in skipped:
        U.append({"kind": "SYNTHESIS_SKIPPED", "expert_id": s_["expert_id"], "statement": f"{E[s_['expert_id']]['display_name']} 执行完成，但综合层读不了它的输出，没有进入综合（{s_['why']}）"})
    for nc in notes:
        if nc["state"] == "NOT_APPLICABLE_NO_TENSION":
            U.append({"kind": "RULE_NO_FINDING", "rule": nc["rule"], "statement": f"{nc['id']} 规则 {nc['rule']}（{nc['fact']}）比较过，没有发现：{nc['why']}"})
        else:
            U.append({"kind": "NOT_COMPARED", "rule": nc["rule"], "rule_error": nc["state"] == "RULE_ERROR",
                      "statement": f"{nc['id']} 规则 {nc['rule']}（{nc['fact']}）没有比较：{nc['why']}"})
    for eid, b in B.items():
        for g in b["gaps"]:
            U.append({"kind": "EXPERT_GAP", "expert_id": eid, **g})
        for k in b["known_open_issues"] if b["used_in_synthesis"] else []:
            U.append({"kind": "KNOWN_OPEN_ISSUE", "expert_id": eid, "detail": k, "statement": f"已知未修（{b['display_name']}）：{k}"})
    for g in ctx.get("data_gaps") or []:
        U.append({"kind": "CONTEXT_GAP", **g})
    for eid, its in (((q8.get("identity") or {}).get("items")) or {}).items():
        weak = [it for it in its if it.get("state") not in ("MATCH_SOURCE_REGISTRY", "CASE_DECLARED")]
        for st_ in sorted({it["state"] for it in weak}):
            xs = [it for it in weak if it["state"] == st_]
            U.append({"kind": "IDENTITY", "expert_id": eid, "state": st_,
                      "statement": f"{E[eid]['display_name']} 的输入里 {len(xs)} 项数据身份为“{xs[0]['state_zh']}”：" + "、".join(str(it.get("label") or it["where"]) for it in xs)})
    st = {e: E[e]["execution_status"] for e in E}
    n_c = sum(1 for v in st.values() if v == "COMPLETED")
    used = [e for e in E if B[e]["used_in_synthesis"]]
    not_cmp = [n for n in notes if n["state"] in ("NOT_COMPARED", "RULE_ERROR")]
    H = _headline(rec, B, sections, U)
    KG = _key_gaps(U)
    findings = {e: {"display_name": B[e]["display_name"], "execution_status": st[e], "execution_status_zh": ZH_STATUS[st[e]], "validation_label": B[e]["validation_label"],
                    "tier_label": B[e]["tier_label"],
                    "main": [{"obs_id": o["obs_id"], "statement": o["statement"]} for o in _main_obs(e, B[e]["observations"])],
                    "reasons": [f"{x.get('code')}：{x.get('meaning') or ''}（{x.get('path') or ''}）" for x in B[e]["status_reasons"]] if st[e] != "COMPLETED" else
                    ([] if B[e]["used_in_synthesis"] and valid_finding(e, B[e]) else
                     [f"执行完成，但没有有效发现：{no_finding_why(e, B[e])}"] if B[e]["used_in_synthesis"] else
                     ["执行完成，但综合层读不了它的输出，没有使用它的任何结果（见关键缺口）"])}
                for e in E}
    origin = rec.get("input_origin")
    feeds = {"C1_input_numbers_consistent": ("X1", "X2"), "C2_observations_consistent": ("X5",), "D1_cross_expert_contradictions": ("X1", "X2", "X5"),
             "D2_different_dimension_or_horizon": ("X2", "X3"), "S_same_expert_source_conflicts": ("X4",)}
    produced = {it["rule"] for v in sections.values() for it in v}
    ran = produced | {n["rule"] for n in notes if n["state"] == "NOT_APPLICABLE_NO_TENSION"}
    never = {n["rule"]: n["why"] for n in notes if n["state"] in ("NOT_COMPARED", "RULE_ERROR") and n["rule"] not in ran}
    sec_status = {sec: {"rules": list(rs), "compared": [r_ for r_ in rs if r_ in ran], "not_compared": [{"rule": r_, "why": never[r_]} for r_ in rs if r_ in never],
                        "all_not_compared": all(r_ in never for r_ in rs)} for sec, rs in feeds.items()}

    def cnt(sec):
        st_ = sec_status[sec]
        if not sections[sec] and st_["all_not_compared"]:
            return "未比较"
        return f"{len(sections[sec])} 条" + ("（" + "、".join(x["rule"] for x in st_["not_compared"]) + " 未比较）" if st_["not_compared"] else "")
    n_valid = sum(1 for e in E if B[e]["used_in_synthesis"] and valid_finding(e, B[e]))
    dk = rec.get("data_kind") or "SYNTHETIC"
    real = dk != "SYNTHETIC"
    S = [{"text": f"运行 {rec['run_id']}：案例 {rec['case_id']}，分析对象 {(ctx.get('issuer') or {}).get('issuer_id')}，截止时间 {ctx.get('as_of')}；"
                  f"输入来源 {origin}" + ("，与登记的案例文件不同" if rec.get("input_differs_from_registered_case") else "") + ("；旧格式回放（身份未核实）" if q8.get("legacy") else "") + "。"
                  f"五个专家：" + "，".join(f"{E[e]['display_name']} {ZH_STATUS[st[e]]}" for e in E) + f"。{n_c}/5 执行完成，其中 {len(used)} 个进入综合、{n_valid} 个有有效发现；执行完成只说明跑完了，不代表结论可靠。"
                  + ({"REAL_PUBLIC_DATA_INTERNAL_TEST": "数据是真实公开来源（SEC EDGAR、Tiingo 免费额度、Cboe、美国国债），只用于内部试验，不能用于收费网站；真实数据上的运行不是金融验证。",
                      "REAL_PUBLIC_DATA_USER_MODIFIED": "数据以真实公开来源为基础，但本次输入经用户修改或另存，不是系统从快照整理出的原样案例；修改过的项按用户声明处理（逐项身份见“数据身份”）。"
                                                        "只用于内部试验，不能用于收费网站；不是金融验证。"}.get(dk, "")),
          "refs": ["A"]},
         {"text": f"最重要的事项 {len(H)} 条（见“最重要的发现、冲突和限制”）；输入数字一致 {cnt('C1_input_numbers_consistent')}，专家观察一致 {cnt('C2_observations_consistent')}，"
                  f"跨专家矛盾 {cnt('D1_cross_expert_contradictions')}，维度 / 时间尺度不同 {cnt('D2_different_dimension_or_horizon')}，"
                  f"同一专家引用的文件互相冲突 {cnt('S_same_expert_source_conflicts')}；没有比较的规则说明 {len(not_cmp)} 条。", "refs": list(SECTION_OF.values())},
         {"text": "关键缺口：" + "；".join(f"{g['group_zh']}（{len(g['items'])}）：{g['items'][0]}" + ("……" if len(g["items"]) > 1 else "") for g in KG) + "。完整列表见“关键缺口”。"
          if KG else "关键缺口：没有。", "refs": ["K"]},
         {"text": "Technical、Macro 是生产 ACTIVE 专家（被调用时原样调用，未改代码），但生产在用不等于经过金融验证；Fundamental、Valuation、Information 是隔离实验版本"
                  "（生产中仍为 DORMANT，本次运行不等于激活）。五个专家的验证状态都是“未确立”。", "refs": ["B.*.validation_status"]},
         {"text": "本报告只整理证据，不包含：" + "、".join(NOT_INCLUDED) + "。", "refs": ["not_included"]}]
    out = {"synthesis_version": SYNTHESIS_VERSION, "rules": copy.deepcopy(RULES), "rule_kinds": copy.deepcopy(KINDS), "categories": copy.deepcopy(CATEGORIES), "status": "COMPLETED",
           "data_kind": dk,
           "A_context": {"run_id": rec["run_id"], "started_at_utc": rec.get("started_at_utc"), "case_id": rec["case_id"], "case_label": rec.get("case_label"),
                         "issuer": copy.deepcopy(ctx.get("issuer")), "as_of": ctx.get("as_of"), "input_fingerprint": rec["input_fingerprint"], "case_sha256": rec["case_sha256"],
                         "input_origin": origin, "input_differs_from_registered_case": rec.get("input_differs_from_registered_case"), "legacy": q8.get("legacy"),
                         "sources": copy.deepcopy(ctx.get("sources")), "expert_statuses": st, "fault_injection": copy.deepcopy(rec.get("fault_injection"))},
           "H_headline": H, "expert_findings": findings, "B_experts": B, **sections, "section_status": sec_status, "X_not_compared": notes, "K_key_gaps": KG,
           "V_valuation_view": _valuation_view(rec), "I_identity_view": _identity_view(rec), "E_uncertainty": U, "F_summary": S,
           "synthesis_skipped": skipped, "not_included": list(NOT_INCLUDED),
           "counts": {"completed": n_c, "used_in_synthesis": len(used), "with_valid_finding": n_valid, "observations": sum(len(b["observations"]) for b in B.values()),
                      **{sec: len(v) for sec, v in sections.items()}, "not_compared": len(not_cmp), "headline": len(H), "uncertainty_items": len(U)}}
    return out


def _main_obs(eid: str, obs: list) -> list:
    """the observations that state each expert's main finding (a fixed choice per expert, not a ranking)"""
    if not obs:
        return []
    pick = {"technical": ("$.counter_evidence", "$.evidence"), "macro": ("$.metadata.regime_hint", "$.counter_evidence", "$.evidence"),
            "fundamental": ("$.findings.financial_growth", "$.findings.financial_profitability", "$.findings.financial_risks", "$.findings.cash_flow_quality"),
            "valuation": ("$.findings.estimated_value_ranges", "$.findings.methods", "$.findings.methods", "$.findings.applicable_methods"),   # Q10 batch 2: the observed multiples (with their basis) before the method list
            "information": ("$.findings.events_detected", "$.findings.claims_verification")}[eid]
    out = []
    if eid == "information":                          # Q10: a decided event first, a tentative or role-less one after it
        obs = sorted(obs, key=lambda o: 0 if isinstance(o.get("value"), dict) and o["value"].get("ambiguity_status") == "UNAMBIGUOUS" else 1)
    for p in pick:
        for o in obs:
            if o["field"].startswith(p) and o not in out:
                if eid == "information" and isinstance(o["value"], dict) and (o["value"].get("evidence_status") or o["value"].get("current_status")) in ("SUPERSEDED",):   # Q11
                    continue
                out.append(o)
                break
        if len(out) >= 3:
            break
    return out or obs[:1]
