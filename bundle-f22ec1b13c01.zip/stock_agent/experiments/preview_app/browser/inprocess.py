"""Q12 - in-process stand-in for subprocess.run, used ONLY where a real child process cannot exist (Pyodide in a browser Web Worker).

The orchestrator (orchestrator/run.py, orchestrator/q8_input.py) runs every expert as `python -I -B ... adapters/<script>` with a JSON request on stdin
and reads one JSON object from stdout. Here that call runs the same script file in this interpreter with run_name "__main__", stdin / stdout
replaced by in-memory streams; the orchestrator and the adapters are not changed. Isolation that a process gave, kept here:
  - every module the script imports from the project (expert roots, the bridge, the production chain's private package) is removed again
    afterwards and sys.path is restored, so two experts never share a module (each expert root has its own `shared` package); the standard
    library and installed packages stay loaded;
  - an exception or SystemExit of the script is the child's exit code, never an exception of the caller;
  - nothing is kept between analyses: the browser starts a NEW worker (a new interpreter) for every analysis and ends it afterwards.
Not kept (said in the page): a hard time limit inside one call (the page ends the worker after its own time limit) and a crash isolation of
os._exit (the only os._exit is the test-only fault 'process_crash', which this stand-in refuses: such a request returns exit code 17 unrun).
"""
from __future__ import annotations

import io
import json
import runpy
import subprocess
import sys
import time
import traceback

_REAL_RUN = subprocess.run


class _Completed:
    def __init__(self, args, returncode, stdout, stderr):
        self.args, self.returncode, self.stdout, self.stderr = args, returncode, stdout, stderr


def run(args, input=None, capture_output=False, text=False, timeout=None, cwd=None, **kw):     # noqa: A002 - the subprocess.run signature
    script = next((a for a in reversed(args) if str(a).endswith(".py")), None)
    if script is None:
        raise RuntimeError("in-process runner: only adapter scripts can run here")
    req = input if isinstance(input, str) else (input or b"").decode("utf-8")
    try:
        fault = (json.loads(req).get("fault_injection") or {}) if req.strip() else {}
    except ValueError:
        fault = {}
    if isinstance(fault, dict) and fault.get("kind") == "process_crash":
        return _Completed(args, 17, "", "process_crash is a test-only fault; it is not run in the browser")
    mods, path = set(sys.modules), list(sys.path)
    stdin, stdout, stderr = sys.stdin, sys.stdout, sys.stderr
    out, err = io.StringIO(), io.StringIO()
    sys.stdin, sys.stdout, sys.stderr = io.StringIO(req), out, err
    code, t = 0, time.monotonic()
    try:
        runpy.run_path(str(script), run_name="__main__")
    except SystemExit as e:
        code = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
    except BaseException:                                   # an uncaught error of the script is the child's failure, not ours
        code = 1
        err.write(traceback.format_exc()[-1500:])
    finally:
        sys.stdin, sys.stdout, sys.stderr = stdin, stdout, stderr
        for m in set(sys.modules) - mods:
            if not _library(sys.modules.get(m)):
                del sys.modules[m]
        sys.path[:] = path
    if timeout is not None and time.monotonic() - t > timeout:
        raise subprocess.TimeoutExpired(args, timeout)
    return _Completed(args, code, out.getvalue(), err.getvalue())


def _library(mod) -> bool:
    """the standard library and installed packages (numpy, pandas, ...) stay loaded: an extension module cannot be initialised twice in one
    interpreter; every other module the script loaded (an expert root, the bridge, the production chain's private package) is dropped"""
    f = getattr(mod, "__file__", None)
    return bool(f) and ("site-packages" in f or "lib-dynload" in f or f.startswith((sys.base_prefix, sys.prefix, "/lib/python")))


def install() -> None:
    subprocess.run = run
