"""Q12 public demo - the Python side of one analysis in the browser (Pyodide in a Web Worker started for this one analysis and ended after it).

analyze(case_id) runs the five experts on one SYNTHETIC case of the demo list (DEMO_CASES; nothing else can be named), through the same
orchestrator.run_q8 the local workbench uses (the subprocess calls run in this interpreter: browser/inprocess.py), builds the beginner report and
returns one JSON text: the page view, the full run record for download, and a SHA-256 of the record, so the page, the download and the browser
history all belong to the same run. No network, no real data: the bundle has no real-data files and no data-fetching module.
Q13: the view also carries the synthesis layer's cross-expert comparison (its own categories and statements, counted, not scored), the
rules it could not compare and why, and what the report never contains - the page shows them in the result and the full report.
"""
from __future__ import annotations

import hashlib
import json
import re
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
APP = HERE.parent
sys.path.insert(0, str(APP))
sys.path.insert(0, str(HERE))
import inprocess  # noqa: E402

inprocess.install()
from orchestrator import q8_input as Q, run as RUN  # noqa: E402
from workbench import beginner as BG  # noqa: E402
from adapters import registry as R  # noqa: E402
from workbench import demo_text as DT  # noqa: E402

DEMO_CASES = {c["case_id"]: {k: v for k, v in c.items() if k != "case_id"} for c in json.loads((HERE / "demo_cases.json").read_text(encoding="utf-8"))["cases"]}   # synthetic only
DEMO_LIMITS = DT.DEMO_LIMITS
EXPERT_ZH = {"technical": "技术面(价格走势)", "macro": "宏观(市场环境)", "fundamental": "基本面(财报)", "valuation": "估值(倍数)", "information": "公告(管理层变动、内部人交易)"}
STATUS_ZH = {"COMPLETED": "已运行", "COMPLETED_NO_RESULT": "已运行,没有结果", "REJECTED": "输入被拒绝", "NOT_APPLICABLE": "不适用", "NOT_EXECUTED": "没有运行",
             "FAILED": "运行失败"}


CROSS = [("D1_cross_expert_contradictions", "CROSS_EXPERT_CONTRADICTION", "不同专家之间的矛盾"),
         ("S_same_expert_source_conflicts", "SAME_EXPERT_SOURCE_CONFLICT", "同一专家引用的文件互相冲突"),
         ("D2_different_dimension_or_horizon", "DIFFERENT_DIMENSION_OR_HORIZON", "维度或时间尺度不同（不是矛盾）"),
         ("C1_input_numbers_consistent", "INPUT_NUMBERS_CONSISTENT", "输入数字一致"),
         ("C2_observations_consistent", "EXPERT_OBSERVATIONS_CONSISTENT", "不同专家的观察一致")]


RULE_ZH = {"X1": "基本面和估值用的同一个财务数字是否一致", "X2": "估值用的股价和技术面的价格是否一致", "X3": "价格走势和已公布财报的增长方向",
           "X4": "公告专家引用的文件之间是否冲突", "X5": "基本面判断的是否亏损和估值的市盈率能否计算"}
EXPLAIN_ZH = {"D2_different_dimension_or_horizon": "维度、时间尺度或数据日期不同（不是矛盾）"}      # Q13 (review N6): a date mismatch is not a 'direction'
EN_ZH = [("one document says the person is leaving the role, another that the person continues in it", "一份公告说此人离任，另一份说此人留任"),
         ("a later document says the incumbent continues in the role another document says a successor was appointed to", "较晚的公告说现任继续担任，另一份公告说已任命了继任者"),
         ("生产模型解读为 negative", "生产模型的规则读法为偏弱"), ("生产模型解读为 positive", "生产模型的规则读法为偏强"),
         ("loss_making = FALSE", "是否亏损：否"), ("loss_making = TRUE", "是否亏损：是"), ("（NOT_MEANINGFUL）", "（没有意义）"),
         ("原因是 NEGATIVE_EARNINGS", "原因是最近一个财年亏损")]
EXPERT_WORD = {"Technical": "技术面", "Macro": "宏观", "Fundamental": "基本面", "Valuation": "估值", "Information": "公告专家"}


def _zh(t: str) -> str:
    """Q13 (review N4): the synthesis layer writes its statements for the technical record (English phrases, metric and field names); the page
    shows them in Chinese - the same words the beginner's report uses; numbers, dates and document ids are not touched"""
    for a, b in EN_ZH:
        t = t.replace(a, b)
    t = re.sub(r"person ([^；]+)；role ([^；]+)；action ([A-Z]+)；dates \[([^\]]*)\]；detail [^。]*",
               lambda m: f"人物 {m.group(1)}；职务 {m.group(2)}；{ {'APPOINTMENT': '任命', 'DEPARTURE': '离任', 'CONTINUATION': '留任'}.get(m.group(3), m.group(3))}；"
                         f"生效日期 {'、'.join(x.strip(chr(39) + ' ') for x in m.group(4).split(','))}", t)
    words = {**BG.TECH_ZH, **BG.METHOD_ZH, **{k: v for k, v in BG.FIELD_ZH.items() if "_" in k or k in ("revenue", "capex", "ebitda")},
             **{k: f"“{v}”" for k, v in BG.CLASS_ZH.items()}, **EXPERT_WORD}
    for k in sorted(words, key=len, reverse=True):
        t = re.sub(rf"(?<![A-Za-z_]){re.escape(k)}(?![A-Za-z_])", words[k], t)
    return t


def _cross(syn: dict) -> dict:
    """the synthesis layer's comparison as it wrote it: per category the count and its statements (in Chinese: _zh); nothing is weighed or scored here.
    Q13 (review N5): a rule not compared is named (X1-X5 in plain Chinese) and listed once per rule"""
    cats = syn.get("categories") or {}
    return {"sections": [{"key": k, "title": t, "explain": EXPLAIN_ZH.get(k) or cats.get(kind) or "", "count": len(syn.get(k) or []),
                          "items": [_zh(str(x.get("statement") or ""))[:700] for x in (syn.get(k) or [])][:12]} for k, kind, t in CROSS],
            "not_compared": [f"{x.get('rule')}「{RULE_ZH.get(x.get('rule'), '一条对照规则')}」没有比较：{_zh(str(x.get('why') or ''))}"
                             for x in (syn.get("X_not_compared") or [])][:12],
            "not_included": [str(x) for x in (syn.get("not_included") or [])]}


def cases() -> str:
    return json.dumps([{"case_id": k, **v} for k, v in DEMO_CASES.items()], ensure_ascii=False)


def _short_version(v) -> str:
    """the version name only - the long development notes inside version strings are not shown on the page"""
    s = str(v or "")
    return s.split(" (")[0][:60]


def analyze(case_id: str) -> str:
    if case_id not in DEMO_CASES:
        return json.dumps({"ok": False, "error": "这个演示只支持列出的合成公司和场景。"}, ensure_ascii=False)
    t = time.time()
    model, kind, _, case_sha = Q.load_case(case_id)
    rec = RUN.run_q8(model, None, "REGISTERED_CASE")
    subject = model.get("subject") or {}
    as_of = model.get("as_of") or rec.get("as_of")
    beg = BG.build(rec, subject.get("security") or "", subject.get("name") or "", str(as_of), {})
    beg["data_notice"] = DT.demo_notice(subject.get("name"), as_of)
    beg.pop("advanced", None)                                  # rule ids and internal codes stay in the downloadable record only
    beg["limits"] = DEMO_LIMITS                                # the beginner report's limits describe the real-data mode; the demo has its own
    record_text = json.dumps(rec, ensure_ascii=False, sort_keys=True, allow_nan=False, default=str)
    sha = hashlib.sha256(record_text.encode("utf-8")).hexdigest()
    experts = []
    plain = {x.get("expert"): x.get("text") for x in beg.get("experts") or []}       # Q13: the beginner report's own sentence (names the field / the other company)
    for eid in R.ORDER:
        r = rec["experts"][eid]
        experts.append({"expert": eid, "name": EXPERT_ZH.get(eid, eid), "status": r["execution_status"],
                        "status_zh": STATUS_ZH.get(r["execution_status"], r["execution_status"]),
                        "version": _short_version(r.get("implementation_version")),
                        "tier": "生产在用(原样调用)" if R.EXPERTS[eid]["tier"] == "PRODUCTION_ACTIVE" else "实验版本(生产中未激活)",
                        "plain": plain.get(eid),
                        "reasons": [{"meaning": x.get("meaning"), "detail": str(x.get("detail") or "")[:300]} for x in (r.get("status_reasons") or [])][:6]})
    view = {"ok": True, "run_id": rec["run_id"], "case_id": case_id, "case": DEMO_CASES[case_id], "subject": subject, "as_of": as_of,
            "started_at": rec.get("started_at_utc") or rec.get("started_at"), "finished_at": rec.get("finished_at_utc") or rec.get("finished_at"), "seconds": round(time.time() - t, 2),   # Q13: the record's keys are *_utc
            "synthesis_status": (rec.get("synthesis") or {}).get("status"), "experts": experts, "beginner": beg, "cross": _cross(rec.get("synthesis") or {}),
            "record_sha256": sha, "case_sha256": case_sha, "python": sys.version.split()[0]}
    return json.dumps({"view": view, "record_text": record_text}, ensure_ascii=False)
