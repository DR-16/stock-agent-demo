"""Orchestrator — Phase 4 pipeline。

严格顺序 + 独立性:
  0. RegimeDetector.detect(as_of, SPY 历史, VIX 历史)  → RegimeSnapshot
  1. 5 独立 Expert(只看 raw ctx)
  2. Bull / Bear Challenge(只看 expert outputs)
  3. Base MetaModel.synthesize(不变) → raw ModelOutput(含 raw probability)
  4. Calibrator.calibrate(raw_prob) → calibrated_prob   (可选,默认 Identity)
  5. RiskEngine.evaluate(meta, experts, challenges, price, regime) → RiskAdjustedDecision
     * 强制不改写 meta / experts

Meta 输出永远保留(raw_probability_positive 单独存字段);
RiskAdjustedDecision 里 raw_signal_preserved 也强制回填。
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional

import pandas as pd

from .data import DataSource, CompanyProfile, Financials
from .data_sources import SECClient
from .models import (
    default_model_set, ExpertModel,
    ChallengeAgent, RuleBasedBullAgent, RuleBasedBearAgent, MetaModel,
)
from .models.base import AnalysisContext, ModelOutput, now_utc
from .models.macro import MACRO_TICKERS
from .regime import RegimeDetector, RegimeSnapshot, SimpleTrendVolatilityRegime
from .risk import RiskEngine, RiskAdjustedDecision
from .calibration import Calibrator, IdentityCalibrator

BENCHMARK_TICKER = "SPY"
VIX_TICKER = "^VIX"


@dataclass
class OrchestrationReport:
    ticker: str
    as_of: datetime
    horizon_days: int
    profile: CompanyProfile
    peer_tickers: list[str]
    model_outputs: list[ModelOutput]
    challenge_outputs: list[ModelOutput] = field(default_factory=list)
    meta_output: Optional[ModelOutput] = None
    regime_snapshot: Optional[RegimeSnapshot] = None
    # 双概率(spec #7):raw = 未校准,calibrated = 经 calibrator
    raw_probability_positive: Optional[float] = None
    calibrated_probability_positive: Optional[float] = None
    calibrator_version: Optional[str] = None
    risk_decision: Optional[RiskAdjustedDecision] = None
    calibrator_provenance: Optional[dict] = None  # Calibrator.to_dict() snapshot
    provider_metadata: Optional[dict] = None      # ProviderMetadata.to_dict() snapshot
    warnings: list[str] = field(default_factory=list)

    def effective_probability(self) -> Optional[float]:
        """当前生效概率:calibrated 优先,fallback raw。"""
        if self.calibrated_probability_positive is not None:
            return self.calibrated_probability_positive
        return self.raw_probability_positive

    def to_dict(self) -> dict:
        return {
            "ticker": self.ticker,
            "as_of": self.as_of.isoformat(),
            "horizon_days": self.horizon_days,
            "profile": {
                "name": self.profile.name,
                "sector": self.profile.sector,
                "industry": self.profile.industry,
                "market_cap": self.profile.market_cap,
                "country": self.profile.country,
                "website": self.profile.website,
            },
            "peer_tickers": self.peer_tickers,
            "regime_snapshot": self.regime_snapshot.to_dict() if self.regime_snapshot else None,
            "meta_output": self.meta_output.to_dict() if self.meta_output else None,
            "raw_probability_positive": self.raw_probability_positive,
            "calibrated_probability_positive": self.calibrated_probability_positive,
            "calibrator_version": self.calibrator_version,
            "calibrator_provenance": self.calibrator_provenance,
            "provider_metadata": self.provider_metadata,
            "risk_decision": self.risk_decision.to_dict() if self.risk_decision else None,
            "challenge_outputs": [o.to_dict() for o in self.challenge_outputs],
            "model_outputs": [o.to_dict() for o in self.model_outputs],
            "warnings": self.warnings,
        }


class Orchestrator:
    def __init__(self,
                 data_source: Optional[DataSource] = None,
                 models: Optional[list[ExpertModel]] = None,
                 bull_agent: Optional[ChallengeAgent] = None,
                 bear_agent: Optional[ChallengeAgent] = None,
                 meta_model: Optional[MetaModel] = None,
                 regime_detector: Optional[RegimeDetector] = None,
                 calibrator: Optional[Calibrator] = None,
                 risk_engine: Optional[RiskEngine] = None,
                 sec_client: Optional[SECClient] = None,
                 peer_limit: int = 12,
                 enable_sec: bool = True,
                 enable_macro: bool = True):
        self.ds = data_source or DataSource()
        self.models = models if models is not None else default_model_set()
        self.bull = bull_agent
        self.bear = bear_agent
        self.meta = meta_model
        self.regime_detector = regime_detector or SimpleTrendVolatilityRegime()
        self.calibrator = calibrator or IdentityCalibrator()
        self.risk_engine = risk_engine or RiskEngine()
        self.sec_client = sec_client or (SECClient() if enable_sec else None)
        self.peer_limit = peer_limit
        self.enable_sec = enable_sec
        self.enable_macro = enable_macro

    def analyze(self, ticker: str, horizon_days: int = 63) -> OrchestrationReport:
        ticker = ticker.upper()
        as_of = now_utc()
        warnings: list[str] = []

        # ---- 数据 ----
        profile = self.ds.get_profile(ticker)
        financials = self.ds.get_financials(ticker)
        price_history = self.ds.get_price_history(ticker, period="2y")
        bench_history = self.ds.get_price_history(BENCHMARK_TICKER, period="2y")
        try:
            vix_history = self.ds.get_price_history(VIX_TICKER, period="1y")
        except Exception:
            vix_history = pd.DataFrame()

        if not profile.name or profile.name == ticker:
            warnings.append(f"未能获取 {ticker} 公司信息,ticker 可能无效")
        if price_history.empty:
            warnings.append(f"无法拉取 {ticker} 价格历史")

        # ---- Phase 5:拉宏观 proxy 到 ctx.macro_prices ----
        macro_prices: dict[str, pd.DataFrame] = {}
        if self.enable_macro:
            for mt in MACRO_TICKERS:
                if mt == VIX_TICKER and not vix_history.empty:
                    macro_prices[mt] = vix_history
                    continue
                try:
                    df = self.ds.get_price_history(mt, period="1y")
                    if df is not None and not df.empty:
                        macro_prices[mt] = df
                except Exception as e:
                    warnings.append(f"macro {mt} 拉取失败: {type(e).__name__}")

        # ---- Phase 5:SEC 数据(insider + 8-K)----
        insider_txns: list[dict] = []
        sec_subs: dict = {}
        if self.enable_sec and self.sec_client is not None:
            try:
                insider_summary = self.sec_client.get_insider_summary(
                    ticker, lookback_days=90, as_of=as_of.date())
                insider_txns = [insider_summary.to_dict()]
            except Exception as e:
                warnings.append(f"SEC insider 拉取失败: {type(e).__name__}")
            try:
                eight_k = self.sec_client.get_8k_event_summary(
                    ticker, lookback_days=180, as_of=as_of.date())
                sec_subs["_8k_summary"] = eight_k
            except Exception as e:
                warnings.append(f"SEC 8-K 拉取失败: {type(e).__name__}")

        peer_tickers = self.ds.get_peers(ticker, limit=self.peer_limit)
        peer_financials: dict[str, Financials] = {}
        peer_price: dict[str, pd.DataFrame] = {}
        peer_profiles: dict[str, CompanyProfile] = {}
        for pt in peer_tickers:
            try:
                peer_financials[pt] = self.ds.get_financials(pt)
                peer_price[pt] = self.ds.get_price_history(pt, period="2y")
                peer_profiles[pt] = self.ds.get_profile(pt)
            except Exception as e:
                warnings.append(f"peer {pt} 拉取失败: {type(e).__name__}")

        # ---- Stage 0: Regime ----
        regime_snapshot: Optional[RegimeSnapshot] = None
        try:
            regime_snapshot = self.regime_detector.detect(
                as_of=as_of,
                benchmark_history=bench_history,
                vix_history=vix_history if not vix_history.empty else None,
            )
        except Exception as e:
            warnings.append(f"regime detector 崩溃: {type(e).__name__}: {e}")

        ctx = AnalysisContext(
            ticker=ticker,
            as_of=as_of,
            horizon_days=horizon_days,
            profile=profile,
            financials=financials,
            price_history=price_history,
            benchmark_history=bench_history,
            peer_financials=peer_financials,
            peer_price_history=peer_price,
            peer_profiles=peer_profiles,
            macro_prices=macro_prices,
            sec_submissions=sec_subs,
            insider_transactions=insider_txns,
        )

        # ---- Stage 1: 5 独立 Expert ----
        expert_outputs: list[ModelOutput] = []
        for model in self.models:
            try:
                expert_outputs.append(model.analyze(ctx))
            except Exception as e:
                warnings.append(f"model {model.name} 崩溃: {type(e).__name__}: {e}")
                expert_outputs.append(model._empty_output(ctx, f"exception: {type(e).__name__}"))

        # ---- Stage 2: Bull / Bear Challenge ----
        bull = self.bull or RuleBasedBullAgent(horizon_days=horizon_days)
        bear = self.bear or RuleBasedBearAgent(horizon_days=horizon_days)
        challenge_outputs: list[ModelOutput] = []
        try:
            challenge_outputs.append(bull.challenge(ctx, expert_outputs))
        except Exception as e:
            warnings.append(f"bull 崩溃: {type(e).__name__}: {e}")
        try:
            challenge_outputs.append(bear.challenge(ctx, expert_outputs))
        except Exception as e:
            warnings.append(f"bear 崩溃: {type(e).__name__}: {e}")

        # ---- Stage 3: Base Meta(不变,不知道 calibration/risk 的存在) ----
        meta = self.meta or MetaModel(horizon_days=horizon_days)
        bull_out = next((o for o in challenge_outputs if o.model_name == "bull_challenge"), None)
        bear_out = next((o for o in challenge_outputs if o.model_name == "bear_challenge"), None)
        meta_output: Optional[ModelOutput] = None
        raw_prob = None
        calibrated_prob = None
        cal_version = None
        try:
            meta_output = meta.synthesize(
                ctx, expert_outputs, bull_out, bear_out,
                market_regime=(regime_snapshot.overall_stance if regime_snapshot else None),
            )
            raw_prob = meta_output.probability_positive
        except Exception as e:
            warnings.append(f"meta 崩溃: {type(e).__name__}: {e}")

        # ---- Stage 4: Calibration(raw → calibrated) ----
        if meta_output is not None and raw_prob is not None:
            try:
                calibrated_prob = float(self.calibrator.calibrate(raw_prob))
                cal_version = self.calibrator.version
            except Exception as e:
                warnings.append(f"calibrator 崩溃: {type(e).__name__}: {e}")

        # ---- Stage 5: Risk Engine ----
        risk_decision: Optional[RiskAdjustedDecision] = None
        if meta_output is not None:
            try:
                risk_decision = self.risk_engine.evaluate(
                    meta_output=meta_output,
                    expert_outputs=expert_outputs,
                    challenge_outputs=challenge_outputs,
                    price_history=price_history,
                    regime=regime_snapshot,
                )
            except Exception as e:
                warnings.append(f"risk engine 崩溃: {type(e).__name__}: {e}")

        # calibrator provenance snapshot
        cal_prov = None
        try:
            cal_prov = self.calibrator.to_dict()
        except Exception:
            pass

        # provider provenance snapshot(v4)
        prov_meta = None
        try:
            if hasattr(self.ds, "provider_metadata"):
                prov_meta = self.ds.provider_metadata().to_dict()
        except Exception:
            pass

        return OrchestrationReport(
            ticker=ticker,
            as_of=as_of,
            horizon_days=horizon_days,
            profile=profile,
            peer_tickers=peer_tickers,
            model_outputs=expert_outputs,
            challenge_outputs=challenge_outputs,
            meta_output=meta_output,
            regime_snapshot=regime_snapshot,
            raw_probability_positive=raw_prob,
            calibrated_probability_positive=calibrated_prob,
            calibrator_version=cal_version,
            risk_decision=risk_decision,
            calibrator_provenance=cal_prov,
            provider_metadata=prov_meta,
            warnings=warnings,
        )


def format_report(report: OrchestrationReport) -> str:
    lines = []
    p = report.profile
    lines.append("=" * 78)
    lines.append(f"{p.name} ({report.ticker})")
    lines.append(f"  Sector: {p.sector or 'n/a'} / {p.industry or 'n/a'}"
                 f"    Market Cap: {_fmt_money(p.market_cap)}")
    lines.append(f"  As of: {report.as_of.strftime('%Y-%m-%d %H:%M UTC')}"
                 f"    Horizon: {report.horizon_days} trading days")
    if report.provider_metadata:
        pm = report.provider_metadata
        lines.append(f"  Data provider: {pm.get('name', 'unknown')} "
                     f"({pm.get('version', '?')})  ·  License: "
                     f"{pm.get('data_license_status', 'unknown')}")
    lines.append("=" * 78)

    # ---- Regime ----
    if report.regime_snapshot:
        r = report.regime_snapshot
        lines.append("")
        lines.append(f"[Market Regime · {r.detector_version}]")
        lines.append(f"  Trend: {r.trend_regime}    Volatility: {r.volatility_regime}"
                     f"    Stance: {r.overall_stance}    Data quality: {r.data_quality:.2f}")
        feats = r.features
        if feats.get("trend_strength_vs_200ma") is not None:
            lines.append(f"  SPY vs 200MA: {feats['trend_strength_vs_200ma']*100:+.1f}%"
                         f"    VIX: {feats.get('vix_close', 'n/a')}"
                         f"    SPY 63d vol(ann): "
                         f"{feats.get('spy_realized_vol_63d_ann', 0)*100:.1f}%" if feats.get('spy_realized_vol_63d_ann') else "")

    # ---- Meta + Risk 头版 ----
    if report.meta_output:
        m = report.meta_output
        lines.append("")
        lines.append("[Meta / Decision Model]")
        sig = f"{m.signal_score:+.3f}" if m.signal_score is not None else "n/a"
        raw_p = f"{report.raw_probability_positive*100:.1f}%" if report.raw_probability_positive is not None else "n/a"
        cal_p = f"{report.calibrated_probability_positive*100:.1f}%" if report.calibrated_probability_positive is not None else "n/a (untrained)"
        lines.append(f"  Composite Signal: {sig}   P(R>0) raw={raw_p}   calibrated={cal_p}")
        lines.append(f"  Confidence (raw): {m.confidence:.2f}   Meta risk: "
                     f"{m.risk_score:.2f}" if m.risk_score is not None else "n/a")
        if m.metadata.get("dampen_factor") is not None:
            lines.append(f"  Disagreement std: {m.metadata['disagreement_std']:.3f}"
                         f"   Dampen: {m.metadata['dampen_factor']:.2f}"
                         f"   Bull/Bear bias: {m.metadata['bull_bear_bias']:+.3f}")

    # ---- Risk Decision ----
    if report.risk_decision:
        rd = report.risk_decision
        lines.append("")
        lines.append(f"[Risk Engine · {rd.engine_version}]")
        lines.append(f"  Conviction: {rd.conviction.value.upper()}"
                     f"   Score: {rd.conviction_score:.2f}"
                     f"   Position hint: {rd.position_size_hint:.2f}"
                     f"   Aggregate risk: {rd.aggregate_risk_score:.2f}")
        lines.append(f"  Raw preserved:  signal={rd.raw_signal_preserved:+.3f}   "
                     f"prob={rd.raw_probability_preserved:.3f}   "
                     f"conf={rd.raw_confidence_preserved:.2f}"
                     if rd.raw_signal_preserved is not None else "  Raw preserved: (meta signal 为 None)")
        if rd.risk_flags:
            lines.append(f"  Risk flags ({len(rd.risk_flags)}):")
            for f in rd.risk_flags:
                lines.append(f"    · [{f.level:<7}] {f.dimension:<22} — {f.rationale}")
        else:
            lines.append("  Risk flags: 无(当前规则集未触发,不代表无风险)")

    # ---- Bull / Bear ----
    for co in report.challenge_outputs:
        lines.append("-" * 78)
        stance = "BULL" if "bull" in co.model_name else "BEAR"
        sig = f"{co.signal_score:+.3f}" if co.signal_score is not None else "n/a"
        rebuts = co.metadata.get('rebuttals_found_by_current_ruleset', 0)
        lines.append(f"[{stance:<4}] signal: {sig}   confidence: {co.confidence:.2f}"
                     f"   rebuttals found (by current ruleset): {rebuts}")
        if rebuts == 0:
            lines.append("   注:'0 rebuttals' 只说明当前规则库/证据集下未找到有效反驳,"
                         "不表示标的客观上无对立面。")
        max_show = 3
        if co.evidence:
            for e in co.evidence[:max_show]:
                v = f"{e.value:.3f}" if e.value is not None else "n/a"
                lines.append(f"    · {e.metric} = {v}  — {e.comment}")
        if co.counter_evidence:
            lines.append(f"  未被驳倒的对立面 (top {min(max_show, len(co.counter_evidence))}):")
            for e in co.counter_evidence[:max_show]:
                v = f"{e.value:.3f}" if e.value is not None else "n/a"
                lines.append(f"    · {e.metric} = {v}  — {e.comment}")

    # ---- 5 Expert 摘要 ----
    lines.append("-" * 78)
    lines.append(f"[5 独立专家]")
    for o in report.model_outputs:
        sig = f"{o.signal_score:+.2f}" if o.signal_score is not None else " n/a"
        risk = f"{o.risk_score:.2f}" if o.risk_score is not None else "n/a"
        note = "  [stub]" if o.metadata.get("status") == "stub" else ""
        lines.append(f"  {o.model_name:<14} signal: {sig:>6}   conf: {o.confidence:.2f}"
                     f"   risk: {risk:>4}   dq: {o.data_quality*100:.0f}%{note}")

    lines.append("-" * 78)
    lines.append(f"对标同行 ({len(report.peer_tickers)}): {', '.join(report.peer_tickers)}")
    if report.warnings:
        lines.append("")
        lines.append("警告:")
        for w in report.warnings:
            lines.append(f"  · {w}")
    lines.append("")
    lines.append("免责: 多模型独立分析 + 对抗验证 + Meta + Calibration + Risk;非投资建议。")
    lines.append(f"      Calibrator: {report.calibrator_version or 'identity (untrained)'};"
                 f" Risk 只调整 conviction/position hint,原始 signal 与 probability 均在 preserved 字段。")
    lines.append("=" * 78)
    return "\n".join(lines)


def _fmt_money(v: float) -> str:
    if not v:
        return "n/a"
    if v >= 1e12:
        return f"${v/1e12:.2f}T"
    if v >= 1e9:
        return f"${v/1e9:.2f}B"
    if v >= 1e6:
        return f"${v/1e6:.2f}M"
    return f"${v:,.0f}"


# 向后兼容
Engine = Orchestrator
AnalysisReport = OrchestrationReport
