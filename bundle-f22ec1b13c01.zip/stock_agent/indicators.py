"""10 个核心指标计算。

每个指标函数:
- 输入 Financials(或 + 价格序列)
- 输出 IndicatorResult(value, higher_is_better, comment)
- value 为 None 表示数据缺失,评分环节会剔除

指标选择依据(教科书 + 学术 factor investing 共识):
1. trailing_pe        估值(低更便宜,但需结合增长)
2. peg                估值 vs 增长(<1 便宜)
3. return_on_equity   盈利质量(DuPont 分解核心)
4. debt_to_equity     财务杠杆(低更安全)
5. fcf_margin         现金流质量(利润≠现金)
6. revenue_5y_cagr    增长(收入端最难 fake)
7. piotroski_f_score  综合财务健康(Piotroski 2000)
8. beta               系统性风险(CAPM)
9. sharpe_2y          风险调整收益(Sharpe 1966)
10. momentum_52w      横截面动量(Jegadeesh-Titman 1993)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

import numpy as np
import pandas as pd

from .data import Financials

TRADING_DAYS_PER_YEAR = 252
RISK_FREE_RATE_ANNUAL = 0.045  # 2026 中期 3M T-Bill 大致水平;可后续接实时


@dataclass
class IndicatorResult:
    name: str
    value: Optional[float]
    higher_is_better: bool
    comment: str = ""

    def is_valid(self) -> bool:
        return self.value is not None and not (
            isinstance(self.value, float) and (np.isnan(self.value) or np.isinf(self.value))
        )


# -------- 基础指标(直接来自 Financials) --------


def trailing_pe(f: Financials) -> IndicatorResult:
    v = f.trailing_pe
    if v is not None and v < 0:
        # 负 PE 意味着亏损,视作数据无效(百分位排序会被排除)
        v = None
    return IndicatorResult("trailing_pe", v, higher_is_better=False,
                           comment="市盈率;低通常更便宜,负值代表亏损")


def peg(f: Financials) -> IndicatorResult:
    v = f.peg_ratio
    if v is not None and v <= 0:
        v = None
    return IndicatorResult("peg", v, higher_is_better=False,
                           comment="PEG = P/E ÷ 增长率;<1 通常被视为便宜")


def return_on_equity(f: Financials) -> IndicatorResult:
    v = f.return_on_equity
    return IndicatorResult("return_on_equity", v, higher_is_better=True,
                           comment="净资产收益率;>15% 优秀")


def debt_to_equity(f: Financials) -> IndicatorResult:
    v = f.debt_to_equity
    return IndicatorResult("debt_to_equity", v, higher_is_better=False,
                           comment="负债/权益;低更安全(不同行业阈值不同)")


def fcf_margin(f: Financials) -> IndicatorResult:
    if f.free_cashflow is None or f.total_revenue in (None, 0):
        return IndicatorResult("fcf_margin", None, higher_is_better=True,
                               comment="自由现金流 / 营收;>10% 优秀")
    return IndicatorResult("fcf_margin", f.free_cashflow / f.total_revenue,
                           higher_is_better=True,
                           comment="自由现金流 / 营收;>10% 优秀")


def revenue_5y_cagr(f: Financials) -> IndicatorResult:
    return IndicatorResult("revenue_5y_cagr", f.revenue_5y_cagr, higher_is_better=True,
                           comment="营收年化增长(yfinance 通常提供 3-4 年财报,按可得区间算 CAGR)")


def beta(f: Financials) -> IndicatorResult:
    return IndicatorResult("beta", f.beta, higher_is_better=False,
                           comment="相对大盘波动;1 = 与市场同步,不必然坏,但 >1.5 风险高")


# -------- Piotroski F-Score(9 项二值加总) --------


def piotroski_f_score(f: Financials) -> IndicatorResult:
    """Piotroski (2000) F-Score,9 项打分,每项达标 +1。

    需要 net_income_history / operating_cashflow_history 等年度序列,
    索引 0 = 最新年度,索引 1 = 上一年度。
    """
    score = 0
    breakdown = []

    def _check(name: str, cond: bool):
        nonlocal score
        if cond:
            score += 1
        breakdown.append(f"{name}={'1' if cond else '0'}")

    ni = f.net_income_history
    ocf = f.operating_cashflow_history
    ta = f.total_assets_history
    ltd = f.long_term_debt_history
    cr = f.current_ratio_history
    shares = f.shares_outstanding_history
    gm = f.gross_margin_history
    at = f.asset_turnover_history

    if len(ni) < 2 or len(ocf) < 1 or len(ta) < 2:
        return IndicatorResult("piotroski_f_score", None, higher_is_better=True,
                               comment="Piotroski 需要至少两年财报,数据不足")

    # 1. 净利润为正
    _check("NI>0", ni[0] > 0)
    # 2. 经营现金流为正
    _check("OCF>0", ocf[0] > 0)
    # 3. ROA 改善(ROA = NI / avg total assets)
    avg_ta_now = (ta[0] + ta[1]) / 2 if len(ta) >= 2 else ta[0]
    roa_now = ni[0] / avg_ta_now if avg_ta_now else 0
    roa_prev = ni[1] / ta[1] if len(ni) >= 2 and len(ta) >= 2 and ta[1] else 0
    _check("ROA↑", roa_now > roa_prev)
    # 4. OCF > NI(盈利质量)
    _check("OCF>NI", ocf[0] > ni[0])
    # 5. 长期负债/资产 下降
    if len(ltd) >= 2 and len(ta) >= 2 and ta[0] and ta[1]:
        _check("LTD/TA↓", (ltd[0] / ta[0]) < (ltd[1] / ta[1]))
    else:
        breakdown.append("LTD/TA↓=n/a")
    # 6. Current Ratio 上升
    if len(cr) >= 2:
        _check("CR↑", cr[0] > cr[1])
    else:
        breakdown.append("CR↑=n/a")
    # 7. 未增发股票
    if len(shares) >= 2:
        _check("Shares≤", shares[0] <= shares[1])
    else:
        breakdown.append("Shares≤=n/a")
    # 8. 毛利率 上升
    if len(gm) >= 2:
        _check("GM↑", gm[0] > gm[1])
    else:
        breakdown.append("GM↑=n/a")
    # 9. 资产周转率 上升
    if len(at) >= 2:
        _check("AT↑", at[0] > at[1])
    else:
        breakdown.append("AT↑=n/a")

    return IndicatorResult("piotroski_f_score", float(score), higher_is_better=True,
                           comment=f"F-Score {score}/9 · " + ", ".join(breakdown))


# -------- 价格衍生指标(需要 price history) --------


def sharpe_2y(price_history: pd.DataFrame) -> IndicatorResult:
    """基于最近 2 年日收益率的年化 Sharpe。"""
    if price_history is None or price_history.empty or "Close" not in price_history.columns:
        return IndicatorResult("sharpe_2y", None, higher_is_better=True,
                               comment="缺少价格数据")
    close = price_history["Close"].dropna()
    if len(close) < 60:
        return IndicatorResult("sharpe_2y", None, higher_is_better=True,
                               comment="价格数据点不足 60 日")
    returns = close.pct_change().dropna()
    if returns.empty or returns.std() == 0:
        return IndicatorResult("sharpe_2y", None, higher_is_better=True,
                               comment="日收益率方差为 0")
    rf_daily = RISK_FREE_RATE_ANNUAL / TRADING_DAYS_PER_YEAR
    excess = returns - rf_daily
    sharpe = np.sqrt(TRADING_DAYS_PER_YEAR) * excess.mean() / returns.std()
    return IndicatorResult("sharpe_2y", float(sharpe), higher_is_better=True,
                           comment="年化 Sharpe;>1 优秀,>2 罕见")


def momentum_52w(price_history: pd.DataFrame,
                 benchmark_history: pd.DataFrame) -> IndicatorResult:
    """52 周相对基准(默认 SPY)的超额收益。"""
    if price_history is None or price_history.empty or "Close" not in price_history.columns:
        return IndicatorResult("momentum_52w", None, higher_is_better=True,
                               comment="缺少价格数据")
    if benchmark_history is None or benchmark_history.empty:
        return IndicatorResult("momentum_52w", None, higher_is_better=True,
                               comment="缺少基准数据")
    close = price_history["Close"].dropna()
    bench = benchmark_history["Close"].dropna()
    if len(close) < 200 or len(bench) < 200:
        return IndicatorResult("momentum_52w", None, higher_is_better=True,
                               comment="价格历史不足 200 日")
    # 取过去 252 日的收益(留 21 日跳过短期反转,可选)
    window = min(252, len(close), len(bench))
    stock_ret = close.iloc[-1] / close.iloc[-window] - 1
    bench_ret = bench.iloc[-1] / bench.iloc[-window] - 1
    excess = stock_ret - bench_ret
    return IndicatorResult("momentum_52w", float(excess), higher_is_better=True,
                           comment=f"过去 {window} 交易日相对基准超额收益")


# -------- 汇总入口 --------


ALL_FUNDAMENTAL_INDICATORS = [
    trailing_pe, peg, return_on_equity, debt_to_equity,
    fcf_margin, revenue_5y_cagr, piotroski_f_score, beta,
]


def compute_all(f: Financials,
                price_history: Optional[pd.DataFrame] = None,
                benchmark_history: Optional[pd.DataFrame] = None) -> list[IndicatorResult]:
    results = [fn(f) for fn in ALL_FUNDAMENTAL_INDICATORS]
    if price_history is not None:
        results.append(sharpe_2y(price_history))
        if benchmark_history is not None:
            results.append(momentum_52w(price_history, benchmark_history))
        else:
            results.append(IndicatorResult("momentum_52w", None, True, "缺少基准"))
    else:
        results.append(IndicatorResult("sharpe_2y", None, True, "缺少价格数据"))
        results.append(IndicatorResult("momentum_52w", None, True, "缺少价格数据"))
    return results
