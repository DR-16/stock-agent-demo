"""Technical Model — 价格与流动性行为。

指标:
  Momentum (12M-1M, 6M, 3M, 1M) — 学术共识:12M-1M 有横截面 alpha
  Relative Strength(相对 benchmark 超额收益)
  Volatility(63d 日收益年化)
  Max Drawdown(2Y)
  Trend(SMA-50 vs SMA-200,Golden/Death Cross)
  Liquidity(20d 平均美元成交额)
  RSI-14

signal_score:
  + 正向动量 + 相对强度 + 价格在 SMA-200 之上
  - 高波动 + 大回撤 + 极低流动性 + RSI 超买

risk_score:高波动 + 大回撤 + 低流动性
"""
from __future__ import annotations

from typing import Optional

import numpy as np
import pandas as pd

from .base import ExpertModel, ModelOutput, Evidence, AnalysisContext

TRADING_DAYS_PER_YEAR = 252
LIQUIDITY_FLOOR_USD = 10_000_000  # 每日 <$10M 视为流动性风险


class TechnicalModel(ExpertModel):
    name = "technical"
    version = "0.1.0"

    def analyze(self, ctx: AnalysisContext) -> ModelOutput:
        px = ctx.price_history
        bench = ctx.benchmark_history
        if px is None or px.empty or "Close" not in px.columns:
            return self._empty_output(ctx, "no price history")

        close = px["Close"].dropna()
        if len(close) < 60:
            return self._empty_output(ctx, "price history < 60 trading days")

        metrics = _compute_technical_metrics(px, bench)
        if all(v is None for v in metrics.values()):
            return self._empty_output(ctx, "no technical metrics computable")

        evidence: list[Evidence] = []
        counter_evidence: list[Evidence] = []
        signal_points = 0.0
        signal_max = 0.0

        # Momentum 12M-1M(去掉最近一月避免短期反转)
        mom_12_1 = metrics.get("momentum_12m_1m")
        if mom_12_1 is not None:
            w = 1.5
            signal_max += w
            if mom_12_1 > 0.10:
                signal_points += w
                evidence.append(Evidence("momentum_12m_1m", mom_12_1, "positive", w,
                                        "12-1M 动量强(> +10%)"))
            elif mom_12_1 < -0.10:
                signal_points -= w
                counter_evidence.append(Evidence("momentum_12m_1m", mom_12_1, "negative", w,
                                                "12-1M 动量弱(< -10%)"))
            else:
                signal_points += w * (mom_12_1 / 0.10)

        # Relative Strength vs Benchmark(过去 6M)
        rs = metrics.get("relative_strength_6m")
        if rs is not None:
            w = 1.0
            signal_max += w
            if rs > 0.05:
                signal_points += w
                evidence.append(Evidence("relative_strength_6m", rs, "positive", w,
                                        "6M 跑赢基准 > 5%"))
            elif rs < -0.05:
                signal_points -= w
                counter_evidence.append(Evidence("relative_strength_6m", rs, "negative", w,
                                                "6M 跑输基准 < -5%"))
            else:
                signal_points += w * (rs / 0.05)

        # Trend:SMA50 vs SMA200
        sma_ratio = metrics.get("sma50_sma200_ratio")
        if sma_ratio is not None:
            w = 1.0
            signal_max += w
            if sma_ratio > 1.02:
                signal_points += w
                evidence.append(Evidence("sma50_sma200_ratio", sma_ratio, "positive", w,
                                        "SMA-50 高于 SMA-200(Golden Cross 状态)"))
            elif sma_ratio < 0.98:
                signal_points -= w
                counter_evidence.append(Evidence("sma50_sma200_ratio", sma_ratio, "negative", w,
                                                "SMA-50 低于 SMA-200(Death Cross 状态)"))

        # Max Drawdown(负值)
        mdd = metrics.get("max_drawdown_2y")
        if mdd is not None:
            w = 0.8
            signal_max += w
            if mdd < -0.40:
                signal_points -= w
                counter_evidence.append(Evidence("max_drawdown_2y", mdd, "negative", w,
                                                "过去 2 年最大回撤 > 40%"))
            elif mdd > -0.15:
                signal_points += w * 0.3
                evidence.append(Evidence("max_drawdown_2y", mdd, "positive", w,
                                        "过去 2 年最大回撤温和"))

        # RSI 超买/超卖
        rsi = metrics.get("rsi_14")
        if rsi is not None:
            w = 0.5
            signal_max += w
            if rsi > 80:
                signal_points -= w
                counter_evidence.append(Evidence("rsi_14", rsi, "negative", w,
                                                "RSI 严重超买(> 80),短期回调风险"))
            elif rsi < 25:
                signal_points += w
                evidence.append(Evidence("rsi_14", rsi, "positive", w,
                                        "RSI 严重超卖(< 25),均值回归机会"))

        # 流动性(evidence only,主要影响 risk score)
        liq = metrics.get("avg_dollar_volume_20d")
        if liq is not None and liq < LIQUIDITY_FLOOR_USD:
            counter_evidence.append(Evidence("avg_dollar_volume_20d", liq, "negative", 1.0,
                                            f"日均成交额 < ${LIQUIDITY_FLOOR_USD/1e6:.0f}M,流动性差"))

        signal_score = self._clamp(signal_points / signal_max) if signal_max > 0 else None

        # data quality:计算成功的 metric 数 / 应有数
        expected = len(metrics)
        present = sum(1 for v in metrics.values() if v is not None)
        data_quality = present / expected if expected else 0.0

        confidence = round(min(0.9, 0.3 + 0.7 * (len(close) / (2 * TRADING_DAYS_PER_YEAR))) * data_quality, 3)

        risk_score = _technical_risk(metrics)

        out = self._new_output(ctx)
        out.signal_score = signal_score
        out.confidence = confidence
        out.risk_score = risk_score
        out.evidence = evidence
        out.counter_evidence = counter_evidence
        out.data_quality = round(data_quality, 3)
        out.data_freshness_days = _price_freshness_days(px, ctx.as_of)
        out.metadata = {
            "metrics": {k: (round(v, 4) if v is not None else None) for k, v in metrics.items()},
            "price_bars_used": len(close),
        }
        return out


def _compute_technical_metrics(px: pd.DataFrame, bench: pd.DataFrame) -> dict[str, Optional[float]]:
    close = px["Close"].dropna()
    m: dict[str, Optional[float]] = {}

    def _ret(days: int) -> Optional[float]:
        if len(close) < days + 1:
            return None
        return float(close.iloc[-1] / close.iloc[-days - 1] - 1)

    # Momentum
    r_1m = _ret(21)
    r_3m = _ret(63)
    r_6m = _ret(126)
    r_12m = _ret(252)
    m["momentum_1m"] = r_1m
    m["momentum_3m"] = r_3m
    m["momentum_6m"] = r_6m
    if r_12m is not None and r_1m is not None:
        # (1+r12) / (1+r1) - 1 ≈ 排除最近 1M 的 11M 收益
        m["momentum_12m_1m"] = (1 + r_12m) / (1 + r_1m) - 1
    else:
        m["momentum_12m_1m"] = None

    # Relative Strength vs benchmark(6M)
    if bench is not None and not bench.empty and "Close" in bench.columns and r_6m is not None:
        bc = bench["Close"].dropna()
        if len(bc) >= 127:
            b_ret = float(bc.iloc[-1] / bc.iloc[-127] - 1)
            m["relative_strength_6m"] = r_6m - b_ret
        else:
            m["relative_strength_6m"] = None
    else:
        m["relative_strength_6m"] = None

    # Volatility (63d annualized)
    ret = close.pct_change().dropna()
    if len(ret) >= 63:
        m["volatility_63d_ann"] = float(ret.iloc[-63:].std() * np.sqrt(TRADING_DAYS_PER_YEAR))
    else:
        m["volatility_63d_ann"] = None

    # Max Drawdown(2Y)
    window = min(len(close), 2 * TRADING_DAYS_PER_YEAR)
    if window >= 60:
        w_close = close.iloc[-window:]
        peak = w_close.cummax()
        dd = w_close / peak - 1
        m["max_drawdown_2y"] = float(dd.min())
    else:
        m["max_drawdown_2y"] = None

    # SMA-50 / SMA-200
    if len(close) >= 200:
        sma50 = float(close.iloc[-50:].mean())
        sma200 = float(close.iloc[-200:].mean())
        m["sma50_sma200_ratio"] = sma50 / sma200 if sma200 > 0 else None
    else:
        m["sma50_sma200_ratio"] = None

    # RSI-14
    m["rsi_14"] = _rsi_14(close)

    # Liquidity: 20d avg dollar volume
    if "Volume" in px.columns:
        vol = px["Volume"].dropna()
        if len(vol) >= 20 and len(close) >= 20:
            dollar_vol = (close.iloc[-20:] * vol.iloc[-20:]).mean()
            m["avg_dollar_volume_20d"] = float(dollar_vol)
        else:
            m["avg_dollar_volume_20d"] = None
    else:
        m["avg_dollar_volume_20d"] = None

    return m


def _rsi_14(close: pd.Series) -> Optional[float]:
    if len(close) < 15:
        return None
    delta = close.diff().dropna()
    gains = delta.clip(lower=0)
    losses = -delta.clip(upper=0)
    avg_gain = gains.iloc[-14:].mean()
    avg_loss = losses.iloc[-14:].mean()
    if avg_loss == 0:
        return 100.0
    rs = avg_gain / avg_loss
    return float(100 - 100 / (1 + rs))


def _technical_risk(m: dict[str, Optional[float]]) -> Optional[float]:
    checks = 0
    pts = 0
    vol = m.get("volatility_63d_ann")
    if vol is not None:
        checks += 1
        if vol > 0.6:
            pts += 2
        elif vol > 0.35:
            pts += 1
    mdd = m.get("max_drawdown_2y")
    if mdd is not None:
        checks += 1
        if mdd < -0.5:
            pts += 2
        elif mdd < -0.25:
            pts += 1
    liq = m.get("avg_dollar_volume_20d")
    if liq is not None:
        checks += 1
        if liq < LIQUIDITY_FLOOR_USD / 10:
            pts += 2
        elif liq < LIQUIDITY_FLOOR_USD:
            pts += 1
    if checks == 0:
        return None
    return round(pts / (checks * 2), 3)


def _price_freshness_days(px: pd.DataFrame, as_of) -> Optional[int]:
    try:
        last = px.index[-1]
        d = last.date() if hasattr(last, "date") else last
        return (as_of.date() - d).days
    except (IndexError, AttributeError):
        return None
