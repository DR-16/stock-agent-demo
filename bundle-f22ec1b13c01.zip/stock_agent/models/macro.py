"""Macro / Regime Model V1 — 用 yfinance 拉的宏观 proxy。

** 命名约定(重要)**:
  本模块所有 "credit" 相关 features 都是 ETF-based proxy,不是 credit spread /
  OAS 本身。ETF price ratio 与真实 OAS(HY yield − IG yield)方向相关,但不等价。
  Feature 名字统一带 `_proxy` 后缀,避免与"真正的 credit spread"混淆。
  Phase 5+ 可接入 FRED BAMLH0A0HYM2 得到真实 OAS。

指标(全部免费,yfinance):
  ^TNX  10Y Treasury Yield(单位 %)
  ^IRX  13-week T-Bill        → 曲线短端
  HYG   高收益公司债 ETF
  LQD   投资级公司债 ETF      → credit_risk_proxy = LQD.close / HYG.close 比值
  UUP   美元 Bullish ETF       → 美元强度 proxy
  ^VIX  波动率(与 Regime Detector 共享)

输出(严格避免因果归因):
  signal_score:Macro V1 规则下当前宏观对 risk-on 的 friendliness [-1, +1]
  risk_score:曲线倒挂 + credit-risk-proxy 恶化 + 高 VIX 加总
  evidence / counter-evidence:仅描述可观测的 feature 变化 + 规则判定,
                              不断言 Fed 政策 / market pricing efficiency 等
  metadata:所有原始 feature 值 + 变化窗口 → 支持完整 reproducibility

独立性:MacroModel 不看 asset 特有数据(financials/price_history);
       只读 ctx.macro_prices。orchestrator 负责提前拉数据填 ctx。

Phase 5+ 可接入 FRED API(需要 free key):
  DGS10, DGS2, CPIAUCSL, BAMLH0A0HYM2 官方数据比 ETF proxy 精确。
"""
from __future__ import annotations

import math
from typing import Optional

import numpy as np
import pandas as pd

from .base import ExpertModel, ModelOutput, Evidence, AnalysisContext

MACRO_TICKERS = ["^TNX", "^IRX", "HYG", "LQD", "UUP", "^VIX"]

# 阈值(经验值,可后续 tune;不是普适真理)
RATE_PROXY_RISE_THRESHOLD = 0.50    # 6M ^TNX 上升 >50bp(单位 %,即 0.5)
RATE_PROXY_FALL_THRESHOLD = -0.50
CURVE_INVERT_THRESHOLD = -0.10       # 10Y − 3M < -10bp 视为倒挂形态
CREDIT_PROXY_STRESS_THRESHOLD = 0.03  # LQD/HYG 3M 比值上升 >3%(ETF proxy,不是真 OAS)
USD_PROXY_STRONG_THRESHOLD = 0.05     # UUP 3M 上升 >5%
VIX_HIGH = 25.0

# 老常量名保留 alias(向下兼容,避免外部导入 break)
RATE_HIKE_BP = RATE_PROXY_RISE_THRESHOLD
RATE_CUT_BP = RATE_PROXY_FALL_THRESHOLD
CREDIT_STRESS_THRESHOLD = CREDIT_PROXY_STRESS_THRESHOLD
USD_STRONG_THRESHOLD = USD_PROXY_STRONG_THRESHOLD


class MacroModel(ExpertModel):
    name = "macro"
    version = "1.0.0-yfinance-proxy"

    def analyze(self, ctx: AnalysisContext) -> ModelOutput:
        prices = ctx.macro_prices or {}
        if not prices:
            return self._empty_output(ctx, "no macro prices in context")

        features = _compute_macro_features(prices, as_of=ctx.as_of)
        if all(v is None for v in features.values()):
            return self._empty_output(ctx, "no macro features computable")

        evidence: list[Evidence] = []
        counter_evidence: list[Evidence] = []
        signal_points = 0.0
        signal_max = 0.0

        # 1. ^TNX 6M 变化 —— 数学差值,不做 Fed 政策 / pricing efficiency 归因
        rate_chg = features.get("tnx_change_6m")
        if rate_chg is not None:
            w = 1.5
            signal_max += w
            if rate_chg > RATE_PROXY_RISE_THRESHOLD:
                signal_points -= w
                counter_evidence.append(Evidence(
                    "tnx_change_6m", rate_chg, "negative", w,
                    f"10Y Treasury yield proxy 6M 上升 +{rate_chg:.2f}pp;"
                    "按 Macro V1 规则视为负面宏观因子(不推断原因)"))
            elif rate_chg < RATE_PROXY_FALL_THRESHOLD:
                signal_points += w
                evidence.append(Evidence(
                    "tnx_change_6m", rate_chg, "positive", w,
                    f"10Y Treasury yield proxy 6M 下降 {rate_chg:.2f}pp;"
                    "按 Macro V1 规则视为正面宏观因子(不推断原因)"))

        # 2. Yield curve slope(^TNX − ^IRX)—— 报告形态,不断言"衰退将至"
        curve = features.get("yield_curve_slope")
        if curve is not None:
            w = 1.2
            signal_max += w
            if curve < CURVE_INVERT_THRESHOLD:
                signal_points -= w
                counter_evidence.append(Evidence(
                    "yield_curve_slope", curve, "negative", w,
                    f"Yield curve proxy 倒挂 (10Y−3M = {curve:.2f}pp);"
                    "该形态在历史样本中与 recession 相关(相关性,非因果)"))
            elif curve > 1.0:
                signal_points += w * 0.5
                evidence.append(Evidence(
                    "yield_curve_slope", curve, "positive", w * 0.5,
                    f"Yield curve proxy 陡峭 (+{curve:.2f}pp)"))

        # 3. Credit-risk proxy(LQD/HYG 3M 比值变化)—— 明说是 ETF proxy,不是 OAS
        credit_chg = features.get("credit_risk_proxy_change_3m")
        if credit_chg is not None:
            w = 1.2
            signal_max += w
            if credit_chg > CREDIT_PROXY_STRESS_THRESHOLD:
                signal_points -= w
                counter_evidence.append(Evidence(
                    "credit_risk_proxy_change_3m", credit_chg, "negative", w,
                    f"LQD/HYG 比值 3M 上升 +{credit_chg*100:.1f}%(ETF-based proxy,"
                    f"非真实 OAS);Macro V1 视为 credit-risk 恶化信号"))
            elif credit_chg < -CREDIT_PROXY_STRESS_THRESHOLD:
                signal_points += w
                evidence.append(Evidence(
                    "credit_risk_proxy_change_3m", credit_chg, "positive", w,
                    f"LQD/HYG 比值 3M 下降 {credit_chg*100:.1f}%(ETF proxy);"
                    "Macro V1 视为 credit-risk 缓和信号"))

        # 4. USD proxy(UUP 3M 变化)—— 事实描述,不做汇率归因
        usd_chg = features.get("usd_proxy_change_3m")
        if usd_chg is not None:
            w = 0.8
            signal_max += w
            if usd_chg > USD_PROXY_STRONG_THRESHOLD:
                signal_points -= w * 0.5
                counter_evidence.append(Evidence(
                    "usd_proxy_change_3m", usd_chg, "negative", w * 0.5,
                    f"USD proxy (UUP) 3M 上升 +{usd_chg*100:.1f}%;"
                    "Macro V1 规则视为对全球风险资产偏负面"))
            elif usd_chg < -USD_PROXY_STRONG_THRESHOLD:
                signal_points += w * 0.5
                evidence.append(Evidence(
                    "usd_proxy_change_3m", usd_chg, "positive", w * 0.5,
                    f"USD proxy (UUP) 3M 下降 {usd_chg*100:.1f}%;Macro V1 视为正面"))

        # 5. VIX 水平 —— 报告数值,不断言"投资者恐慌"
        vix = features.get("vix_level")
        if vix is not None:
            w = 0.8
            signal_max += w
            if vix > VIX_HIGH:
                signal_points -= w
                counter_evidence.append(Evidence(
                    "vix_level", vix, "negative", w,
                    f"VIX = {vix:.1f} > {VIX_HIGH};Macro V1 视为高隐含波动 regime"))
            elif vix < 15:
                signal_points += w * 0.3
                evidence.append(Evidence(
                    "vix_level", vix, "positive", w * 0.3,
                    f"VIX = {vix:.1f} < 15;Macro V1 视为低隐含波动 regime"))

        signal_score = self._clamp(signal_points / signal_max) if signal_max > 0 else None

        # data quality:成功计算的 feature 数
        present = sum(1 for v in features.values() if v is not None)
        expected = len(features)
        data_quality = present / expected if expected else 0.0

        confidence = round(min(0.85, 0.3 + 0.6 * data_quality), 3)

        # risk score:曲线倒挂 + 信用压力 + 高 VIX → 高
        risk_score = _macro_risk(features)

        # freshness:取最新 bar 与 as_of 的差
        freshness_days = _macro_freshness(prices, ctx.as_of)

        out = self._new_output(ctx)
        out.signal_score = signal_score
        out.confidence = confidence
        out.risk_score = risk_score
        out.evidence = evidence
        out.counter_evidence = counter_evidence
        out.data_quality = round(data_quality, 3)
        out.data_freshness_days = freshness_days
        out.metadata = {
            "features": {k: (round(v, 4) if v is not None else None)
                         for k, v in features.items()},
            "macro_tickers_used": [t for t in MACRO_TICKERS if t in prices and not prices[t].empty],
            "regime_hint": _regime_hint(features),
        }
        return out


def _compute_macro_features(prices: dict[str, pd.DataFrame],
                            as_of) -> dict[str, Optional[float]]:
    """所有 feature 值均为原始数学量,不含因果推断。

    命名约定:凡 ETF-based 的 features 名字带 `_proxy` 后缀,以免与真实 OAS 混淆。
    """
    f: dict[str, Optional[float]] = {
        "tnx_level": None,
        "irx_level": None,
        "yield_curve_slope": None,
        "tnx_change_6m": None,
        # credit_risk_proxy_* :ETF price ratio-based;不是真 OAS
        "credit_risk_proxy_ratio": None,
        "credit_risk_proxy_change_3m": None,
        "usd_proxy_level": None,
        "usd_proxy_change_3m": None,
        "vix_level": None,
    }

    tnx = _closes_to(prices.get("^TNX"), as_of)
    irx = _closes_to(prices.get("^IRX"), as_of)
    hyg = _closes_to(prices.get("HYG"), as_of)
    lqd = _closes_to(prices.get("LQD"), as_of)
    uup = _closes_to(prices.get("UUP"), as_of)
    vix = _closes_to(prices.get("^VIX"), as_of)

    if tnx is not None and len(tnx) > 0:
        f["tnx_level"] = float(tnx.iloc[-1])
        if len(tnx) >= 130:
            f["tnx_change_6m"] = float(tnx.iloc[-1] - tnx.iloc[-130])

    if irx is not None and len(irx) > 0:
        f["irx_level"] = float(irx.iloc[-1])
        if f["tnx_level"] is not None:
            f["yield_curve_slope"] = f["tnx_level"] - f["irx_level"]

    if lqd is not None and hyg is not None and len(lqd) > 0 and len(hyg) > 0:
        ratio_now = float(lqd.iloc[-1] / hyg.iloc[-1])
        f["credit_risk_proxy_ratio"] = ratio_now
        if len(lqd) >= 65 and len(hyg) >= 65:
            ratio_prev = float(lqd.iloc[-65] / hyg.iloc[-65])
            f["credit_risk_proxy_change_3m"] = ratio_now / ratio_prev - 1

    if uup is not None and len(uup) > 0:
        f["usd_proxy_level"] = float(uup.iloc[-1])
        if len(uup) >= 65:
            f["usd_proxy_change_3m"] = float(uup.iloc[-1] / uup.iloc[-65] - 1)

    if vix is not None and len(vix) > 0:
        f["vix_level"] = float(vix.iloc[-1])

    return f


def _closes_to(df: Optional[pd.DataFrame], as_of) -> Optional[pd.Series]:
    """截断到 <= as_of,返回 Close 序列。no-lookahead 保护。"""
    if df is None or df.empty or "Close" not in df.columns:
        return None
    idx = df.index
    if getattr(idx, "tz", None) is not None:
        df = df.copy()
        df.index = idx.tz_localize(None)
    cutoff = pd.Timestamp(as_of.date() if hasattr(as_of, "date") else as_of)
    sliced = df.loc[:cutoff]
    if sliced.empty:
        return None
    return sliced["Close"].dropna()


def _macro_risk(f: dict[str, Optional[float]]) -> Optional[float]:
    """系统性风险粗略打分:curve 倒挂 + credit-risk proxy 恶化 + 高 VIX 加总。"""
    checks = 0
    pts = 0
    curve = f.get("yield_curve_slope")
    if curve is not None:
        checks += 1
        if curve < CURVE_INVERT_THRESHOLD:
            pts += 2
        elif curve < 0:
            pts += 1
    credit = f.get("credit_risk_proxy_change_3m")
    if credit is not None:
        checks += 1
        if credit > 0.05:
            pts += 2
        elif credit > 0.02:
            pts += 1
    vix = f.get("vix_level")
    if vix is not None:
        checks += 1
        if vix > 30:
            pts += 2
        elif vix > 20:
            pts += 1
    if checks == 0:
        return None
    return round(pts / (checks * 2), 3)


def _macro_freshness(prices: dict, as_of) -> Optional[int]:
    """所有宏观 ticker 里最陈旧的距 as_of 天数。"""
    if not prices:
        return None
    max_gap = None
    cutoff = as_of.date() if hasattr(as_of, "date") else as_of
    for df in prices.values():
        if df is None or df.empty:
            continue
        idx = df.index
        if getattr(idx, "tz", None) is not None:
            last = idx.tz_localize(None)[-1]
        else:
            last = idx[-1]
        d = last.date() if hasattr(last, "date") else last
        gap = (cutoff - d).days
        if max_gap is None or gap > max_gap:
            max_gap = gap
    return int(max_gap) if max_gap is not None else None


def _regime_hint(f: dict[str, Optional[float]]) -> str:
    """从 features 推导一个可读 hint,存 metadata 便于查询。

    label 是 Macro V1 规则下的分类,不断言真实经济状态。
    """
    curve = f.get("yield_curve_slope")
    credit = f.get("credit_risk_proxy_change_3m")
    vix = f.get("vix_level")
    if (curve is not None and curve < CURVE_INVERT_THRESHOLD) or \
       (credit is not None and credit > 0.05) or \
       (vix is not None and vix > 30):
        return "macro_stress"
    if (curve is not None and curve > 1.0) and \
       (credit is None or credit < 0) and \
       (vix is not None and vix < 20):
        return "macro_supportive"
    return "macro_neutral"
