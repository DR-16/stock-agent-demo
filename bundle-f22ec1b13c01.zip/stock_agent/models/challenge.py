"""Bull / Bear Challenge Layer — 对抗式验证。

spec 明确:
  * Bull Agent 主动寻找支持上涨的证据
  * Bear Agent 主动寻找支持下跌或反对当前判断的证据
  * 两个 Agent 必须尽可能寻找能够推翻已有结论的证据,而不是替已有结论辩护

设计:
  * ChallengeAgent 消费 5 专家的 ModelOutput,不看 raw data(避免重复计算)
  * 规则驱动版本:遍历所有 evidence / counter-evidence,做对抗式反问
  * LLM 版本(Phase 5):同接口,替换 challenge() 实现即可
  * 输出用同一 ModelOutput schema,model_name = "bull_challenge" | "bear_challenge"
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Optional

from .base import ExpertModel, ModelOutput, Evidence, AnalysisContext


class ChallengeAgent(ABC):
    """接收 expert outputs,主动质疑,输出 challenge signal + 反驳证据。"""

    name: str = "challenge_base"
    version: str = "0.1.0"
    stance: str = "neutral"  # "bull" | "bear"

    def __init__(self, horizon_days: int = 63):
        self.horizon_days = horizon_days

    @abstractmethod
    def challenge(self, ctx: AnalysisContext,
                  expert_outputs: list[ModelOutput]) -> ModelOutput:
        """返回一个 ModelOutput,signal 方向受 stance 约束。

        Bull: signal ∈ [0, 1](只支持看多论)
        Bear: signal ∈ [-1, 0](只支持看空论)
        """

    def _new_output(self, ctx: AnalysisContext) -> ModelOutput:
        return ModelOutput(
            model_name=self.name,
            model_version=self.version,
            asset=ctx.ticker,
            as_of=ctx.as_of,
            horizon_days=self.horizon_days,
        )


# -------- 规则驱动 Bull / Bear --------


class RuleBasedBullAgent(ChallengeAgent):
    """规则驱动 Bull:

      1. 汇总所有 expert 的 positive evidence(自然支持看多)
      2. 对每条 counter-evidence,尝试用其他 expert 的 evidence 驳回
         → 若能驳回则 counter 视作"已中和",不影响 bull signal
      3. Bull signal 强度 = (支撑度 - 有效反对度) 归一化 → [0, 1]
      4. 强制:即便找不到支撑,信号最多为 0(不能给负数,否则不叫 bull)
    """

    name = "bull_challenge"
    stance = "bull"

    def challenge(self, ctx, expert_outputs):
        out = self._new_output(ctx)
        pos_evidence: list[Evidence] = []
        neg_evidence: list[Evidence] = []
        for eo in expert_outputs:
            if eo.model_name in ("bull_challenge", "bear_challenge", "meta"):
                continue
            pos_evidence.extend(eo.evidence)
            neg_evidence.extend(eo.counter_evidence)

        # 每条 counter 尝试用 positive 反驳
        rebuttals: list[Evidence] = []
        neutralized = 0
        for c in neg_evidence:
            reb = _find_bull_rebuttal(c, pos_evidence)
            if reb:
                neutralized += 1
                rebuttals.append(Evidence(
                    metric=f"rebut::{c.metric}",
                    value=None,
                    interpretation="positive",
                    weight=c.weight * 0.6,
                    comment=f"驳 {c.metric}:{reb}",
                ))

        support_weight = sum(e.weight for e in pos_evidence)
        effective_opposition = sum(e.weight for e in neg_evidence) - sum(r.weight for r in rebuttals)
        effective_opposition = max(0.0, effective_opposition)
        total = support_weight + effective_opposition

        if total == 0:
            out.signal_score = 0.0
            out.confidence = 0.0
            out.evidence = rebuttals
            out.counter_evidence = []
            out.data_quality = 0.0
            out.metadata = {"support": 0.0, "opposition": 0.0, "neutralized": 0}
            return out

        strength = support_weight / total  # ∈ [0, 1]
        out.signal_score = round(max(0.0, strength), 4)
        # confidence:证据量 + 未被反驳的 counter 越少越自信
        out.confidence = round(min(0.9, 0.3 + 0.6 * (1 - effective_opposition / max(1, total))), 3)
        out.evidence = pos_evidence + rebuttals
        out.counter_evidence = [c for c in neg_evidence
                                if _find_bull_rebuttal(c, pos_evidence) is None]
        out.data_quality = round(min(1.0, len(pos_evidence) / 10.0), 3)
        out.metadata = {
            "support_weight": round(support_weight, 2),
            "opposition_weight_raw": round(sum(e.weight for e in neg_evidence), 2),
            "opposition_weight_effective": round(effective_opposition, 2),
            "rebuttals_found_by_current_ruleset": neutralized,
            "total_positive_evidence": len(pos_evidence),
            "total_counter_evidence": len(neg_evidence),
            "interpretation_note": (
                "'rebuttals_found_by_current_ruleset' 只反映当前规则库能匹配到的驳论;"
                "值为 0 只说明规则库/证据集下未找到有效反驳,不代表标的客观上无缺陷。"
            ),
        }
        return out


class RuleBasedBearAgent(ChallengeAgent):
    """规则驱动 Bear(镜像 Bull)。

      Bear signal ∈ [-1, 0]。
      核心:遍历所有 positive evidence,用其他 expert 的 counter 驳回。
    """

    name = "bear_challenge"
    stance = "bear"

    def challenge(self, ctx, expert_outputs):
        out = self._new_output(ctx)
        pos_evidence: list[Evidence] = []
        neg_evidence: list[Evidence] = []
        for eo in expert_outputs:
            if eo.model_name in ("bull_challenge", "bear_challenge", "meta"):
                continue
            pos_evidence.extend(eo.evidence)
            neg_evidence.extend(eo.counter_evidence)

        rebuttals: list[Evidence] = []
        neutralized = 0
        for p in pos_evidence:
            reb = _find_bear_rebuttal(p, neg_evidence)
            if reb:
                neutralized += 1
                rebuttals.append(Evidence(
                    metric=f"rebut::{p.metric}",
                    value=None,
                    interpretation="negative",
                    weight=p.weight * 0.6,
                    comment=f"驳 {p.metric}:{reb}",
                ))

        opposition = sum(e.weight for e in neg_evidence)
        effective_support = sum(e.weight for e in pos_evidence) - sum(r.weight for r in rebuttals)
        effective_support = max(0.0, effective_support)
        total = opposition + effective_support

        if total == 0:
            out.signal_score = 0.0
            out.confidence = 0.0
            out.evidence = rebuttals
            out.counter_evidence = []
            out.data_quality = 0.0
            out.metadata = {"opposition": 0.0, "support": 0.0, "neutralized": 0}
            return out

        strength = opposition / total  # ∈ [0, 1]
        out.signal_score = round(-max(0.0, strength), 4)  # bear 输出负号
        out.confidence = round(min(0.9, 0.3 + 0.6 * (1 - effective_support / max(1, total))), 3)
        out.evidence = neg_evidence + rebuttals  # bear 的"支持证据"是 counter-evidence
        out.counter_evidence = [p for p in pos_evidence
                                if _find_bear_rebuttal(p, neg_evidence) is None]
        out.data_quality = round(min(1.0, len(neg_evidence) / 10.0), 3)
        out.metadata = {
            "opposition_weight": round(opposition, 2),
            "support_weight_raw": round(sum(e.weight for e in pos_evidence), 2),
            "support_weight_effective": round(effective_support, 2),
            "rebuttals_found_by_current_ruleset": neutralized,
            "total_positive_evidence": len(pos_evidence),
            "total_counter_evidence": len(neg_evidence),
            "interpretation_note": (
                "'rebuttals_found_by_current_ruleset' 只反映当前规则库能匹配到的驳论;"
                "值为 0 只说明规则库/证据集下未找到有效反驳,不代表标的客观上无风险。"
            ),
        }
        return out


# -------- 反驳规则库 --------

# spec 强调 Bull/Bear "必须寻找推翻已有结论的证据"。
# 规则驱动的反驳基于跨 metric 的经济学关联:
#   * "P/E 高" 可以被 "高增长" 驳(合理估值上升)
#   * "债务高" 可以被 "利息覆盖高 + 现金流强" 驳
#   * "近期动量弱" 可以被 "长期动量强 + 财务改善" 驳
#   * "F-Score 8/9" 可以被 "近期收入增长掉头" 驳
# 这些规则是经济学常识,不是主观判断。


_BULL_REBUTTALS = {
    "trailing_pe": [
        ("revenue_growth_1y", lambda v: v is not None and v > 0.15, "高营收增长支撑估值"),
        ("revenue_cagr_multi_yr", lambda v: v is not None and v > 0.15, "多年高增长支撑估值"),
        ("return_on_equity", lambda v: v is not None and v > 0.20, "高 ROE 支撑估值溢价"),
    ],
    "forward_pe": [
        ("earnings_growth", lambda v: v is not None and v > 0.20, "高 EPS 增长支撑前瞻估值"),
        ("revenue_growth_1y", lambda v: v is not None and v > 0.15, "高营收增长支撑前瞻估值"),
    ],
    "peg": [
        ("revenue_cagr_multi_yr", lambda v: v is not None and v > 0.20, "多年高增长质量支撑 PEG"),
    ],
    "ev_ebitda": [
        ("operating_margin", lambda v: v is not None and v > 0.30, "高利润率支撑高估值"),
        ("revenue_growth_1y", lambda v: v is not None and v > 0.15, "高增长支撑高估值"),
    ],
    "ev_sales": [
        ("gross_margin", lambda v: v is not None and v > 0.60, "极高毛利支撑高销售倍数"),
    ],
    "p_fcf": [
        ("revenue_cagr_multi_yr", lambda v: v is not None and v > 0.20, "高营收增长支撑现金流倍数"),
    ],
    "fcf_yield": [
        ("revenue_cagr_multi_yr", lambda v: v is not None and v > 0.20, "高增长期望支撑低当期 yield"),
    ],
    "price_to_book": [
        ("return_on_equity", lambda v: v is not None and v > 0.25, "极高 ROE 支撑高 P/B"),
    ],
    "debt_to_equity": [
        ("interest_coverage", lambda v: v is not None and v > 8.0, "高利息覆盖抵消债务担忧"),
        ("fcf_margin", lambda v: v is not None and v > 0.15, "强现金流可轻松偿债"),
    ],
    "interest_coverage": [
        ("fcf_margin", lambda v: v is not None and v > 0.15, "自由现金流足以覆盖利息"),
    ],
    "max_drawdown_2y": [
        ("momentum_12m_1m", lambda v: v is not None and v > 0.15, "长期动量已经修复"),
    ],
    "momentum_12m_1m": [
        ("revenue_growth_1y", lambda v: v is not None and v > 0.15, "基本面改善,动量将追赶"),
    ],
    "avg_dollar_volume_20d": [],  # 流动性问题难驳
    "rsi_14": [
        ("revenue_growth_1y", lambda v: v is not None and v > 0.20, "增长强,超买属合理"),
    ],
}

_BEAR_REBUTTALS = {
    "return_on_equity": [
        ("debt_to_equity", lambda v: v is not None and v > 2.0, "高 ROE 靠杠杆撑起,风险大"),
        ("earnings_quality", lambda v: v is not None and v < 0.7, "利润质量差,ROE 含水分"),
    ],
    "roic": [
        ("debt_to_equity", lambda v: v is not None and v > 2.0, "投资回报靠杠杆放大"),
    ],
    "piotroski_f_score": [
        ("revenue_growth_1y", lambda v: v is not None and v < 0, "F-Score 是回顾指标,增长已掉头"),
    ],
    "fcf_margin": [
        ("revenue_growth_1y", lambda v: v is not None and v < 0, "现金流强但增长熄火"),
    ],
    "gross_margin": [
        ("revenue_growth_1y", lambda v: v is not None and v < 0, "毛利高但收入萎缩"),
    ],
    "operating_margin": [
        ("revenue_growth_1y", lambda v: v is not None and v < 0, "利润率高但收入萎缩"),
    ],
    "net_margin": [
        ("revenue_growth_1y", lambda v: v is not None and v < 0, "净利率高但收入萎缩"),
    ],
    "revenue_growth_1y": [
        ("gross_margin", lambda v: v is not None and v < 0.20, "增长靠低毛利业务,质量差"),
        ("fcf_margin", lambda v: v is not None and v < 0, "增长烧钱,不产生现金"),
    ],
    "revenue_cagr_multi_yr": [
        ("revenue_growth_1y", lambda v: v is not None and v < 0, "多年 CAGR 好但最近一年掉头"),
    ],
    "momentum_12m_1m": [
        ("revenue_growth_1y", lambda v: v is not None and v < -0.05, "动量强但基本面已崩"),
    ],
    "sma50_sma200_ratio": [
        ("revenue_growth_1y", lambda v: v is not None and v < -0.05, "技术形态好但基本面恶化"),
    ],
    "relative_strength_6m": [
        ("revenue_growth_1y", lambda v: v is not None and v < -0.05, "跑赢大盘但基本面转弱"),
    ],
    "peg": [
        ("interest_coverage", lambda v: v is not None and v < 2.0, "PEG 便宜但债务承压"),
    ],
    "fcf_yield": [
        ("revenue_growth_1y", lambda v: v is not None and v < 0, "yield 高但增长熄火,可能是 value trap"),
    ],
}


def _find_bull_rebuttal(counter: Evidence, pos_evidence: list[Evidence]) -> Optional[str]:
    """给一条 counter,返回能驳倒它的 positive 证据描述(如有)。"""
    rules = _BULL_REBUTTALS.get(counter.metric, [])
    for target_metric, predicate, msg in rules:
        for p in pos_evidence:
            if p.metric == target_metric and predicate(p.value):
                return f"{msg}({target_metric}={_fmt(p.value)})"
    return None


def _find_bear_rebuttal(positive: Evidence, neg_evidence: list[Evidence]) -> Optional[str]:
    rules = _BEAR_REBUTTALS.get(positive.metric, [])
    for target_metric, predicate, msg in rules:
        for c in neg_evidence:
            if c.metric == target_metric and predicate(c.value):
                return f"{msg}({target_metric}={_fmt(c.value)})"
    return None


def _fmt(v: Optional[float]) -> str:
    return f"{v:.3f}" if v is not None else "n/a"


# ---- LLM 插槽(Phase 5 才实现)----


class LLMBullAgent(ChallengeAgent):
    """留位:后续接 LLM 的 Bull。目前 raise。"""
    name = "bull_challenge_llm"
    stance = "bull"

    def challenge(self, ctx, expert_outputs):
        raise NotImplementedError("Phase 5:LLM Bull 接入,当前不启用")


class LLMBearAgent(ChallengeAgent):
    name = "bear_challenge_llm"
    stance = "bear"

    def challenge(self, ctx, expert_outputs):
        raise NotImplementedError("Phase 5:LLM Bear 接入,当前不启用")
