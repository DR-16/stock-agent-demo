"""Meta / Decision Model — 综合 5 专家 + Bull/Bear 输出最终判断。

spec 明确:
  * Meta 不重新分析公司,只读 5 专家的结构化输出
  * 学习:在什么资产/行业/时间尺度/regime 下,哪个 model 更值得相信
  * Prediction = Σ wi(X, Regime, Horizon) × Prediction_i
  * wi 根据 out-of-sample 历史表现学习和调整

Phase 3 v1(未接学习权重):
  * 用 confidence 加权(Phase 4 才用 backtest 学 wi)
  * Bull/Bear 作为对抗修正
  * 分歧惩罚:5 专家 signal std 大 → confidence 削弱
  * probability_positive:sigmoid(k × signal),k 固定 2.5;Phase 4 用 calibration 学
  * expected_return:留 None,Phase 4 用 backtest 学 signal → return 映射
"""
from __future__ import annotations

import math
from typing import Optional

import numpy as np

from .base import ExpertModel, ModelOutput, Evidence, AnalysisContext


DEFAULT_SIGMOID_K = 2.5           # sigmoid 斜率;Phase 4 用 calibration 学
MIN_EXPERT_CONFIDENCE = 0.15      # confidence 低于此不参与综合
DISAGREEMENT_HALF_LIFE_STD = 0.5  # signal std 达此值时 confidence 折半
EVIDENCE_TOP_N = 8                # 报告里展示的证据条数上限


class MetaModel:
    """不继承 ExpertModel — 因为它不接 raw context,只消费 ModelOutput 列表。"""

    name = "meta"
    version = "0.1.0"

    def __init__(self, horizon_days: int = 63,
                 sigmoid_k: float = DEFAULT_SIGMOID_K,
                 expert_weights: Optional[dict[str, float]] = None,
                 learned_weights_provenance: Optional[dict] = None):
        """learned_weights_provenance 是 LearnedWeights.provenance_dict() 的输出,
        Meta 把它写入 output.metadata 供 ledger 存;Meta 本身不做权重计算。
        """
        self.horizon_days = horizon_days
        self.sigmoid_k = sigmoid_k
        # Phase 4 会从 backtest 学到 model_name → weight
        # v1 全部为 1.0(纯 confidence 加权)
        self.expert_weights = expert_weights or {}
        self.learned_weights_provenance = learned_weights_provenance

    def synthesize(self,
                   ctx: AnalysisContext,
                   expert_outputs: list[ModelOutput],
                   bull_output: Optional[ModelOutput] = None,
                   bear_output: Optional[ModelOutput] = None,
                   market_regime: Optional[str] = None) -> ModelOutput:

        experts = [o for o in expert_outputs
                   if o.model_name not in ("bull_challenge", "bear_challenge", "meta")]

        # 1. 有效专家:signal 非空 且 confidence 达标
        valid = [(o, self.expert_weights.get(o.model_name, 1.0) * o.confidence)
                 for o in experts
                 if o.signal_score is not None and o.confidence >= MIN_EXPERT_CONFIDENCE]

        out = ModelOutput(
            model_name=self.name,
            model_version=self.version,
            asset=ctx.ticker,
            as_of=ctx.as_of,
            horizon_days=self.horizon_days,
        )

        if not valid:
            out.signal_score = None
            out.confidence = 0.0
            out.metadata = {
                "reason": "no expert with signal & confidence >= threshold",
                "min_confidence_threshold": MIN_EXPERT_CONFIDENCE,
                "expert_participation": {o.model_name: {
                    "signal": o.signal_score,
                    "confidence": o.confidence,
                    "excluded": True,
                } for o in experts},
            }
            return out

        # 2. 加权综合 signal
        signals = np.array([o.signal_score for o, _ in valid])
        weights = np.array([w for _, w in valid])
        if weights.sum() <= 0:
            weighted_signal = float(signals.mean())
        else:
            weighted_signal = float((signals * weights).sum() / weights.sum())

        # 3. Bull/Bear 修正
        bull_s = float(bull_output.signal_score) if (bull_output and bull_output.signal_score is not None) else 0.0
        bear_s_pos = float(-bear_output.signal_score) if (bear_output and bear_output.signal_score is not None) else 0.0
        bull_bear_bias = (bull_s - bear_s_pos) * 0.30  # 最多 ±0.30 的额外偏置
        bull_bear_extremeness = min(bull_s, bear_s_pos)  # 两边都强 → 冲突

        # 4. 分歧惩罚
        disagreement_std = float(signals.std(ddof=0)) if len(signals) >= 2 else 0.0
        # 半衰式:std=0 → 1.0;std=DISAGREEMENT_HALF_LIFE_STD → 0.5
        dampen = 1.0 / (1.0 + (disagreement_std / DISAGREEMENT_HALF_LIFE_STD) ** 2)

        raw_signal = weighted_signal + bull_bear_bias
        composite_signal = _clamp(raw_signal * dampen, -1.0, 1.0)

        # 5. Probability positive:sigmoid
        prob_positive = _sigmoid(self.sigmoid_k * composite_signal)

        # 6. Confidence
        weighted_conf = float((weights * np.array([o.confidence for o, _ in valid])).sum()
                              / max(1e-9, weights.sum()))
        confidence = weighted_conf * dampen * (1.0 - bull_bear_extremeness * 0.3)
        confidence = _clamp(confidence, 0.0, 1.0)

        # 7. Risk score:以 data_quality 为权重的加权平均
        risks = [(o.risk_score, o.data_quality) for o in experts
                 if o.risk_score is not None]
        if risks:
            r_arr = np.array([r for r, _ in risks])
            w_arr = np.array([q for _, q in risks])
            if w_arr.sum() > 0:
                risk_score = float((r_arr * w_arr).sum() / w_arr.sum())
            else:
                risk_score = float(r_arr.mean())
        else:
            risk_score = None

        # 8. 汇总证据(按权重取 top-N)
        all_pos: list[Evidence] = []
        all_neg: list[Evidence] = []
        for o in experts:
            all_pos.extend(o.evidence)
            all_neg.extend(o.counter_evidence)
        if bull_output:
            all_pos.extend(bull_output.evidence)
        if bear_output:
            all_neg.extend(bear_output.evidence)  # bear 的 evidence 是 counter 派

        all_pos.sort(key=lambda e: e.weight, reverse=True)
        all_neg.sort(key=lambda e: e.weight, reverse=True)

        out.signal_score = round(composite_signal, 4)
        out.probability_positive = round(prob_positive, 4)
        out.expected_return = None  # Phase 4 接入 backtest 学到的映射
        out.confidence = round(confidence, 3)
        out.risk_score = round(risk_score, 3) if risk_score is not None else None
        out.evidence = all_pos[:EVIDENCE_TOP_N]
        out.counter_evidence = all_neg[:EVIDENCE_TOP_N]
        out.data_quality = round(np.mean([o.data_quality for o in experts]), 3)
        out.metadata = {
            "sigmoid_k": self.sigmoid_k,
            "market_regime": market_regime,
            "raw_weighted_signal": round(weighted_signal, 4),
            "bull_bear_bias": round(bull_bear_bias, 4),
            "bull_signal": round(bull_s, 4),
            "bear_signal": round(-bear_s_pos, 4),
            "disagreement_std": round(disagreement_std, 4),
            "dampen_factor": round(dampen, 4),
            "expert_participation": {o.model_name: {
                "signal": o.signal_score,
                "confidence": o.confidence,
                "weight_used": float(w),
            } for (o, w) in valid},
            "excluded_experts": [o.model_name for o in experts
                                 if o.signal_score is None or o.confidence < MIN_EXPERT_CONFIDENCE],
            "expert_weights_config": self.expert_weights or "uniform (default prior)",
            "learned_weights_provenance": self.learned_weights_provenance,
        }
        return out


def _sigmoid(x: float) -> float:
    # 溢出安全
    if x >= 50:
        return 1.0
    if x <= -50:
        return 0.0
    return 1.0 / (1.0 + math.exp(-x))


def _clamp(v: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, v))
