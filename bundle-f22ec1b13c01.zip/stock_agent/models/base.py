"""Expert Model 抽象基类 + 统一 I/O schema。

每个专家模型独立分析 AnalysisContext,不依赖其他模型输出。
所有模型输出结构相同(ModelOutput),便于 Meta / Judge / Risk 层消费。
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from typing import Optional

import pandas as pd

from ..data import CompanyProfile, Financials


@dataclass
class Evidence:
    """证据条目:一个可验证的观察,支持或反对某个判断。"""
    metric: str
    value: Optional[float]
    interpretation: str  # "positive" | "negative" | "neutral"
    weight: float = 1.0
    comment: str = ""

    def to_dict(self) -> dict:
        return asdict(self)


@dataclass
class ModelOutput:
    """5 个专家模型的统一输出结构。所有下游层(Meta/Bull-Bear/Risk)只消费这个。

    字段含义:
      signal_score: -1(强烈看空)到 +1(强烈看多),None 表示模型放弃判断
      expected_return: 该模型对 horizon_days 内的期望收益预测(如适用)
      probability_positive: P(Return > 0 over horizon)
      confidence: 模型对自身输出的信心 0-1,由 data_quality + peer_count 决定
      risk_score: 该资产在该模型视角下的风险 0-1(higher=更危险)
      evidence: 支持当前 signal 的证据
      counter_evidence: 反对当前 signal 的证据(强制自省,减少 confirmation bias)
      data_quality: 该模型所需 feature 的可得比例 0-1
      data_freshness_days: 输入数据最"陈旧"的项距今天数,越大越不可靠
    """
    model_name: str
    model_version: str
    asset: str
    as_of: datetime
    horizon_days: int
    signal_score: Optional[float] = None
    expected_return: Optional[float] = None
    probability_positive: Optional[float] = None
    confidence: float = 0.0
    risk_score: Optional[float] = None
    evidence: list[Evidence] = field(default_factory=list)
    counter_evidence: list[Evidence] = field(default_factory=list)
    data_quality: float = 0.0
    data_freshness_days: Optional[int] = None
    metadata: dict = field(default_factory=dict)

    def is_actionable(self) -> bool:
        return self.signal_score is not None and self.confidence >= 0.3

    def to_dict(self) -> dict:
        return {
            "model_name": self.model_name,
            "model_version": self.model_version,
            "asset": self.asset,
            "as_of": self.as_of.isoformat(),
            "horizon_days": self.horizon_days,
            "signal_score": self.signal_score,
            "expected_return": self.expected_return,
            "probability_positive": self.probability_positive,
            "confidence": self.confidence,
            "risk_score": self.risk_score,
            "evidence": [e.to_dict() for e in self.evidence],
            "counter_evidence": [e.to_dict() for e in self.counter_evidence],
            "data_quality": self.data_quality,
            "data_freshness_days": self.data_freshness_days,
            "metadata": self.metadata,
        }


@dataclass
class AnalysisContext:
    """所有模型的共同输入。orchestrator 一次性构造,分发给每个模型。

    模型必须只读,不得修改 context(以免污染下一模型输入)。
    """
    ticker: str
    as_of: datetime
    horizon_days: int
    profile: CompanyProfile
    financials: Financials
    price_history: pd.DataFrame
    benchmark_history: pd.DataFrame
    peer_financials: dict[str, Financials] = field(default_factory=dict)
    peer_price_history: dict[str, pd.DataFrame] = field(default_factory=dict)
    peer_profiles: dict[str, CompanyProfile] = field(default_factory=dict)
    # Phase 5:宏观 proxy 价格(orchestrator 提前拉,MacroModel 从这里读)
    #   e.g. {"^TNX": df, "^IRX": df, "HYG": df, "LQD": df, "UUP": df}
    macro_prices: dict[str, pd.DataFrame] = field(default_factory=dict)
    # Phase 5:SEC EDGAR 数据(Information Model 消费)
    sec_submissions: dict = field(default_factory=dict)  # {"cik": ..., "filings": [...]}
    insider_transactions: list[dict] = field(default_factory=list)  # Form 4 汇总
    # 待接入的数据源
    macro_snapshot: dict = field(default_factory=dict)
    filings: list[dict] = field(default_factory=list)
    news: list[dict] = field(default_factory=list)


class ExpertModel(ABC):
    """所有专家模型的抽象基类。子类必须实现 analyze()。"""

    name: str = "base"
    version: str = "0.1.0"
    default_horizon_days: int = 63  # 约 3 个月

    def __init__(self, horizon_days: Optional[int] = None):
        self.horizon_days = horizon_days or self.default_horizon_days

    @abstractmethod
    def analyze(self, ctx: AnalysisContext) -> ModelOutput:
        """给定 raw context,输出一个 ModelOutput。禁止访问其他模型输出。"""

    # --- 子类可用的工具方法 ---

    def _empty_output(self, ctx: AnalysisContext, reason: str) -> ModelOutput:
        """模型放弃判断时(数据不足、异常)的标准输出。"""
        return ModelOutput(
            model_name=self.name,
            model_version=self.version,
            asset=ctx.ticker,
            as_of=ctx.as_of,
            horizon_days=self.horizon_days,
            signal_score=None,
            confidence=0.0,
            data_quality=0.0,
            metadata={"reason_no_signal": reason},
        )

    def _new_output(self, ctx: AnalysisContext) -> ModelOutput:
        return ModelOutput(
            model_name=self.name,
            model_version=self.version,
            asset=ctx.ticker,
            as_of=ctx.as_of,
            horizon_days=self.horizon_days,
        )

    @staticmethod
    def _clamp(v: float, lo: float = -1.0, hi: float = 1.0) -> float:
        return max(lo, min(hi, v))


def now_utc() -> datetime:
    return datetime.now(tz=timezone.utc)
