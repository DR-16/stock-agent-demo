"""Calibrator — 把 raw probability 映射到 calibrated。

Phase 4 提供 3 种:
  IdentityCalibrator  — 默认(未训练时 = 直通)
  BinCalibrator       — 直方图 + 单调化 → 无参数,鲁棒,少样本可用
  PlattCalibrator     — logistic 拟合(手写 gradient descent,不依赖 sklearn)

Provenance(Phase 4 v3):每个 Calibrator 记录
  * fitted_at:训练完成时点(UTC datetime)
  * training_sample_size:训练用样本数
  * training_cutoff:训练数据的最新 as_of(以后任何 prediction 的 as_of 必须严格 > cutoff)
"""
from __future__ import annotations

import math
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Optional

import numpy as np


class Calibrator(ABC):
    version: str = "abstract"

    def __init__(self):
        self.fitted_at: Optional[datetime] = None
        self.training_sample_size: Optional[int] = None
        self.training_cutoff: Optional[datetime] = None

    @abstractmethod
    def calibrate(self, raw_probability: float) -> float:
        """raw → calibrated,∈ [0, 1]。"""

    @abstractmethod
    def fit(self, raw_probs: list[float], realized_positive: list[bool],
            training_cutoff: Optional[datetime] = None) -> None:
        """训练。同一 calibrator 反复 fit 会覆盖。training_cutoff 是训练数据最新 as_of。"""

    @property
    @abstractmethod
    def is_fitted(self) -> bool:
        ...

    def _record_provenance(self, n_samples: int,
                           training_cutoff: Optional[datetime] = None) -> None:
        self.fitted_at = datetime.now(tz=timezone.utc)
        self.training_sample_size = n_samples
        self.training_cutoff = training_cutoff

    def to_dict(self) -> dict:
        return {
            "version": self.version,
            "is_fitted": self.is_fitted,
            "fitted_at": self.fitted_at.isoformat() if self.fitted_at else None,
            "training_sample_size": self.training_sample_size,
            "training_cutoff": (self.training_cutoff.isoformat()
                                if self.training_cutoff else None),
        }


class IdentityCalibrator(Calibrator):
    version = "identity-1"

    def calibrate(self, raw_probability):
        return float(_clip01(raw_probability))

    def fit(self, raw_probs, realized_positive, training_cutoff=None):
        # Identity 不需要 fit,但仍记录 provenance(reproducibility)
        self._record_provenance(len(raw_probs), training_cutoff)

    @property
    def is_fitted(self):
        # Identity 恒等于"已就绪";但 fitted_at 反映是否显式 fit 过
        return True


class BinCalibrator(Calibrator):
    """Histogram + monotonic bin calibrator。

    fit:把 raw probs 按 quantile 分 n bins,每 bin 记录 empirical positive rate
        (对 rate 序列做 monotonic isotonic-like 平滑,保证单调不减)
    predict:线性插值。
    """
    version = "bin-1"

    def __init__(self, n_bins: int = 10, min_samples: int = 30):
        super().__init__()
        self.n_bins = n_bins
        self.min_samples = min_samples
        self._bins: list[tuple[float, float]] = []  # (raw_center, calibrated_rate)
        self._fitted = False

    def calibrate(self, raw_probability):
        raw = _clip01(raw_probability)
        if not self._fitted or not self._bins:
            return float(raw)
        # 找最近的两个 bin 做线性插值
        xs = [b[0] for b in self._bins]
        ys = [b[1] for b in self._bins]
        if raw <= xs[0]:
            return float(ys[0])
        if raw >= xs[-1]:
            return float(ys[-1])
        for i in range(len(xs) - 1):
            if xs[i] <= raw <= xs[i + 1]:
                dx = xs[i + 1] - xs[i]
                if dx == 0:
                    return float(ys[i])
                t = (raw - xs[i]) / dx
                return float(ys[i] * (1 - t) + ys[i + 1] * t)
        return float(raw)

    def fit(self, raw_probs, realized_positive, training_cutoff=None):
        if len(raw_probs) < self.min_samples:
            raise ValueError(
                f"BinCalibrator 需要至少 {self.min_samples} 条样本,got {len(raw_probs)}"
            )
        if len(raw_probs) != len(realized_positive):
            raise ValueError("raw_probs and realized_positive length mismatch")

        p = np.asarray(raw_probs, dtype=float)
        y = np.asarray([1.0 if v else 0.0 for v in realized_positive])
        self._record_provenance(len(raw_probs), training_cutoff)

        # 按 quantile 分 bin(避免空 bin)
        try:
            quantiles = np.quantile(p, np.linspace(0, 1, self.n_bins + 1))
            quantiles = np.unique(quantiles)  # 去重防退化
        except Exception:
            quantiles = np.linspace(0, 1, self.n_bins + 1)
        if len(quantiles) < 2:
            self._bins = [(0.5, float(y.mean()))]
            self._fitted = True
            return

        bins_raw: list[tuple[float, float]] = []
        for i in range(len(quantiles) - 1):
            lo, hi = quantiles[i], quantiles[i + 1]
            mask = (p >= lo) & (p <= hi if i == len(quantiles) - 2 else p < hi)
            if mask.sum() < 2:
                continue
            bins_raw.append((float(p[mask].mean()), float(y[mask].mean())))

        # 单调化(PAVA 简版):合并递减相邻 bin
        smoothed = _monotone_smooth(bins_raw)
        # 保证首尾扩到 [0, 1]
        if smoothed[0][0] > 0.0:
            smoothed = [(0.0, smoothed[0][1])] + smoothed
        if smoothed[-1][0] < 1.0:
            smoothed = smoothed + [(1.0, smoothed[-1][1])]
        self._bins = smoothed
        self._fitted = True

    @property
    def is_fitted(self):
        return self._fitted

    def to_dict(self):
        d = super().to_dict()
        d["n_bins"] = self.n_bins
        d["bins"] = self._bins
        return d


class PlattCalibrator(Calibrator):
    """logistic sigmoid(a * logit(raw) + b),手写 gradient descent。

    Platt scaling:calibrated = sigmoid(a*x + b),其中 x = logit(raw)。
    """
    version = "platt-1"

    def __init__(self, learning_rate: float = 0.05, epochs: int = 500,
                 min_samples: int = 30):
        super().__init__()
        self.lr = learning_rate
        self.epochs = epochs
        self.min_samples = min_samples
        self._a = 1.0
        self._b = 0.0
        self._fitted = False

    def calibrate(self, raw_probability):
        raw = _clip01(raw_probability)
        if not self._fitted:
            return float(raw)
        x = _logit(raw)
        return float(_sigmoid(self._a * x + self._b))

    def fit(self, raw_probs, realized_positive, training_cutoff=None):
        if len(raw_probs) < self.min_samples:
            raise ValueError(
                f"PlattCalibrator 需要至少 {self.min_samples} 条样本,got {len(raw_probs)}"
            )
        if len(raw_probs) != len(realized_positive):
            raise ValueError("length mismatch")
        self._record_provenance(len(raw_probs), training_cutoff)
        x = np.array([_logit(_clip01(p)) for p in raw_probs])
        y = np.array([1.0 if v else 0.0 for v in realized_positive])

        a, b = 1.0, 0.0
        for _ in range(self.epochs):
            z = a * x + b
            p = 1.0 / (1.0 + np.exp(-np.clip(z, -30, 30)))
            grad_a = float(((p - y) * x).mean())
            grad_b = float((p - y).mean())
            a -= self.lr * grad_a
            b -= self.lr * grad_b
        self._a = float(a)
        self._b = float(b)
        self._fitted = True

    @property
    def is_fitted(self):
        return self._fitted

    def to_dict(self):
        d = super().to_dict()
        d["a"] = self._a
        d["b"] = self._b
        return d


# -------- fit_from_backtest --------


def fit_calibrator_from_backtest(calibrator: Calibrator,
                                 backtest_runs: list,
                                 sigmoid_k: float = 2.5) -> Calibrator:
    """从 walk-forward BacktestRun 中抽取 signal → prob,fit calibrator。

    spec #5:训练数据必须来自 walk-forward OOS。这里不接受任何 live ledger 输入。
    signal → raw_prob 转换用与 Meta 相同的 sigmoid(k=2.5)。
    provenance:training_cutoff = 训练样本里最大 as_of_date。
    """
    raw_probs = []
    outcomes = []
    max_asof = None
    for run in backtest_runs:
        for p in run.points:
            if p.signal_score is None or p.realized_return is None:
                continue
            raw_p = 1.0 / (1.0 + math.exp(-sigmoid_k * p.signal_score))
            raw_probs.append(raw_p)
            outcomes.append(bool(p.realized_return > 0))
            if p.as_of_date is not None:
                if max_asof is None or p.as_of_date > max_asof:
                    max_asof = p.as_of_date
    if not raw_probs:
        raise ValueError("no valid (signal, outcome) pairs in backtest_runs")
    cutoff = None
    if max_asof is not None:
        from datetime import datetime, timezone, date as _date
        if isinstance(max_asof, _date) and not isinstance(max_asof, datetime):
            cutoff = datetime(max_asof.year, max_asof.month, max_asof.day, tzinfo=timezone.utc)
        else:
            cutoff = max_asof
    calibrator.fit(raw_probs, outcomes, training_cutoff=cutoff)
    return calibrator


# -------- helpers --------


def _clip01(x) -> float:
    if x is None:
        return 0.5
    try:
        x = float(x)
    except (TypeError, ValueError):
        return 0.5
    if math.isnan(x):
        return 0.5
    return max(0.0, min(1.0, x))


def _sigmoid(z):
    return 1.0 / (1.0 + math.exp(-max(min(z, 50), -50)))


def _logit(p):
    p = _clip01(p)
    p = min(max(p, 1e-6), 1 - 1e-6)
    return math.log(p / (1 - p))


def _monotone_smooth(bins: list[tuple[float, float]]) -> list[tuple[float, float]]:
    """PAVA-lite:相邻 bin 若 y 递减,合并到前一段共同 y = 加权均值。"""
    if not bins:
        return []
    xs = [b[0] for b in bins]
    ys = [b[1] for b in bins]
    ws = [1] * len(bins)
    i = 0
    while i < len(ys) - 1:
        if ys[i] > ys[i + 1]:
            new_y = (ys[i] * ws[i] + ys[i + 1] * ws[i + 1]) / (ws[i] + ws[i + 1])
            new_w = ws[i] + ws[i + 1]
            new_x = (xs[i] * ws[i] + xs[i + 1] * ws[i + 1]) / new_w
            ys[i] = new_y
            xs[i] = new_x
            ws[i] = new_w
            del ys[i + 1]
            del xs[i + 1]
            del ws[i + 1]
            i = max(0, i - 1)
        else:
            i += 1
    return list(zip(xs, ys))
